import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  calculateAppRate,
  parseBitazzaAdjustmentPercent,
  parseBitazzaLastPrice,
} from "../src/lib/bitazza-rate.ts";

describe("Bitazza USDT/THB rate", () => {
  const now = Date.UTC(2026, 9, 24, 7, 0);

  it("uses the last-traded price and applies signed decimal percentages", () => {
    const marketPrice = parseBitazzaLastPrice(
      { LastTradedPx: "33.75", LastTradeTime: now - 60_000 },
      now,
    );
    assert.equal(marketPrice, 33.75);
    assert.equal(calculateAppRate(marketPrice), 32.7375);
    assert.equal(calculateAppRate(marketPrice, -3.5), 32.56875);
    assert.equal(calculateAppRate(marketPrice, 2.2), 34.4925);
    assert.equal(calculateAppRate(marketPrice, 0), marketPrice);
    assert.equal(calculateAppRate(marketPrice, -5), 32.0625);
    assert.equal(calculateAppRate(marketPrice, 5), 35.4375);
  });

  it("defaults to minus three percent and rejects adjustments outside five percent", () => {
    assert.equal(parseBitazzaAdjustmentPercent(undefined), -3);
    assert.equal(parseBitazzaAdjustmentPercent("2.2"), 2.2);
    assert.throws(() => parseBitazzaAdjustmentPercent(-5.1));
    assert.throws(() => parseBitazzaAdjustmentPercent(5.1));
    assert.throws(() => parseBitazzaAdjustmentPercent(Number.NaN));
  });

  it("rejects missing, invalid, future, or over-24-hour-old trades", () => {
    assert.throws(() => parseBitazzaLastPrice(null, now));
    assert.throws(
      () => parseBitazzaLastPrice({ LastTradedPx: 0, LastTradeTime: now }, now),
    );
    assert.throws(
      () =>
        parseBitazzaLastPrice(
          { LastTradedPx: 33.75, LastTradeTime: now + 120_000 },
          now,
        ),
    );
    assert.throws(
      () =>
        parseBitazzaLastPrice(
          {
            LastTradedPx: 33.75,
            LastTradeTime: now - 24 * 60 * 60 * 1000 - 1,
          },
          now,
        ),
    );
  });
});
