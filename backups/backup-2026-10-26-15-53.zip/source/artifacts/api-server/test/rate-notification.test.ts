import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  isRateNotificationCooldownActive,
  isRateNotificationQuietHours,
} from "../src/lib/rate-notification.ts";

describe("rate notification quiet hours", () => {
  it("suppresses notices from midnight until just before 08:00 Vietnam time", () => {
    assert.equal(
      isRateNotificationQuietHours(new Date("2026-10-24T17:00:00.000Z")),
      true,
    );
    assert.equal(
      isRateNotificationQuietHours(new Date("2026-10-25T00:59:00.000Z")),
      true,
    );
    assert.equal(
      isRateNotificationQuietHours(new Date("2026-10-25T00:59:59.999Z")),
      true,
    );
  });

  it("allows notices before midnight and from exactly 08:00 Vietnam time", () => {
    assert.equal(
      isRateNotificationQuietHours(new Date("2026-10-24T16:59:00.000Z")),
      false,
    );
    assert.equal(
      isRateNotificationQuietHours(new Date("2026-10-25T01:00:00.000Z")),
      false,
    );
  });
});

describe("rate notification hourly limit", () => {
  const now = new Date("2026-10-25T12:00:00.000Z");

  it("blocks another notice for 60 minutes after the last broadcast claim", () => {
    assert.equal(
      isRateNotificationCooldownActive("2026-10-25T11:00:01.000Z", now),
      true,
    );
    assert.equal(
      isRateNotificationCooldownActive("2026-10-25T11:30:00.000Z", now),
      true,
    );
    assert.equal(
      isRateNotificationCooldownActive("2026-10-25T11:00:00.000Z", now),
      false,
    );
  });

  it("allows the first notice and ignores an invalid saved timestamp", () => {
    assert.equal(isRateNotificationCooldownActive(null, now), false);
    assert.equal(isRateNotificationCooldownActive("not-a-date", now), false);
  });
});
