import { and, eq, ne, sql } from "drizzle-orm";
import { db, settingsTable, usersTable } from "@workspace/db";
import {
  getTelegramChatId,
  sendRateTelegramMessageDetailed,
  sendTelegramMessageDetailed,
} from "./telegram";
import { logger } from "./logger";

const SEND_GAP_MS = 50;
const RATE_NOTIFICATION_COOLDOWN_MS = 60 * 60 * 1000;
const RATE_NOTIFICATION_TIME_ZONE = "Asia/Ho_Chi_Minh";
const RATE_NOTIFICATION_LAST_CLAIM_KEY = "rate_notification_last_claimed_at";
const RATE_NOTIFICATION_LOCK_NAME = "anderspay:rate-notification-cooldown";
const RATE_NOTIFICATION_HOUR = new Intl.DateTimeFormat("en-GB", {
  timeZone: RATE_NOTIFICATION_TIME_ZONE,
  hour: "2-digit",
  hourCycle: "h23",
});
let rateNotifyInFlight = false;

export function isRateNotificationQuietHours(at = new Date()): boolean {
  return Number(RATE_NOTIFICATION_HOUR.format(at)) < 8;
}

export function isRateNotificationCooldownActive(
  lastClaimAt: string | null | undefined,
  now = new Date(),
): boolean {
  if (!lastClaimAt) return false;
  const lastClaimAtMs = Date.parse(lastClaimAt);
  return (
    Number.isFinite(lastClaimAtMs) &&
    now.getTime() - lastClaimAtMs < RATE_NOTIFICATION_COOLDOWN_MS
  );
}

async function claimRateNotificationCooldown(): Promise<boolean> {
  return db.transaction(async (tx) => {
    await tx.execute(
      sql`SELECT pg_advisory_xact_lock(hashtextextended(${RATE_NOTIFICATION_LOCK_NAME}, 0))`,
    );
    const [lastClaim] = await tx
      .select({ value: settingsTable.value })
      .from(settingsTable)
      .where(eq(settingsTable.key, RATE_NOTIFICATION_LAST_CLAIM_KEY))
      .limit(1);
    const now = new Date();
    if (isRateNotificationCooldownActive(lastClaim?.value, now)) {
      return false;
    }

    await tx
      .insert(settingsTable)
      .values({
        key: RATE_NOTIFICATION_LAST_CLAIM_KEY,
        value: now.toISOString(),
        updatedAt: now,
      })
      .onConflictDoUpdate({
        target: settingsTable.key,
        set: { value: now.toISOString(), updatedAt: now },
      });
    return true;
  });
}

export function notifyRateChange(params: {
  oldRate: number;
  newRate: number;
  triggeredByUserId?: string;
}): void {
  if (isRateNotificationQuietHours()) {
    logger.info(
      { timeZone: RATE_NOTIFICATION_TIME_ZONE },
      "[rates] Telegram rate notification suppressed during quiet hours",
    );
    return;
  }

  if (rateNotifyInFlight) {
    logger.warn("[rates] Telegram rate notification skipped; another broadcast is running");
    return;
  }

  rateNotifyInFlight = true;
  setImmediate(() => {
    void (async () => {
      try {
        const linkedTelegramUsers = sql`(${usersTable.telegramChatId} IS NOT NULL OR ${usersTable.telegramId} IS NOT NULL)`;
        const recipientFilter = params.triggeredByUserId
          ? and(
              linkedTelegramUsers,
              ne(usersTable.id, params.triggeredByUserId),
            )
          : linkedTelegramUsers;
        const recipients = await db
          .select({
            id: usersTable.id,
            telegramChatId: usersTable.telegramChatId,
            telegramId: usersTable.telegramId,
          })
          .from(usersTable)
          .where(recipientFilter);

        if (isRateNotificationQuietHours()) {
          logger.info(
            { timeZone: RATE_NOTIFICATION_TIME_ZONE },
            "[rates] Telegram rate notification suppressed during quiet hours",
          );
          return;
        }

        const cooldownClaimed = await claimRateNotificationCooldown();
        if (!cooldownClaimed) {
          logger.info(
            { cooldownMinutes: 60 },
            "[rates] Telegram rate notification skipped; hourly limit is active",
          );
          return;
        }

        if (isRateNotificationQuietHours()) {
          logger.info(
            { timeZone: RATE_NOTIFICATION_TIME_ZONE },
            "[rates] Telegram rate notification suppressed during quiet hours",
          );
          return;
        }

        const diff = params.newRate - params.oldRate;
        const arrow = diff > 0 ? "📈" : diff < 0 ? "📉" : "➖";
        const diffStr =
          diff === 0
            ? ""
            : ` (${diff > 0 ? "+" : ""}${diff.toFixed(2)} THB)`;
        const updatedAt = new Date().toLocaleString("vi-VN", {
          timeZone: "Asia/Bangkok",
          hour12: false,
        });

        const message =
          `${arrow} <b>Tỷ giá USDT/THB mới</b>\n\n` +
          `1 USDT = <b>${params.newRate.toFixed(2)} THB</b>${diffStr}\n` +
          `Tỷ giá cũ: ${params.oldRate.toFixed(2)} THB\n` +
          `Cập nhật: ${updatedAt} (ICT)`;

        const rateGroupMessage =
          `${message}\n\n` +
          `— —\n` +
          `💸 <b>AndersPay+</b> — ví điện tử thanh toán Baht Thái như ngân hàng Thái Lan.\n` +
          `📲 Tải app: <a href="https://anderspay.com">anderspay.com</a>`;

        const groupResult =
          await sendRateTelegramMessageDetailed(rateGroupMessage);
        if (!groupResult.ok && groupResult.reason !== "no_chat") {
          logger.warn(
            { reason: groupResult.reason, description: groupResult.description },
            "[rates] exchange-rate group notify failed",
          );
        }

        let okCount = 0;
        let failCount = 0;
        for (let index = 0; index < recipients.length; index++) {
          if (isRateNotificationQuietHours()) {
            logger.info(
              {
                timeZone: RATE_NOTIFICATION_TIME_ZONE,
                remainingRecipients: recipients.length - index,
              },
              "[rates] Telegram rate notification stopped at quiet hours",
            );
            break;
          }
          const recipient = recipients[index]!;
          const chatId = getTelegramChatId(recipient);
          if (!chatId) continue;
          const result = await sendTelegramMessageDetailed(message, chatId);
          if (result.ok) {
            okCount++;
          } else {
            failCount++;
            logger.warn(
              {
                userId: recipient.id,
                reason: result.reason,
                description: result.description,
              },
              "[rates] telegram notify failed",
            );
          }
          await new Promise((resolve) => setTimeout(resolve, SEND_GAP_MS));
        }

        logger.info(
          {
            total: recipients.length,
            okCount,
            failCount,
            oldRate: params.oldRate,
            newRate: params.newRate,
          },
          "rate_change_broadcast",
        );
      } catch (err) {
        logger.error({ err }, "[rates] notifyRateChange failed");
      } finally {
        rateNotifyInFlight = false;
      }
    })();
  });
}
