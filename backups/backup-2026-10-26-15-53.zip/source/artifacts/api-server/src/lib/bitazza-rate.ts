import { db, rateHistoryTable, settingsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { logger } from "./logger";
import { notifyRateChange } from "./rate-notification";

const BITAZZA_API = "https://apexapi.bitazza.co.th/ap";
const OMS_ID = 1;
const REFRESH_INTERVAL_MS = 30 * 60 * 1000;
const MAX_TRADE_AGE_MS = 24 * 60 * 60 * 1000;
const RATE_KEY = "thb_usdt_rate";
export const BITAZZA_ADJUSTMENT_KEY = "bitazza_rate_adjustment_percent";
export const BITAZZA_SOURCE_PRICE_KEY = "bitazza_source_price";
export const BITAZZA_SOURCE_UPDATED_AT_KEY = "bitazza_source_updated_at";
export const DEFAULT_BITAZZA_ADJUSTMENT_PERCENT = -3;
export const BITAZZA_RATE_LOCK_NAME = "anderspay:bitazza-usdt-thb-rate";

export type BitazzaAdjustmentPercent = number;

export function parseBitazzaAdjustmentPercent(
  value: unknown,
): BitazzaAdjustmentPercent {
  if (value === undefined || value === null || value === "") {
    return DEFAULT_BITAZZA_ADJUSTMENT_PERCENT;
  }
  const percent = Number(value);
  if (Number.isFinite(percent) && percent >= -5 && percent <= 5) {
    return percent;
  }
  throw new Error("Bitazza adjustment must be between -5% and +5%");
}

type BitazzaInstrument = {
  InstrumentId?: number;
  OMSId?: number;
  Symbol?: string;
  SessionStatus?: string;
};

type BitazzaLevel1 = {
  LastTradedPx?: number | string;
  LastTradeTime?: number | string;
};

async function getJson(url: string): Promise<unknown> {
  const response = await fetch(url, {
    headers: { Accept: "application/json" },
    signal: AbortSignal.timeout(10_000),
  });
  if (!response.ok) {
    throw new Error(`Bitazza market data returned HTTP ${response.status}`);
  }
  return response.json();
}

export function parseBitazzaLastPrice(
  value: unknown,
  nowMs = Date.now(),
): number {
  if (typeof value !== "object" || value === null) {
    throw new Error("Bitazza returned an invalid ticker");
  }

  const ticker = value as BitazzaLevel1;
  const price = Number(ticker.LastTradedPx);
  const tradeTime = Number(ticker.LastTradeTime);
  if (!Number.isFinite(price) || price <= 0) {
    throw new Error("Bitazza ticker has no valid last-traded price");
  }
  if (
    !Number.isFinite(tradeTime) ||
    tradeTime <= 0 ||
    tradeTime > nowMs + 60_000 ||
    nowMs - tradeTime > MAX_TRADE_AGE_MS
  ) {
    throw new Error("Bitazza last-trade timestamp is stale or invalid");
  }
  return price;
}

export function calculateAppRate(
  lastTradedPrice: number,
  adjustmentPercent: unknown = DEFAULT_BITAZZA_ADJUSTMENT_PERCENT,
): number {
  if (!Number.isFinite(lastTradedPrice) || lastTradedPrice <= 0) {
    throw new Error("Cannot calculate a rate from an invalid Bitazza price");
  }
  const adjustment = parseBitazzaAdjustmentPercent(adjustmentPercent);
  return Number((lastTradedPrice * (1 + adjustment / 100)).toFixed(6));
}

async function getLatestBitazzaLastPrice(): Promise<number> {
  const instrumentsUrl = new URL(`${BITAZZA_API}/GetInstruments`);
  instrumentsUrl.searchParams.set("OMSId", String(OMS_ID));
  const instruments = await getJson(instrumentsUrl.toString());
  if (!Array.isArray(instruments)) {
    throw new Error("Bitazza returned an invalid instrument list");
  }

  const instrument = (instruments as BitazzaInstrument[]).find(
    (item) =>
      item.Symbol === "USDTTHB" &&
      (item.OMSId === undefined || item.OMSId === OMS_ID),
  );
  if (!instrument || !Number.isInteger(instrument.InstrumentId)) {
    throw new Error("Bitazza USDT/THB instrument is unavailable");
  }
  if (instrument.SessionStatus !== "Running") {
    throw new Error("Bitazza USDT/THB market is not running");
  }

  const tickerUrl = new URL(`${BITAZZA_API}/GetLevel1`);
  tickerUrl.searchParams.set("InstrumentId", String(instrument.InstrumentId));
  tickerUrl.searchParams.set("OMSId", String(OMS_ID));
  const ticker = await getJson(tickerUrl.toString());
  return parseBitazzaLastPrice(ticker);
}

export async function refreshBitazzaRate(
  options: { notifyOnChange?: boolean } = {},
): Promise<boolean> {
  const result = await db.transaction(async (tx) => {
    // The transaction-scoped lock prevents multiple API instances
    // from polling the exchange and writing the rate at the same time.
    const lock = await tx.execute(
      sql`SELECT pg_try_advisory_xact_lock(hashtextextended(${BITAZZA_RATE_LOCK_NAME}, 0)) AS acquired`,
    );
    if (!lock.rows[0]?.acquired) return null;

    const [adjustmentSetting] = await tx
      .select({ value: settingsTable.value })
      .from(settingsTable)
      .where(eq(settingsTable.key, BITAZZA_ADJUSTMENT_KEY))
      .limit(1);
    const adjustmentPercent = parseBitazzaAdjustmentPercent(
      adjustmentSetting?.value,
    );

    // Fetch while holding the lock. A failure rolls back without touching
    // settings, so the last known-good rate remains active.
    const marketPrice = await getLatestBitazzaLastPrice();
    const rate = calculateAppRate(marketPrice, adjustmentPercent);
    const updatedAt = new Date();
    const [previous] = await tx
      .select({ value: settingsTable.value })
      .from(settingsTable)
      .where(eq(settingsTable.key, RATE_KEY))
      .limit(1);

    await tx
      .insert(settingsTable)
      .values({ key: RATE_KEY, value: String(rate), updatedAt })
      .onConflictDoUpdate({
        target: settingsTable.key,
        set: { value: String(rate), updatedAt },
      });

    for (const [key, value] of [
      [BITAZZA_SOURCE_PRICE_KEY, String(marketPrice)],
      [BITAZZA_SOURCE_UPDATED_AT_KEY, updatedAt.toISOString()],
    ]) {
      await tx
        .insert(settingsTable)
        .values({ key, value, updatedAt })
        .onConflictDoUpdate({
          target: settingsTable.key,
          set: { value, updatedAt },
        });
    }

    const previousRate = previous ? Number(previous.value) : null;
    const changed =
      previousRate === null ||
      !Number.isFinite(previousRate) ||
      Math.abs(previousRate - rate) > 1e-9;
    const shouldNotify =
      previousRate !== null &&
      Number.isFinite(previousRate) &&
      Math.abs(previousRate - rate) > 1e-9;
    if (changed) {
      await tx.insert(rateHistoryTable).values({ rate: String(rate) });
    }
    return {
      marketPrice,
      rate,
      adjustmentPercent,
      changed,
      previousRate,
      shouldNotify,
      updatedAt,
    };
  });

  if (!result) {
    logger.debug("[rates] Bitazza refresh skipped; another instance holds the lock");
    return false;
  }
  if (
    options.notifyOnChange &&
    result.shouldNotify &&
    result.previousRate !== null
  ) {
    notifyRateChange({
      oldRate: result.previousRate,
      newRate: result.rate,
    });
  }
  logger.info(
    {
      marketPrice: result.marketPrice,
      thbPerUsdt: result.rate,
      adjustmentPercent: result.adjustmentPercent,
      changed: result.changed,
      updatedAt: result.updatedAt.toISOString(),
    },
    "[rates] Bitazza market rate refreshed",
  );
  return true;
}

export function startBitazzaRateScheduler(
  options: { notifyOnChange?: boolean } = {},
): void {
  const run = async (source: "startup" | "half-hour") => {
    try {
      await refreshBitazzaRate(options);
    } catch (err) {
      // Keep the last known-good rate if Bitazza is unavailable.
      logger.error({ err, source }, "[rates] Bitazza refresh failed; keeping the last known-good rate");
    }
  };

  void run("startup");
  const delayToNextRefresh =
    REFRESH_INTERVAL_MS - (Date.now() % REFRESH_INTERVAL_MS);
  setTimeout(() => {
    void run("half-hour");
    setInterval(() => void run("half-hour"), REFRESH_INTERVAL_MS);
  }, delayToNextRefresh);
  logger.info(
    { firstRefreshInMs: delayToNextRefresh, intervalMs: REFRESH_INTERVAL_MS },
    "[rates] Bitazza 30-minute scheduler started",
  );
}
