import { Router } from "express";
import { db, settingsTable, usersTable, rateHistoryTable } from "@workspace/db";
import { eq, and, gte, lt, desc, asc, sql } from "drizzle-orm";
import {
  GetRateAdjustmentResponse,
  SetExchangeRateBody,
  SetRateAdjustmentBody,
  SetRateAdjustmentResponse,
} from "@workspace/api-zod";
import { z } from "zod";
import { authenticateRequest } from "../lib/jwt";
import { isAdminUser } from "../lib/admin";
import { logger } from "../lib/logger";
import { notifyRateChange } from "../lib/rate-notification";
import {
  BITAZZA_ADJUSTMENT_KEY,
  BITAZZA_RATE_LOCK_NAME,
  BITAZZA_SOURCE_PRICE_KEY,
  BITAZZA_SOURCE_UPDATED_AT_KEY,
  parseBitazzaAdjustmentPercent,
  refreshBitazzaRate,
} from "../lib/bitazza-rate";

const router = Router();

const RATE_KEY = "thb_usdt_rate";
const DEFAULT_RATE = 35.5;

async function getBitazzaSourceMetadata(): Promise<{
  bitazzaPrice: number | null;
  sourceUpdatedAt: Date | null;
}> {
  const rows = await db
    .select({ key: settingsTable.key, value: settingsTable.value })
    .from(settingsTable)
    .where(
      sql`${settingsTable.key} IN (${BITAZZA_SOURCE_PRICE_KEY}, ${BITAZZA_SOURCE_UPDATED_AT_KEY})`,
    );
  const settings = new Map(rows.map(({ key, value }) => [key, value]));
  const price = Number(settings.get(BITAZZA_SOURCE_PRICE_KEY));
  const updatedAtValue = settings.get(BITAZZA_SOURCE_UPDATED_AT_KEY);
  const updatedAt = updatedAtValue ? new Date(updatedAtValue) : null;

  return {
    bitazzaPrice: Number.isFinite(price) && price > 0 ? price : null,
    sourceUpdatedAt:
      updatedAt && Number.isFinite(updatedAt.getTime()) ? updatedAt : null,
  };
}

// ─── Public rate cache (5 s TTL) ─────────────────────────────────────────────
const ALLOWED_ORIGINS = new Set([
  "https://chovietthai.com",
  "https://www.chovietthai.com",
]);
let _rateCache: { usdt_thb: number; updatedAt: string } | null = null;
let _rateCacheAt = 0;
const CACHE_TTL_MS = 5_000;

// GET /rates — public, CORS-restricted, cached 5 s.
// Returns the current THB/USDT rate exactly as stored by the admin.
// 503 when no rate row exists in the database yet.
router.get("/rates", async (req, res) => {
  // CORS — only the two allowed origins get the header.
  const origin = req.headers.origin ?? "";
  if (ALLOWED_ORIGINS.has(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
  }
  res.setHeader("Access-Control-Allow-Methods", "GET");
  res.setHeader("Cache-Control", "public, max-age=5");

  // Serve from cache when fresh.
  if (_rateCache && Date.now() - _rateCacheAt < CACHE_TTL_MS) {
    res.json({ success: true, rates: _rateCache });
    return;
  }

  const [row] = await db
    .select()
    .from(settingsTable)
    .where(eq(settingsTable.key, RATE_KEY))
    .limit(1);

  if (!row) {
    res.status(503).json({ success: false, message: "Rate unavailable" });
    return;
  }

  _rateCache = {
    usdt_thb: parseFloat(row.value),
    updatedAt: row.updatedAt.toISOString(),
  };
  _rateCacheAt = Date.now();

  res.json({ success: true, rates: _rateCache });
});

export async function getCurrentRate(): Promise<{ thbPerUsdt: number; updatedAt: Date }> {
  const [row] = await db
    .select()
    .from(settingsTable)
    .where(eq(settingsTable.key, RATE_KEY))
    .limit(1);

  if (!row) {
    return { thbPerUsdt: DEFAULT_RATE, updatedAt: new Date() };
  }

  return {
    thbPerUsdt: parseFloat(row.value),
    updatedAt: row.updatedAt,
  };
}

// GET /rates/thb-usdt
router.get("/rates/thb-usdt", async (req, res) => {
  const rate = await getCurrentRate();
  res.json({
    thbPerUsdt: rate.thbPerUsdt,
    updatedAt: rate.updatedAt.toISOString(),
  });
});

// POST /rates/thb-usdt — admin sets daily rate.
// Authorization is derived strictly from a verified JWT bearer; the legacy
// `adminPhone` body field is accepted for backwards-compat only and is
// ignored for access decisions. An attacker cannot forge admin identity by
// supplying any phone in the request body.
router.post("/rates/thb-usdt", async (req, res) => {
  const parsed = SetExchangeRateBody.extend({ adminPhone: z.string().optional() }).safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid rate value", code: "VALIDATION_ERROR" });
    return;
  }

  const jwtPayload = await authenticateRequest(req);
  if (!jwtPayload) {
    res.status(401).json({ message: "unauthorized", code: "UNAUTHORIZED" });
    return;
  }
  const [me] = await db
    .select({ id: usersTable.id, phone: usersTable.phone, isAdmin: usersTable.isAdmin })
    .from(usersTable)
    .where(eq(usersTable.id, jwtPayload.userId))
    .limit(1);
  if (!me || !isAdminUser(me)) {
    res.status(403).json({ message: "Forbidden: admin only", code: "FORBIDDEN" });
    return;
  }

  const { thbPerUsdt } = parsed.data;

  // Capture the previous rate so the broadcast message can show the
  // delta. `getCurrentRate()` returns the default when the row is
  // missing, which is fine for the very first update.
  const previous = await getCurrentRate();

  await db
    .insert(settingsTable)
    .values({ key: RATE_KEY, value: String(thbPerUsdt), updatedAt: new Date() })
    .onConflictDoUpdate({
      target: settingsTable.key,
      set: { value: String(thbPerUsdt), updatedAt: new Date() },
    });

  // Append to the rate history log so the home-screen candlestick chart
  // has a data point. Only log actual changes to keep the series clean.
  if (Math.abs(previous.thbPerUsdt - thbPerUsdt) > 1e-9) {
    try {
      await db.insert(rateHistoryTable).values({ rate: String(thbPerUsdt) });
    } catch (err) {
      logger.warn({ err }, "[rates] failed to append rate history");
    }
  }

  // Fire-and-forget Telegram fan-out so the HTTP response isn't blocked
  // on potentially hundreds of bot API calls. Only notifies on an
  // actual change — re-saving the same value is silent (avoids spam
  // from accidental double-submits).
  if (Math.abs(previous.thbPerUsdt - thbPerUsdt) > 1e-9) {
    notifyRateChange({
      oldRate: previous.thbPerUsdt,
      newRate: thbPerUsdt,
      triggeredByUserId: me.id,
    });
  }

  res.json({
    thbPerUsdt,
    updatedAt: new Date().toISOString(),
  });
});

router.get("/rates/thb-usdt/adjustment", async (req, res): Promise<void> => {
  const [setting] = await db
    .select({ value: settingsTable.value })
    .from(settingsTable)
    .where(eq(settingsTable.key, BITAZZA_ADJUSTMENT_KEY))
    .limit(1);
  const source = await getBitazzaSourceMetadata();
  res.json(
    GetRateAdjustmentResponse.parse({
      adjustmentPercent: parseBitazzaAdjustmentPercent(setting?.value),
      ...source,
    }),
  );
});

router.post("/rates/thb-usdt/adjustment", async (req, res): Promise<void> => {
  const parsed = SetRateAdjustmentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid rate adjustment", code: "VALIDATION_ERROR" });
    return;
  }

  const jwtPayload = await authenticateRequest(req);
  if (!jwtPayload) {
    res.status(401).json({ message: "unauthorized", code: "UNAUTHORIZED" });
    return;
  }
  const [me] = await db
    .select({ id: usersTable.id, phone: usersTable.phone, isAdmin: usersTable.isAdmin })
    .from(usersTable)
    .where(eq(usersTable.id, jwtPayload.userId))
    .limit(1);
  if (!me || !isAdminUser(me)) {
    res.status(403).json({ message: "Forbidden: admin only", code: "FORBIDDEN" });
    return;
  }

  const updatedAt = new Date();
  await db.transaction(async (tx) => {
    // Serialize a margin change with refreshes so the next quote cannot
    // overwrite the setting using the previous adjustment.
    await tx.execute(
      sql`SELECT pg_advisory_xact_lock(hashtextextended(${BITAZZA_RATE_LOCK_NAME}, 0))`,
    );
    await tx
      .insert(settingsTable)
      .values({
        key: BITAZZA_ADJUSTMENT_KEY,
        value: String(parsed.data.adjustmentPercent),
        updatedAt,
      })
      .onConflictDoUpdate({
        target: settingsTable.key,
        set: {
          value: String(parsed.data.adjustmentPercent),
          updatedAt,
        },
      });
  });

  let rateRefreshed = false;
  try {
    rateRefreshed = await refreshBitazzaRate({ notifyOnChange: true });
  } catch (err) {
    logger.warn({ err }, "[rates] margin saved but immediate Bitazza refresh failed");
  }

  const source = await getBitazzaSourceMetadata();

  res.json(
    SetRateAdjustmentResponse.parse({
      adjustmentPercent: parsed.data.adjustmentPercent,
      rateRefreshed,
      ...source,
    }),
  );
});

const HOUR_MS = 60 * 60 * 1000;

// GET /rates/thb-usdt/candles?hours=24
// Builds hourly OHLC candles for the THB/USDT rate from the append-only
// rate_history log. Every hour in the window gets exactly one candle:
// if the rate changed during the hour, OHLC reflects those changes
// (open = the carried-forward previous close); if it didn't change, the
// candle is flat (open=high=low=close) at the last known rate. This way
// the chart always shows "1 hour = 1 candle" even on quiet hours.
router.get("/rates/thb-usdt/candles", async (req, res) => {
  const hoursRaw = Number(req.query.hours ?? 24);
  const hours = Number.isFinite(hoursRaw)
    ? Math.min(168, Math.max(1, Math.floor(hoursRaw)))
    : 24;

  const now = Date.now();
  const currentHourStart = Math.floor(now / HOUR_MS) * HOUR_MS;
  const windowStart = currentHourStart - (hours - 1) * HOUR_MS;
  const windowStartDate = new Date(windowStart);

  // History points inside the window, oldest first.
  const inWindow = await db
    .select({ rate: rateHistoryTable.rate, recordedAt: rateHistoryTable.recordedAt })
    .from(rateHistoryTable)
    .where(gte(rateHistoryTable.recordedAt, windowStartDate))
    .orderBy(asc(rateHistoryTable.recordedAt));

  // Baseline = the rate as it stood at the moment the window opens. Prefer
  // the most recent history point before the window; otherwise fall back to
  // the oldest in-window point, and finally to the current settings rate.
  let baseline: number;
  const [before] = await db
    .select({ rate: rateHistoryTable.rate })
    .from(rateHistoryTable)
    .where(lt(rateHistoryTable.recordedAt, windowStartDate))
    .orderBy(desc(rateHistoryTable.recordedAt))
    .limit(1);

  if (before) {
    baseline = parseFloat(before.rate);
  } else if (inWindow.length > 0) {
    baseline = parseFloat(inWindow[0]!.rate);
  } else {
    baseline = (await getCurrentRate()).thbPerUsdt;
  }

  // Bucket in-window points by their hour start.
  const buckets = new Map<number, number[]>();
  for (const p of inWindow) {
    const bucket = Math.floor(p.recordedAt.getTime() / HOUR_MS) * HOUR_MS;
    const arr = buckets.get(bucket) ?? [];
    arr.push(parseFloat(p.rate));
    buckets.set(bucket, arr);
  }

  const candles: {
    time: string;
    open: number;
    high: number;
    low: number;
    close: number;
  }[] = [];

  let prevClose = baseline;
  for (let h = windowStart; h <= currentHourStart; h += HOUR_MS) {
    const pts = buckets.get(h);
    let open: number, high: number, low: number, close: number;
    if (!pts || pts.length === 0) {
      open = high = low = close = prevClose;
    } else {
      open = prevClose;
      close = pts[pts.length - 1]!;
      high = Math.max(open, ...pts);
      low = Math.min(open, ...pts);
    }
    candles.push({ time: new Date(h).toISOString(), open, high, low, close });
    prevClose = close;
  }

  res.json({ candles });
});

export default router;
