import app from "./app";
import { logger } from "./lib/logger";
import { registerWebhook } from "./lib/telegram";
import {
  startDailyBalanceBackupScheduler,
  startPeriodicBalanceBackupScheduler,
  startSupportMessageCleanupScheduler,
} from "./lib/scheduler";
import { startBackupScheduler } from "./lib/backup/run";
import { cleanupInvalidUids } from "./lib/uid-cleanup";
import { startOtpLoginMigrationNoticeScheduler } from "./lib/otp-login-migration-notice";
import { startBitazzaRateScheduler } from "./lib/bitazza-rate";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

// Permanent-UID rollout: scrub any legacy `users.uid` values that do
// not match the new `^098\d{6}$` format BEFORE accepting traffic, so
// no request can hit `PATCH /profile/uid` while a stale invalid uid
// still makes the atomic `WHERE uid IS NULL` guard reject legitimate
// first-time creation. Safe to run on every boot — the SQL is
// idempotent. Failures are logged but do not block startup.
await cleanupInvalidUids().catch((err) => {
  logger.error({ err }, "uid-cleanup: failed during startup, continuing");
});

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");

  const isDeployment = !!process.env["REPLIT_DEPLOYMENT"];
  const prodDomain = process.env["REPLIT_DOMAINS"]?.split(",")[0];
  // The local preview runs this scheduler against its development database
  // so admins can verify the feed without changing production data or
  // notifying real Telegram users from a development refresh.
  startBitazzaRateScheduler({
    notifyOnChange: isDeployment && !!prodDomain,
  });

  // Register Telegram webhook ONLY in production deployment.
  // In dev, we skip registration so the local workflow does not hijack
  // the bot away from the production server (which would cause Telegram
  // to deliver user /otp commands to a sleeping dev preview).
  if (isDeployment && prodDomain) {
    registerWebhook(`https://${prodDomain}`).catch(() => {});
    // Daily balance-backup Telegram report. Only in production so the
    // dev server doesn't double-send while staging.
    startDailyBalanceBackupScheduler();
    // Supplemental backup every 2 hours, sharing the same in-flight
    // mutex so a collision with the daily 05:30 ICT tick never produces
    // duplicate Telegram messages.
    startPeriodicBalanceBackupScheduler();
    // GitHub backup scheduler (daily/weekly per admin setting). Production
    // only, same as the other schedulers, so dev never double-pushes.
    startBackupScheduler();
    // Support message retention: delete messages older than 10 days.
    startSupportMessageCleanupScheduler();
    // One-off password-to-Telegram-OTP migration warning.
    startOtpLoginMigrationNoticeScheduler();
  } else {
    logger.info(
      { isDeployment, hasProdDomain: !!prodDomain },
      "Skipping Telegram webhook registration + daily backup scheduler (not in production deployment)"
    );
  }
});
