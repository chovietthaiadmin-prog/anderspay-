import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, TrendingUp, Save, Calendar, AlertCircle } from "lucide-react";
import {
  useGetExchangeRate,
  getGetExchangeRateQueryKey,
  useGetRateAdjustment,
  getGetRateAdjustmentQueryKey,
} from "@workspace/api-client-react";
import { useLang } from "@/lib/use-lang";
import { useAuth } from "@/lib/auth";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";

interface RateManagerProps {
  open: boolean;
  onClose: () => void;
}

export default function RateManager({ open, onClose }: RateManagerProps) {
  const { t, lang } = useLang();
  const { token } = useAuth();
  const rt = t.rateManager;
  const queryClient = useQueryClient();

  const { data: currentRate } = useGetExchangeRate({
    query: { queryKey: getGetExchangeRateQueryKey(), refetchInterval: 30000 }
  });
  const { data: savedAdjustment, isLoading: adjustmentLoading } = useGetRateAdjustment({
    query: { queryKey: getGetRateAdjustmentQueryKey(), refetchInterval: 30000 }
  });

  const [newRate, setNewRate] = useState("");
  const [adjustmentText, setAdjustmentText] = useState("-3");
  const [saving, setSaving] = useState(false);
  const [savingAdjustment, setSavingAdjustment] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");
  const [adjustmentMessage, setAdjustmentMessage] = useState("");
  const [adjustmentError, setAdjustmentError] = useState("");

  useEffect(() => {
    if (savedAdjustment) {
      setAdjustmentText(String(savedAdjustment.adjustmentPercent));
    }
  }, [savedAdjustment?.adjustmentPercent]);

  const handleSave = async () => {
    const rate = parseFloat(newRate);
    if (!newRate || isNaN(rate) || rate <= 0 || rate > 1000) {
      setError(rt.invalidRate);
      return;
    }

    setSaving(true);
    setError("");
    setSuccess(false);

    try {
      const base = import.meta.env.BASE_URL.replace(/\/$/, "");
      const res = await fetch(`${base}/api/rates/thb-usdt`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ thbPerUsdt: rate }),
      });

      if (!res.ok) throw new Error("Failed");

      await queryClient.invalidateQueries({ queryKey: getGetExchangeRateQueryKey() });
      setSuccess(true);
      setNewRate("");
      setTimeout(() => setSuccess(false), 3000);
    } catch {
      setError(rt.saveFailed);
    } finally {
      setSaving(false);
    }
  };

  const handleSaveAdjustment = async () => {
    const adjustmentPercent = Number(adjustmentText.trim().replace(",", "."));
    if (
      !adjustmentText.trim() ||
      !Number.isFinite(adjustmentPercent) ||
      adjustmentPercent < -5 ||
      adjustmentPercent > 5
    ) {
      setAdjustmentError(rt.invalidAdjustment);
      setAdjustmentMessage("");
      return;
    }

    setSavingAdjustment(true);
    setAdjustmentError("");
    setAdjustmentMessage("");
    try {
      const base = import.meta.env.BASE_URL.replace(/\/$/, "");
      const response = await fetch(`${base}/api/rates/thb-usdt/adjustment`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ adjustmentPercent }),
      });
      if (!response.ok) throw new Error("Failed");
      const result = (await response.json()) as {
        adjustmentPercent: number;
        rateRefreshed?: boolean;
      };

      setAdjustmentText(String(result.adjustmentPercent));
      await Promise.all([
        queryClient.invalidateQueries({
          queryKey: getGetRateAdjustmentQueryKey(),
        }),
        queryClient.invalidateQueries({
          queryKey: getGetExchangeRateQueryKey(),
        }),
      ]);
      setAdjustmentMessage(
        result.rateRefreshed
          ? rt.adjustmentSaved
          : rt.adjustmentSavedPending,
      );
      setTimeout(() => setAdjustmentMessage(""), 4000);
    } catch {
      setAdjustmentError(rt.adjustmentSaveFailed);
    } finally {
      setSavingAdjustment(false);
    }
  };

  const today = new Date().toLocaleDateString(lang === "vi" ? "vi-VN" : "en-US", {
    weekday: "long", year: "numeric", month: "long", day: "numeric"
  });
  const sourceMultiplier =
    1 + (savedAdjustment?.adjustmentPercent ?? -3) / 100;
  const sourceUpdatedAt = savedAdjustment?.sourceUpdatedAt
    ? new Date(savedAdjustment.sourceUpdatedAt).toLocaleString(
        lang === "vi" ? "vi-VN" : "en-US",
      )
    : null;

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 z-50 backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, y: -40, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -30, scale: 0.97 }}
            transition={{ type: "spring", damping: 24, stiffness: 300 }}
            className="fixed top-0 left-0 right-0 z-50 flex justify-center pt-[env(safe-area-inset-top)]"
          >
            <div className="relative w-full max-w-[480px] max-h-[calc(100dvh-env(safe-area-inset-top))] overflow-y-auto bg-card rounded-b-3xl border-b border-border shadow-2xl p-6 pt-14">
              <div className="w-10 h-1 bg-border rounded-full mx-auto mb-6" />

              <button onClick={onClose} className="absolute top-11 right-5 text-muted-foreground hover:text-foreground transition-colors">
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <h2 className="font-bold text-lg">{rt.title}</h2>
                  <p className="text-xs text-muted-foreground">{rt.subtitle}</p>
                </div>
              </div>

              {/* Today's date */}
              <div className="flex items-center gap-2 mb-5 text-xs text-muted-foreground bg-secondary/40 rounded-xl px-3 py-2">
                <Calendar className="w-3.5 h-3.5" />
                <span>{today}</span>
              </div>

              {/* Current rate */}
              <Card className="bg-secondary/30 border-border mb-5">
                <CardContent className="p-4 flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">{rt.currentRate}</span>
                  <div className="text-right">
                    {currentRate ? (
                      <>
                        <span className="text-xl font-bold text-accent font-mono tabular-nums">
                          {currentRate.thbPerUsdt.toFixed(4)}
                        </span>
                        <span className="text-sm text-muted-foreground ml-1">THB/USDT</span>
                      </>
                    ) : (
                      <div className="h-6 w-28 bg-muted animate-pulse rounded" />
                    )}
                  </div>
                </CardContent>
              </Card>

              {savedAdjustment?.bitazzaPrice != null && (
                <div className="rounded-xl border border-border bg-secondary/20 px-4 py-3 mb-5 text-xs text-muted-foreground">
                  <p className="flex flex-wrap items-center justify-between gap-x-3 gap-y-1">
                    <span>{rt.bitazzaSource}</span>
                    <span className="font-mono tabular-nums text-foreground">
                      {savedAdjustment.bitazzaPrice.toFixed(4)} ×{" "}
                      {Number(sourceMultiplier.toFixed(6))} ={" "}
                      {(savedAdjustment.bitazzaPrice * sourceMultiplier).toFixed(4)}{" "}
                      THB
                    </span>
                  </p>
                  {sourceUpdatedAt && (
                    <p className="mt-2 flex flex-wrap items-center justify-between gap-x-3 gap-y-1">
                      <span>{rt.sourceUpdatedAt}</span>
                      <time
                        className="text-foreground"
                        dateTime={savedAdjustment.sourceUpdatedAt ?? undefined}
                      >
                        {sourceUpdatedAt}
                      </time>
                    </p>
                  )}
                </div>
              )}

              {/* Select and persist the percentage used by automatic updates */}
              <div className="rounded-xl border border-border bg-secondary/20 p-4 mb-5">
                <label
                  htmlFor="bitazza-adjustment"
                  className="text-xs uppercase tracking-wider text-muted-foreground font-medium"
                >
                  {rt.adjustmentLabel}
                </label>
                <div className="flex gap-3 mt-2">
                  <Input
                    id="bitazza-adjustment"
                    type="text"
                    inputMode="decimal"
                    placeholder={rt.adjustmentPlaceholder}
                    value={adjustmentText}
                    onChange={(e) => {
                      setAdjustmentText(e.target.value);
                      setAdjustmentError("");
                      setAdjustmentMessage("");
                    }}
                    className="bg-input border-border h-12 text-lg font-bold tabular-nums focus-visible:ring-accent"
                    aria-describedby="bitazza-adjustment-hint"
                  />
                  <Button
                    className="h-12 px-4 gap-2 bg-accent text-accent-foreground hover:bg-accent/90 font-bold shrink-0"
                    onClick={handleSaveAdjustment}
                    disabled={savingAdjustment || adjustmentLoading}
                  >
                    <Save className="w-4 h-4" />
                    {savingAdjustment
                      ? rt.savingAdjustment
                      : rt.saveAdjustment}
                  </Button>
                </div>
                <p
                  id="bitazza-adjustment-hint"
                  className="text-xs text-muted-foreground mt-2"
                >
                  {rt.adjustmentHint}
                </p>
                {adjustmentError && (
                  <p role="alert" className="text-xs text-red-400 mt-2">
                    {adjustmentError}
                  </p>
                )}
                {adjustmentMessage && (
                  <p role="status" className="text-xs text-green-400 mt-2">
                    {adjustmentMessage}
                  </p>
                )}
              </div>

              {/* Set new rate */}
              <div className="flex flex-col gap-3">
                <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">{rt.setRate}</p>
                <div className="flex gap-3">
                  <div className="relative flex-1">
                    <Input
                      type="number"
                      step="0.01"
                      min="1"
                      max="1000"
                      placeholder={rt.ratePlaceholder}
                      value={newRate}
                      onChange={(e) => { setNewRate(e.target.value); setError(""); setSuccess(false); }}
                      className="bg-input border-border h-12 text-lg font-bold tabular-nums pr-20 focus-visible:ring-accent"
                      onKeyDown={(e) => e.key === "Enter" && handleSave()}
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground font-medium">
                      THB
                    </span>
                  </div>
                  <Button
                    className="h-12 px-5 gap-2 bg-accent text-accent-foreground hover:bg-accent/90 font-bold shrink-0"
                    onClick={handleSave}
                    disabled={saving || !newRate}
                  >
                    <Save className="w-4 h-4" />
                    {saving ? rt.saving : rt.save}
                  </Button>
                </div>

                <p className="text-xs text-muted-foreground">{rt.hint}</p>

                <AnimatePresence>
                  {error && (
                    <motion.div
                      initial={{ opacity: 0, y: -4 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="flex items-center gap-2 text-sm text-red-400 bg-red-500/10 rounded-lg px-3 py-2"
                    >
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      {error}
                    </motion.div>
                  )}
                  {success && (
                    <motion.div
                      initial={{ opacity: 0, y: -4 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="flex items-center gap-2 text-sm text-green-400 bg-green-500/10 rounded-lg px-3 py-2"
                    >
                      <span>✓</span>
                      {rt.saveSuccess}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
