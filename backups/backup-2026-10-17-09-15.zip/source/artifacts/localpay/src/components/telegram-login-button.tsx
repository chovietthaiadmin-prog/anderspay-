import { useEffect, useRef, useState } from "react";
import type { TelegramLoginPayload } from "@/lib/auth";

// Bot identity for the Telegram Login Widget. Both must match the bot
// whose token is in TELEGRAM_BOT_TOKEN on the server, and the app's
// domain must be registered with that bot via @BotFather `/setdomain`
// for Telegram to accept the auth popup. Hard-coded because the bot
// is fixed per deployment — if it ever changes, swap both constants
// AND the server-side bot token together.
export const TELEGRAM_BOT_USERNAME = "AndersPayPlus_bot";
export const TELEGRAM_BOT_ID = 8749071938;

declare global {
  interface Window {
    Telegram?: {
      Login?: {
        auth: (
          opts: { bot_id: number; request_access?: string; lang?: string },
          callback: (user: TelegramLoginPayload | false) => void,
        ) => void;
      };
    };
  }
}

// Load Telegram's widget script once per page so `window.Telegram.Login.auth`
// becomes available. We do NOT use the script's data-* attribute mode —
// that mode injects a Telegram-controlled iframe whose render is fragile
// inside SPAs and dark themes. Instead we render our own button and call
// `Telegram.Login.auth(...)` programmatically; Telegram opens its own
// popup window for the user to confirm, then invokes our callback with
// the signed payload.
let telegramScriptPromise: Promise<void> | null = null;
function loadTelegramScript(): Promise<void> {
  if (telegramScriptPromise) return telegramScriptPromise;
  if (typeof window === "undefined") return Promise.reject(new Error("no_window"));
  if (window.Telegram?.Login?.auth) return Promise.resolve();
  telegramScriptPromise = new Promise<void>((resolve, reject) => {
    const existing = document.querySelector<HTMLScriptElement>(
      "script[data-anderspay-telegram-loader]",
    );
    if (existing) {
      existing.addEventListener("load", () => resolve());
      existing.addEventListener("error", () => reject(new Error("script_load_failed")));
      return;
    }
    const s = document.createElement("script");
    s.src = "https://telegram.org/js/telegram-widget.js?22";
    s.async = true;
    s.dataset.anderspayTelegramLoader = "1";
    s.onload = () => resolve();
    s.onerror = () => reject(new Error("script_load_failed"));
    document.head.appendChild(s);
  });
  return telegramScriptPromise;
}

// One-click Telegram auth button. Renders our own styled button (so it
// always shows, regardless of whether Telegram's CDN script has finished
// loading) and on click calls `Telegram.Login.auth(...)`, which opens
// Telegram's own popup for the user to confirm. The popup invokes our
// callback with the signed payload, which we hand to the server for
// HMAC verification. We deliberately avoid the widget's auto-injected
// iframe mode: that iframe is fragile inside SPAs / dark themes and was
// the reason early builds appeared "missing".
export default function TelegramLoginButton({
  onAuth,
  disabled,
  label,
}: {
  onAuth: (payload: TelegramLoginPayload) => void;
  disabled?: boolean;
  label: string;
}) {
  const [scriptReady, setScriptReady] = useState<boolean>(
    typeof window !== "undefined" && !!window.Telegram?.Login?.auth,
  );
  const [scriptFailed, setScriptFailed] = useState(false);
  const onAuthRef = useRef(onAuth);
  onAuthRef.current = onAuth;

  useEffect(() => {
    let cancelled = false;
    loadTelegramScript()
      .then(() => {
        if (!cancelled) setScriptReady(true);
      })
      .catch(() => {
        if (!cancelled) setScriptFailed(true);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const handleClick = () => {
    const auth = window.Telegram?.Login?.auth;
    if (!auth) {
      setScriptFailed(true);
      return;
    }
    auth({ bot_id: TELEGRAM_BOT_ID, request_access: "write" }, (user) => {
      // Telegram passes `false` if the user dismissed the popup or the
      // domain check failed — treat both as a no-op so the form stays
      // usable for password fallback.
      if (!user) return;
      try {
        onAuthRef.current(user);
      } catch {
        // Errors surface via the parent's error UI; never let them
        // escape Telegram's callback.
      }
    });
  };

  const isDisabled = disabled || !scriptReady;
  return (
    <div className="flex flex-col items-stretch gap-1.5">
      <button
        type="button"
        onClick={handleClick}
        disabled={isDisabled}
        aria-label={label}
        className="flex items-center justify-center gap-2 h-11 px-4 rounded-xl bg-[#229ED9] hover:bg-[#1f8fc5] active:bg-[#1c7fb0] disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-semibold shadow-md transition-colors"
      >
        <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor" aria-hidden>
          <path d="M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z" />
        </svg>
        <span>{label}</span>
      </button>
      {scriptFailed && (
        <p className="text-[10px] text-red-400 text-center">
          Không tải được Telegram. Vui lòng kiểm tra mạng và thử lại.
        </p>
      )}
    </div>
  );
}
