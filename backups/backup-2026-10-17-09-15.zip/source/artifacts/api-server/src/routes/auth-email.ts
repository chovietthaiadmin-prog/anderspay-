import { Router } from "express";
import { db, usersTable, emailOtpsTable, transactionsTable } from "@workspace/db";
import { eq, and, gt, sql, desc } from "drizzle-orm";
import { randomUUID, randomInt, createHash } from "crypto";
import { z } from "zod";
import { issueSession, authenticateRequest } from "../lib/jwt";
import { logger } from "../lib/logger";
import { sendEmail, otpEmailHtml, otpEmailText } from "../lib/mailer";
import { notifyAdminNewUser } from "./auth";

const router = Router();

const OTP_TTL_MS = 10 * 60 * 1000; // 10 minutes
const RESEND_GAP_MS = 60 * 1000; // 60s between sends
const MAX_PER_HOUR = 5;
const MAX_PER_DAY = 20;
const MAX_ATTEMPTS = 5;
const LOCK_MS = 15 * 60 * 1000; // 15 minutes
const REFERRAL_REWARD_USDT = "10";

const EmailBody = z.object({ email: z.string().trim().toLowerCase().email().max(254) });
const VerifyBody = EmailBody.extend({
  otp: z.string().trim().regex(/^\d{6}$/),
  referralCode: z.string().trim().max(32).optional(),
});

function hashOtp(email: string, otp: string): string {
  // Keyed with the server session secret so a leaked DB dump alone
  // cannot be brute-forced offline against a known-format 6-digit space
  // without also having the secret.
  const key = process.env.SESSION_SECRET || process.env.JWT_SECRET || "";
  return createHash("sha256").update(`${key}:${email}:${otp}`).digest("hex");
}

function generateOtp(): string {
  return randomInt(0, 1_000_000).toString().padStart(6, "0");
}

// Shared send-OTP core used by both the public auth flow and the
// authenticated email-change flow. Enforces resend gap + hourly/daily
// caps per (email, purpose-family) and emails the code.
async function sendOtpTo(
  email: string,
  purpose: string,
): Promise<{ ok: true } | { ok: false; status: number; body: object }> {
  const now = Date.now();
  const hourAgo = new Date(now - 60 * 60 * 1000);
  const dayAgo = new Date(now - 24 * 60 * 60 * 1000);

  const recent = await db
    .select({ createdAt: emailOtpsTable.createdAt })
    .from(emailOtpsTable)
    .where(and(eq(emailOtpsTable.email, email), gt(emailOtpsTable.createdAt, dayAgo)))
    .orderBy(desc(emailOtpsTable.createdAt));

  if (recent.length >= MAX_PER_DAY) {
    return { ok: false, status: 429, body: { error: "rate_limited", message: "Đã vượt giới hạn gửi mã trong ngày. Vui lòng thử lại sau.", retryAfterSec: 3600 } };
  }
  const inLastHour = recent.filter((r) => r.createdAt > hourAgo);
  if (inLastHour.length >= MAX_PER_HOUR) {
    const oldest = inLastHour[inLastHour.length - 1].createdAt.getTime();
    const retryAfterSec = Math.max(60, Math.ceil((oldest + 60 * 60 * 1000 - now) / 1000));
    return { ok: false, status: 429, body: { error: "rate_limited", message: "Đã gửi quá nhiều mã trong 1 giờ. Vui lòng thử lại sau.", retryAfterSec } };
  }
  if (recent.length > 0) {
    const last = recent[0].createdAt.getTime();
    if (now - last < RESEND_GAP_MS) {
      const retryAfterSec = Math.ceil((last + RESEND_GAP_MS - now) / 1000);
      return { ok: false, status: 429, body: { error: "rate_limited", message: "Vui lòng đợi trước khi gửi lại mã.", retryAfterSec } };
    }
  }

  const otp = generateOtp();
  await db.insert(emailOtpsTable).values({
    id: randomUUID(),
    email,
    purpose,
    otpHash: hashOtp(email, otp),
    expiresAt: new Date(now + OTP_TTL_MS),
  });

  await sendEmail({
    to: email,
    subject: "Your AndersPay+ Verification Code",
    html: otpEmailHtml(otp),
    text: otpEmailText(otp),
  });
  return { ok: true };
}

// Verify an OTP row for (email, purpose): enforces expiry, attempt
// counting and the 15-minute lock. Consumes the row on success.
async function verifyOtpFor(
  email: string,
  purpose: string,
  otp: string,
): Promise<{ ok: true } | { ok: false; status: number; body: object }> {
  const [row] = await db
    .select()
    .from(emailOtpsTable)
    .where(and(eq(emailOtpsTable.email, email), eq(emailOtpsTable.purpose, purpose)))
    .orderBy(desc(emailOtpsTable.createdAt))
    .limit(1);

  const now = Date.now();
  if (row?.lockedUntil && row.lockedUntil.getTime() > now) {
    const retryAfterSec = Math.ceil((row.lockedUntil.getTime() - now) / 1000);
    return { ok: false, status: 423, body: { error: "locked", message: "Nhập sai quá 5 lần. Vui lòng thử lại sau 15 phút.", retryAfterSec } };
  }
  if (!row || row.consumedAt || row.expiresAt.getTime() < now) {
    return { ok: false, status: 400, body: { error: "invalid_otp", message: "Mã không hợp lệ hoặc đã hết hạn." } };
  }
  if (row.otpHash !== hashOtp(email, otp)) {
    const attempts = row.attempts + 1;
    const locked = attempts >= MAX_ATTEMPTS;
    await db
      .update(emailOtpsTable)
      .set({ attempts, lockedUntil: locked ? new Date(now + LOCK_MS) : null })
      .where(eq(emailOtpsTable.id, row.id));
    if (locked) {
      return { ok: false, status: 423, body: { error: "locked", message: "Nhập sai quá 5 lần. Vui lòng thử lại sau 15 phút.", retryAfterSec: Math.ceil(LOCK_MS / 1000) } };
    }
    return { ok: false, status: 400, body: { error: "invalid_otp", message: "Mã không đúng. Vui lòng thử lại.", attemptsLeft: MAX_ATTEMPTS - attempts } };
  }
  // Atomic consume: the conditional update guards against concurrent
  // verifies replaying the same code — only one request can win.
  const consumed = await db
    .update(emailOtpsTable)
    .set({ consumedAt: new Date() })
    .where(and(eq(emailOtpsTable.id, row.id), sql`${emailOtpsTable.consumedAt} IS NULL`))
    .returning({ id: emailOtpsTable.id });
  if (consumed.length !== 1) {
    return { ok: false, status: 400, body: { error: "invalid_otp", message: "Mã không hợp lệ hoặc đã hết hạn." } };
  }
  return { ok: true };
}

function serializeUser(user: typeof usersTable.$inferSelect) {
  return {
    id: user.id,
    name: user.name,
    nameUpdatedAt: user.nameUpdatedAt?.toISOString() ?? null,
    phone: user.phone,
    email: user.email || undefined,
    emailVerified: user.emailVerified,
    nickname: user.nickname,
    avatarUrl: user.avatarUrl,
    dob: user.dob,
    createdAt: user.createdAt.toISOString(),
    uid: user.uid,
    isAdmin: user.isAdmin || undefined,
    usdtBalance: parseFloat(user.usdtBalance),
    thbBalance: parseFloat(user.thbBalance),
  };
}

// POST /auth/email/send-otp — public. Sends a login/registration code.
router.post("/auth/email/send-otp", async (req, res) => {
  const parsed = EmailBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "invalid_email", message: "Email không hợp lệ." });
    return;
  }
  const email = parsed.data.email;

  const [existing] = await db
    .select({ id: usersTable.id })
    .from(usersTable)
    .where(and(eq(usersTable.email, email), eq(usersTable.emailVerified, true)))
    .limit(1);

  const sent = await sendOtpTo(email, "auth");
  if (!sent.ok) {
    res.status(sent.status).json(sent.body);
    return;
  }
  req.log.info({ email, exists: !!existing }, "email auth otp sent");
  res.json({ ok: true, exists: !!existing });
});

// POST /auth/email/verify — public. Verifies the code; logs into the
// existing verified-email account or creates a fresh one.
router.post("/auth/email/verify", async (req, res) => {
  const parsed = VerifyBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "invalid_input", message: "Dữ liệu không hợp lệ." });
    return;
  }
  const { email, otp, referralCode } = parsed.data;

  const verdict = await verifyOtpFor(email, "auth", otp);
  if (!verdict.ok) {
    res.status(verdict.status).json(verdict.body);
    return;
  }

  // Existing account with this VERIFIED email → login. (Unverified
  // matches are deliberately ignored: anyone could type a stranger's
  // email into settings, and matching it here would let signups land
  // in an attacker-controlled account.)
  const [existing] = await db
    .select()
    .from(usersTable)
    .where(and(eq(usersTable.email, email), eq(usersTable.emailVerified, true)))
    .limit(1);

  if (existing) {
    const token = await issueSession(existing.id);
    res.json({ ok: true, token, user: serializeUser(existing), created: false });
    return;
  }

  // New account. Claim the email: clear it from any rows that hold it
  // unverified so one email can never point at two accounts.
  type RegErr = "invalid_referral_code";
  let user: typeof usersTable.$inferSelect;
  try {
    user = await db.transaction(async (tx) => {
      await tx
        .update(usersTable)
        .set({ email: "", emailVerified: false, emailVerifiedAt: null })
        .where(and(eq(usersTable.email, email), eq(usersTable.emailVerified, false)));

      let referrerId: string | null = null;
      if (referralCode && referralCode.trim()) {
        const [referrer] = await tx
          .select({ id: usersTable.id })
          .from(usersTable)
          .where(eq(usersTable.uid, referralCode.trim().toUpperCase()))
          .limit(1);
        if (!referrer) {
          const e = new Error("invalid_referral_code") as Error & { code?: RegErr };
          e.code = "invalid_referral_code";
          throw e;
        }
        referrerId = referrer.id;
      }

      const suffix = randomInt(10000, 100000).toString();
      const [u] = await tx
        .insert(usersTable)
        .values({
          id: randomUUID(),
          name: `User${suffix}`,
          nickname: `User${suffix}`,
          email,
          emailVerified: true,
          emailVerifiedAt: new Date(),
          // Synthetic placeholder, same pattern as Telegram-widget
          // accounts (`tg:<id>`). Not a real phone; digit-only phone
          // auth paths can never match it.
          phone: `em:${randomUUID()}`,
          // Invalid bcrypt string — password login disabled until the
          // user explicitly sets a password later.
          passwordHash: "!email-only!",
          verified: true,
          referredBy: referrerId,
        })
        .returning();

      if (referrerId) {
        await tx
          .update(usersTable)
          .set({
            referralRewardBalance: sql`${usersTable.referralRewardBalance} + ${REFERRAL_REWARD_USDT}::numeric`,
            totalReferralEarned: sql`${usersTable.totalReferralEarned} + ${REFERRAL_REWARD_USDT}::numeric`,
            referralCount: sql`${usersTable.referralCount} + 1`,
          })
          .where(eq(usersTable.id, referrerId));
        await tx.insert(transactionsTable).values({
          id: randomUUID(),
          userId: referrerId,
          type: "referral_reward",
          amountUsdt: REFERRAL_REWARD_USDT,
          amountThb: "0",
          rate: "0",
        });
      }
      return u;
    });
  } catch (err) {
    if ((err as { code?: RegErr }).code === "invalid_referral_code") {
      res.status(400).json({ error: "invalid_referral_code", message: "Mã giới thiệu không tồn tại. Vui lòng kiểm tra lại." });
      return;
    }
    throw err;
  }

  notifyAdminNewUser(user, "email");
  logger.info({ userId: user.id }, "email account created");
  const token = await issueSession(user.id);
  res.json({ ok: true, token, user: serializeUser(user), created: true });
});

// POST /auth/email/change/send-otp — authenticated. Sends a code to the
// NEW address to prove ownership before switching.
router.post("/auth/email/change/send-otp", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const parsed = EmailBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "invalid_email", message: "Email không hợp lệ." });
    return;
  }
  const email = parsed.data.email;

  const [taken] = await db
    .select({ id: usersTable.id })
    .from(usersTable)
    .where(and(eq(usersTable.email, email), eq(usersTable.emailVerified, true)))
    .limit(1);
  if (taken && taken.id !== payload.userId) {
    res.status(409).json({ error: "email_taken", message: "Email này đã được dùng cho tài khoản khác." });
    return;
  }

  const sent = await sendOtpTo(email, `change:${payload.userId}`);
  if (!sent.ok) {
    res.status(sent.status).json(sent.body);
    return;
  }
  res.json({ ok: true });
});

// POST /auth/email/change/verify — authenticated. Applies the change.
router.post("/auth/email/change/verify", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const parsed = VerifyBody.omit({ referralCode: true }).safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "invalid_input", message: "Dữ liệu không hợp lệ." });
    return;
  }
  const { email, otp } = parsed.data;

  const verdict = await verifyOtpFor(email, `change:${payload.userId}`, otp);
  if (!verdict.ok) {
    res.status(verdict.status).json(verdict.body);
    return;
  }

  const [taken] = await db
    .select({ id: usersTable.id })
    .from(usersTable)
    .where(and(eq(usersTable.email, email), eq(usersTable.emailVerified, true)))
    .limit(1);
  if (taken && taken.id !== payload.userId) {
    res.status(409).json({ error: "email_taken", message: "Email này đã được dùng cho tài khoản khác." });
    return;
  }

  await db
    .update(usersTable)
    .set({ email, emailVerified: true, emailVerifiedAt: new Date() })
    .where(eq(usersTable.id, payload.userId));
  req.log.info({ userId: payload.userId }, "email changed and verified");
  res.json({ ok: true, email, emailVerified: true });
});

export default router;
