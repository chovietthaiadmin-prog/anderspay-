import { Router } from "express";
import {
  db,
  usersTable,
  otpsTable,
  telegramLinksTable,
  transactionsTable,
  ordersTable,
  webauthnCredentialsTable,
  supportMessagesTable,
} from "@workspace/db";
import { eq, and, gt, sql, isNotNull, or, inArray } from "drizzle-orm";
import { randomUUID } from "crypto";
import bcrypt from "bcryptjs";
import { issueSession, authenticateRequest } from "../lib/jwt";
import { SendOtpBody, RegisterBody, LoginBody, ResetPasswordBody } from "@workspace/api-zod";
import { isAdminPhone, isAdminUser, getAdminPhones } from "../lib/admin";
import { logger } from "../lib/logger";
import { getTelegramChatId, sendTelegramMessage, sendTelegramMessageDetailed } from "../lib/telegram";
import { verifyTelegramAuth } from "../lib/telegram-auth";
import { sendEmail, otpEmailHtml, otpEmailText } from "../lib/mailer";

const router = Router();

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const API = () => `https://api.telegram.org/bot${BOT_TOKEN}`;

function generateOtp(): string {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function normalizePhone(raw: string): string {
  let cleaned = raw.replace(/[\s\-()]/g, "");
  if (!cleaned.startsWith("+")) cleaned = `+${cleaned}`;
  cleaned = cleaned.replace(/^\+0+(\d)/, "+$1");
  return cleaned;
}

// Escape the small set of characters Telegram's HTML parse mode treats
// as markup, so user-supplied names/usernames can't break the message.
function escapeHtml(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// Notify each admin's *personal* Telegram chat that a new customer
// registered — NOT the shared "bill nạp USDT" group (TELEGRAM_CHAT_ID).
// Admins are users flagged is_admin OR whose phone is in ADMIN_PHONES;
// we message every admin who has linked their Telegram account.
// Fire-and-forget: never blocks or fails the signup request.
// `source` distinguishes the phone+OTP flow from Telegram login.
export function notifyAdminNewUser(
  user: typeof usersTable.$inferSelect,
  source: "phone" | "telegram" | "email",
): void {
  const createdAt = user.createdAt.toLocaleString("vi-VN", {
    timeZone: "Asia/Bangkok",
    hour12: false,
  });
  const lines = [
    "🆕 <b>Khách hàng mới đăng ký</b>",
    "",
    `👤 Tên: <b>${escapeHtml(user.name)}</b>`,
    `🆔 UID: <code>${escapeHtml(user.uid ?? "—")}</code>`,
  ];
  if (!user.phone.startsWith("tg:")) {
    lines.push(`📱 SĐT: <code>${escapeHtml(user.phone)}</code>`);
  }
  if (user.telegramUsername) {
    lines.push(`💬 Telegram: @${escapeHtml(user.telegramUsername)}`);
  }
  if (user.referredBy) {
    lines.push(`🎁 Được giới thiệu bởi: <code>${escapeHtml(user.referredBy)}</code>`);
  }
  lines.push(`🔗 Hình thức: ${source === "telegram" ? "Telegram Login" : source === "email" ? "Email OTP" : "SĐT + OTP"}`);
  lines.push(`🕒 Thời gian: ${createdAt} (ICT)`);
  const message = lines.join("\n");

  // Run async without blocking the signup response.
  void (async () => {
    try {
      // Collect admin chats: DB-flagged admins plus founding admins
      // identified purely by phone (ADMIN_PHONES), both filtered to
      // those who have linked a Telegram chat.
      const adminPhones = getAdminPhones();
      const candidates = await db
        .select({
          id: usersTable.id,
          phone: usersTable.phone,
          isAdmin: usersTable.isAdmin,
          telegramChatId: usersTable.telegramChatId,
          telegramId: usersTable.telegramId,
        })
        .from(usersTable)
        .where(
          and(
            or(
              isNotNull(usersTable.telegramChatId),
              isNotNull(usersTable.telegramId),
            ),
            or(
              eq(usersTable.isAdmin, true),
              adminPhones.length > 0 ? inArray(usersTable.phone, adminPhones) : sql`false`,
            ),
          ),
        );

      // Dedupe by chat id so an admin linked once isn't pinged twice,
      // and never echo the notification to the new user themselves.
      const seen = new Set<string>();
      const chatIds = candidates
        .filter((c) => c.id !== user.id && isAdminUser(c) && getTelegramChatId(c))
        .map((c) => getTelegramChatId(c)!)
        .filter((cid) => (seen.has(cid) ? false : (seen.add(cid), true)));

      if (chatIds.length === 0) {
        logger.warn({ userId: user.id }, "[register] no admin telegram chats to notify");
        return;
      }

      for (const chatId of chatIds) {
        const result = await sendTelegramMessageDetailed(message, chatId);
        if (!result.ok) {
          logger.warn(
            { chatId, reason: result.reason, description: result.description },
            "[register] admin new-user notify failed",
          );
        }
        await new Promise((resolve) => setTimeout(resolve, 50));
      }
    } catch (err) {
      logger.error({ err }, "[register] notifyAdminNewUser threw");
    }
  })();
}

// Returns { ok: true } on successful Telegram delivery, otherwise
// { ok: false, reason, description? } so the caller can surface an
// actionable message ("bot was blocked", "chat not found"...) and the
// server can log the underlying Telegram description.
type SendResult =
  | { ok: true }
  | { ok: false; reason: "no_token" | "network" | "telegram_error"; description?: string };

async function sendOtpViaTelegram(chatId: string, otp: string): Promise<SendResult> {
  if (!BOT_TOKEN) {
    logger.error("[otp] TELEGRAM_BOT_TOKEN not configured — cannot send OTP");
    return { ok: false, reason: "no_token" };
  }
  try {
    const res = await fetch(`${API()}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        parse_mode: "HTML",
        text: [
          `🔐 <b>AndersPay+ — Mã OTP</b>`,
          ``,
          `Mã xác nhận của bạn là:`,
          ``,
          `<code>  ${otp}  </code>`,
          ``,
          `⏱ Mã có hiệu lực trong <b>15 phút</b>.`,
          `❌ Không chia sẻ mã này cho bất kỳ ai.`,
        ].join("\n"),
      }),
    });
    const data = (await res.json().catch(() => ({}))) as {
      ok?: boolean;
      description?: string;
      error_code?: number;
    };
    if (data.ok) return { ok: true };
    logger.warn(
      { chatId, status: res.status, errorCode: data.error_code, description: data.description },
      "[otp] telegram sendMessage failed",
    );
    return { ok: false, reason: "telegram_error", description: data.description };
  } catch (err) {
    logger.error({ err, chatId }, "[otp] telegram sendMessage threw");
    return { ok: false, reason: "network" };
  }
}

router.post("/auth/send-otp", async (req, res) => {
  const parsed = SendOtpBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "phone required", details: parsed.error.flatten().fieldErrors });
    return;
  }
  const { phone } = parsed.data;
  const normalizedPhone = normalizePhone(phone);

  const [link] = await db
    .select()
    .from(telegramLinksTable)
    .where(eq(telegramLinksTable.phone, normalizedPhone))
    .limit(1);

  if (!link) {
    res.status(404).json({
      error: "telegram_not_linked",
      message: `Số ${normalizedPhone} chưa liên kết Telegram. Vui lòng nhắn /otp ${normalizedPhone} cho @AndersPayPlus_bot trước.`,
    });
    return;
  }

  await db.delete(otpsTable).where(eq(otpsTable.phone, normalizedPhone));

  const otp = generateOtp();
  const expiresAt = new Date(Date.now() + 15 * 60 * 1000);

  await db.insert(otpsTable).values({
    id: randomUUID(),
    phone: normalizedPhone,
    code: otp,
    expiresAt,
  });

  const sent = await sendOtpViaTelegram(link.chatId, otp);
  if (!sent.ok) {
    // Map underlying Telegram failure to an explicit error code +
    // human-readable Vietnamese hint so the UI can show something
    // actionable instead of a vague "try again".
    const desc = sent.reason === "telegram_error" ? sent.description ?? "" : "";
    const lower = desc.toLowerCase();
    let code = "telegram_send_failed";
    let message = "Không gửi được OTP qua Telegram. Vui lòng thử lại sau.";
    if (sent.reason === "no_token") {
      code = "telegram_not_configured";
      message = "Hệ thống chưa cấu hình bot Telegram. Liên hệ admin.";
    } else if (lower.includes("bot was blocked") || lower.includes("forbidden")) {
      code = "telegram_blocked";
      message = "Bạn đã chặn bot @AndersPayPlus_bot. Vui lòng bỏ chặn rồi thử lại.";
    } else if (lower.includes("chat not found")) {
      code = "telegram_chat_not_found";
      message = `Chat Telegram không tồn tại. Vui lòng nhắn /otp ${normalizedPhone} cho @AndersPayPlus_bot để liên kết lại.`;
    }
    res.status(502).json({ error: code, message, description: desc || undefined });
    return;
  }

  res.json({ ok: true });
});

router.post("/auth/register", async (req, res) => {
  const parsed = RegisterBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "All fields are required", details: parsed.error.flatten().fieldErrors });
    return;
  }
  const { phone, password, otp, referralCode } = parsed.data;
  const normalizedPhone = normalizePhone(phone);

  const [existing] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.phone, normalizedPhone))
    .limit(1);

  if (existing) {
    res.status(409).json({ error: "phone_taken", message: "Số điện thoại đã được sử dụng" });
    return;
  }

  const [link] = await db
    .select()
    .from(telegramLinksTable)
    .where(eq(telegramLinksTable.phone, normalizedPhone))
    .limit(1);

  const passwordHash = await bcrypt.hash(password, 10);

  const defaultName = `User${normalizedPhone.slice(-4)}`;

  // Single transaction so a failure at any step rolls back: OTP consume,
  // optional referrer resolution + credit, and user insert are all-or-
  // nothing. Referrer lookup happens AFTER OTP consume — without a valid
  // OTP, an attacker cannot probe whether an arbitrary 098xxxxxx UID
  // exists, so the response cannot be used as an enumeration oracle.
  const REFERRAL_REWARD_USDT = "10";
  type RegisterErr = "invalid_otp" | "invalid_referral_code";
  let user: typeof usersTable.$inferSelect;
  try {
    user = await db.transaction(async (tx) => {
      const now = new Date();
      const [consumed] = await tx
        .update(otpsTable)
        .set({ used: true })
        .where(
          and(
            eq(otpsTable.phone, normalizedPhone),
            eq(otpsTable.code, otp),
            eq(otpsTable.used, false),
            gt(otpsTable.expiresAt, now),
          ),
        )
        .returning();

      if (!consumed) {
        const e = new Error("invalid_otp") as Error & { code?: RegisterErr };
        e.code = "invalid_otp";
        throw e;
      }

      let referrerId: string | null = null;
      if (referralCode) {
        const [referrer] = await tx
          .select({ id: usersTable.id })
          .from(usersTable)
          .where(eq(usersTable.uid, referralCode))
          .limit(1);
        if (!referrer) {
          const e = new Error("invalid_referral_code") as Error & { code?: RegisterErr };
          e.code = "invalid_referral_code";
          throw e;
        }
        referrerId = referrer.id;
      }

      const [u] = await tx.insert(usersTable).values({
        id: randomUUID(),
        name: defaultName,
        phone: normalizedPhone,
        passwordHash,
        telegramChatId: link?.chatId ?? null,
        verified: true,
        referredBy: referrerId,
      }).returning();

      if (referrerId) {
        const credited = await tx
          .update(usersTable)
          .set({
            referralRewardBalance: sql`${usersTable.referralRewardBalance} + ${REFERRAL_REWARD_USDT}::numeric`,
            totalReferralEarned: sql`${usersTable.totalReferralEarned} + ${REFERRAL_REWARD_USDT}::numeric`,
            referralCount: sql`${usersTable.referralCount} + 1`,
          })
          .where(eq(usersTable.id, referrerId))
          .returning({ id: usersTable.id });
        if (credited.length !== 1) {
          // Referrer disappeared between resolve and credit — abort
          // rather than ship a `referredBy` pointer with no counter bump.
          const e = new Error("invalid_referral_code") as Error & { code?: RegisterErr };
          e.code = "invalid_referral_code";
          throw e;
        }

        await tx.insert(transactionsTable).values({
          id: randomUUID(),
          userId: referrerId,
          type: "referral_reward",
          amountUsdt: REFERRAL_REWARD_USDT,
          amountThb: "0",
          rate: "0",
        });
      }
      return u;
    });
  } catch (err) {
    const code = (err as { code?: RegisterErr }).code;
    if (code === "invalid_otp") {
      res.status(400).json({ error: "invalid_otp", message: "OTP không hợp lệ hoặc đã hết hạn" });
      return;
    }
    if (code === "invalid_referral_code") {
      res.status(400).json({
        error: "invalid_referral_code",
        message: "Mã giới thiệu không tồn tại. Vui lòng kiểm tra lại.",
      });
      return;
    }
    throw err;
  }

  notifyAdminNewUser(user, "phone");

  const token = await issueSession(user.id);
  res.json({ ok: true, token, user: { id: user.id, name: user.name, nameUpdatedAt: user.nameUpdatedAt?.toISOString() ?? null, phone: user.phone, email: user.email || undefined, nickname: user.nickname, avatarUrl: user.avatarUrl, dob: user.dob, createdAt: user.createdAt.toISOString(), uid: user.uid, usdtBalance: parseFloat(user.usdtBalance), thbBalance: parseFloat(user.thbBalance) } });
});

// POST /auth/telegram — Telegram Login Widget callback. Verifies the
// HMAC hash with the bot token, then either logs in an existing user
// (matched by stable telegram_id, or a legacy private chat id — NOT username,
// which can change)
// or creates a fresh account in a single transaction. Optional
// `referralCode` activates the same referrer reward path used by the
// phone+OTP signup. Issues a JWT session on success exactly like the
// other auth flows so the client treats it identically.
router.post("/auth/telegram", async (req, res) => {
  const verified = verifyTelegramAuth(req.body);
  if (!verified.ok) {
    const status = verified.reason === "no_token" ? 503 : 401;
    res.status(status).json({
      error: verified.reason,
      message:
        verified.reason === "no_token"
          ? "Hệ thống chưa cấu hình bot Telegram. Liên hệ admin."
          : verified.reason === "expired"
            ? "Phiên đăng nhập Telegram đã hết hạn. Vui lòng thử lại."
            : "Xác thực Telegram thất bại. Vui lòng thử lại.",
    });
    return;
  }

  const { telegramId, telegramUsername, telegramFirstName, telegramPhotoUrl } = verified.data;
  const referralCode =
    typeof (req.body as { referralCode?: unknown })?.referralCode === "string"
      ? ((req.body as { referralCode?: string }).referralCode as string).trim()
      : "";

  // Match by stable telegram_id first. Older accounts linked through the
  // /otp flow may only have telegram_chat_id, so use that as a migration
  // fallback; the Telegram Login HMAC has already verified ownership of it.
  // Never match by username, which can change.
  const [existing] = await db
    .select()
    .from(usersTable)
    .where(or(eq(usersTable.telegramId, telegramId), eq(usersTable.telegramChatId, telegramId)))
    .limit(1);

  let user: typeof usersTable.$inferSelect;
  if (existing) {
    // Refresh cached profile fields so a renamed username / new photo
    // surfaces on the next page load. Never touch balances, password,
    // referral, or admin flags here.
    const [updated] = await db
      .update(usersTable)
      .set({
        telegramUsername,
        telegramFirstName,
        telegramPhotoUrl,
        // Telegram Login already proves ownership of this Telegram user.
        // Use the verified Telegram user id as the private chat target so
        // notifications work without a second manual "link Telegram"
        // step. Preserve an existing contact-share chat id when present.
        telegramChatId: existing.telegramChatId ?? telegramId,
        ...(telegramFirstName && existing.name === `User${existing.phone.slice(-4)}`
          ? { name: telegramFirstName }
          : {}),
      })
      .where(eq(usersTable.id, existing.id))
      .returning();
    user = updated ?? existing;
  } else {
    // Brand-new account. Phone + password_hash are NOT NULL in the
    // schema; we synthesize unique sentinel values so the DB constraints
    // are satisfied without claiming a real phone number that could
    // collide with a future SMS-based signup. The user can later add a
    // real phone via the existing settings flow.
    const REFERRAL_REWARD_USDT = "10";
    type TgRegErr = "invalid_referral_code";
    try {
      user = await db.transaction(async (tx) => {
        let referrerId: string | null = null;
        if (referralCode) {
          if (!/^098\d{6}$/.test(referralCode)) {
            const e = new Error("invalid_referral_code") as Error & { code?: TgRegErr };
            e.code = "invalid_referral_code";
            throw e;
          }
          const [referrer] = await tx
            .select({ id: usersTable.id })
            .from(usersTable)
            .where(eq(usersTable.uid, referralCode))
            .limit(1);
          if (!referrer) {
            const e = new Error("invalid_referral_code") as Error & { code?: TgRegErr };
            e.code = "invalid_referral_code";
            throw e;
          }
          referrerId = referrer.id;
        }

        const displayName =
          (telegramFirstName && telegramFirstName.trim()) ||
          (telegramUsername && telegramUsername.trim()) ||
          `TG${telegramId.slice(-4)}`;

        const [u] = await tx
          .insert(usersTable)
          .values({
            id: randomUUID(),
            name: displayName,
            // Synthetic placeholder — guaranteed unique because
            // telegram_id is unique. NOT a real phone number; the
            // normalize/login OTP paths reject `tg:` prefixes implicitly
            // (they require digits), so this row cannot be hijacked
            // through the SMS auth surface.
            phone: `tg:${telegramId}`,
            // Sentinel hash that bcrypt.compare will never accept (it
            // is not a valid bcrypt string), so password-based login is
            // effectively disabled until the user explicitly sets one.
            passwordHash: "!telegram-only!",
            telegramId,
            // A private Telegram user chat can be addressed by the verified
            // Telegram user id. This makes Telegram Login self-linking for
            // notifications; no separate notification connection prompt is
            // needed.
            telegramChatId: telegramId,
            telegramUsername,
            telegramFirstName,
            telegramPhotoUrl,
            verified: true,
            referredBy: referrerId,
          })
          .returning();

        if (referrerId) {
          const credited = await tx
            .update(usersTable)
            .set({
              referralRewardBalance: sql`${usersTable.referralRewardBalance} + ${REFERRAL_REWARD_USDT}::numeric`,
              totalReferralEarned: sql`${usersTable.totalReferralEarned} + ${REFERRAL_REWARD_USDT}::numeric`,
              referralCount: sql`${usersTable.referralCount} + 1`,
            })
            .where(eq(usersTable.id, referrerId))
            .returning({ id: usersTable.id });
          if (credited.length !== 1) {
            const e = new Error("invalid_referral_code") as Error & { code?: TgRegErr };
            e.code = "invalid_referral_code";
            throw e;
          }
          await tx.insert(transactionsTable).values({
            id: randomUUID(),
            userId: referrerId,
            type: "referral_reward",
            amountUsdt: REFERRAL_REWARD_USDT,
            amountThb: "0",
            rate: "0",
          });
        }
        return u;
      });
    } catch (err) {
      const code = (err as { code?: TgRegErr }).code;
      if (code === "invalid_referral_code") {
        res.status(400).json({
          error: "invalid_referral_code",
          message: "Mã giới thiệu không tồn tại. Vui lòng kiểm tra lại.",
        });
        return;
      }
      throw err;
    }
    // Only a brand-new Telegram-login account reaches here (the
    // `existing` branch returns early above), so this fires exactly
    // once per new customer.
    notifyAdminNewUser(user, "telegram");
  }

  const token = await issueSession(user.id);
  const admin = isAdminUser(user);
  res.json({
    ok: true,
    token,
    user: {
      id: user.id,
      name: user.name,
      nameUpdatedAt: user.nameUpdatedAt?.toISOString() ?? null,
      phone: user.phone.startsWith("tg:") ? undefined : user.phone,
      email: user.email || undefined,
      nickname: user.nickname,
      avatarUrl: user.avatarUrl ?? user.telegramPhotoUrl ?? undefined,
      dob: user.dob,
      createdAt: user.createdAt.toISOString(),
      isAdmin: admin,
      uid: user.uid,
      usdtBalance: parseFloat(user.usdtBalance),
      thbBalance: parseFloat(user.thbBalance),
      telegramId: user.telegramId ?? undefined,
      telegramUsername: user.telegramUsername ?? undefined,
      telegramFirstName: user.telegramFirstName ?? undefined,
      telegramPhotoUrl: user.telegramPhotoUrl ?? undefined,
    },
  });
});

router.post("/auth/reset-password", async (req, res) => {
  const parsed = ResetPasswordBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "All fields are required", details: parsed.error.flatten().fieldErrors });
    return;
  }
  const { phone, otp, newPassword } = parsed.data;
  const normalizedPhone = normalizePhone(phone);

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.phone, normalizedPhone))
    .limit(1);

  if (!user) {
    res.status(404).json({ error: "user_not_found", message: "Số điện thoại chưa đăng ký" });
    return;
  }

  const now = new Date();
  const [consumed] = await db
    .update(otpsTable)
    .set({ used: true })
    .where(
      and(
        eq(otpsTable.phone, normalizedPhone),
        eq(otpsTable.code, otp),
        eq(otpsTable.used, false),
        gt(otpsTable.expiresAt, now)
      )
    )
    .returning();

  if (!consumed) {
    res.status(400).json({ error: "invalid_otp", message: "OTP không hợp lệ hoặc đã hết hạn" });
    return;
  }

  const passwordHash = await bcrypt.hash(newPassword, 10);
  const [updated] = await db
    .update(usersTable)
    .set({ passwordHash })
    .where(eq(usersTable.id, user.id))
    .returning();

  const admin = isAdminUser(updated);
  const token = await issueSession(updated.id);
  res.json({ ok: true, token, user: { id: updated.id, name: updated.name, nameUpdatedAt: updated.nameUpdatedAt?.toISOString() ?? null, phone: updated.phone, email: updated.email || undefined, nickname: updated.nickname, avatarUrl: updated.avatarUrl, dob: updated.dob, createdAt: updated.createdAt.toISOString(), isAdmin: admin, uid: updated.uid, usdtBalance: parseFloat(updated.usdtBalance), thbBalance: parseFloat(updated.thbBalance) } });
});

// Two-phase login. Step 1 (`POST /auth/login`) verifies the password
// and dispatches a one-time OTP via Telegram. Step 2
// (`POST /auth/login/verify`) re-verifies password + OTP and only then
// issues the session token. This adds an out-of-band 2nd factor on
// every login, so a stolen password alone cannot grant access.
router.post("/auth/login", async (req, res) => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "phone and password required", details: parsed.error.flatten().fieldErrors });
    return;
  }
  const { phone, password } = parsed.data;
  const normalizedPhone = normalizePhone(phone);

  let [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.phone, normalizedPhone))
    .limit(1);

  // Founding-admin bootstrap: an env-pinned admin who has never logged
  // in has no row yet. Auto-create the row with their first password so
  // they can complete the OTP step and receive a session.
  if (!user && isAdminPhone(normalizedPhone)) {
    const passwordHash = await bcrypt.hash(password, 10);
    const [created] = await db.insert(usersTable).values({
      id: randomUUID(),
      name: "Admin",
      phone: normalizedPhone,
      passwordHash,
      telegramChatId: null,
      verified: true,
    }).returning();
    user = created;
  }

  if (!user) {
    res.status(401).json({ error: "invalid_credentials" });
    return;
  }

  const match = await bcrypt.compare(password, user.passwordHash);
  if (!match) {
    res.status(401).json({ error: "invalid_credentials" });
    return;
  }

  // Resolve OTP delivery target. Telegram Login users are already verified
  // as reachable private chats, so their telegramId is an automatic fallback.
  // Only env-bootstrap admins use the global ops chat as a final fallback.
  const deliveryChat = (user.telegramChatId ?? user.telegramId)
    ?? (isAdminPhone(normalizedPhone) ? (process.env.TELEGRAM_CHAT_ID ?? null) : null);

  if (!deliveryChat) {
    res.status(412).json({
      error: "telegram_not_linked",
      message: `Số ${normalizedPhone} chưa liên kết Telegram. Vui lòng nhắn /otp ${normalizedPhone} cho @AndersPayPlus_bot trước.`,
    });
    return;
  }

  // Invalidate any prior pending OTPs for this phone so only the
  // freshest code is valid.
  await db.delete(otpsTable).where(eq(otpsTable.phone, normalizedPhone));

  const otp = generateOtp();
  const expiresAt = new Date(Date.now() + 15 * 60 * 1000);
  await db.insert(otpsTable).values({
    id: randomUUID(),
    phone: normalizedPhone,
    code: otp,
    expiresAt,
  });

  const sent = await sendOtpViaTelegram(deliveryChat, otp);
  if (!sent.ok) {
    const desc = sent.reason === "telegram_error" ? sent.description ?? "" : "";
    const lower = desc.toLowerCase();
    let code = "otp_send_failed";
    let message = "Không gửi được OTP qua Telegram. Vui lòng thử lại sau.";
    if (sent.reason === "no_token") {
      code = "telegram_not_configured";
      message = "Hệ thống chưa cấu hình bot Telegram. Liên hệ admin.";
    } else if (lower.includes("bot was blocked") || lower.includes("forbidden")) {
      code = "telegram_blocked";
      message = "Bạn đã chặn bot @AndersPayPlus_bot. Vui lòng bỏ chặn rồi thử lại.";
    } else if (lower.includes("chat not found")) {
      code = "telegram_chat_not_found";
      message = `Chat Telegram không tồn tại. Vui lòng nhắn /otp ${normalizedPhone} cho @AndersPayPlus_bot để liên kết lại.`;
    }
    res.status(502).json({ error: code, message, description: desc || undefined });
    return;
  }

  res.json({ ok: true, otpRequired: true });
});

// Step 2 of login. Re-checks the password (so a leaked OTP alone is
// useless) and consumes the OTP atomically before issuing a session.
router.post("/auth/login/verify", async (req, res) => {
  const phone = typeof req.body?.phone === "string" ? req.body.phone : "";
  const password = typeof req.body?.password === "string" ? req.body.password : "";
  const otp = typeof req.body?.otp === "string" ? req.body.otp : "";
  if (!phone || !password || !otp) {
    res.status(400).json({ error: "phone, password and otp required" });
    return;
  }
  const normalizedPhone = normalizePhone(phone);

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.phone, normalizedPhone))
    .limit(1);

  if (!user) {
    res.status(401).json({ error: "invalid_credentials" });
    return;
  }

  const match = await bcrypt.compare(password, user.passwordHash);
  if (!match) {
    res.status(401).json({ error: "invalid_credentials" });
    return;
  }

  const now = new Date();
  const [consumed] = await db
    .update(otpsTable)
    .set({ used: true })
    .where(
      and(
        eq(otpsTable.phone, normalizedPhone),
        eq(otpsTable.code, otp),
        eq(otpsTable.used, false),
        gt(otpsTable.expiresAt, now),
      ),
    )
    .returning();

  if (!consumed) {
    res.status(400).json({ error: "invalid_otp", message: "OTP không hợp lệ hoặc đã hết hạn" });
    return;
  }

  const token = await issueSession(user.id);
  const admin = isAdminUser(user);
  res.json({ ok: true, token, user: { id: user.id, name: user.name, nameUpdatedAt: user.nameUpdatedAt?.toISOString() ?? null, phone: user.phone, email: user.email || undefined, nickname: user.nickname, avatarUrl: user.avatarUrl, dob: user.dob, createdAt: user.createdAt.toISOString(), isAdmin: admin, uid: user.uid, usdtBalance: parseFloat(user.usdtBalance), thbBalance: parseFloat(user.thbBalance) } });
});

// POST /auth/telegram-otp/verify — password-free Telegram OTP login/registration.
// The caller first obtains an OTP via POST /auth/send-otp (which requires the
// phone to be linked in telegramLinksTable). This endpoint then:
//   • verifies the OTP atomically (same table + TTL as the password flow),
//   • if the phone already has an account → issues a JWT session (login),
//   • if no account exists → auto-creates one with a random passwordHash and
//     issues a JWT session (registration, no password needed by the user).
// `referralCode` is optional; works identically to POST /auth/register.
router.post("/auth/telegram-otp/verify", async (req, res) => {
  const phone = typeof req.body?.phone === "string" ? req.body.phone : "";
  const otp = typeof req.body?.otp === "string" ? req.body.otp : "";
  const referralCode =
    typeof req.body?.referralCode === "string" && req.body.referralCode
      ? req.body.referralCode
      : undefined;

  if (!phone || !otp) {
    res.status(400).json({ error: "phone_and_otp_required", message: "Vui lòng cung cấp số điện thoại và OTP." });
    return;
  }
  const normalizedPhone = normalizePhone(phone);

  const now = new Date();
  const [consumed] = await db
    .update(otpsTable)
    .set({ used: true })
    .where(
      and(
        eq(otpsTable.phone, normalizedPhone),
        eq(otpsTable.code, otp),
        eq(otpsTable.used, false),
        gt(otpsTable.expiresAt, now),
      ),
    )
    .returning();

  if (!consumed) {
    res.status(400).json({ error: "invalid_otp", message: "OTP không hợp lệ hoặc đã hết hạn" });
    return;
  }

  // Fetch telegram link so we can backfill telegramChatId for new or
  // existing accounts that were created before the link table existed.
  const [link] = await db
    .select()
    .from(telegramLinksTable)
    .where(eq(telegramLinksTable.phone, normalizedPhone))
    .limit(1);

  let [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.phone, normalizedPhone))
    .limit(1);

  let isNew = false;

  if (!user) {
    // Auto-register: generate a random cryptographic password so the
    // users.password_hash NOT NULL constraint is satisfied, but the user
    // never needs to know or enter this value — OTP is the auth factor.
    const passwordHash = await bcrypt.hash(randomUUID(), 10);
    const defaultName = `User${normalizedPhone.slice(-4)}`;

    const REFERRAL_REWARD_USDT = "10";
    type RegisterErr = "invalid_referral_code";

    try {
      user = await db.transaction(async (tx) => {
        let referrerId: string | null = null;
        if (referralCode) {
          const [referrer] = await tx
            .select({ id: usersTable.id })
            .from(usersTable)
            .where(eq(usersTable.uid, referralCode))
            .limit(1);
          if (!referrer) {
            const e = new Error("invalid_referral_code") as Error & { code?: RegisterErr };
            e.code = "invalid_referral_code";
            throw e;
          }
          referrerId = referrer.id;
        }

        const [u] = await tx.insert(usersTable).values({
          id: randomUUID(),
          name: defaultName,
          phone: normalizedPhone,
          passwordHash,
          telegramChatId: link?.chatId ?? null,
          verified: true,
          referredBy: referrerId,
        }).returning();

        if (referrerId) {
          const credited = await tx
            .update(usersTable)
            .set({
              referralRewardBalance: sql`${usersTable.referralRewardBalance} + ${REFERRAL_REWARD_USDT}::numeric`,
              totalReferralEarned: sql`${usersTable.totalReferralEarned} + ${REFERRAL_REWARD_USDT}::numeric`,
              referralCount: sql`${usersTable.referralCount} + 1`,
            })
            .where(eq(usersTable.id, referrerId))
            .returning({ id: usersTable.id });
          if (credited.length !== 1) {
            const e = new Error("invalid_referral_code") as Error & { code?: RegisterErr };
            e.code = "invalid_referral_code";
            throw e;
          }
          await tx.insert(transactionsTable).values({
            id: randomUUID(),
            userId: referrerId,
            type: "referral_reward",
            amountUsdt: REFERRAL_REWARD_USDT,
            amountThb: "0",
            rate: "0",
          });
        }
        return u;
      });
    } catch (err) {
      const code = (err as { code?: RegisterErr }).code;
      if (code === "invalid_referral_code") {
        res.status(400).json({
          error: "invalid_referral_code",
          message: "Mã giới thiệu không tồn tại. Vui lòng kiểm tra lại.",
        });
        return;
      }
      throw err;
    }

    isNew = true;
    notifyAdminNewUser(user, "phone");
  } else {
    // Existing user — backfill telegramChatId when missing so future OTP
    // deliveries work even if the link was established after account creation.
    if (!user.telegramChatId && link?.chatId) {
      const [updated] = await db
        .update(usersTable)
        .set({ telegramChatId: link.chatId })
        .where(eq(usersTable.id, user.id))
        .returning();
      user = updated;
    }
  }

  const admin = isAdminUser(user);
  const token = await issueSession(user.id);
  res.json({
    ok: true,
    isNew,
    token,
    user: {
      id: user.id,
      name: user.name,
      nameUpdatedAt: user.nameUpdatedAt?.toISOString() ?? null,
      phone: user.phone,
      email: user.email || undefined,
      nickname: user.nickname,
      avatarUrl: user.avatarUrl,
      dob: user.dob,
      createdAt: user.createdAt.toISOString(),
      isAdmin: admin,
      uid: user.uid,
      usdtBalance: parseFloat(user.usdtBalance),
      thbBalance: parseFloat(user.thbBalance),
    },
  });
});

// GET /auth/me — return the current user with a *freshly computed*
// isAdmin. The client caches the user object in localStorage, so when
// the owner promotes someone to admin (or revokes it) the cached flag
// goes stale. The app calls this on load to pick up role changes
// without forcing a re-login, so a newly-added admin immediately gets
// full admin access (and loses the customer-only screens).
router.get("/auth/me", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId))
    .limit(1);
  if (!user) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const admin = isAdminUser(user);
  res.json({ ok: true, user: { id: user.id, name: user.name, nameUpdatedAt: user.nameUpdatedAt?.toISOString() ?? null, phone: user.phone.startsWith("tg:") ? undefined : user.phone, email: user.email || undefined, emailVerified: user.emailVerified, nickname: user.nickname, avatarUrl: user.avatarUrl ?? user.telegramPhotoUrl ?? undefined, dob: user.dob, createdAt: user.createdAt.toISOString(), isAdmin: admin, uid: user.uid, usdtBalance: parseFloat(user.usdtBalance), thbBalance: parseFloat(user.thbBalance), telegramId: user.telegramId ?? undefined, telegramUsername: user.telegramUsername ?? undefined, telegramFirstName: user.telegramFirstName ?? undefined, telegramPhotoUrl: user.telegramPhotoUrl ?? undefined } });
});

// POST /auth/account/delete-otp — send a 6-digit OTP via Telegram to
// the currently logged-in user's linked chat. Used as the second
// confirmation factor for permanent account deletion. Requires JWT.
router.post("/auth/account/delete-otp", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId))
    .limit(1);
  if (!user) {
    res.status(404).json({ error: "user_not_found" });
    return;
  }
  const [link] = await db
    .select()
    .from(telegramLinksTable)
    .where(eq(telegramLinksTable.phone, user.phone))
    .limit(1);
  const chatId = link?.chatId || getTelegramChatId(user);
  const canEmail = !chatId && user.emailVerified && user.email;
  if (!chatId && !canEmail) {
    res.status(404).json({
      error: "telegram_not_linked",
      message: `Số ${user.phone} chưa liên kết Telegram. Không thể gửi OTP xác minh xóa tài khoản.`,
    });
    return;
  }

  await db.delete(otpsTable).where(eq(otpsTable.phone, user.phone));
  const otp = generateOtp();
  await db.insert(otpsTable).values({
    id: randomUUID(),
    phone: user.phone,
    code: otp,
    expiresAt: new Date(Date.now() + 15 * 60 * 1000),
  });
  // Email-only accounts (synthetic em:<uuid> phone, no Telegram link)
  // receive the deletion OTP at their verified email instead.
  if (canEmail) {
    try {
      await sendEmail({
        to: user.email!,
        subject: "Your AndersPay+ Verification Code",
        html: otpEmailHtml(otp),
        text: otpEmailText(otp),
      });
      res.json({ ok: true, channel: "email" });
    } catch {
      res.status(502).json({ error: "email_send_failed", message: "Không gửi được OTP qua email. Vui lòng thử lại sau." });
    }
    return;
  }
  const sent = await sendOtpViaTelegram(chatId!, otp);
  if (!sent.ok) {
    res.status(502).json({
      error: "telegram_send_failed",
      message: "Không gửi được OTP qua Telegram. Vui lòng thử lại sau.",
    });
    return;
  }
  res.json({ ok: true });
});

// DELETE /auth/account — verify the OTP issued by /auth/account/delete-otp
// and permanently wipe the account: transactions, webauthn credentials,
// support messages, orders, OTPs, telegram link, and finally the user
// row itself. Logged out client-side after success. Requires JWT.
router.delete("/auth/account", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const otp = String((req.body as { otp?: unknown })?.otp ?? "").trim();
  if (!/^\d{6}$/.test(otp)) {
    res.status(400).json({ error: "invalid_otp", message: "OTP không hợp lệ" });
    return;
  }
  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId))
    .limit(1);
  if (!user) {
    res.status(404).json({ error: "user_not_found" });
    return;
  }

  const now = new Date();
  const [consumed] = await db
    .update(otpsTable)
    .set({ used: true })
    .where(
      and(
        eq(otpsTable.phone, user.phone),
        eq(otpsTable.code, otp),
        eq(otpsTable.used, false),
        gt(otpsTable.expiresAt, now),
      ),
    )
    .returning();
  if (!consumed) {
    res.status(400).json({ error: "invalid_otp", message: "OTP không hợp lệ hoặc đã hết hạn" });
    return;
  }

  // Cascading wipe — orders + transactions + support + webauthn + otp
  // rows + the telegram link, then the user row itself. There are no
  // hard FKs in the schema so order doesn't matter for integrity, but
  // we wrap everything in a transaction so a partial failure can't
  // leave orphaned rows behind.
  await db.transaction(async (tx) => {
    await tx.delete(transactionsTable).where(eq(transactionsTable.userId, user.id));
    await tx.delete(webauthnCredentialsTable).where(eq(webauthnCredentialsTable.userId, user.id));
    await tx.delete(supportMessagesTable).where(eq(supportMessagesTable.userId, user.id));
    await tx.delete(ordersTable).where(eq(ordersTable.userId, user.id));
    await tx.delete(otpsTable).where(eq(otpsTable.phone, user.phone));
    await tx.delete(telegramLinksTable).where(eq(telegramLinksTable.phone, user.phone));
    await tx.delete(usersTable).where(eq(usersTable.id, user.id));
  });

  const display = user.nickname?.trim() || user.name;
  sendTelegramMessage(
    `🗑️ <b>TÀI KHOẢN ĐÃ TỰ XÓA VĨNH VIỄN</b>\n\n` +
      `👤 <b>${display}</b> (<code>${user.phone}</code>)\n` +
      `🕒 ${new Date().toLocaleString("vi-VN", { timeZone: "Asia/Bangkok" })} (ICT)`,
  ).catch(() => {});

  req.log?.warn?.({ userId: user.id, phone: user.phone }, "account_self_deleted");
  res.json({ ok: true });
});

export default router;
