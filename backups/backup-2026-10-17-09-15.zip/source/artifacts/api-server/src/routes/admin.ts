import { Router } from "express";
import {
  db,
  usersTable,
  transactionsTable,
  ordersTable,
  supportMessagesTable,
  webauthnCredentialsTable,
  otpsTable,
  telegramLinksTable,
  broadcastsTable,
} from "@workspace/db";
import { eq, desc, sql, inArray, notInArray, and, or, isNull } from "drizzle-orm";
import { authenticateRequest } from "../lib/jwt";
import { getAdminPhones, isAdminUser } from "../lib/admin";
import { TESTER_USER_IDS, TESTER_USER_PHONES } from "../lib/tester-accounts";
import { verifyDestructiveKey } from "../lib/destructive-key";
import { sendTelegramMessage, sendTelegramMessageWithBot } from "../lib/telegram";
import { sendBalanceBackupReport } from "../lib/balance-backup";

const router = Router();

// "Online" window: how recently lastSeenAt must be updated for a user to
// count as currently using the app. /api/wallet polls every 5s, so a 90s
// window comfortably tolerates network jitter and tab switches.
const ONLINE_WINDOW_MS = 90 * 1000;

// GET /admin/users — admin-only directory with online status.
// Auth: Bearer JWT whose user.phone is in ADMIN_PHONES.
router.get("/admin/users", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ message: "unauthorized", code: "UNAUTHORIZED" });
    return;
  }

  const [me] = await db
    .select({ phone: usersTable.phone, isAdmin: usersTable.isAdmin })
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId))
    .limit(1);

  if (!me || !isAdminUser(me)) {
    res.status(403).json({ message: "Forbidden: admin only", code: "FORBIDDEN" });
    return;
  }

  const rows = await db
    .select({
      id: usersTable.id,
      uid: usersTable.uid,
      name: usersTable.name,
      nickname: usersTable.nickname,
      phone: usersTable.phone,
      avatarUrl: usersTable.avatarUrl,
      usdtBalance: usersTable.usdtBalance,
      thbBalance: usersTable.thbBalance,
      lastSeenAt: usersTable.lastSeenAt,
      createdAt: usersTable.createdAt,
      isAdmin: usersTable.isAdmin,
    })
    .from(usersTable)
    .where(
      and(
        notInArray(usersTable.id, TESTER_USER_IDS),
        notInArray(usersTable.phone, TESTER_USER_PHONES),
      ),
    )
    .orderBy(desc(usersTable.lastSeenAt));

  const now = Date.now();
  const adminPhoneSet = new Set(getAdminPhones());
  const users = rows.map((u) => ({
    id: u.id,
    uid: u.uid,
    name: u.name,
    nickname: u.nickname,
    phone: u.phone,
    avatarUrl: u.avatarUrl,
    usdtBalance: parseFloat(u.usdtBalance),
    thbBalance: parseFloat(u.thbBalance),
    lastSeenAt: u.lastSeenAt ? u.lastSeenAt.toISOString() : null,
    createdAt: u.createdAt.toISOString(),
    online: u.lastSeenAt ? now - u.lastSeenAt.getTime() < ONLINE_WINDOW_MS : false,
    isAdmin: adminPhoneSet.has(u.phone) || u.isAdmin,
    // Founding admins (configured via ADMIN_PHONES env) cannot be
    // demoted from the UI — only the DB-promoted admins are toggleable.
    isFoundingAdmin: adminPhoneSet.has(u.phone),
  }));

  res.json({
    onlineCount: users.filter((u) => u.online).length,
    total: users.length,
    users,
  });
});

// GET /admin/transactions — admin-only unified activity feed.
//
// The historical version of this endpoint only read the ledger
// (`transactions` table), which is populated when an order is settled
// (paid/confirmed/converted/refunded). After `POST /admin/balances/wipe`
// — or any window where most orders are still pending — the ledger
// looks empty, so the admin UI showed "no transactions" even though
// the `orders` table was full. We now merge BOTH sources so the admin
// sees every member activity with its current status:
//
//   • orders   → one row per order (status: pending/paid/completed/
//     expired/refunded), type derived from whether it's a topup (no
//     destination bank) or a THB payment.
//   • ledger   → one row per ledger entry (status: "settled"),
//     preserving the previous behaviour for completed flows.
//
// Both streams are joined to `users` so the UI can render UID + name
// + avatar without a second round-trip. Guest orders (user_id IS NULL)
// are still surfaced — they're the bulk of pending traffic and admins
// need visibility into them.
router.get("/admin/transactions", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ message: "unauthorized", code: "UNAUTHORIZED" });
    return;
  }

  const [me] = await db
    .select({ phone: usersTable.phone, isAdmin: usersTable.isAdmin })
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId))
    .limit(1);

  if (!me || !isAdminUser(me)) {
    res.status(403).json({ message: "Forbidden: admin only", code: "FORBIDDEN" });
    return;
  }

  const limitRaw = Number(req.query.limit ?? 200);
  const limit = Math.min(Math.max(Number.isFinite(limitRaw) ? limitRaw : 200, 1), 500);

  // Optional `?userId=<uuid>` filter — used by the per-user "Sao kê"
  // (statement) view on the admin dashboard. Without this, the
  // statement would only see rows that happen to fall inside the
  // most-recent `limit` window of the global feed, which can hide
  // older activity entirely for less-active users.
  const userIdFilter =
    typeof req.query.userId === "string" && req.query.userId.length > 0
      ? req.query.userId
      : null;

  // Always exclude tester/internal accounts from the admin feed.
  // or(isNull, notInArray) keeps guest orders (userId=null) visible while
  // dropping any row whose userId is in TESTER_USER_IDS.
  const noTesterOrder = or(
    isNull(ordersTable.userId),
    and(
      notInArray(ordersTable.userId, TESTER_USER_IDS),
      notInArray(usersTable.phone, TESTER_USER_PHONES),
    ),
  );
  const noTesterTx = or(
    isNull(transactionsTable.userId),
    and(
      notInArray(transactionsTable.userId, TESTER_USER_IDS),
      notInArray(usersTable.phone, TESTER_USER_PHONES),
    ),
  );

  const orderWhere = userIdFilter ? and(eq(ordersTable.userId, userIdFilter), noTesterOrder) : noTesterOrder;
  const txWhere = userIdFilter ? and(eq(transactionsTable.userId, userIdFilter), noTesterTx) : noTesterTx;

  // Fan-out the two reads in parallel and over-fetch each stream up
  // to `limit` so the merged feed can fairly pick the newest rows
  // regardless of source.
  const [orderRows, txRows] = await Promise.all([
    db
      .select({
        id: ordersTable.id,
        orderId: ordersTable.orderId,
        userId: ordersTable.userId,
        amountUsdt: ordersTable.amountUsdt,
        amountThb: ordersTable.amountThb,
        rate: ordersTable.exchangeRate,
        bankName: ordersTable.bankName,
        bahtSource: ordersTable.bahtSource,
        bahtSourceName: ordersTable.bahtSourceName,
        status: ordersTable.status,
        createdAt: ordersTable.createdAt,
        userUid: usersTable.uid,
        userName: usersTable.name,
        userNickname: usersTable.nickname,
        userPhone: usersTable.phone,
        userAvatarUrl: usersTable.avatarUrl,
      })
      .from(ordersTable)
      .leftJoin(usersTable, eq(usersTable.id, ordersTable.userId))
      .where(orderWhere)
      .orderBy(desc(ordersTable.createdAt))
      .limit(limit),
    db
      .select({
        id: transactionsTable.id,
        userId: transactionsTable.userId,
        type: transactionsTable.type,
        amountUsdt: transactionsTable.amountUsdt,
        amountThb: transactionsTable.amountThb,
        rate: transactionsTable.rate,
        refOrderId: transactionsTable.refOrderId,
        createdAt: transactionsTable.createdAt,
        userUid: usersTable.uid,
        userName: usersTable.name,
        userNickname: usersTable.nickname,
        userPhone: usersTable.phone,
        userAvatarUrl: usersTable.avatarUrl,
      })
      .from(transactionsTable)
      .leftJoin(usersTable, eq(usersTable.id, transactionsTable.userId))
      .where(txWhere)
      .orderBy(desc(transactionsTable.createdAt))
      .limit(limit),
  ]);

  const ordersMapped = orderRows.map((r) => ({
    id: r.id,
    code: r.orderId,
    source: "order" as const,
    // Topup orders are created with empty bank/account fields (see
    // `POST /orders/topup` in routes/orders.ts). Use that to split
    // them from THB-payment orders without a separate `kind` column.
    type: (r.bankName && r.bankName.length > 0 ? "order_payment" : "order_topup") as
      | "order_payment"
      | "order_topup",
    userId: r.userId,
    amountUsdt: parseFloat(r.amountUsdt),
    amountThb: parseFloat(r.amountThb),
    rate: parseFloat(r.rate),
    bahtSource: r.bahtSource,
    bahtSourceName: r.bahtSourceName,
    refOrderId: r.orderId,
    status: r.status as string,
    createdAt: r.createdAt.toISOString(),
    user: {
      uid: r.userUid,
      name: r.userName,
      nickname: r.userNickname,
      phone: r.userPhone,
      avatarUrl: r.userAvatarUrl,
    },
  }));

  const txMapped = txRows.map((r) => ({
    id: r.id,
    code: r.id,
    source: "ledger" as const,
    type: r.type,
    userId: r.userId,
    amountUsdt: parseFloat(r.amountUsdt),
    amountThb: parseFloat(r.amountThb),
    rate: parseFloat(r.rate),
    refOrderId: r.refOrderId,
    status: "settled" as const,
    createdAt: r.createdAt.toISOString(),
    user: {
      uid: r.userUid,
      name: r.userName,
      nickname: r.userNickname,
      phone: r.userPhone,
      avatarUrl: r.userAvatarUrl,
    },
  }));

  const merged = [...ordersMapped, ...txMapped]
    .sort((a, b) => (a.createdAt < b.createdAt ? 1 : a.createdAt > b.createdAt ? -1 : 0))
    .slice(0, limit);

  res.json({
    total: merged.length,
    orderCount: ordersMapped.length,
    ledgerCount: txMapped.length,
    transactions: merged,
  });
});

// POST /admin/transactions/report — send a transaction history summary to the
// Admin report group (TELEGRAM_ADMIN_REPORT_CHAT_ID), sent by the dedicated
// report bot (TELEGRAM_ADMIN_REPORT_BOT_TOKEN). Admin-only. No destructive
// key required — read-only action.
router.post("/admin/transactions/report", async (req, res) => {
  const category = req.body?.category;
  const categoryTypes: Record<string, string[]> = {
    topup: ["deposit", "topup_fee", "order_topup"],
    convert: ["convert_in", "convert_out"],
    payment: ["payment", "payment_fee", "payment_refund", "payment_refund_reversal", "order_payment"],
  };
  if (typeof category !== "string" || !categoryTypes[category]) {
    res.status(400).json({
      message: "A valid report category is required",
      code: "INVALID_CATEGORY",
    });
    return;
  }

  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ message: "unauthorized", code: "UNAUTHORIZED" });
    return;
  }

  const [me] = await db
    .select({ phone: usersTable.phone, isAdmin: usersTable.isAdmin, name: usersTable.name, nickname: usersTable.nickname })
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId))
    .limit(1);

  if (!me || !isAdminUser(me)) {
    res.status(403).json({ message: "Forbidden: admin only", code: "FORBIDDEN" });
    return;
  }

  // Fetch the 50 most recent transactions (merged orders + ledger, same as GET)
  const REPORT_LIMIT = 50;
  const [orderRows, txRows] = await Promise.all([
    db
      .select({
        id: ordersTable.id,
        orderId: ordersTable.orderId,
        userId: ordersTable.userId,
        amountUsdt: ordersTable.amountUsdt,
        amountThb: ordersTable.amountThb,
        bankName: ordersTable.bankName,
        status: ordersTable.status,
        createdAt: ordersTable.createdAt,
        userUid: usersTable.uid,
        userName: usersTable.name,
        userNickname: usersTable.nickname,
      })
      .from(ordersTable)
      .leftJoin(usersTable, eq(usersTable.id, ordersTable.userId))
      .where(
        or(
          isNull(ordersTable.userId),
          and(
            notInArray(ordersTable.userId, TESTER_USER_IDS),
            notInArray(usersTable.phone, TESTER_USER_PHONES),
          ),
        ),
      )
      .orderBy(desc(ordersTable.createdAt))
      .limit(REPORT_LIMIT),
    db
      .select({
        id: transactionsTable.id,
        type: transactionsTable.type,
        amountUsdt: transactionsTable.amountUsdt,
        amountThb: transactionsTable.amountThb,
        createdAt: transactionsTable.createdAt,
        userUid: usersTable.uid,
        userName: usersTable.name,
        userNickname: usersTable.nickname,
      })
      .from(transactionsTable)
      .leftJoin(usersTable, eq(usersTable.id, transactionsTable.userId))
      .where(
        or(
          isNull(transactionsTable.userId),
          and(
            notInArray(transactionsTable.userId, TESTER_USER_IDS),
            notInArray(usersTable.phone, TESTER_USER_PHONES),
          ),
        ),
      )
      .orderBy(desc(transactionsTable.createdAt))
      .limit(REPORT_LIMIT),
  ]);

  type ReportRow = {
    category: "topup" | "convert" | "payment" | "other";
    label: string;
    sign: string;
    amountUsdt: number;
    amountThb: number;
    name: string;
    uid: string | null;
    status: string;
    createdAt: Date;
  };

  const TYPE_LABELS: Record<string, string> = {
    deposit: "Nạp USDT", convert_in: "Đổi→THB", convert_out: "Đổi←USDT",
    topup_fee: "Phí nạp", payment_fee: "Phí TT", payment: "Thanh toán",
    payment_refund: "Hoàn tiền", payment_refund_reversal: "Đảo hoàn tiền", referral_reward: "Thưởng GT",
    order_topup: "Lệnh nạp", order_payment: "Lệnh TT THB",
  };
  const STATUS_LABELS: Record<string, string> = {
    pending: "Chờ", paid: "Đã CK", completed: "Hoàn tất",
    expired: "Hết hạn", refunded: "Đã hoàn", settled: "Đã ghi sổ",
  };

  const ordersMapped: ReportRow[] = orderRows.map((r) => ({
    category: r.bankName && r.bankName.length > 0 ? "payment" : "topup",
    label: r.bankName && r.bankName.length > 0 ? "Lệnh TT THB" : "Lệnh nạp",
    sign: r.bankName && r.bankName.length > 0 ? "-" : "+",
    amountUsdt: parseFloat(r.amountUsdt),
    amountThb: parseFloat(r.amountThb),
    name: r.userNickname?.trim() || r.userName || "Khách",
    uid: r.userUid,
    status: STATUS_LABELS[r.status] ?? r.status,
    createdAt: r.createdAt,
  }));

  const txMapped: ReportRow[] = txRows.map((r) => ({
    category: ["convert_in", "convert_out"].includes(r.type)
      ? "convert"
      : ["payment", "payment_fee", "payment_refund", "payment_refund_reversal", "order_payment"].includes(r.type)
        ? "payment"
        : ["deposit", "topup_fee"].includes(r.type)
          ? "topup"
          : "other",
    label: TYPE_LABELS[r.type] ?? r.type,
    sign: ["deposit", "convert_in", "payment_refund", "referral_reward", "order_topup"].includes(r.type) ? "+" : "-",
    amountUsdt: parseFloat(r.amountUsdt),
    amountThb: parseFloat(r.amountThb),
    name: r.userNickname?.trim() || r.userName || "Khách",
    uid: r.userUid,
    status: "Đã ghi sổ",
    createdAt: r.createdAt,
  }));

  const merged = [...ordersMapped, ...txMapped]
    .filter((row) => row.category === category)
    .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
    .slice(0, 25);

  const CATEGORY_LABELS: Record<string, string> = {
    topup: "Lệnh nạp + phí nạp",
    convert: "Lệnh đổi → THB",
    payment: "Lệnh thanh toán + phí giao dịch",
  };

  // Format timestamp in ICT (UTC+7)
  const now = new Date();
  const ict = new Date(now.getTime() + 7 * 60 * 60 * 1000);
  const pad = (n: number) => String(n).padStart(2, "0");
  const ts = `${pad(ict.getUTCDate())}/${pad(ict.getUTCMonth() + 1)}/${ict.getUTCFullYear()} ${pad(ict.getUTCHours())}:${pad(ict.getUTCMinutes())} ICT`;

  const senderName = me.nickname?.trim() || me.name || me.phone;

  const lines = merged.map((r) => {
    const usdtPart = r.amountUsdt > 0 ? ` ${r.sign}${r.amountUsdt.toFixed(4)} USDT` : "";
    const thbPart = r.amountThb > 0 ? ` ${r.sign}${r.amountThb.toLocaleString("th-TH", { maximumFractionDigits: 0 })} THB` : "";
    const uidTag = r.uid ? ` <code>#${r.uid}</code>` : "";
    return `• <b>${r.name}</b>${uidTag} — ${r.label} [${r.status}]${usdtPart}${thbPart}`;
  });

  const text =
    `📊 <b>Báo cáo ${CATEGORY_LABELS[category]}</b>\n` +
    `📅 ${ts}  |  👤 Gửi bởi: ${senderName}\n` +
    `📌 Hiển thị ${merged.length} giao dịch gần nhất\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    lines.join("\n");

  const ok = await sendTelegramMessageWithBot(
    text,
    process.env.TELEGRAM_ADMIN_REPORT_BOT_TOKEN,
    process.env.TELEGRAM_ADMIN_REPORT_CHAT_ID,
  );
  if (!ok) {
    res.status(500).json({ message: "Telegram send failed", code: "TELEGRAM_ERROR" });
    return;
  }

  res.json({ ok: true, sent: merged.length });
});

// POST /admin/users/:userId/role — promote / demote a user to admin.
//
// Authorisation: caller must be a current admin (founding or promoted)
// AND must include the destructive operator key in the
// `X-Destructive-Key` header. The key is intentionally a separate
// secret from the admin JWT so a stolen session cannot grant new
// admins on its own.
//
// Body: { isAdmin: boolean }
//
// Founding admins (ADMIN_PHONES env) cannot be demoted via this
// endpoint — they are bootstrap principals.
//
// On success, fires a Telegram notification to the configured admin
// chat so the team can audit role changes out-of-band.
router.post("/admin/users/:userId/role", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ message: "unauthorized", code: "UNAUTHORIZED" });
    return;
  }

  const [me] = await db
    .select({ id: usersTable.id, phone: usersTable.phone, isAdmin: usersTable.isAdmin, name: usersTable.name, nickname: usersTable.nickname })
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId))
    .limit(1);

  if (!me || !isAdminUser(me)) {
    res.status(403).json({ message: "Forbidden: admin only", code: "FORBIDDEN" });
    return;
  }

  if (!verifyDestructiveKey(req)) {
    res.status(403).json({ message: "Operator key required", code: "DESTRUCTIVE_KEY_REQUIRED" });
    return;
  }

  const targetId = req.params.userId;
  const desired = req.body?.isAdmin;
  if (typeof desired !== "boolean") {
    res.status(400).json({ message: "isAdmin (boolean) required", code: "BAD_REQUEST" });
    return;
  }

  const [target] = await db
    .select({ id: usersTable.id, phone: usersTable.phone, name: usersTable.name, nickname: usersTable.nickname, isAdmin: usersTable.isAdmin })
    .from(usersTable)
    .where(eq(usersTable.id, targetId))
    .limit(1);

  if (!target) {
    res.status(404).json({ message: "User not found", code: "NOT_FOUND" });
    return;
  }

  // Defense in depth: an admin must not be able to demote themselves
  // via the API, even if the UI button is hidden. Prevents accidental
  // self-lockout when only one promoted admin exists.
  if (target.id === me.id) {
    res.status(409).json({ message: "You cannot change your own admin role", code: "SELF_TOGGLE" });
    return;
  }

  // Founding admins are immutable — they're declared in env, not DB.
  if (getAdminPhones().includes(target.phone)) {
    res.status(409).json({ message: "Founding admins cannot be modified here", code: "FOUNDING_ADMIN" });
    return;
  }

  // No-op short-circuit so we don't spam Telegram on accidental retries.
  if (target.isAdmin === desired) {
    res.json({ ok: true, isAdmin: desired, changed: false });
    return;
  }

  await db.update(usersTable).set({ isAdmin: desired }).where(eq(usersTable.id, target.id));

  const targetDisplay = target.nickname?.trim() || target.name;
  const actorDisplay = me.nickname?.trim() || me.name;
  const action = desired ? "ĐÃ NÂNG QUYỀN ADMIN" : "ĐÃ GỠ QUYỀN ADMIN";
  const msg =
    `🛡️ <b>${action}</b>\n\n` +
    `Người dùng: <b>${targetDisplay}</b>\n` +
    `SĐT: <code>${target.phone}</code>\n` +
    `Bởi: ${actorDisplay} (${me.phone})\n` +
    `Lúc: ${new Date().toISOString()}`;
  // Fire-and-forget: do not block the HTTP response on Telegram.
  sendTelegramMessage(msg).catch(() => {});

  req.log?.info?.(
    { actorId: me.id, targetId: target.id, desired },
    desired ? "admin_promoted" : "admin_demoted",
  );

  res.json({ ok: true, isAdmin: desired, changed: true });
});

// DELETE /admin/users/:userId — permanently remove a member and all the
// rows they own (orders, ledger entries, support thread, passkeys, OTPs,
// Telegram link). Intended for cleaning out long-inactive accounts.
// Irreversible. Requires admin JWT + the destructive operator key
// (X-Destructive-Key), mirroring the role-toggle / balance-wipe flows.
router.delete("/admin/users/:userId", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ message: "unauthorized", code: "UNAUTHORIZED" });
    return;
  }

  const [me] = await db
    .select({ id: usersTable.id, phone: usersTable.phone, isAdmin: usersTable.isAdmin, name: usersTable.name, nickname: usersTable.nickname })
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId))
    .limit(1);

  if (!me || !isAdminUser(me)) {
    res.status(403).json({ message: "Forbidden: admin only", code: "FORBIDDEN" });
    return;
  }

  if (!verifyDestructiveKey(req)) {
    res.status(403).json({ message: "Operator key required", code: "DESTRUCTIVE_KEY_REQUIRED" });
    return;
  }

  const targetId = req.params.userId;

  const [target] = await db
    .select({ id: usersTable.id, phone: usersTable.phone, name: usersTable.name, nickname: usersTable.nickname, isAdmin: usersTable.isAdmin })
    .from(usersTable)
    .where(eq(usersTable.id, targetId))
    .limit(1);

  if (!target) {
    res.status(404).json({ message: "User not found", code: "NOT_FOUND" });
    return;
  }

  // Defense in depth: an admin must not be able to delete themselves.
  if (target.id === me.id) {
    res.status(409).json({ message: "You cannot delete your own account", code: "SELF_DELETE" });
    return;
  }

  // Founding admins are immutable — declared in env, not DB.
  if (getAdminPhones().includes(target.phone)) {
    res.status(409).json({ message: "Founding admins cannot be deleted", code: "FOUNDING_ADMIN" });
    return;
  }

  // Promoted admins must be demoted before deletion so the action is
  // never a shortcut around the role-toggle audit trail.
  if (target.isAdmin) {
    res.status(409).json({ message: "Remove admin role before deleting this user", code: "CANNOT_DELETE_ADMIN" });
    return;
  }

  // Remove all rows the user owns, then the user. No FK cascade exists
  // (these are plain text columns), so we clean up explicitly inside a
  // transaction. orders/transactions/support are keyed by user_id;
  // OTPs and the Telegram link are keyed by phone.
  await db.transaction(async (tx) => {
    await tx.delete(ordersTable).where(eq(ordersTable.userId, target.id));
    await tx.delete(transactionsTable).where(eq(transactionsTable.userId, target.id));
    await tx.delete(supportMessagesTable).where(eq(supportMessagesTable.userId, target.id));
    await tx.delete(webauthnCredentialsTable).where(eq(webauthnCredentialsTable.userId, target.id));
    // OTPs are stored under two phone keys: the plain phone (registration
    // / login OTPs) and a "pay:"-prefixed key for payment OTPs (see
    // PAY_OTP_PREFIX in orders.ts). Clean up both namespaces.
    await tx
      .delete(otpsTable)
      .where(inArray(otpsTable.phone, [target.phone, `pay:${target.phone}`]));
    await tx.delete(telegramLinksTable).where(eq(telegramLinksTable.phone, target.phone));
    // Drop dangling referrer pointers: anyone this user referred keeps
    // their account, but `referred_by` would otherwise point at a row
    // that no longer exists. (Referrers' lifetime reward totals are not
    // rolled back — they are by design append-only.)
    await tx
      .update(usersTable)
      .set({ referredBy: null })
      .where(eq(usersTable.referredBy, target.id));
    // `broadcasts.sent_by_user_id` is NOT NULL, so it cannot be nulled.
    // A deletable member could be a demoted ex-admin who once sent
    // broadcasts; remove those authored rows so no dangling actor
    // reference remains (consistent with a full account purge).
    await tx.delete(broadcastsTable).where(eq(broadcastsTable.sentByUserId, target.id));
    await tx.delete(usersTable).where(eq(usersTable.id, target.id));
  });

  const targetDisplay = target.nickname?.trim() || target.name;
  const actorDisplay = me.nickname?.trim() || me.name;
  const msg =
    `🗑️ <b>ĐÃ XÓA THÀNH VIÊN</b>\n\n` +
    `Người dùng: <b>${targetDisplay}</b>\n` +
    `SĐT: <code>${target.phone}</code>\n` +
    `Bởi: ${actorDisplay} (${me.phone})\n` +
    `Lúc: ${new Date().toISOString()}`;
  // Fire-and-forget: do not block the HTTP response on Telegram.
  sendTelegramMessage(msg).catch(() => {});

  req.log?.info?.({ actorId: me.id, targetId: target.id }, "admin_deleted_user");

  res.json({ ok: true, deleted: true });
});

// POST /admin/balances/wipe — reset every customer's THB and USDT
// balances to 0. Irreversible. Requires admin JWT + the destructive
// operator key (X-Destructive-Key) on top of admin auth, mirroring the
// /admin/users/:id/role pattern. Fires a Telegram audit notification
// to the configured admin chat so the team has an out-of-band record.
router.post("/admin/balances/wipe", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ message: "unauthorized", code: "UNAUTHORIZED" });
    return;
  }

  const [me] = await db
    .select({
      id: usersTable.id,
      phone: usersTable.phone,
      isAdmin: usersTable.isAdmin,
      name: usersTable.name,
      nickname: usersTable.nickname,
    })
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId))
    .limit(1);

  if (!me || !isAdminUser(me)) {
    res.status(403).json({ message: "Forbidden: admin only", code: "FORBIDDEN" });
    return;
  }

  if (!verifyDestructiveKey(req)) {
    res.status(403).json({ message: "Operator key required", code: "DESTRUCTIVE_KEY_REQUIRED" });
    return;
  }

  // Snapshot pre-wipe totals so the audit message tells the operator
  // exactly what was zeroed out.
  const before = await db
    .select({
      count: sql<number>`COUNT(*)::int`,
      sumUsdt: sql<string>`COALESCE(SUM(${usersTable.usdtBalance}::numeric), 0)::text`,
      sumThb: sql<string>`COALESCE(SUM(${usersTable.thbBalance}::numeric), 0)::text`,
      affected: sql<number>`COUNT(*) FILTER (WHERE ${usersTable.usdtBalance}::numeric <> 0 OR ${usersTable.thbBalance}::numeric <> 0)::int`,
    })
    .from(usersTable);
  const snap = before[0] ?? { count: 0, sumUsdt: "0", sumThb: "0", affected: 0 };

  // Reset every customer's balance and purge the historical ledger so
  // storage is fully reclaimed: transactions ledger first (FK soft-link
  // to orders by orderId), then the orders table itself.
  await db.update(usersTable).set({ usdtBalance: "0", thbBalance: "0" });
  const deletedTx = await db
    .delete(transactionsTable)
    .returning({ id: transactionsTable.id });
  const deletedOrders = await db
    .delete(ordersTable)
    .returning({ id: ordersTable.id });

  const actorDisplay = me.nickname?.trim() || me.name;
  const msg =
    `🧨 <b>ĐÃ XÓA TOÀN BỘ SỐ DƯ + LỊCH SỬ KHÁCH HÀNG</b>\n\n` +
    `👤 Bởi: <b>${actorDisplay}</b> (<code>${me.phone}</code>)\n` +
    `🕒 Lúc: ${new Date().toLocaleString("vi-VN", { timeZone: "Asia/Bangkok" })} (ICT)\n\n` +
    `📊 <b>Trước khi xóa</b>\n` +
    `   • Số tài khoản có số dư: <b>${snap.affected}</b> / ${snap.count}\n` +
    `   • Tổng USDT đã xóa: <code>${snap.sumUsdt}</code>\n` +
    `   • Tổng THB đã xóa: <code>${snap.sumThb}</code>\n` +
    `   • Đơn hàng đã xóa: <b>${deletedOrders.length}</b>\n` +
    `   • Giao dịch đã xóa: <b>${deletedTx.length}</b>`;
  sendTelegramMessage(msg).catch(() => {});

  req.log?.warn?.(
    {
      actorId: me.id,
      affected: snap.affected,
      total: snap.count,
      sumUsdt: snap.sumUsdt,
      sumThb: snap.sumThb,
      deletedOrders: deletedOrders.length,
      deletedTransactions: deletedTx.length,
    },
    "balances_and_history_wiped",
  );

  res.json({
    ok: true,
    affected: snap.affected,
    total: snap.count,
    sumUsdt: snap.sumUsdt,
    sumThb: snap.sumThb,
    deletedOrders: deletedOrders.length,
    deletedTransactions: deletedTx.length,
  });
});

// POST /admin/balance-backup/run — fire the daily backup report on
// demand. Useful for testing that TELEGRAM_BACKUP_CHAT_ID is configured
// correctly and the message format looks right without waiting for the
// scheduled time. Admin-only.
router.post("/admin/balance-backup/run", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ message: "unauthorized", code: "UNAUTHORIZED" });
    return;
  }
  const [me] = await db
    .select({ phone: usersTable.phone, isAdmin: usersTable.isAdmin })
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId))
    .limit(1);
  if (!me || !isAdminUser(me)) {
    res.status(403).json({ message: "Forbidden: admin only", code: "FORBIDDEN" });
    return;
  }
  try {
    const result = await sendBalanceBackupReport();
    res.json(result);
  } catch (err) {
    req.log?.error?.({ err }, "balance_backup_manual_failed");
    res.status(500).json({ ok: false, message: "send_failed" });
  }
});

export default router;
