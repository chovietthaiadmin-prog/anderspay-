#!/usr/bin/env node
// Bump artifacts/localpay's package.json version with the rule the user
// requested: patch increments 0..9; when patch hits 10 it rolls over and
// bumps the minor; when minor hits 10 it rolls over and bumps the major.
// Run before publishing: `pnpm bump:version`.
import { readFileSync, writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";

const here = path.dirname(fileURLToPath(import.meta.url));
const pkgPath = path.resolve(here, "..", "..", "artifacts", "localpay", "package.json");

const pkg = JSON.parse(readFileSync(pkgPath, "utf-8"));
const current = String(pkg.version ?? "0.0.0");
const m = current.match(/^(\d+)\.(\d+)\.(\d+)$/);
if (!m) {
  console.error(`Refusing to bump: current version "${current}" is not semver MAJOR.MINOR.PATCH.`);
  process.exit(1);
}

let [major, minor, patch] = [Number(m[1]), Number(m[2]), Number(m[3])];
patch += 1;
if (patch >= 10) {
  patch = 0;
  minor += 1;
}
if (minor >= 10) {
  minor = 0;
  major += 1;
}

const next = `${major}.${minor}.${patch}`;
pkg.version = next;
writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + "\n");
console.log(`AndersPay+ version: ${current} -> ${next}`);
