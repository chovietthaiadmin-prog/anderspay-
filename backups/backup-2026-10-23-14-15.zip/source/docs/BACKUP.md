# Hệ thống Sao lưu GitHub (System Backup)

Tự động sao lưu **mã nguồn + dữ liệu database** của AndersPay+ lên GitHub.

## Cấu hình (Secrets)

| Secret | Bắt buộc | Mô tả |
|---|---|---|
| `GITHUB_BACKUP_TOKEN` | ✅ | GitHub Personal Access Token (PAT) có quyền `repo` (Contents: Read & Write) |
| `GITHUB_BACKUP_REPO` | ✅ | Repo đích, dạng `owner/repo` (ví dụ `anders/andersplus-backup`) hoặc URL đầy đủ |
| `GITHUB_BACKUP_BRANCH` | ❌ | Nhánh đích, mặc định `backup` |

## Nội dung mỗi bản sao lưu

Mỗi lần chạy tạo file `backup-YYYY-MM-DD-HH-mm.zip` đẩy lên thư mục `backups/` của nhánh `backup`:

- `source/…` — toàn bộ mã nguồn (loại trừ `node_modules`, `.git`, `dist`, `build`, cache, `.env*`, thư mục `backup/`, `logs/`)
- `database/database-dump.sql` — dump dữ liệu tất cả bảng (INSERT statements)
- `backup-info.json` — metadata: thời gian, số file, phiên bản Node, trigger

Kèm theo file `.sql` thô đặt cạnh file zip (phục vụ restore không cần giải nén).

## Sử dụng (Admin)

Cài đặt → **Sao lưu hệ thống** (chỉ admin thấy):

- **Sao lưu ngay** — chạy thủ công, có thanh tiến độ %.
- **Kiểm tra kết nối GitHub** — xác minh token/repo/nhánh.
- **Lịch tự động** — Thủ công / Hằng ngày / Hằng tuần (chạy lúc ~03:00 giờ Thái Lan, chỉ trong môi trường production).
- **Lịch sử** — 30 lần chạy gần nhất (trạng thái, dung lượng, số file, lỗi nếu có).

## API (admin JWT bắt buộc)

| Method | Endpoint | Mô tả |
|---|---|---|
| POST | `/api/admin/backup/run` | Chạy backup (nền, poll status để xem tiến độ) |
| GET | `/api/admin/backup/status` | Tiến độ + cấu hình + lần chạy gần nhất |
| GET | `/api/admin/backup/history` | 30 bản ghi gần nhất |
| POST | `/api/admin/backup/test-github` | Kiểm tra kết nối GitHub |
| POST | `/api/admin/backup/schedule` | Body `{ "mode": "off" \| "daily" \| "weekly" }` |
| POST | `/api/admin/backup/restore` | **Chưa có UI.** Khôi phục DỮ LIỆU database từ bản dump trên GitHub. Body `{ "fileName": "backup-….zip" }`. Yêu cầu thêm header `X-Destructive-Key` (secret `DESTRUCTIVE_OP_KEY`) vì thao tác này XÓA và ghi đè toàn bộ dữ liệu. |

## Ghi chú kỹ thuật

- Lịch sử lưu trong bảng `backup_runs` (DB) vì filesystem production không bền vững qua các lần deploy.
- File zip cục bộ giữ tối đa 10 bản gần nhất trong thư mục `backup/` (tự xoá bản cũ).
- Log chi tiết ghi vào `logs/backup.log`.
- Giới hạn upload 90 MB/file (giới hạn GitHub Contents API ~100 MB).
- Scheduler kiểm tra mỗi 15 phút, chỉ chạy trong production (tránh backup trùng từ môi trường dev).
