# Threat Model

## Project Overview

AndersPay+ is a pnpm workspace monorepo for a USDT→THB exchange PWA. The production system consists of a React/Vite frontend in `artifacts/localpay` and an Express 5 API in `artifacts/api-server`, backed by PostgreSQL via Drizzle in `lib/db`. Users register with phone number, password, and a Telegram-delivered OTP; authenticated sessions use bearer JWTs. Admin workflows include setting exchange rates and confirming payment activity through the app and Telegram bot/webhook integration.

Production assumption notes:
- `NODE_ENV=production` in deployed environments.
- Replit-managed TLS protects traffic in transit.
- `artifacts/mockup-sandbox` is dev-only and should be ignored unless production reachability is demonstrated.

## Assets

- **User accounts and sessions** — phone numbers, password hashes, JWT bearer tokens, Telegram-linked identities. Compromise enables impersonation and access to payment history or profile data.
- **Payment and order records** — exchange orders, bank account destination details, wallet addresses, order lifecycle state, and proof-of-payment uploads. Compromise can cause financial loss, privacy exposure, or fraudulent status transitions.
- **Admin capabilities** — exchange-rate management and order completion authority. Abuse directly affects pricing integrity and settlement outcomes.
- **PII and recovery data** — phone numbers, optional emails, nicknames, avatars, and linked Telegram chat IDs. Exposure can harm user privacy and enable targeted attacks.
- **Application secrets and integrations** — `JWT_SECRET`, database credentials, Telegram bot token, and test secrets. Loss of these secrets enables spoofing, unauthorized automation, or backend compromise.

## Trust Boundaries

- **Browser / API boundary** — all frontend input is untrusted. The API must authenticate and authorize every state-changing or user-data-bearing request.
- **API / PostgreSQL boundary** — the API has broad access to order, user, OTP, settings, and Telegram link tables. Server-side access control failures can become full data exposure.
- **API / Telegram boundary** — the server both calls Telegram Bot APIs and receives Telegram webhook traffic. Incoming webhook data must be authenticated as Telegram-originated before it is trusted to trigger business actions.
- **Public / authenticated / admin boundary** — public status/rate/health surfaces are distinct from user order/profile flows and from admin-only rate management and order settlement functions.
- **Production / test-only boundary** — test helpers guarded by `TEST_API_SECRET` must remain unreachable in production and never become alternate auth paths.
- **User-upload / static-serving boundary** — avatar and bill uploads cross from untrusted user-controlled bytes into server processing. Avatar data is currently stored inline rather than same-origin static hosting, so the remaining production concern is validation and redistribution of untrusted content rather than arbitrary file hosting.

## Scan Anchors

- **Production entry points:** `artifacts/api-server/src/index.ts`, `artifacts/api-server/src/app.ts`, `artifacts/api-server/src/routes/*`, `artifacts/localpay/src/App.tsx`.
- **Highest-risk code areas:** `artifacts/api-server/src/routes/orders.ts`, `artifacts/api-server/src/routes/telegram.ts`, `artifacts/api-server/src/routes/auth.ts`, `artifacts/api-server/src/routes/rates.ts`, `artifacts/api-server/src/routes/profile.ts`, `artifacts/api-server/src/lib/jwt.ts`.
- **Public surfaces:** health, exchange-rate read path, Telegram webhook, order status/history pages, and any order lookup endpoints reachable without auth.
- **Authenticated surfaces:** profile mutation, bill upload, user-specific order flows.
- **Admin surfaces:** exchange-rate mutation and any flow that can mark orders complete or otherwise settle funds.
- **Usually dev-only:** `artifacts/mockup-sandbox`, e2e helpers guarded by `TEST_API_SECRET`, and test artifacts under `artifacts/localpay/e2e`.

## Threat Categories

### Spoofing

This project relies on JWT bearer tokens for authenticated users and Telegram as an external identity/control channel. The system must only accept authenticated sessions derived from a verified JWT, and it must authenticate Telegram webhook traffic before trusting messages or callback actions. Admin authority must come from a server-verified principal, not from client-asserted identifiers such as a phone number supplied in a request body.

### Tampering

Order state, exchange rates, and linked account data are business-critical. Attackers must not be able to create, alter, or settle orders except through authorized flows. All sensitive state transitions, including payment confirmation and rate updates, must be protected by server-side authorization tied to the acting user or admin role. Uploaded files must be validated as actual permitted content before the server stores or redistributes them.

### Information Disclosure

Orders contain bank destination data, payment amounts, lifecycle state, and timestamps; user records contain phone numbers, emails, avatars, and Telegram links. The API must only disclose order and profile data to the owning user or an authorized admin, and public responses must avoid exposing unnecessary financial or personal details. Secrets, bot tokens, JWT signing keys, and raw uploads must never leak through responses, logs, or client bundles.

### Denial of Service

Public registration, OTP delivery, upload, and webhook endpoints can be abused to create excessive backend work, spam Telegram notifications, or consume storage/memory. The production system should bound upload size, reject malformed input early, and protect externally triggered flows from cheap unauthenticated abuse.

### Elevation of Privilege

The most important elevation risks are broken access control on order retrieval or state transitions, client-controlled admin checks, forged Telegram-originated actions, and unsafe file handling that can yield same-origin script execution. The system must ensure that user-level access cannot reach admin-only capabilities and that untrusted uploads cannot become executable content on the application origin.
