import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { randomUUID } from "node:crypto";

// Read-only requests and denied writes only; never creates a user or message.
const enabled = process.env.RUN_GUEST_ACCESS_TESTS === "1" && !process.env.REPLIT_DEPLOYMENT;
const guestId = randomUUID();
const credentials: { label: string; headers: Record<string, string> }[] = [
  { label: "no credentials", headers: {} },
  { label: "legacy guest header", headers: { "X-Guest-Id": guestId } },
  { label: "invalid session plus guest header", headers: { Authorization: "Bearer invalid", "X-Guest-Id": guestId } },
];
const operations = [
  { method: "GET", path: "/support/messages" },
  { method: "GET", path: "/support/unread" },
  { method: "POST", path: "/support/messages", body: { body: "Must never be delivered" } },
  { method: "POST", path: "/support/messages/image", body: {} },
  { method: "POST", path: "/support/presence", body: { conversationOpen: true } },
  { method: "POST", path: "/wallet-risk/check", body: { network: "bsc", address: "0x0000000000000000000000000000000000000001" } },
];

describe("guest access against the running development API", { skip: !enabled }, () => {
  for (const credential of credentials) {
    for (const operation of operations) {
      it(`${operation.method} ${operation.path} rejects ${credential.label}`, async () => {
        const response = await fetch(`http://localhost:80/api${operation.path}`, {
          method: operation.method,
          headers: { "Content-Type": "application/json", ...credential.headers },
          ...(operation.method === "POST" ? { body: JSON.stringify(operation.body) } : {}),
          signal: AbortSignal.timeout(5000),
        });
        assert.equal(response.status, 401);
      });
    }
  }
  it("keeps public rates and announcements available to view", async () => {
    for (const path of ["/rates/thb-usdt", "/announcements"]) {
      const response = await fetch(`http://localhost:80/api${path}`, { signal: AbortSignal.timeout(5000) });
      assert.equal(response.status, 200);
    }
  });
});
