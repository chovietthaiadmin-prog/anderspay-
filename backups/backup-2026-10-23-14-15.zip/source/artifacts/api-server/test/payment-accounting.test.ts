import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { randomUUID } from "node:crypto";
import pg from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
import { eq, and } from "drizzle-orm";
import type * as schema from "@workspace/db/schema";
import type * as Accounting from "../src/lib/payment-accounting.ts";
import type * as Credit from "../src/lib/wallet-credit.ts";

const enabled = process.env.RUN_ACCOUNTING_DB_TESTS === "1" && !process.env.REPLIT_DEPLOYMENT;
const namespace = `accounting_test_${randomUUID().replace(/-/g, "")}`;
let pool: pg.Pool;
let rootPool: pg.Pool;
let database: typeof import("@workspace/db").db;
let usersTable: typeof schema.usersTable;
let ordersTable: typeof schema.ordersTable;
let transactionsTable: typeof schema.transactionsTable;
let debitPaymentAccount: typeof Accounting.debitPaymentAccount;
let refundPayment: typeof Accounting.refundPayment;
let reversePaymentRefund: typeof Accounting.reversePaymentRefund;
let completeOrderAndCredit: typeof Credit.completeOrderAndCredit;

describe("financial transactions in an isolated development schema", { skip: !enabled }, () => {
  before(async () => {
    const tables = await import("@workspace/db/schema");
    rootPool = (await import("@workspace/db")).pool;
    ({ usersTable, ordersTable, transactionsTable } = tables);
    ({ debitPaymentAccount, refundPayment, reversePaymentRefund } = await import("../src/lib/payment-accounting.ts"));
    ({ completeOrderAndCredit } = await import("../src/lib/wallet-credit.ts"));
    pool = new pg.Pool({
      connectionString: process.env.DATABASE_URL,
      options: `-c search_path=${namespace},public`,
    });
    database = drizzle(pool, { schema: tables });
    await rootPool.query(`CREATE SCHEMA ${namespace}`);
    for (const table of ["users", "orders", "transactions"]) {
      await rootPool.query(`CREATE TABLE ${namespace}.${table} (LIKE public.${table} INCLUDING ALL)`);
    }
  });
  after(async () => {
    await pool.end();
    await rootPool.query(`DROP SCHEMA IF EXISTS ${namespace} CASCADE`);
    await rootPool.end();
  });

  async function fixture(referralSource: string | null = "0.300000", deposit = false) {
    const userId = randomUUID();
    const id = randomUUID();
    const orderId = `TEST-${randomUUID()}`;
    await database.insert(usersTable).values({
      id: userId, name: "Isolated accounting test", phone: `test:${userId}`,
      passwordHash: "not-a-login-password", usdtBalance: "4", thbBalance: "0",
    });
    await database.insert(ordersTable).values({
      id, orderId, userId, bankName: deposit ? "" : "Test Bank",
      accountNumber: deposit ? "" : "test", accountName: deposit ? "" : "Test",
      walletAddress: "test-only", status: "pending", amountUsdt: deposit ? "100" : "3",
      amountThb: "100", exchangeRate: "30",
    });
    if (!deposit) await database.insert(transactionsTable).values([
      { id: randomUUID(), userId, type: "payment", amountUsdt: "0", amountThb: "100", rate: "30", refOrderId: id },
      { id: randomUUID(), userId, type: "payment_fee", amountUsdt: "0.8",
        referralAmountUsdt: referralSource, amountThb: "24", rate: "30", refOrderId: id },
    ]);
    return { userId, id, orderId };
  }
  async function balances(userId: string) {
    const [user] = await database.select().from(usersTable).where(eq(usersTable.id, userId));
    return [user.usdtBalance, user.thbBalance, user.referralRewardBalance];
  }
  async function rows(id: string, type: (typeof transactionsTable.$inferSelect)["type"]) {
    return database.select().from(transactionsTable)
      .where(and(eq(transactionsTable.refOrderId, id), eq(transactionsTable.type, type)));
  }

  it("refunds the exact charged amounts to their original wallets only once", async () => {
    const f = await fixture();
    const results = await Promise.all([refundPayment(f.id, database), refundPayment(f.id, database)]);
    assert.equal(results.filter(Boolean).length, 1);
    assert.deepEqual(await balances(f.userId), ["4.500000", "100.00", "0.300000"]);
    assert.equal((await rows(f.id, "payment_refund")).length, 1);
    // Recorded 0.8 USDT, not the fee recomputed from today's fee schedule.
    assert.equal((await rows(f.id, "payment_refund"))[0].amountUsdt, "0.800000");
  });
  it("reverses a refund only once under concurrent force-complete calls", async () => {
    const f = await fixture();
    await refundPayment(f.id, database);
    const results = await Promise.allSettled([
      reversePaymentRefund(f.orderId, database), reversePaymentRefund(f.orderId, database),
    ]);
    assert.equal(results.filter((r) => r.status === "fulfilled").length, 1);
    assert.deepEqual(await balances(f.userId), ["4.000000", "0.00", "0.000000"]);
    assert.equal((await rows(f.id, "payment_refund_reversal")).length, 1);
  });
  it("rolls back force-complete if refunded funds have been spent", async () => {
    const f = await fixture();
    await refundPayment(f.id, database);
    await database.update(usersTable).set({ thbBalance: "0" }).where(eq(usersTable.id, f.userId));
    await assert.rejects(reversePaymentRefund(f.orderId, database), /REFUND_BALANCE_SPENT/);
    const [order] = await database.select().from(ordersTable).where(eq(ordersTable.id, f.id));
    assert.equal(order.status, "refunded");
    assert.deepEqual(await balances(f.userId), ["4.500000", "0.00", "0.300000"]);
    assert.equal((await rows(f.id, "payment_refund_reversal")).length, 0);
  });
  it("does not guess the fee source for legacy payment charges", async () => {
    const f = await fixture(null);
    await assert.rejects(refundPayment(f.id, database), /FEE_SOURCE_UNKNOWN/);
    const [order] = await database.select().from(ordersTable).where(eq(ordersTable.id, f.id));
    assert.equal(order.status, "pending");
    assert.deepEqual(await balances(f.userId), ["4.000000", "0.00", "0.000000"]);
    assert.equal((await rows(f.id, "payment_refund")).length, 0);
  });
  it("reverses historical refunds from spendable USDT, where they were credited", async () => {
    const f = await fixture(null);
    await database.update(ordersTable).set({ status: "refunded" }).where(eq(ordersTable.id, f.id));
    await database.update(usersTable).set({ usdtBalance: "4.8", thbBalance: "100" }).where(eq(usersTable.id, f.userId));
    await database.insert(transactionsTable).values({
      id: randomUUID(), userId: f.userId, type: "payment_refund",
      amountUsdt: "0.8", amountThb: "100", rate: "30", refOrderId: f.id,
    });
    await reversePaymentRefund(f.orderId, database);
    assert.deepEqual(await balances(f.userId), ["4.000000", "0.00", "0.000000"]);
  });
  it("serializes payment creation so simultaneous requests cannot create two outstanding orders", async () => {
    const f = await fixture();
    await database.update(ordersTable).set({ status: "completed" }).where(eq(ordersTable.id, f.id));
    await database.update(usersTable).set({ thbBalance: "300" }).where(eq(usersTable.id, f.userId));
    const create = () => database.transaction(async (tx) => {
      await debitPaymentAccount(tx, f.userId, "100.00", "0.800000");
      await tx.insert(ordersTable).values({
        id: randomUUID(), orderId: `TEST-${randomUUID()}`, userId: f.userId,
        bankName: "Test Bank", accountNumber: "test", accountName: "Test",
        walletAddress: "test-only", status: "pending", amountUsdt: "3", amountThb: "100", exchangeRate: "30",
      });
    });
    const results = await Promise.allSettled([create(), create()]);
    assert.equal(results.filter((r) => r.status === "fulfilled").length, 1);
    const rejected = results.find((r) => r.status === "rejected");
    assert.match(String(rejected?.status === "rejected" && rejected.reason), /PENDING_ORDER_EXISTS/);
    assert.equal((await balances(f.userId))[1], "200.00");
    assert.equal((await balances(f.userId))[0], "3.200000");
  });
  it("debits and refunds a mixed-source payment back to the exact starting balances", async () => {
    const f = await fixture();
    await database.update(ordersTable).set({ status: "completed" }).where(eq(ordersTable.id, f.id));
    await database.update(usersTable).set({ usdtBalance: "4", thbBalance: "300", referralRewardBalance: "0.3" })
      .where(eq(usersTable.id, f.userId));
    const id = randomUUID();
    await database.transaction(async (tx) => {
      const split = await debitPaymentAccount(tx, f.userId, "100.00", "0.800000");
      await tx.insert(ordersTable).values({
        id, orderId: `TEST-${id}`, userId: f.userId, bankName: "Test Bank",
        accountNumber: "test", accountName: "Test", walletAddress: "test-only",
        status: "pending", amountUsdt: "3", amountThb: "100", exchangeRate: "30",
      });
      await tx.insert(transactionsTable).values([
        { id: randomUUID(), userId: f.userId, type: "payment", amountThb: "100", rate: "30", refOrderId: id },
        { id: randomUUID(), userId: f.userId, type: "payment_fee", amountUsdt: "0.8",
          referralAmountUsdt: split.referral, rate: "30", refOrderId: id },
      ]);
    });
    assert.deepEqual(await balances(f.userId), ["3.500000", "200.00", "0.000000"]);
    await refundPayment(id, database);
    assert.deepEqual(await balances(f.userId), ["4.000000", "300.00", "0.300000"]);
  });
  it("does not debit either wallet when the principal or gas reserve guard fails", async () => {
    const f = await fixture();
    await database.update(ordersTable).set({ status: "completed" }).where(eq(ordersTable.id, f.id));
    await assert.rejects(database.transaction((tx) => debitPaymentAccount(tx, f.userId, "1", "0.8")), /INSUFFICIENT_THB_BALANCE/);
    await database.update(usersTable).set({ thbBalance: "100" }).where(eq(usersTable.id, f.userId));
    await assert.rejects(database.transaction((tx) => debitPaymentAccount(tx, f.userId, "100", "2")), /INSUFFICIENT_FEE_BALANCE/);
    assert.deepEqual(await balances(f.userId), ["4.000000", "100.00", "0.000000"]);
  });
  it("credits net top-up once and refuses orphan deposits without changing their status", async () => {
    const f = await fixture(null, true);
    const results = await Promise.all([completeOrderAndCredit(f.id, database), completeOrderAndCredit(f.id, database)]);
    assert.equal(results.filter(Boolean).length, 1);
    assert.equal((await balances(f.userId))[0], "103.000000");
    const orphan = await fixture(null, true);
    await database.update(ordersTable).set({ userId: null }).where(eq(ordersTable.id, orphan.id));
    await assert.rejects(completeOrderAndCredit(orphan.id, database), /DEPOSIT_USER_REQUIRED/);
    const [order] = await database.select().from(ordersTable).where(eq(ordersTable.id, orphan.id));
    assert.equal(order.status, "pending");
  });
});
