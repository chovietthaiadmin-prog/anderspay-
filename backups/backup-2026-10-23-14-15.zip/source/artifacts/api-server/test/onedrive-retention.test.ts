import assert from "node:assert/strict";
import { afterEach, describe, it } from "node:test";
import {
  getDownloadUrl,
  setOneDriveProxyForTests,
  uploadPaymentBill,
} from "../src/lib/onedrive.ts";
import { archiveBillToOneDrive } from "../src/lib/bill-archive.ts";

type ProxyCall = {
  path: string;
  init: {
    method: string;
    body?: Buffer | string;
    headers?: Record<string, string>;
  };
};

const restores: Array<() => void> = [];

afterEach(() => {
  let restore: (() => void) | undefined;
  while ((restore = restores.pop())) {
    restore();
  }
});

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function installDrive() {
  const calls: ProxyCall[] = [];
  const files = new Map<string, { id: string; bytes: Buffer; downloadUrl: string }>();
  let folderCreated = false;
  let nextId = 1;

  const restore = setOneDriveProxyForTests(async (_connection, path, init) => {
    calls.push({ path, init });

    if (path === "/v1.0/me/drive/root:/AndersPay Bills" && init.method === "GET") {
      return folderCreated ? jsonResponse({ id: "folder-1" }) : jsonResponse({}, 404);
    }

    if (path === "/v1.0/me/drive/root/children" && init.method === "POST") {
      folderCreated = true;
      return jsonResponse({ id: "folder-1" }, 201);
    }

    if (path.includes("/AndersPay Bills/") && path.endsWith(":/content") && init.method === "PUT") {
      const fileName = decodeURIComponent(path.split("/AndersPay Bills/")[1].replace(":/content", ""));
      const id = `file-${nextId++}`;
      files.set(id, {
        id,
        bytes: Buffer.from(init.body as Buffer),
        downloadUrl: `https://drive.test/download/${id}`,
      });
      return jsonResponse({ id, name: fileName }, 201);
    }

    if (path.startsWith("/v1.0/me/drive/items/") && init.method === "GET") {
      const id = decodeURIComponent(path.slice("/v1.0/me/drive/items/".length));
      const file = files.get(id);
      return file
        ? jsonResponse({
            id: file.id,
            "@microsoft.graph.downloadUrl": file.downloadUrl,
          })
        : jsonResponse({}, 404);
    }

    throw new Error(`Unexpected fake OneDrive request: ${init.method} ${path}`);
  });
  restores.push(restore);

  return { calls, files };
}

describe("payment bill OneDrive retention", () => {
  it("creates the bills folder and preserves original bytes for top-ups and proofs", async () => {
    const drive = installDrive();
    const topupBytes = Buffer.from([0, 1, 2, 253, 254, 255]);
    const paymentBytes = Buffer.from("original-payment-proof", "utf8");

    const topup = await uploadPaymentBill(
      "AP-TOPUP-123",
      topupBytes,
      "image/png",
      "bank screenshot.png",
      "topup",
    );
    const payment = await uploadPaymentBill(
      "AP-PAYMENT-456",
      paymentBytes,
      "application/pdf",
      "proof.pdf",
      "payment",
    );

    const folderCreate = drive.calls.find(
      (call) => call.path === "/v1.0/me/drive/root/children" && call.init.method === "POST",
    );
    assert.ok(folderCreate, "the AndersPay Bills folder should be created on first use");
    assert.match(String(folderCreate.init.body), /AndersPay Bills/);

    const uploads = drive.calls.filter((call) => call.init.method === "PUT");
    assert.equal(uploads.length, 2);
    assert.deepEqual(uploads[0].init.body, topupBytes);
    assert.deepEqual(uploads[1].init.body, paymentBytes);
    assert.match(uploads[0].path, /AndersPay Bills\/topup-AP-TOPUP-123-bank-screenshot-[^/]+\.png:\/content$/);
    assert.match(uploads[1].path, /AndersPay Bills\/payment-AP-PAYMENT-456-proof-[^/]+\.pdf:\/content$/);
    assert.equal(topup.fileName.includes("AP-TOPUP-123"), true);
    assert.equal(payment.fileName.includes("AP-PAYMENT-456"), true);
  });

  it("keeps repeated uploads discoverable by order ID and downloadable", async () => {
    const drive = installDrive();
    const orderId = "AP-RETRY-789";
    const bytes = Buffer.from("same original bytes");

    const first = await uploadPaymentBill(orderId, bytes, "image/jpeg", "receipt.jpg", "payment");
    const second = await uploadPaymentBill(orderId, bytes, "image/jpeg", "receipt.jpg", "payment");

    assert.notEqual(first.itemId, second.itemId);
    assert.equal(first.fileName.includes(orderId), true);
    assert.equal(second.fileName.includes(orderId), true);
    assert.deepEqual(drive.files.get(first.itemId)?.bytes, bytes);
    assert.deepEqual(drive.files.get(second.itemId)?.bytes, bytes);
    assert.equal(await getDownloadUrl(first.itemId), `https://drive.test/download/${first.itemId}`);
    assert.equal(await getDownloadUrl(second.itemId), `https://drive.test/download/${second.itemId}`);
  });

  it("logs OneDrive failures while leaving a successful API result and order status untouched", async () => {
    const response = { statusCode: 201, body: { ok: true } };
    const order = { status: "pending" };
    const errors: unknown[] = [];
    const uploader = async () => {
      throw new Error("simulated OneDrive outage");
    };

    await archiveBillToOneDrive(
      "AP-FAIL-001",
      Buffer.from("proof"),
      "image/jpeg",
      "proof.jpg",
      "payment",
      {
        upload: uploader,
        log: {
          info: () => {},
          error: (...args: unknown[]) => errors.push(args),
        },
      },
    );

    assert.deepEqual(response, { statusCode: 201, body: { ok: true } });
    assert.equal(order.status, "pending");
    assert.equal(errors.length, 1);
    assert.match(String(errors[0]), /failed to archive bill to OneDrive/);
  });
});