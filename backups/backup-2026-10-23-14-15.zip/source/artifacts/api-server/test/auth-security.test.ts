import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { randomUUID, randomInt } from "node:crypto";
import pg from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
import type * as Challenges from "../src/lib/auth-otp.ts";

const enabled = process.env.RUN_AUTH_SECURITY_TESTS === "1" && !process.env.REPLIT_DEPLOYMENT;
const namespace = `auth_test_${randomUUID().replaceAll("-", "")}`;
let root: pg.Pool;
let pool: pg.Pool;
let database: typeof import("@workspace/db").db;
let realDb: typeof database;
let challenges: typeof Challenges;

describe("authentication security in an isolated development schema", { skip: !enabled }, () => {
  before(async () => {
    const tables = await import("@workspace/db/schema");
    const original = await import("@workspace/db");
    root = original.pool;
    realDb = original.db;
    challenges = await import("../src/lib/auth-otp.ts");
    await root.query(`CREATE SCHEMA ${namespace}`);
    await root.query(`CREATE TABLE ${namespace}.email_otps (LIKE public.email_otps INCLUDING ALL)`);
    pool = new pg.Pool({ connectionString: process.env.DATABASE_URL, options: `-c search_path=${namespace},public` });
    database = drizzle(pool, { schema: tables });
  });
  after(async () => {
    await pool?.end();
    if (root) {
      await root.query(`DROP SCHEMA IF EXISTS ${namespace} CASCADE`);
      await root.end();
    }
  });

  async function issue(identity = randomUUID(), purpose = "auth") {
    const result = await challenges.issueOtp(identity, purpose, database);
    assert.ok(result.ok);
    return { ...result, identity, purpose };
  }

  it("generates six digits and stores only a keyed, identity/purpose-bound digest", async () => {
    const c = await issue();
    assert.match(c.otp, /^\d{6}$/);
    const { rows: [row] } = await pool.query("SELECT * FROM email_otps WHERE id=$1", [c.id]);
    assert.match(row.otp_hash, /^hmac:v1:[a-f0-9]{64}$/);
    assert.notEqual(row.otp_hash, c.otp);
    assert.notEqual(challenges.otpDigest(c.identity, c.purpose, c.otp), challenges.otpDigest(c.identity, "delete:user", c.otp));
    assert.notEqual(challenges.otpDigest(c.identity, c.purpose, c.otp), challenges.otpDigest("other", c.purpose, c.otp));
  });

  it("allows exactly one concurrent redemption", async () => {
    const c = await issue();
    const results = await Promise.all(Array.from({ length: 6 }, () =>
      challenges.verifyOtpFor(c.identity, c.purpose, c.otp, database)));
    assert.equal(results.filter((r) => r.ok).length, 1);
  });

  it("serializes failed attempts and blocks resend and correct codes during lockout", async () => {
    const c = await issue();
    const wrong = c.otp === "000000" ? "000001" : "000000";
    await Promise.all(Array.from({ length: 9 }, () =>
      challenges.verifyOtpFor(c.identity, c.purpose, wrong, database)));
    const { rows: [row] } = await pool.query("SELECT attempts FROM email_otps WHERE id=$1", [c.id]);
    assert.equal(row.attempts, 5);
    const correct = await challenges.verifyOtpFor(c.identity, c.purpose, c.otp, database);
    const resend = await challenges.issueOtp(c.identity, c.purpose, database);
    assert.ok(!correct.ok && correct.status === 423);
    assert.ok(!resend.ok && resend.status === 423);
  });

  it("does not let concurrent sends bypass the 60-second resend gap", async () => {
    const identity = randomUUID();
    const results = await Promise.all(Array.from({ length: 6 }, () => challenges.issueOtp(identity, "auth", database)));
    assert.equal(results.filter((r) => r.ok).length, 1);
    assert.equal(results.filter((r) => !r.ok && r.status === 429).length, 5);
  });

  it("invalidates previous codes on resend and never accepts expired codes", async () => {
    const c = await issue();
    await pool.query("UPDATE email_otps SET created_at=now()-interval '61 seconds' WHERE id=$1", [c.id]);
    const fresh = await issue(c.identity, c.purpose);
    assert.equal((await challenges.verifyOtpFor(c.identity, c.purpose, c.otp, database)).ok, false);
    await pool.query("UPDATE email_otps SET expires_at=now()-interval '1 second' WHERE id=$1", [fresh.id]);
    assert.equal((await challenges.verifyOtpFor(c.identity, c.purpose, fresh.otp, database)).ok, false);
  });

  it("separates login from deletion and rejects legacy plaintext challenges", async () => {
    const c = await issue("phone:" + randomUUID(), "phone-login");
    assert.equal((await challenges.verifyOtpFor(c.identity, "delete:user", c.otp, database)).ok, false);
    await pool.query("UPDATE email_otps SET otp_hash=$1 WHERE id=$2", [c.otp, c.id]);
    assert.equal((await challenges.verifyOtpFor(c.identity, c.purpose, c.otp, database)).ok, false);
  });

  it("enforces hourly and daily send quotas across purposes", async () => {
    for (const [count, age] of [[5, "2 minutes"], [20, "2 hours"]] as const) {
      const identity = randomUUID();
      for (let i = 0; i < count; i++) {
        await pool.query(
          `INSERT INTO email_otps(id,email,purpose,otp_hash,expires_at,created_at)
           VALUES($1,$2,'auth','unused',now(),now()-$3::interval)`,
          [randomUUID(), identity, age],
        );
      }
      const result = await challenges.issueOtp(identity, "another-purpose", database);
      assert.ok(!result.ok && result.status === 429);
    }
  });

  it("retires all four password endpoints without issuing any session", async () => {
    for (const path of ["login", "login/verify", "register", "reset-password"]) {
      const response = await fetch(`http://localhost:80/api/auth/${path}`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: "+66000000000", password: "not-a-real-password", otp: "000000" }),
      });
      assert.equal(response.status, 410);
      const data = await response.json();
      assert.equal(data.error, "password_auth_removed");
      assert.equal(data.token, undefined);
    }
  });

  it("real email and phone OTP logins issue working sessions and reject replay", async () => {
    // Only this synthetic user/challenge is written to the development
    // public schema, so the running API can redeem it. No email is sent.
    for (const kind of ["email", "phone"] as const) {
    const id = randomUUID();
    const email = `auth_${id}@example.invalid`;
    const phone = kind === "email" ? `em:${id}` : `+660${randomInt(10_000_000, 99_999_999)}`;
    try {
      await root.query(
        `INSERT INTO users(id,name,phone,password_hash,email,email_verified,verified)
         VALUES($1,'Auth security test',$2,'!email-only!',$3,true,true)`,
        [id, phone, email],
      );
      const identity = kind === "email" ? email : `phone:${phone}`;
      const challenge = await challenges.issueOtp(identity, kind === "email" ? "auth" : "phone-login", realDb);
      assert.ok(challenge.ok);
      const login = () => fetch(`http://localhost:80/api/auth/${kind === "email" ? "email" : "telegram-otp"}/verify`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, phone, otp: challenge.otp }),
      });
      const response = await login();
      assert.equal(response.status, 200);
      const data = await response.json();
      assert.equal(data.user.id, id);
      assert.equal(typeof data.token, "string");
      const me = await fetch("http://localhost:80/api/auth/me", { headers: { Authorization: `Bearer ${data.token}` } });
      assert.equal(me.status, 200);
      assert.equal((await me.json()).user.id, id);
      assert.equal((await login()).status, 400);
    } finally {
      await root.query("DELETE FROM email_otps WHERE email=$1 OR email=$2", [email, `phone:${phone}`]);
      await root.query("DELETE FROM users WHERE id=$1", [id]);
    }
    }
  });
});
