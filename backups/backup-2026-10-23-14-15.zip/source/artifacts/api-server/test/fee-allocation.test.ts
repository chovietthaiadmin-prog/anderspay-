import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { conversionAmounts, recordedFeeSplit, splitPaymentFee } from "../src/lib/fee-allocation.ts";

describe("exact payment accounting", () => {
  it("spends rewards first and preserves six-decimal precision", () => {
    assert.deepEqual(splitPaymentFee("0.800001", "0.300002"),
      { referral: "0.300002", wallet: "0.499999" });
    assert.deepEqual(splitPaymentFee("0.8", "10"), { referral: "0.800000", wallet: "0.000000" });
    assert.deepEqual(splitPaymentFee("0.8", "0"), { referral: "0.000000", wallet: "0.800000" });
  });
  it("restores only recorded sources and handles historical refunds explicitly", () => {
    assert.deepEqual(recordedFeeSplit("0.8", "0.3"), { referral: "0.300000", wallet: "0.500000" });
    assert.throws(() => recordedFeeSplit("0.8", null), /FEE_SOURCE_UNKNOWN/);
    assert.deepEqual(recordedFeeSplit("0.8", null, true), { referral: "0.000000", wallet: "0.800000" });
    assert.throws(() => recordedFeeSplit("0.8", "0.9"), /INVALID_LEDGER_AMOUNT/);
    assert.throws(() => recordedFeeSplit("-0.8", "0"), /INVALID_LEDGER_AMOUNT/);
  });
  it("never debits USDT for a zero-THB conversion", () => {
    assert.throws(() => conversionAmounts(0.000001, 30), /AMOUNT_TOO_SMALL/);
    assert.deepEqual(conversionAmounts(1.000001, 30), { usdt: "1.000001", thb: "30.00" });
    assert.deepEqual(conversionAmounts(0.0002, 30), { usdt: "0.000200", thb: "0.01" });
  });
});
