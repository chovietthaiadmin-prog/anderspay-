import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  paymentSlipRecipients,
  paymentSlipFullyDelivered,
} from "../src/services/payment-slip-delivery.ts";

describe("mandatory payment receipt delivery", () => {
  it("targets the administrator and the user", () => {
    assert.deepEqual(paymentSlipRecipients("admin", "user"), ["admin", "user"]);
    assert.equal(paymentSlipFullyDelivered("admin", "user", [{ ok: true }, { ok: true }]), true);
  });

  it("sends only one copy when the user is also the configured administrator", () => {
    assert.deepEqual(paymentSlipRecipients("same", "same"), ["same"]);
    assert.equal(paymentSlipFullyDelivered("same", "same", [{ ok: true }]), true);
  });

  it("does not report success when either required destination is missing", () => {
    assert.deepEqual(paymentSlipRecipients("admin", null), ["admin"]);
    assert.equal(paymentSlipFullyDelivered("admin", null, [{ ok: true }]), false);
    assert.equal(paymentSlipFullyDelivered(undefined, "user", [{ ok: true }]), false);
    assert.equal(paymentSlipFullyDelivered(undefined, null, []), false);
  });

  it("does not hide failed or incomplete delivery behind one successful send", () => {
    assert.equal(paymentSlipFullyDelivered("admin", "user", [{ ok: true }, { ok: false }]), false);
    assert.equal(paymentSlipFullyDelivered("admin", "user", [{ ok: true }]), false);
  });
});
