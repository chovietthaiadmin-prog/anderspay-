/** A shared destination only needs one copy, even when it serves both roles. */
export function paymentSlipRecipients(
  adminChatId: string | undefined,
  userChatId: string | null,
): string[] {
  return [...new Set(
    [adminChatId, userChatId].filter((chatId): chatId is string => Boolean(chatId)),
  )];
}

/** Partial delivery must never be reported as delivery to both recipients. */
export function paymentSlipFullyDelivered(
  adminChatId: string | undefined,
  userChatId: string | null,
  results: readonly { ok: boolean }[],
): boolean {
  return Boolean(adminChatId && userChatId)
    && results.length === paymentSlipRecipients(adminChatId, userChatId).length
    && results.every((result) => result.ok);
}
