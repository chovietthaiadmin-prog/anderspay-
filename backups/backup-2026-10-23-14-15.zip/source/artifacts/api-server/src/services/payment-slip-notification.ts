import { randomUUID } from "node:crypto";
import { db, notificationLogsTable, ordersTable, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { getTelegramChatId, sendTelegramPhotoDetailed } from "../lib/telegram";
import { renderPaymentSlipPng } from "../lib/payment-slip";
import { paymentSlipRecipients, paymentSlipFullyDelivered } from "./payment-slip-delivery";

type CompletedOrder = typeof ordersTable.$inferSelect;
const ADMIN_CHAT_ID = process.env.ADMIN_TELEGRAM_CHAT_ID;

/**
 * Sends the same THB payment slip to the admin chat and the order owner's
 * private Telegram chat. Receipts are mandatory transaction notifications,
 * independent of optional payment-notification preferences. It is best-effort:
 * a Telegram outage can never undo a completed payment. Call it only after a
 * successful status transition so the order state itself acts as the
 * idempotency guard.
 */
export async function notifyCompletedPaymentSlip(order: CompletedOrder): Promise<void> {
  if (!order.bankName) return;

  const logMessage = `Payment slip ${order.orderId}`;
  try {
    const [user] = order.userId
      ? await db
          .select({
            telegramChatId: usersTable.telegramChatId,
            telegramId: usersTable.telegramId,
          })
          .from(usersTable)
          .where(eq(usersTable.id, order.userId))
          .limit(1)
      : [undefined];

    const userChatId = user ? getTelegramChatId(user) : null;
    const recipients = paymentSlipRecipients(ADMIN_CHAT_ID, userChatId);
    if (recipients.length === 0) {
      throw new Error("No Telegram receipt destinations are configured");
    }

    const image = await renderPaymentSlipPng({
      orderId: order.orderId,
      amountThb: order.amountThb,
      bankName: order.bankName,
      accountNumber: order.accountNumber,
      accountName: order.accountName,
      confirmedAt: order.confirmedAt ?? order.updatedAt,
    });
    const caption = [
      `<b>AndersPay+ · Payment receipt</b>`,
      ``,
      `✅ Payment completed`,
      `📋 Reference: <code>${order.orderId}</code>`,
    ].join("\n");
    const deliveries = recipients.map((chatId) =>
      sendTelegramPhotoDetailed(
        image,
        caption,
        `anderspay-slip-${order.orderId}.png`,
        "image/png",
        chatId,
      ),
    );
    const results = await Promise.all(deliveries);
    const sent = paymentSlipFullyDelivered(ADMIN_CHAT_ID, userChatId, results);
    if (!sent) {
      console.warn({
        orderId: order.orderId,
        adminChatConfigured: Boolean(ADMIN_CHAT_ID),
        userTelegramLinked: Boolean(userChatId),
        results: results.map((result) => result.ok ? "sent" : result.reason),
      }, "[payment-slip] Receipt was not delivered to all required destinations");
    }

    await db.insert(notificationLogsTable).values({
      id: randomUUID(),
      type: "payment_slip",
      userId: order.userId,
      message: logMessage,
      telegramStatus: sent ? "sent" : "failed",
    });
  } catch (error) {
    console.warn({ orderId: order.orderId, error }, "[payment-slip] Telegram delivery failed");
    try {
      await db.insert(notificationLogsTable).values({
        id: randomUUID(),
        type: "payment_slip",
        userId: order.userId,
        message: logMessage,
        telegramStatus: "failed",
      });
    } catch {
      // The payment itself is already complete; logging must remain best-effort.
    }
  }
}