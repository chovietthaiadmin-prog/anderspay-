/**
 * Private Telegram Notification Service
 * ======================================
 * Cung cấp thông báo Telegram 1-1 (private) cho hệ thống hộp thư hỗ trợ.
 *
 * sendAdminMessage() — gửi thông báo cho ADMIN khi khách gửi tin mới.
 *   · Dùng ADMIN_TELEGRAM_CHAT_ID (fallback: TELEGRAM_CHAT_ID).
 *   · Chống spam: > 3 tin / phút từ cùng 1 user sẽ gộp thành 1 cảnh báo.
 *
 * sendUserMessage()  — gửi thông báo riêng cho USER khi admin trả lời.
 *   · Chỉ gửi nếu user có telegram_chat_id và telegram_opt_in = true.
 *   · Không gửi cho khách vãng lai (guest:...).
 *
 * Bảo mật:
 *   · Không trả telegram_chat_id ra ngoài.
 *   · Không dùng group id.
 *   · Ghi log trạng thái gửi (sent / failed) vào notification_logs.
 *
 * Env vars:
 *   TELEGRAM_BOT_TOKEN        — bot token chung
 *   ADMIN_TELEGRAM_CHAT_ID    — chat id riêng của admin
 *   TELEGRAM_CHAT_ID          — fallback nếu ADMIN_TELEGRAM_CHAT_ID chưa set
 */

import { randomUUID } from "crypto";
import { db, usersTable, notificationLogsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { getTelegramChatId, sendTelegramMessageDetailed } from "../lib/telegram";
import { notifyAdminNewSupportMessage } from "../lib/admin-telegram-notify";
import { isUserViewingChat, isOnNotifCooldown, markNotified } from "../lib/presence";

const SUPPORT_URL = "https://anderspay.com/support";

// ── sendAdminMessage ──────────────────────────────────────────────────────
//
// Delegate hoàn toàn sang notifyAdminNewSupportMessage() đã có sẵn.
// Hàm đó đã xử lý: spam-collapse, user lookup, build text, send, log.
// Giữ nguyên để không duplicate logic.

export async function sendAdminMessage(
  userId: string,
  messageText: string,
): Promise<void> {
  return notifyAdminNewSupportMessage(userId, messageText);
}

// ── sendUserMessage ───────────────────────────────────────────────────────

/**
 * Gửi thông báo Telegram riêng cho user khi admin gửi phản hồi.
 * Fire-and-forget: không bao giờ throw — lỗi được swallow.
 */
export async function sendUserMessage(
  userId: string,
  adminMessageText: string,
): Promise<void> {
  try {
    // Khách vãng lai không có telegram_chat_id — bỏ qua.
    if (userId.startsWith("guest:")) return;

    // ── Smart presence check ─────────────────────────────────────────
    // Bỏ qua nếu user đang xem cuộc trò chuyện live trên trình duyệt.
    if (isUserViewingChat(userId)) return;

    // ── 30-second per-conversation cooldown ──────────────────────────
    const cooldownKey = `user:${userId}`;
    if (isOnNotifCooldown(cooldownKey)) return;

    // Lấy thông tin user: chat_id + opt-in flag
    const [u] = await db
      .select({
        telegramChatId: usersTable.telegramChatId,
        telegramId: usersTable.telegramId,
        telegramOptIn: usersTable.telegramOptIn,
      })
      .from(usersTable)
      .where(eq(usersTable.id, userId))
      .limit(1);

    if (!u) return;

    // Chỉ gửi nếu user đã liên kết Telegram và chưa opt-out.
    const chatId = getTelegramChatId(u);
    if (!chatId) return;
    if (!u.telegramOptIn) return;

    // Nội dung ngắn gọn — không lộ toàn bộ tin nhắn (spec: không gửi thông tin nhạy cảm)
    const text =
      `🔔 <b>Hỗ trợ đã trả lời bạn.</b>\n\n` +
      `👉 <a href="${SUPPORT_URL}">Mở anderspay+ để xem</a>`;

    const result = await sendTelegramMessageDetailed(text, chatId);
    markNotified(cooldownKey);

    // Ghi log trạng thái gửi
    await db.insert(notificationLogsTable).values({
      id: randomUUID(),
      type: "user_support_reply",
      userId,
      message: adminMessageText.slice(0, 500),
      telegramStatus: result.ok ? "sent" : "failed",
    });
  } catch {
    // Thông báo không được phép làm hỏng luồng HTTP chính.
  }
}
