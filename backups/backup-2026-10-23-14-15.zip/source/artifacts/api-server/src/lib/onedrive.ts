/**
 * OneDrive file helpers.
 *
 * Files are stored under "AndersPay Chat/<friendshipId>/<uuid>.<ext>"
 * in the authenticated user's OneDrive.
 *
 * The SDK handles OAuth token refresh automatically.
 */

import { ReplitConnectors } from "@replit/connectors-sdk";
import { randomUUID } from "crypto";

const connectors = new ReplitConnectors();

const ROOT_FOLDER = "AndersPay Chat";

const MIME_TO_EXT: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/jpg": "jpg",
  "image/png": "png",
  "image/gif": "gif",
  "image/webp": "webp",
  "image/heic": "heic",
  "image/heif": "heif",
  "video/mp4": "mp4",
  "video/quicktime": "mov",
  "video/webm": "webm",
  "video/x-matroska": "mkv",
  "video/3gpp": "3gp",
  "video/mpeg": "mpeg",
  "application/pdf": "pdf",
};

type ConnectorProxy = {
  proxy: (
    connection: string,
    path: string,
    init: {
      method: string;
      body?: Buffer | string;
      headers?: Record<string, string>;
    },
  ) => Promise<Response>;
};

const graph = connectors as unknown as ConnectorProxy;

let proxy: ConnectorProxy["proxy"] = graph.proxy.bind(graph);

/**
 * Replace the connector proxy for isolated tests and return a restore
 * function. Production code always uses the real Replit connector.
 */
export function setOneDriveProxyForTests(
  proxyImplementation: ConnectorProxy["proxy"],
): () => void {
  const previous = proxy;
  proxy = proxyImplementation;
  return () => {
    proxy = previous;
  };
}

export function mimeToExt(mimeType: string): string {
  return MIME_TO_EXT[mimeType] ?? "bin";
}

export function isVideoMime(mimeType: string): boolean {
  return mimeType.startsWith("video/");
}

interface DriveItem {
  id: string;
  "@microsoft.graph.downloadUrl"?: string;
  name?: string;
  size?: number;
}

interface GraphError {
  error?: { message?: string; code?: string };
}

/**
 * Upload file bytes (from base64 data URL or raw base64) to OneDrive.
 * Uses simple upload (≤ 250 MB). Returns the OneDrive item ID.
 */
export async function uploadChatMedia(
  friendshipId: string,
  base64Data: string,
  mimeType: string
): Promise<{ itemId: string }> {
  const ext = mimeToExt(mimeType);
  const fileName = `${randomUUID()}.${ext}`;
  // Strip "data:<type>;base64," prefix when present
  const rawBase64 = base64Data.includes(",") ? base64Data.split(",")[1] : base64Data;
  const buffer = Buffer.from(rawBase64, "base64");

  const path = `/v1.0/me/drive/root:/${ROOT_FOLDER}/${encodeURIComponent(friendshipId)}/${fileName}:/content`;

  const res = await proxy("onedrive", path, {
    method: "PUT",
    body: buffer,
    headers: { "Content-Type": mimeType },
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({})) as GraphError;
    throw new Error(
      `OneDrive upload failed (${res.status}): ${err?.error?.message ?? "unknown error"}`
    );
  }

  const item = await res.json() as DriveItem;
  return { itemId: item.id };
}

const PAYMENT_BILLS_FOLDER = "AndersPay Bills";

function safeFilePart(value: string, fallback: string): string {
  const cleaned = value
    .replace(/[^a-zA-Z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
  return cleaned || fallback;
}

async function ensurePaymentBillsFolder(): Promise<void> {
  const folderPath = `/v1.0/me/drive/root:/${PAYMENT_BILLS_FOLDER}`;
  const existing = await proxy("onedrive", folderPath, { method: "GET" });
  if (existing.ok) return;
  if (existing.status !== 404) {
    throw new Error(`OneDrive folder lookup failed (${existing.status})`);
  }

  const created = await proxy("onedrive", "/v1.0/me/drive/root/children", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name: PAYMENT_BILLS_FOLDER,
      folder: {},
    }),
  });

  // A concurrent upload may have created the folder between the GET and POST.
  // A conflict is therefore safe; the next upload can use the known path.
  if (!created.ok && created.status !== 409) {
    const err = await created.json().catch(() => ({})) as GraphError;
    throw new Error(
      `OneDrive folder creation failed (${created.status}): ${err?.error?.message ?? "unknown error"}`,
    );
  }
}

/**
 * Archive an original customer payment bill in OneDrive.
 *
 * Files are kept in one stable folder and include the order ID in their name,
 * so an order can be located later without storing bill bytes in PostgreSQL.
 * This uses the simple Graph upload endpoint and is suitable for the existing
 * 25 MB bill limit.
 */
export async function uploadPaymentBill(
  orderId: string,
  billBuffer: Buffer,
  mimeType: string,
  originalName: string,
  kind: "topup" | "payment",
): Promise<{ itemId: string; fileName: string }> {
  await ensurePaymentBillsFolder();

  const ext = mimeToExt(mimeType);
  const sourceName = safeFilePart(
    originalName.replace(/\.[^/.]+$/, ""),
    "bill",
  );
  const fileName = `${kind}-${safeFilePart(orderId, "order")}-${sourceName}-${randomUUID()}.${ext}`;
  const path = `/v1.0/me/drive/root:/${PAYMENT_BILLS_FOLDER}/${fileName}:/content`;
  const res = await proxy("onedrive", path, {
    method: "PUT",
    body: billBuffer,
    headers: { "Content-Type": mimeType },
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({})) as GraphError;
    throw new Error(
      `OneDrive bill upload failed (${res.status}): ${err?.error?.message ?? "unknown error"}`,
    );
  }

  const item = await res.json() as DriveItem;
  return { itemId: item.id, fileName };
}

/**
 * Fetch the pre-authenticated CDN download URL for an OneDrive item.
 *
 * IMPORTANT: Do NOT use $select here. The `@microsoft.graph.downloadUrl`
 * field is an OData annotation, not a regular property. Using $select
 * suppresses all annotations and causes the field to be absent even when
 * the item exists. Fetch the full item metadata so Graph includes it.
 */
export async function getDownloadUrl(itemId: string): Promise<string> {
  // No $select — annotations like @microsoft.graph.downloadUrl are only
  // returned when the full item response is requested.
  const path = `/v1.0/me/drive/items/${encodeURIComponent(itemId)}`;
  const res = await proxy("onedrive", path, { method: "GET" });

  if (!res.ok) {
    const errBody = await res.json().catch(() => ({})) as GraphError;
    throw new Error(
      `OneDrive item lookup failed (${res.status}): ${errBody?.error?.message ?? itemId}`
    );
  }

  const item = await res.json() as DriveItem;
  const url = item["@microsoft.graph.downloadUrl"];
  if (!url) {
    throw new Error(
      `OneDrive returned no download URL for item ${itemId} (item name: ${item.name ?? "unknown"})`
    );
  }
  return url;
}

/**
 * Download a chat attachment and return it as a Response suitable for piping.
 *
 * Strategy:
 * 1. Fetch the item metadata via the connector to get the pre-authenticated
 *    CDN URL (@microsoft.graph.downloadUrl).
 * 2. Fetch the CDN URL directly with a plain fetch (no connector proxy) —
 *    the pre-authenticated URL does not need Replit proxy headers and the
 *    connector proxy headers would cause the CDN to reject the request.
 */
export async function downloadChatMedia(itemId: string): Promise<Response> {
  const downloadUrl = await getDownloadUrl(itemId);
  // The CDN URL is pre-authenticated. A plain fetch is correct here —
  // routing through the connector proxy would add Replit auth headers that
  // the CDN does not recognise and may reject.
  return fetch(downloadUrl);
}

/**
 * Delete an OneDrive item silently (fire-and-forget).
 */
export async function deleteItem(itemId: string): Promise<void> {
  proxy("onedrive", `/v1.0/me/drive/items/${encodeURIComponent(itemId)}`, {
    method: "DELETE",
  }).catch(() => {});
}
