/**
 * User IDs that are test/internal accounts.
 * Their transactions and orders are excluded from:
 *   - GET  /api/admin/transactions  (admin history view)
 *   - POST /api/admin/transactions/report  (Telegram report)
 *   - GET  /api/external/combined|transactions|orders|users  (Onavixpay feed)
 *
 * Keep both IDs and stable phone identities here. Development and production
 * databases can contain the same tester with different generated UUIDs.
 */
export const TESTER_USER_IDS: string[] = [
  "f6ea7fea-baca-4abd-8ebd-798b3014661e", // Dachapat +66928754076
  "3dcf17d1-85b2-406c-aaef-2621b8c0339e", // Dachapat production UUID
];

export const TESTER_USER_PHONES: string[] = [
  "+66928754076", // Dachapat
];
