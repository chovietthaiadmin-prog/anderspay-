import { db, settingsTable, usersTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { getTelegramChatId, sendTelegramMessageDetailed } from "./telegram";
import { logger } from "./logger";

const NOTICE_KEY = "telegram_notice_otp_login_migration_2026_08_13";
const NOTICE_AT = new Date("2026-08-13T08:00:00+07:00").getTime();
const RETRY_WINDOW_MS = 2 * 60 * 60 * 1000;
const CHECK_AFTER_SEND_MS = 60 * 1000;

const NOTICE_TEXT = `⚠️ <b>CẢNH BÁO QUAN TRỌNG — CẬP NHẬT ĐĂNG NHẬP</b>

AndersPay+ sẽ bắt đầu chuyển đổi hệ thống đăng nhập sang OTP Telegram từ 08:00 sáng ngày 13/08/2026.

Vui lòng đăng nhập bằng Telegram để hệ thống nhận diện và cập nhật tài khoản của bạn. Nếu đang dùng mật khẩu, hãy hoàn tất việc đăng nhập bằng Telegram trước khi hệ thống được reset.

Nếu có thắc mắc hoặc xảy ra vấn đề như mất tài khoản, xóa nhầm nick hoặc sai số dư, vui lòng liên hệ Telegram admin: <b>@anderspays</b>.

⚠️ Không gửi mã OTP cho bất kỳ ai.`;

type NoticeState = {
  status: "sending" | "sent";
  remaining: string[];
  sentCount: number;
  failedCount: number;
};

let inFlight = false;

function parseState(value: string | undefined): NoticeState | null {
  if (!value) return null;
  try {
    const parsed = JSON.parse(value) as Partial<NoticeState>;
    if (parsed.status === "sent") {
      return { status: "sent", remaining: [], sentCount: parsed.sentCount ?? 0, failedCount: parsed.failedCount ?? 0 };
    }
    if (parsed.status === "sending" && Array.isArray(parsed.remaining)) {
      return {
        status: "sending",
        remaining: parsed.remaining.filter((id): id is string => typeof id === "string" && id.length > 0),
        sentCount: typeof parsed.sentCount === "number" ? parsed.sentCount : 0,
        failedCount: typeof parsed.failedCount === "number" ? parsed.failedCount : 0,
      };
    }
  } catch {
    // Treat malformed state as unscheduled and rebuild it at send time.
  }
  return null;
}

async function saveState(state: NoticeState): Promise<void> {
  const value = JSON.stringify(state);
  await db
    .insert(settingsTable)
    .values({ key: NOTICE_KEY, value, updatedAt: new Date() })
    .onConflictDoUpdate({
      target: settingsTable.key,
      set: { value, updatedAt: new Date() },
    });
}

async function loadState(): Promise<NoticeState | null> {
  const [row] = await db
    .select({ value: settingsTable.value })
    .from(settingsTable)
    .where(eq(settingsTable.key, NOTICE_KEY))
    .limit(1);
  return parseState(row?.value);
}

async function getRecipientChatIds(): Promise<string[]> {
  const rows = await db
    .select({
      telegramChatId: usersTable.telegramChatId,
      telegramId: usersTable.telegramId,
    })
    .from(usersTable)
    .where(sql`(${usersTable.telegramChatId} IS NOT NULL OR ${usersTable.telegramId} IS NOT NULL)`);

  return [...new Set(rows.map(getTelegramChatId).filter((id): id is string => Boolean(id)))];
}

async function runNoticeIfDue(): Promise<void> {
  if (inFlight || Date.now() < NOTICE_AT) return;
  inFlight = true;

  try {
    let state = await loadState();
    if (state?.status === "sent") return;

    if (!state) {
      state = {
        status: "sending",
        remaining: await getRecipientChatIds(),
        sentCount: 0,
        failedCount: 0,
      };
      await saveState(state);
    }

    // Do not keep a one-off notice alive indefinitely if Telegram has already
    // rejected a recipient or the connector is unavailable after the window.
    const expired = Date.now() > NOTICE_AT + RETRY_WINDOW_MS;
    for (const chatId of state.remaining) {
      const result = await sendTelegramMessageDetailed(NOTICE_TEXT, chatId);
      if (result.ok || result.errorCode === 403 || expired) {
        state.remaining = state.remaining.filter((id) => id !== chatId);
        if (result.ok) state.sentCount += 1;
        else state.failedCount += 1;
        await saveState(state);
      }
      await new Promise((resolve) => setTimeout(resolve, 120));
    }

    if (state.remaining.length === 0) {
      state.status = "sent";
      await saveState(state);
      logger.info(
        { sentCount: state.sentCount, failedCount: state.failedCount },
        "[scheduler] OTP login migration notice completed",
      );
    } else {
      logger.warn(
        { remainingCount: state.remaining.length, sentCount: state.sentCount, failedCount: state.failedCount },
        "[scheduler] OTP login migration notice will retry failed deliveries",
      );
    }
  } catch (err) {
    logger.error({ err }, "[scheduler] OTP login migration notice failed");
  } finally {
    inFlight = false;
  }
}

/**
 * One-off important notice for the password-to-Telegram-OTP migration.
 * Production-only and persisted in settings so restarts do not lose the
 * schedule or resend messages that already succeeded.
 */
export function startOtpLoginMigrationNoticeScheduler(): void {
  const tick = () => {
    runNoticeIfDue().finally(() => {
      const delay = Date.now() < NOTICE_AT
        ? NOTICE_AT - Date.now()
        : CHECK_AFTER_SEND_MS;
      setTimeout(tick, Math.max(1000, delay));
    });
  };

  logger.info(
    { noticeAt: new Date(NOTICE_AT).toISOString() },
    "[scheduler] OTP login migration notice scheduled",
  );
  tick();
}