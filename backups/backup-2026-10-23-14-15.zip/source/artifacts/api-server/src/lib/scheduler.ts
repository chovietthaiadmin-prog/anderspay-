import { logger } from "./logger";
import { sendBalanceBackupReport } from "./balance-backup";
import { db, supportMessagesTable } from "@workspace/db";
import { lt, sql } from "drizzle-orm";

// Time-of-day (Asia/Bangkok / ICT) at which the daily balance backup
// report fires. Override via BALANCE_BACKUP_HOUR_ICT (0-23) and
// BALANCE_BACKUP_MINUTE_ICT (0-59). Default 05:30 ICT.
const BACKUP_HOUR_ICT = (() => {
  const raw = process.env.BALANCE_BACKUP_HOUR_ICT;
  const n = raw ? Number(raw) : 5;
  return Number.isFinite(n) && n >= 0 && n <= 23 ? Math.floor(n) : 5;
})();
const BACKUP_MINUTE_ICT = (() => {
  const raw = process.env.BALANCE_BACKUP_MINUTE_ICT;
  const n = raw ? Number(raw) : 30;
  return Number.isFinite(n) && n >= 0 && n <= 59 ? Math.floor(n) : 30;
})();

// ICT is UTC+7 with no DST, so we can compute the next fire time purely
// in UTC arithmetic — no timezone library needed.
function msUntilNextFire(now: Date = new Date()): number {
  const ICT_OFFSET_MIN = 7 * 60;
  const nowIctMs = now.getTime() + ICT_OFFSET_MIN * 60 * 1000;
  const nowIct = new Date(nowIctMs);
  const target = new Date(nowIctMs);
  target.setUTCHours(BACKUP_HOUR_ICT, BACKUP_MINUTE_ICT, 0, 0);
  if (target.getTime() <= nowIct.getTime()) {
    target.setUTCDate(target.getUTCDate() + 1);
  }
  return target.getTime() - nowIct.getTime();
}

// Single in-flight guard shared by both the daily 5:30 ICT scheduler and
// the periodic 2-hour scheduler so the two cron paths can never spam the
// Telegram group with overlapping reports if their fire times collide.
let backupInFlight = false;

async function runBackupOnce(source: string): Promise<void> {
  if (backupInFlight) {
    logger.warn({ source }, "[scheduler] balance backup already running — skipping this tick");
    return;
  }
  backupInFlight = true;
  try {
    await sendBalanceBackupReport();
  } catch (err) {
    // Telegram failures must never crash the server — log and move on so
    // the next scheduled tick still fires.
    logger.error({ err, source }, "[scheduler] balance backup failed");
  } finally {
    backupInFlight = false;
  }
}

export function startDailyBalanceBackupScheduler(): void {
  const schedule = () => {
    const delay = msUntilNextFire();
    const fireAt = new Date(Date.now() + delay);
    logger.info(
      { fireAt: fireAt.toISOString(), hourIct: BACKUP_HOUR_ICT, minuteIct: BACKUP_MINUTE_ICT, delayMs: delay },
      "[scheduler] next balance backup scheduled"
    );
    setTimeout(async () => {
      try {
        await runBackupOnce("daily");
      } finally {
        // Always re-arm so a single failure can't kill the daily cadence.
        schedule();
      }
    }, delay);
  };
  schedule();
}

// Interval (ms) between supplemental balance-backup reports. Default 1h.
// Override via BALANCE_BACKUP_INTERVAL_HOURS for ops tuning.
const PERIODIC_BACKUP_INTERVAL_MS = (() => {
  const raw = process.env.BALANCE_BACKUP_INTERVAL_HOURS;
  const n = raw ? Number(raw) : 1;
  const hours = Number.isFinite(n) && n > 0 ? n : 1;
  return Math.floor(hours * 60 * 60 * 1000);
})();

export function startPeriodicBalanceBackupScheduler(): void {
  logger.info(
    { intervalMs: PERIODIC_BACKUP_INTERVAL_MS },
    "[scheduler] periodic balance backup scheduler started"
  );
  setInterval(() => {
    runBackupOnce("periodic").catch((err) => {
      logger.error({ err }, "[scheduler] periodic balance backup unexpected failure");
    });
  }, PERIODIC_BACKUP_INTERVAL_MS);
}

// ── Support message retention (10-day rolling delete) ──────────────────────
const SUPPORT_RETENTION_DAYS = 10;

async function runSupportMessageCleanup(): Promise<void> {
  const cutoff = sql`now() - interval '${sql.raw(String(SUPPORT_RETENTION_DAYS))} days'`;
  const result = await db
    .delete(supportMessagesTable)
    .where(lt(supportMessagesTable.createdAt, cutoff));
  logger.info(
    { retentionDays: SUPPORT_RETENTION_DAYS },
    "[scheduler] support message cleanup complete"
  );
}

// Runs once a day, offset by 1 hour after the balance backup (06:30 ICT)
// so cleanup never competes with the backup report.
export function startSupportMessageCleanupScheduler(): void {
  const INTERVAL_MS = 24 * 60 * 60 * 1000; // 24 h

  // Run once at startup (catches any backlog from before this feature shipped)
  runSupportMessageCleanup().catch((err) => {
    logger.error({ err }, "[scheduler] support message cleanup startup run failed");
  });

  setInterval(() => {
    runSupportMessageCleanup().catch((err) => {
      logger.error({ err }, "[scheduler] support message cleanup daily run failed");
    });
  }, INTERVAL_MS);

  logger.info(
    { retentionDays: SUPPORT_RETENTION_DAYS, intervalMs: INTERVAL_MS },
    "[scheduler] support message cleanup scheduler started"
  );
}
