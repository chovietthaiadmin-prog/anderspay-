import { ReplitConnectors } from "@replit/connectors-sdk";
import { logger } from "./logger";

// Sends transactional email through the user's connected Gmail account
// (Replit Gmail connector). The SDK proxies requests to the Gmail API
// with automatic OAuth token refresh — never cache clients or tokens.

function base64Url(input: string): string {
  return Buffer.from(input).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

// RFC 2047 encode a header value so UTF-8 subjects survive transport.
function encodeHeader(value: string): string {
  if (/^[\x20-\x7e]*$/.test(value)) return value;
  return `=?UTF-8?B?${Buffer.from(value).toString("base64")}?=`;
}

export async function sendEmail(opts: { to: string; subject: string; html: string; text: string }): Promise<void> {
  const boundary = `ap-${Date.now().toString(36)}`;
  const mime = [
    `To: ${opts.to}`,
    `Subject: ${encodeHeader(opts.subject)}`,
    "MIME-Version: 1.0",
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
    "",
    `--${boundary}`,
    'Content-Type: text/plain; charset="UTF-8"',
    "Content-Transfer-Encoding: base64",
    "",
    Buffer.from(opts.text).toString("base64"),
    `--${boundary}`,
    'Content-Type: text/html; charset="UTF-8"',
    "Content-Transfer-Encoding: base64",
    "",
    Buffer.from(opts.html).toString("base64"),
    `--${boundary}--`,
  ].join("\r\n");

  const connectors = new ReplitConnectors();
  const response = await connectors.proxy("google-mail", "/gmail/v1/users/me/messages/send", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ raw: base64Url(mime) }),
  });
  if (!response.ok) {
    const body = await response.text().catch(() => "");
    logger.error({ status: response.status, body: body.slice(0, 300) }, "gmail send failed");
    throw new Error(`email_send_failed:${response.status}`);
  }
}

// Branded OTP email. Dark card on light backdrop so it renders well in
// both light- and dark-mode mail clients.
export function otpEmailHtml(otp: string): string {
  const digits = otp
    .split("")
    .map(
      (d) =>
        `<td style="width:44px;height:56px;background:#1a1a1a;border:1px solid #333;border-radius:10px;text-align:center;font-size:26px;font-weight:700;color:#f5c542;font-family:'Courier New',monospace;">${d}</td><td style="width:8px;"></td>`,
    )
    .join("");
  return `<!doctype html>
<html><body style="margin:0;padding:0;background:#f4f4f5;font-family:Arial,Helvetica,sans-serif;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="padding:32px 16px;">
    <tr><td align="center">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:420px;background:#0b0b0b;border-radius:16px;padding:32px 28px;">
        <tr><td align="center" style="padding-bottom:20px;">
          <span style="font-size:24px;font-weight:800;color:#f5c542;">Anders</span><span style="font-size:24px;font-weight:800;color:#ff3b3b;">Pay</span><span style="font-size:15px;font-weight:800;color:#f5c542;vertical-align:top;">+</span>
        </td></tr>
        <tr><td align="center" style="color:#e5e5e5;font-size:15px;padding-bottom:8px;">Your verification code is:</td></tr>
        <tr><td align="center" style="padding:16px 0 20px;">
          <table role="presentation" cellpadding="0" cellspacing="0"><tr>${digits}</tr></table>
        </td></tr>
        <tr><td align="center" style="color:#9ca3af;font-size:13px;line-height:1.6;">
          This code expires in <strong style="color:#e5e5e5;">10 minutes</strong>.<br/>
          If you did not request this code, ignore this email.
        </td></tr>
        <tr><td align="center" style="padding-top:24px;border-top:1px solid #222;margin-top:20px;">
          <span style="color:#6b7280;font-size:11px;">AndersPay+ — Thailand Payment Platform</span>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body></html>`;
}

export function otpEmailText(otp: string): string {
  return `Your AndersPay+ verification code is: ${otp}\n\nThis code expires in 10 minutes.\nIf you did not request this code, ignore this email.`;
}
