import { db, usersTable } from "@workspace/db";
import { sql, desc } from "drizzle-orm";
import { logger } from "./logger";
import { sendTelegramMessage } from "./telegram";

// Telegram caps a single message at 4096 chars. We pack rows into
// chunks by actual rendered length (not a fixed user count) so that
// a few long display names can't silently push a chunk over the limit
// and cause sendMessage to fail.
const TELEGRAM_MAX_CHARS = 4096;
const CHUNK_CHAR_BUDGET = 3800; // leave headroom for header + footer
const BACKUP_CHAT_ID = process.env.TELEGRAM_BACKUP_CHAT_ID;

function fmtThb(n: number): string {
  return n.toLocaleString("th-TH", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function fmtUsdt(n: number): string {
  return n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 6 });
}

interface BackupRow {
  uid: string | null;
  name: string;
  nickname: string | null;
  thb: number;
  usdt: number;
}

async function fetchBalanceRows(): Promise<BackupRow[]> {
  // Only include users with a non-zero balance — keeps the report
  // compact and meaningful even as the user base grows.
  const rows = await db
    .select({
      uid: usersTable.uid,
      name: usersTable.name,
      nickname: usersTable.nickname,
      usdtBalance: usersTable.usdtBalance,
      thbBalance: usersTable.thbBalance,
    })
    .from(usersTable)
    // Include any non-zero balance (positive OR negative) so the daily
    // backup still surfaces accounts that owe / are owed funds after
    // adjustments or reconciliations.
    .where(sql`${usersTable.usdtBalance}::numeric <> 0 OR ${usersTable.thbBalance}::numeric <> 0`)
    .orderBy(desc(sql`ABS(${usersTable.thbBalance}::numeric) + ABS(${usersTable.usdtBalance}::numeric) * 35`));

  return rows.map((r) => ({
    uid: r.uid,
    name: r.name,
    nickname: r.nickname,
    thb: Number(r.thbBalance ?? 0),
    usdt: Number(r.usdtBalance ?? 0),
  }));
}

function escapeHtml(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// Defensive cap: a single pathological display name shouldn't be
// allowed to occupy a whole Telegram message on its own.
const MAX_DISPLAY_LEN = 80;

function clip(s: string): string {
  return s.length > MAX_DISPLAY_LEN ? s.slice(0, MAX_DISPLAY_LEN - 1) + "…" : s;
}

function renderRow(r: BackupRow): string {
  // Show legal name AND nickname (when present) on separate lines so
  // operators can identify a customer by either. The previous layout
  // collapsed to nickname-or-name, hiding one of the two when both
  // existed. UID is the permanent public ID; "(chưa có UID)" flags
  // accounts that haven't completed onboarding.
  const name = escapeHtml(clip(r.name));
  const nickRaw = r.nickname?.trim();
  const nick = nickRaw ? escapeHtml(clip(nickRaw)) : "—";
  const uid = r.uid ? `<code>${escapeHtml(r.uid)}</code>` : `<i>(chưa có UID)</i>`;
  return [
    `• <b>${name}</b>`,
    `   💬 ${nick}`,
    `   👤 ${uid}  |  THB <code>${fmtThb(r.thb)}</code>  |  USDT <code>${fmtUsdt(r.usdt)}</code>`,
  ].join("\n");
}

function buildChunks(rows: BackupRow[]): string[] {
  const now = new Date().toLocaleString("vi-VN", { timeZone: "Asia/Bangkok" });
  const totalThb = rows.reduce((s, r) => s + r.thb, 0);
  const totalUsdt = rows.reduce((s, r) => s + r.usdt, 0);

  if (rows.length === 0) {
    return [
      [
        `🗂 <b>BACKUP SỐ DƯ KHÁCH HÀNG — AndersPay+</b>`,
        `📅 ${now} (ICT)`,
        ``,
        `<i>Không có khách hàng nào còn số dư.</i>`,
      ].join("\n"),
    ];
  }

  const header =
    `🗂 <b>BACKUP SỐ DƯ KHÁCH HÀNG — AndersPay+</b>\n` +
    `📅 ${now} (ICT)\n` +
    `👥 Tổng số khách có số dư: <b>${rows.length}</b>\n` +
    `💰 Tổng THB: <b>${fmtThb(totalThb)}</b>\n` +
    `💵 Tổng USDT: <b>${fmtUsdt(totalUsdt)}</b>\n`;
  const footer = `\n<i>— Hết báo cáo —</i>`;

  // Pack rows by actual rendered length, never letting a chunk exceed
  // the Telegram per-message cap. The first chunk includes the header.
  const chunks: string[] = [];
  let current = header;

  for (const row of rows) {
    const line = renderRow(row);
    // +1 for the joining newline.
    if (current.length + 1 + line.length > CHUNK_CHAR_BUDGET) {
      chunks.push(current);
      current = `🗂 <b>BACKUP SỐ DƯ — phần tiếp theo</b>\n`;
    }
    current += "\n" + line;
  }
  // Append the footer to the final chunk only if it fits, else send
  // it as its own tiny chunk so we never overflow.
  if (current.length + footer.length <= TELEGRAM_MAX_CHARS) {
    current += footer;
    chunks.push(current);
  } else {
    chunks.push(current);
    chunks.push(`🗂 <b>BACKUP SỐ DƯ</b>${footer}`);
  }

  // Re-label multi-part chunks now that we know the total count.
  if (chunks.length > 1) {
    for (let i = 1; i < chunks.length; i++) {
      chunks[i] = chunks[i]!.replace(
        "🗂 <b>BACKUP SỐ DƯ — phần tiếp theo</b>",
        `🗂 <b>BACKUP SỐ DƯ — phần ${i + 1}/${chunks.length}</b>`,
      );
    }
  }
  return chunks;
}

export interface BackupResult {
  ok: boolean;
  reason?: "no_chat_id" | "send_failed";
  userCount: number;
  chunkCount: number;
  totalThb: number;
  totalUsdt: number;
}

export async function sendBalanceBackupReport(): Promise<BackupResult> {
  if (!BACKUP_CHAT_ID) {
    logger.warn("[balance-backup] TELEGRAM_BACKUP_CHAT_ID not set — skipping report");
    return { ok: false, reason: "no_chat_id", userCount: 0, chunkCount: 0, totalThb: 0, totalUsdt: 0 };
  }
  const rows = await fetchBalanceRows();
  const totalThb = rows.reduce((s, r) => s + r.thb, 0);
  const totalUsdt = rows.reduce((s, r) => s + r.usdt, 0);
  const chunks = buildChunks(rows);

  let allOk = true;
  for (const text of chunks) {
    const ok = await sendTelegramMessage(text, BACKUP_CHAT_ID);
    if (!ok) allOk = false;
    // Tiny pacing gap so Telegram doesn't reorder large reports.
    await new Promise((r) => setTimeout(r, 250));
  }

  logger.info(
    { users: rows.length, chunks: chunks.length, ok: allOk },
    "[balance-backup] daily report sent"
  );
  return {
    ok: allOk,
    reason: allOk ? undefined : "send_failed",
    userCount: rows.length,
    chunkCount: chunks.length,
    totalThb,
    totalUsdt,
  };
}
