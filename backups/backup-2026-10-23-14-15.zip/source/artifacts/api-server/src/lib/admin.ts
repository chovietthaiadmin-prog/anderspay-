/**
 * Single source of truth for "is this user an admin?".
 *
 * Two signals are combined:
 *   1. `ADMIN_PHONES` env var — comma-separated list of founding admin
 *      phone numbers. These are bootstrap admins; they cannot be
 *      demoted via the UI.
 *   2. `users.is_admin` DB column — set by the in-app "Add admin"
 *      flow, which is itself gated by the destructive operator key.
 *
 * Any code that needs to gate an admin-only capability should call
 * `isAdminUser({ phone, isAdmin })` with the row freshly loaded from
 * the database (so a just-promoted/demoted user is honoured on the
 * next request, no relogin required).
 */
export function getAdminPhones(): string[] {
  return (process.env.ADMIN_PHONES ?? "")
    .split(",")
    .map((p) => p.trim())
    .filter(Boolean);
}

export function isAdminPhone(phone: string): boolean {
  return getAdminPhones().includes(phone);
}

export function isAdminUser(u: { phone: string; isAdmin?: boolean | null }): boolean {
  return isAdminPhone(u.phone) || !!u.isAdmin;
}
