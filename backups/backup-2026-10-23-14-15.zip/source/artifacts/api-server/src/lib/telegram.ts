import QRCode from "qrcode";

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
// Default chat — used for USDT deposits ("bill nạp") and as fallback
const CHAT_ID = process.env.TELEGRAM_CHAT_ID;
// Separate admin group/chat for administrative reports and alerts
const ADMIN_CHAT_ID = process.env.ADMIN_TELEGRAM_CHAT_ID;
// Separate chat for THB payment requests ("yêu cầu thanh toán baht")
const PAYMENT_CHAT_ID = process.env.TELEGRAM_PAYMENT_CHAT_ID;
// Separate group for exchange-rate change notifications
const RATE_CHAT_ID = process.env.TELEGRAM_RATE_CHAT_ID;
// Separate bot for exchange-rate notifications only
const RATE_BOT_TOKEN = process.env.TELEGRAM_RATE_BOT_TOKEN;

const API = () => `https://api.telegram.org/bot${BOT_TOKEN}`;

/**
 * Telegram Login already verifies that the app may address the user's
 * private Telegram chat. Older Telegram-authenticated accounts may have
 * telegramId but no telegramChatId because they were created before the
 * automatic linking flow existed, so use telegramId as a safe fallback.
 */
export function getTelegramChatId(user: {
  telegramChatId?: string | null;
  telegramId?: string | null;
}): string | null {
  return user.telegramChatId ?? user.telegramId ?? null;
}

/** Resolve which chat a message should go to. */
function resolveChatId(target?: "deposit" | "payment" | "admin" | string | number): string | undefined {
  if (typeof target === "number") return String(target);
  if (
    typeof target === "string" &&
    target !== "deposit" &&
    target !== "payment" &&
    target !== "admin"
  ) {
    return target;
  }
  if (target === "admin") return ADMIN_CHAT_ID;
  if (target === "payment") return PAYMENT_CHAT_ID ?? CHAT_ID;
  return CHAT_ID;
}

export async function sendTelegramMessage(
  text: string,
  target?: "deposit" | "payment" | "admin" | "rate" | string | number
): Promise<boolean> {
  const r = await sendTelegramMessageDetailed(text, target);
  return r.ok;
}

export type TelegramSendResult =
  | { ok: true }
  | {
      ok: false;
      reason: "no_token" | "no_chat" | "network" | "telegram_error";
      description?: string;
      errorCode?: number;
    };

export async function sendTelegramMessageDetailed(
  text: string,
  target?: "deposit" | "payment" | "admin" | "rate" | string | number,
): Promise<TelegramSendResult> {
  const chatId = resolveChatId(target);
  return sendTelegramMessageWithBotDetailed(text, BOT_TOKEN, chatId);
}

/**
 * Send through a separately configured bot. Used for admin reports so they
 * never share the bill-deposit bot's token or destination.
 */
export async function sendTelegramMessageWithBot(
  text: string,
  botToken: string | undefined,
  chatId: string | number | undefined,
): Promise<boolean> {
  const r = await sendTelegramMessageWithBotDetailed(text, botToken, chatId);
  return r.ok;
}

async function sendTelegramMessageWithBotDetailed(
  text: string,
  botToken: string | undefined,
  chatId: string | number | undefined,
): Promise<TelegramSendResult> {
  if (!botToken) return { ok: false, reason: "no_token" };
  if (!chatId) return { ok: false, reason: "no_chat" };
  try {
    const res = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: String(chatId), text, parse_mode: "HTML" }),
    });
    const data = (await res.json().catch(() => ({}))) as {
      ok?: boolean;
      description?: string;
      error_code?: number;
    };
    if (data.ok) return { ok: true };
    return {
      ok: false,
      reason: "telegram_error",
      description: data.description,
      errorCode: data.error_code,
    };
  } catch (err) {
    return {
      ok: false,
      reason: "network",
      description: err instanceof Error ? err.message : String(err),
    };
  }
}

/** Send an exchange-rate update through the dedicated rate bot and group. */
export async function sendRateTelegramMessageDetailed(
  text: string,
): Promise<TelegramSendResult> {
  return sendTelegramMessageWithBotDetailed(text, RATE_BOT_TOKEN, RATE_CHAT_ID);
}

export async function sendTelegramMessageWithButton(
  text: string,
  orderId: string,   // UUID — used as callback_data
  target?: "deposit" | "payment"
): Promise<void> {
  const chatId = resolveChatId(target);
  if (!BOT_TOKEN || !chatId) return;
  // Payment orders (THB withdrawal): admin either confirms transfer or refunds.
  // Deposit orders (USDT bill): admin either confirms received or marks not received.
  const buttons = target === "payment"
    ? [
        { text: "✅ Xác nhận đã gửi", callback_data: `payment_confirm:${orderId}` },
        { text: "💸 Hoàn tiền",       callback_data: `payment_refund:${orderId}` },
      ]
    : [
        { text: "✅ Xác nhận hoàn thành", callback_data: `confirm:${orderId}` },
        { text: "❌ Chưa nhận",            callback_data: `not_received:${orderId}` },
      ];
  try {
    await fetch(`${API()}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [buttons] },
      }),
    });
  } catch {
    // Non-blocking
  }
}

export async function editMessageRemoveButtons(
  chatId: number | string,
  messageId: number
): Promise<void> {
  if (!BOT_TOKEN) return;
  try {
    await fetch(`${API()}/editMessageReplyMarkup`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        message_id: messageId,
        reply_markup: { inline_keyboard: [] },
      }),
    });
  } catch {
    // Non-blocking
  }
}

/**
 * Replace the inline keyboard of an existing message with a new layout.
 * Used to swap original action buttons for a confirm/cancel row.
 */
export async function editMessageInlineKeyboard(
  chatId: number | string,
  messageId: number,
  inlineKeyboard: Array<Array<{ text: string; callback_data: string }>>,
): Promise<void> {
  if (!BOT_TOKEN) return;
  try {
    await fetch(`${API()}/editMessageReplyMarkup`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        message_id: messageId,
        reply_markup: { inline_keyboard: inlineKeyboard },
      }),
    });
  } catch {
    // Non-blocking
  }
}

export async function answerCallbackQuery(callbackQueryId: string, text: string): Promise<void> {
  if (!BOT_TOKEN) return;
  try {
    await fetch(`${API()}/answerCallbackQuery`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ callback_query_id: callbackQueryId, text, show_alert: false }),
    });
  } catch {
    // Non-blocking
  }
}

export async function sendTelegramPhoto(
  imageBuffer: Buffer,
  caption: string,
  filename: string,
  target?: "deposit" | "payment"
): Promise<void> {
  const chatId = resolveChatId(target);
  if (!BOT_TOKEN || !chatId) return;
  try {
    const formData = new FormData();
    formData.append("chat_id", chatId);
    formData.append("caption", caption);
    formData.append("parse_mode", "HTML");
    formData.append("photo", new Blob([new Uint8Array(imageBuffer)], { type: "image/jpeg" }), filename);
    await fetch(`${API()}/sendPhoto`, { method: "POST", body: formData });
  } catch {
    // Non-blocking
  }
}

// Like sendTelegramMessageDetailed but for photos with caption.
// Used by admin broadcast — returns ok/error so each delivery can be
// counted in the audit row.
export async function sendTelegramPhotoDetailed(
  imageBuffer: Buffer,
  caption: string,
  filename: string,
  mimeType: string,
  chatId: string,
): Promise<TelegramSendResult> {
  if (!BOT_TOKEN) return { ok: false, reason: "no_token" };
  if (!chatId) return { ok: false, reason: "no_chat" };
  try {
    const formData = new FormData();
    formData.append("chat_id", chatId);
    if (caption) formData.append("caption", caption);
    formData.append("parse_mode", "HTML");
    formData.append(
      "photo",
      new Blob([new Uint8Array(imageBuffer)], { type: mimeType || "image/jpeg" }),
      filename,
    );
    const res = await fetch(`${API()}/sendPhoto`, { method: "POST", body: formData });
    const data = (await res.json().catch(() => ({}))) as {
      ok?: boolean;
      description?: string;
      error_code?: number;
    };
    if (data.ok) return { ok: true };
    return {
      ok: false,
      reason: "telegram_error",
      description: data.description,
      errorCode: data.error_code,
    };
  } catch (err) {
    return {
      ok: false,
      reason: "network",
      description: err instanceof Error ? err.message : String(err),
    };
  }
}

export async function sendTelegramPhotoWithButtons(
  imageBuffer: Buffer,
  caption: string,
  filename: string,
  orderId: string,
  target?: "deposit" | "payment"
): Promise<void> {
  const chatId = resolveChatId(target);
  if (!BOT_TOKEN || !chatId) return;
  try {
    const formData = new FormData();
    formData.append("chat_id", chatId);
    formData.append("caption", caption);
    formData.append("parse_mode", "HTML");
    formData.append("photo", new Blob([new Uint8Array(imageBuffer)], { type: "image/jpeg" }), filename);
    formData.append("reply_markup", JSON.stringify({
      inline_keyboard: [[
        { text: "✅ Xác nhận", callback_data: `confirm:${orderId}` },
        { text: "❌ Từ chối — sai số USDT", callback_data: `topup_reject:${orderId}` },
      ]],
    }));
    await fetch(`${API()}/sendPhoto`, { method: "POST", body: formData });
  } catch {
    // Non-blocking
  }
}

/**
 * Render a raw EMVCo QR payload string to a PNG and post it to the
 * payment Telegram chat with a transfer-amount caption. Used so admin
 * can scan and pay the same QR the customer scanned without having to
 * re-key bank details.
 */
export async function sendPromPayQrToTelegram(params: {
  qrPayload: string;
  /** Internal UUID — used as callback_data so the webhook can look up the
      order by primary key. Must match orders.id in the DB. */
  id: string;
  /** Human-readable short code (e.g. "AP-XXXX") shown in the caption. */
  orderId: string;
  amountThb: number;
  bankName: string;
  accountNumber: string;
  accountName: string;
  /** Customer identity for the admin-facing caption. Optional because
      guest orders (no auth) won't have any of these fields. */
  customer?: CustomerSummary;
}): Promise<void> {
  const { qrPayload, id, orderId, amountThb, bankName, accountNumber, accountName, customer } = params;
  const chatId = resolveChatId("payment");
  if (!BOT_TOKEN || !chatId) return;
  try {
    const png = await QRCode.toBuffer(qrPayload, {
      errorCorrectionLevel: "M",
      margin: 2,
      width: 600,
      color: { dark: "#000000", light: "#FFFFFF" },
    });
    const amountStr = amountThb.toLocaleString("th-TH", { maximumFractionDigits: 2 });
    const caption = [
      `🇹🇭 <b>QR PROMPAY KHÁCH ĐÃ QUÉT — AndersPay+</b>`,
      ``,
      `━━━━━━━━━━━━━━`,
      `💰 <b>SỐ TIỀN CẦN CHUYỂN</b>`,
      `<b>👉 <code>${amountStr}</code> THB 👈</b>`,
      `━━━━━━━━━━━━━━`,
      ``,
      ...buildCustomerLines(customer),
      `📋 <b>Mã lệnh:</b> <code>${orderId}</code>`,
      ``,
      `🏦 <b>Ngân hàng:</b> ${bankName}`,
      `🔢 <b>Số TK:</b> <code>${accountNumber}</code>`,
      `👤 <b>Chủ TK:</b> ${accountName}`,
      ``,
      `📲 <i>Quét lại mã QR bên dưới để chuyển khoản đúng số tiền khách yêu cầu.</i>`,
    ].join("\n");
    const formData = new FormData();
    formData.append("chat_id", chatId);
    formData.append("caption", caption);
    formData.append("parse_mode", "HTML");
    formData.append("photo", new Blob([new Uint8Array(png)], { type: "image/png" }), `qr-${orderId}.png`);
    // Same admin actions as the bank-transfer flow — confirm "đã gửi" or refund.
    // The telegram webhook handles `payment_confirm:` / `payment_refund:` callbacks
    // and clears the buttons on this exact message via editMessageRemoveButtons.
    formData.append("reply_markup", JSON.stringify({
      inline_keyboard: [[
        { text: "✅ Xác nhận đã gửi", callback_data: `payment_confirm:${id}` },
        { text: "💸 Hoàn tiền",       callback_data: `payment_refund:${id}` },
      ]],
    }));
    await fetch(`${API()}/sendPhoto`, { method: "POST", body: formData });
  } catch {
    // Non-blocking — admin still has the text-only order notification.
  }
}

export function buildTopupCaption(params: {
  orderId: string;
  amountUsdt: number;
  amountThb: number;
  rate: number;
  network: string;
  customer?: CustomerSummary;
}): string {
  const { orderId, amountUsdt, amountThb, rate, network, customer } = params;
  const now = new Date().toLocaleString("vi-VN", { timeZone: "Asia/Bangkok" });
  return [
    `📥 <b>NẠP USDT MỚI — AndersPay+</b>`,
    ``,
    ...buildCustomerLines(customer),
    `📋 <b>Mã lệnh:</b> <code>${orderId}</code>`,
    `📅 <b>Thời gian:</b> ${now} (ICT)`,
    ``,
    `🌐 <b>Mạng:</b> ${network}`,
    `💵 <b>Số USDT:</b> <code>${amountUsdt.toFixed(6)}</code> USDT`,
    `💱 <b>Tỷ giá:</b> 1 USDT = ${rate.toFixed(2)} THB`,
    `💰 <b>Tương đương:</b> <code>${amountThb.toLocaleString("th-TH", { maximumFractionDigits: 2 })}</code> THB`,
    ``,
    `⏳ <i>Chờ xác nhận từ admin</i>`,
  ].join("\n");
}

export async function registerWebhook(baseUrl: string): Promise<void> {
  if (!BOT_TOKEN) return;
  const webhookUrl = `${baseUrl}/api/telegram/webhook`;
  try {
    const res = await fetch(`${API()}/setWebhook`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: webhookUrl, allowed_updates: ["callback_query", "message"] }),
    });
    const data = (await res.json()) as { ok: boolean; description?: string };
    if (data.ok) {
      console.log(`[telegram] Webhook registered: ${webhookUrl}`);
    } else {
      console.warn(`[telegram] Webhook registration failed: ${data.description}`);
    }
  } catch (e) {
    console.warn("[telegram] Webhook registration error:", e);
  }
}

export function buildBillCaption(params: {
  orderId: string;
  amountUsdt: number;
  amountThb: number;
  customer?: CustomerSummary;
}): string {
  const { orderId, amountUsdt, amountThb, customer } = params;
  const now = new Date().toLocaleString("vi-VN", { timeZone: "Asia/Bangkok" });
  return [
    `📸 <b>BILL NẠP USDT — AndersPay+</b>`,
    ``,
    ...buildCustomerLines(customer),
    `📋 <b>Mã lệnh:</b> <code>${orderId}</code>`,
    `📅 <b>Thời gian:</b> ${now} (ICT)`,
    `💵 <b>Số USDT:</b> <code>${amountUsdt.toFixed(6)}</code> USDT`,
    `💰 <b>Nhận THB:</b> <code>${amountThb.toLocaleString("th-TH", { maximumFractionDigits: 2 })}</code> THB`,
    ``,
    `🔍 <i>Vui lòng xác minh giao dịch</i>`,
  ].join("\n");
}

/**
 * Customer identity surfaced in admin-facing Telegram captions so the
 * operator can immediately see WHO placed the order without opening
 * the admin UI. All fields are optional because:
 *   • Guest (unauthenticated) orders have no user record.
 *   • Authenticated users may not have set a `uid` or `nickname` yet.
 * Empty / missing values are rendered as a "—" placeholder so the
 * row layout stays stable across orders.
 */
export type CustomerSummary = {
  uid?: string | null;
  name?: string | null;
  nickname?: string | null;
};

export function buildCustomerLines(customer?: CustomerSummary): string[] {
  if (!customer) {
    return [`👻 <i>Khách vãng lai (chưa đăng nhập)</i>`, ``];
  }
  const uid = customer.uid?.trim() || "—";
  const name = customer.name?.trim() || "—";
  const nickname = customer.nickname?.trim() || "—";
  return [
    `👤 <b>UID:</b> <code>${uid}</code>`,
    `📛 <b>Tên:</b> ${name}`,
    `💬 <b>Biệt danh:</b> ${nickname}`,
    ``,
  ];
}

export function buildNewOrderMessage(params: {
  orderId: string;
  amountUsdt: number;
  amountThb: number;
  rate: number;
  bankName: string;
  accountNumber: string;
  accountName: string;
  customer?: CustomerSummary;
}): string {
  const { orderId, amountThb, bankName, accountNumber, accountName, customer } = params;
  const now = new Date().toLocaleString("vi-VN", { timeZone: "Asia/Bangkok" });
  return [
    `🔔 <b>LỆNH THANH TOÁN THB — AndersPay+</b>`,
    ``,
    ...buildCustomerLines(customer),
    `📋 <b>Mã lệnh:</b> <code>${orderId}</code>`,
    `📅 <b>Thời gian:</b> ${now} (ICT)`,
    ``,
    `💰 <b>Khách gửi:</b> <code>${amountThb.toLocaleString("th-TH", { maximumFractionDigits: 2 })}</code> THB vào STK phía dưới:`,
    ``,
    `🏦 <b>Ngân hàng:</b> ${bankName}`,
    `🔢 <b>Số TK:</b> <code>${accountNumber}</code>`,
    `👤 <b>Chủ TK:</b> ${accountName}`,
    ``,
    `⏳ <i>Trạng thái: Chờ chuyển THB</i>`,
  ].join("\n");
}

export function buildReviewRequestCaption(params: {
  orderId: string;
  kind: "deposit" | "payment";
  amountUsdt: number;
  amountThb: number;
  bankName: string;
  accountNumber: string;
  accountName: string;
  createdAtIso: string;
  customer?: CustomerSummary;
}): string {
  const { orderId, kind, amountUsdt, amountThb, bankName, accountNumber, accountName, createdAtIso, customer } = params;
  const created = new Date(createdAtIso).toLocaleString("vi-VN", { timeZone: "Asia/Bangkok" });
  const now = new Date().toLocaleString("vi-VN", { timeZone: "Asia/Bangkok" });
  const minutes = Math.floor((Date.now() - new Date(createdAtIso).getTime()) / 60000);
  const header = kind === "deposit"
    ? "⚠️ <b>KHÁCH YÊU CẦU XEM XÉT — LỆNH NẠP USDT</b>"
    : "⚠️ <b>KHÁCH YÊU CẦU XEM XÉT — LỆNH THANH TOÁN THB</b>";
  const lines = [
    header,
    ``,
    ...buildCustomerLines(customer),
    `📋 <b>Mã lệnh:</b> <code>${orderId}</code>`,
    `📅 <b>Tạo lúc:</b> ${created} (ICT)`,
    `🔁 <b>Yêu cầu lúc:</b> ${now} (ICT) — đã chờ ${minutes} phút`,
    ``,
    `💵 <b>USDT:</b> <code>${amountUsdt.toFixed(6)}</code>`,
    `💰 <b>THB:</b> <code>${amountThb.toLocaleString("th-TH", { maximumFractionDigits: 2 })}</code>`,
  ];
  if (kind === "payment") {
    lines.push(
      ``,
      `🏦 <b>Ngân hàng:</b> ${bankName}`,
      `🔢 <b>Số TK:</b> <code>${accountNumber}</code>`,
      `👤 <b>Chủ TK:</b> ${accountName}`,
    );
  }
  lines.push(``, `🙏 <i>Vui lòng kiểm tra lại lệnh giúp khách.</i>`);
  return lines.join("\n");
}

export function buildCompletedMessage(params: {
  orderId: string;
  amountUsdt: number;
  amountThb: number;
  bankName: string;
  accountNumber: string;
  accountName: string;
  bahtSourceName?: string | null;
}): string {
  const { orderId, amountUsdt, amountThb, bankName, accountNumber, accountName, bahtSourceName } = params;
  const now = new Date().toLocaleString("vi-VN", { timeZone: "Asia/Bangkok" });

  // Topup orders are created with empty bank/account fields (see
  // POST /orders/topup in routes/orders.ts). For those we render a
  // dedicated "USDT credited" confirmation — no THB transfer, no bank
  // info — instead of the THB-payment layout, which would leave the
  // bank/STK/Chủ TK rows blank and read as a formatting bug.
  const isTopup = !bankName || bankName.trim().length === 0;
  if (isTopup) {
    return [
      `✅ <b>HOÀN THÀNH — AndersPay+</b>`,
      ``,
      `📋 <b>Mã lệnh:</b> <code>${orderId}</code>`,
      `📅 <b>Thời gian XN:</b> ${now} (ICT)`,
      ``,
      `💵 <b>Số USDT:</b> <code>${amountUsdt.toLocaleString("en-US", { maximumFractionDigits: 6 })}</code> USDT`,
      `💰 <b>Tương đương:</b> <code>${amountThb.toLocaleString("th-TH", { maximumFractionDigits: 2 })}</code> THB`,
      ``,
      `🎉 <i>Đã cộng USDT vào ví khách thành công!</i>`,
    ].join("\n");
  }

  return [
    `✅ <b>HOÀN THÀNH — AndersPay+</b>`,
    ``,
    `📋 <b>Mã lệnh:</b> <code>${orderId}</code>`,
    `📅 <b>Thời gian XN:</b> ${now} (ICT)`,
    ``,
    `💰 <b>THB đã chuyển:</b> <code>${amountThb.toLocaleString("th-TH", { maximumFractionDigits: 2 })}</code> THB`,
    ...(bahtSourceName ? [`🏦 <b>Nguồn Baht:</b> ${bahtSourceName}`] : []),
    ``,
    `🏦 <b>Ngân hàng:</b> ${bankName}`,
    `🔢 <b>Số TK:</b> <code>${accountNumber}</code>`,
    `👤 <b>Chủ TK:</b> ${accountName}`,
    ``,
    `🎉 <i>Đã chuyển THB thành công!</i>`,
  ].join("\n");
}
