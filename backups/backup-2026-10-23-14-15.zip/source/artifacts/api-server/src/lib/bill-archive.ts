import { uploadPaymentBill } from "./onedrive";
import { logger } from "./logger";

type BillKind = "topup" | "payment";

type BillArchiveUploader = typeof uploadPaymentBill;

type BillArchiveLogger = Pick<typeof logger, "info" | "error">;

const defaultDependencies = {
  upload: uploadPaymentBill,
  log: logger,
};

/**
 * Archive a customer bill without allowing the retention side effect to
 * change the payment API's response or order state.
 *
 * The dependency arguments are intentionally small so the archive contract
 * can be tested without a live OneDrive connection.
 */
export async function archiveBillToOneDrive(
  orderId: string,
  billBuffer: Buffer,
  billMime: string,
  billName: string,
  kind: BillKind,
  dependencies: {
    upload?: BillArchiveUploader;
    log?: BillArchiveLogger;
  } = {},
): Promise<void> {
  const { upload, log } = {
    ...defaultDependencies,
    upload: dependencies.upload ?? defaultDependencies.upload,
    log: dependencies.log ?? defaultDependencies.log,
  };

  try {
    const archived = await upload(orderId, billBuffer, billMime, billName, kind);
    log.info(
      { orderId, kind, itemId: archived.itemId, fileName: archived.fileName },
      "[orders] bill archived to OneDrive",
    );
  } catch (err) {
    // OneDrive is an archive/retention side effect. It must never turn a
    // valid order into a failed payment or cause the client to retry it.
    log.error({ err, orderId, kind }, "[orders] failed to archive bill to OneDrive");
  }
}