import type { Request } from "express";
import { safeEqual } from "./safe-equal";

/**
 * Per-policy: every admin-initiated destructive action — wiping data,
 * editing customer profile fields, deleting accounts/orders outside the
 * normal lifecycle — must carry a hard-coded operator key in the
 * `X-Destructive-Key` header. This is a second factor on top of the
 * admin JWT / ADMIN_API_SECRET so an attacker who steals an admin token
 * still cannot one-click delete production data.
 *
 * The key itself lives in the `DESTRUCTIVE_OP_KEY` secret. If the env
 * var isn't configured the helper fails closed (returns false), which
 * means destructive endpoints are inert until an operator deliberately
 * sets the secret. Comparison uses constant-time equality.
 */
export function verifyDestructiveKey(req: Request): boolean {
  const expected = process.env.DESTRUCTIVE_OP_KEY;
  if (!expected) return false;
  const provided = req.headers["x-destructive-key"];
  const raw = Array.isArray(provided) ? provided[0] : provided;
  if (typeof raw !== "string" || raw.length === 0) return false;
  return safeEqual(raw, expected);
}
