import { createHash, createHmac, timingSafeEqual } from "crypto";
import { logger } from "./logger";

// Payload shape produced by the Telegram Login Widget callback. All
// fields except `id`, `auth_date`, and `hash` are optional — Telegram
// only sends username/first_name/photo_url when the account exposes
// them.
export interface TelegramAuthPayload {
  id: number;
  first_name?: string;
  last_name?: string;
  username?: string;
  photo_url?: string;
  auth_date: number;
  hash: string;
}

export interface VerifiedTelegramAuth {
  telegramId: string;
  telegramUsername: string | null;
  telegramFirstName: string | null;
  telegramPhotoUrl: string | null;
}

// Reject login payloads older than 24h so a leaked widget callback
// can't be replayed weeks later. Telegram itself recommends 86400.
const MAX_AUTH_AGE_SEC = 86400;

function buildDataCheckString(payload: TelegramAuthPayload): string {
  // Per Telegram spec: take every key EXCEPT `hash`, sort
  // alphabetically, render as `key=value` lines joined by \n.
  const entries: [string, string][] = [];
  for (const [k, v] of Object.entries(payload)) {
    if (k === "hash" || v === undefined || v === null) continue;
    entries.push([k, String(v)]);
  }
  entries.sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
  return entries.map(([k, v]) => `${k}=${v}`).join("\n");
}

export type TelegramAuthVerifyResult =
  | { ok: true; data: VerifiedTelegramAuth }
  | { ok: false; reason: "no_token" | "bad_payload" | "bad_hash" | "expired" };

// Validate a Telegram Login Widget payload exactly as documented at
// https://core.telegram.org/widgets/login#checking-authorization. We
// derive the signing key from SHA-256(bot_token), HMAC-SHA256 the
// sorted data-check-string, and compare in constant time so a
// timing oracle can't be used to forge a hash byte-by-byte.
export function verifyTelegramAuth(raw: unknown): TelegramAuthVerifyResult {
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  if (!botToken) {
    logger.error("[telegram-auth] TELEGRAM_BOT_TOKEN not configured");
    return { ok: false, reason: "no_token" };
  }
  if (!raw || typeof raw !== "object") return { ok: false, reason: "bad_payload" };

  const r = raw as Record<string, unknown>;
  const idNum = typeof r.id === "number" ? r.id : Number(r.id);
  const authDateNum = typeof r.auth_date === "number" ? r.auth_date : Number(r.auth_date);
  const hashStr = typeof r.hash === "string" ? r.hash : "";
  if (!Number.isFinite(idNum) || idNum <= 0) return { ok: false, reason: "bad_payload" };
  if (!Number.isFinite(authDateNum) || authDateNum <= 0) return { ok: false, reason: "bad_payload" };
  if (!/^[a-f0-9]{64}$/i.test(hashStr)) return { ok: false, reason: "bad_payload" };

  const payload: TelegramAuthPayload = {
    id: idNum,
    auth_date: authDateNum,
    hash: hashStr,
    ...(typeof r.first_name === "string" ? { first_name: r.first_name } : {}),
    ...(typeof r.last_name === "string" ? { last_name: r.last_name } : {}),
    ...(typeof r.username === "string" ? { username: r.username } : {}),
    ...(typeof r.photo_url === "string" ? { photo_url: r.photo_url } : {}),
  };

  const dataCheckString = buildDataCheckString(payload);
  const secretKey = createHash("sha256").update(botToken).digest();
  const expected = createHmac("sha256", secretKey).update(dataCheckString).digest("hex");

  // Constant-time hex comparison — both buffers are guaranteed
  // 64 bytes by the regex above, so timingSafeEqual is safe.
  const a = Buffer.from(expected, "utf8");
  const b = Buffer.from(payload.hash.toLowerCase(), "utf8");
  if (a.length !== b.length || !timingSafeEqual(a, b)) {
    return { ok: false, reason: "bad_hash" };
  }

  const nowSec = Math.floor(Date.now() / 1000);
  if (nowSec - payload.auth_date > MAX_AUTH_AGE_SEC) {
    return { ok: false, reason: "expired" };
  }

  return {
    ok: true,
    data: {
      telegramId: String(payload.id),
      telegramUsername: payload.username ?? null,
      telegramFirstName: payload.first_name ?? null,
      telegramPhotoUrl: payload.photo_url ?? null,
    },
  };
}
