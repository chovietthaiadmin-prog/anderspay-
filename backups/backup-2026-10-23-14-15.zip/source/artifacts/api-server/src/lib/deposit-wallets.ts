export const WALLET_ADDRESSES = {
  TRC20: "TU8x5xYV5gnHAakuQPh38DqNk4ofPpnGn3",
  BEP20: "0x07c27c73d9b3182ccab7ea06a633e5bea2052c10",
  ERC20: "0x6b7Fc3F701180621b187846A591C1fe157722D6D",
} as const;

export type DepositWalletNetwork = "bsc" | "ethereum" | "tron";

export function isOfficialDepositAddress(network: DepositWalletNetwork, address: string): boolean {
  if (network === "tron") return address === WALLET_ADDRESSES.TRC20;
  // Both EVM addresses are valid on both EVM chains: changing the selected
  // network must not reveal details for either official deposit address.
  return [WALLET_ADDRESSES.BEP20, WALLET_ADDRESSES.ERC20]
    .some((configured) => address.toLowerCase() === configured.toLowerCase());
}