import { sql } from "drizzle-orm";
import { db, usersTable } from "@workspace/db";
import { logger } from "./logger";

// One-shot, idempotent cleanup that enforces the new permanent UID
// format (`^098\d{6}$` — exactly 9 digits starting with 098). Any
// row whose `uid` column does not match the new format is reset to
// NULL so the user is forced through the UID-creation screen on
// their next login. Existing balances, orders, history and account
// records are NEVER touched here — only the `uid` field.
//
// Runs on every server boot. Idempotent: subsequent runs match zero
// rows once the dataset is clean. Logs the affected user count once.
export async function cleanupInvalidUids(): Promise<void> {
  try {
    const result = await db
      .update(usersTable)
      .set({ uid: null })
      .where(sql`${usersTable.uid} IS NOT NULL AND ${usersTable.uid} !~ '^098[0-9]{6}$'`)
      .returning({ id: usersTable.id });
    if (result.length > 0) {
      logger.warn(
        { count: result.length },
        "uid-cleanup: reset invalid UIDs to NULL (users will be prompted to create a new permanent UID)",
      );
    } else {
      logger.info("uid-cleanup: no invalid UIDs found");
    }
  } catch (err) {
    // Never block server startup on a cleanup failure — surface and
    // continue. Manual operator action can re-run the migration later.
    logger.error({ err }, "uid-cleanup: failed to reset invalid UIDs");
  }
}
