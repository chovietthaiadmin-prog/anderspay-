import { spawn } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

export type PaymentSlipData = {
  orderId: string;
  amountThb: string;
  bankName: string;
  accountNumber: string;
  accountName: string;
  confirmedAt: Date;
};

function escapeXml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function formatAmount(amount: string): string {
  return Number.parseFloat(amount).toLocaleString("th-TH", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

function formatBangkokDate(date: Date): string {
  return new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Bangkok",
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(date).replace(",", " ·") + " ICT";
}

function maskAccount(value: string): string {
  const visible = value.trim();
  if (visible.length <= 4) return visible;
  return `•••• ${visible.slice(-4)}`;
}

function loadAndersPayLogoDataUri(): string {
  const moduleDir = path.dirname(fileURLToPath(import.meta.url));
  const candidates = [
    path.join(moduleDir, "assets", "anderspay-logo.png"),
    path.resolve(process.cwd(), "src/assets/anderspay-logo.png"),
    path.resolve(process.cwd(), "artifacts/api-server/src/assets/anderspay-logo.png"),
    path.resolve(process.cwd(), "artifacts/localpay/public/anderspay-logo.png"),
  ];
  const logoPath = candidates.find((candidate) => existsSync(candidate));
  if (!logoPath) {
    throw new Error("AndersPay+ logo asset is missing from the API server build");
  }
  return `data:image/png;base64,${readFileSync(logoPath).toString("base64")}`;
}

/**
 * Builds a THB-only customer receipt. Internal conversion, USDT and fee data
 * are intentionally excluded because this is the recipient-facing artifact.
 */
export function buildPaymentSlipSvg(data: PaymentSlipData): string {
  const logoDataUri = loadAndersPayLogoDataUri();
  const amount = formatAmount(data.amountThb);
  const date = formatBangkokDate(data.confirmedAt);
  const recipient = escapeXml(data.accountName || "Recipient");
  const bank = escapeXml(data.bankName || "Thai bank");
  const account = escapeXml(maskAccount(data.accountNumber));
  const reference = escapeXml(data.orderId);

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1440" viewBox="0 0 1080 1440">
  <defs>
    <linearGradient id="header" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#C8102E"/>
      <stop offset="100%" stop-color="#FF3B3B"/>
    </linearGradient>
    <filter id="softShadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="16" stdDeviation="22" flood-color="#6F1D26" flood-opacity=".14"/>
    </filter>
  </defs>

  <rect width="1080" height="1440" fill="#F8EEEE"/>
  <g opacity=".055" fill="none" stroke="#C8102E" stroke-width="4">
    <circle cx="548" cy="785" r="420"/>
    <circle cx="548" cy="785" r="360"/>
    <circle cx="548" cy="785" r="302"/>
    <path d="M164 1120 L310 500 L548 340 L788 500 L930 1120"/>
    <path d="M290 1110 L290 610 L548 470 L806 610 L806 1110"/>
    <path d="M368 1080 V648 M448 1080 V572 M548 1080 V514 M648 1080 V572 M728 1080 V648"/>
  </g>

  <rect x="68" y="72" width="944" height="1296" rx="44" fill="#FFFDFD" filter="url(#softShadow)"/>
  <path d="M68 116 Q68 72 112 72 H968 Q1012 72 1012 116 V292 H68Z" fill="url(#header)"/>

  <image href="${logoDataUri}" x="100" y="137" width="88" height="88" preserveAspectRatio="xMidYMid meet"/>
  <text x="210" y="192" font-family="DejaVu Sans, Arial, sans-serif" font-size="38" font-weight="800" fill="#FFFFFF">AndersPay+</text>
  <text x="911" y="187" text-anchor="end" font-family="DejaVu Sans, Arial, sans-serif" font-size="21" font-weight="700" letter-spacing="3" fill="#FFE6E8">PAYMENT RECEIPT</text>

  <circle cx="540" cy="375" r="52" fill="#FFE2E5" stroke="#F1B5BD" stroke-width="3"/>
  <circle cx="540" cy="375" r="25" fill="none" stroke="#CE1F34" stroke-width="6"/>
  <path d="M527 375 L538 386 L557 363" fill="none" stroke="#CE1F34" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>
  <text x="540" y="478" text-anchor="middle" font-family="DejaVu Sans, Arial, sans-serif" font-size="22" font-weight="800" letter-spacing="3" fill="#B42A39">PAYMENT COMPLETED</text>
  <text x="540" y="558" text-anchor="middle" font-family="DejaVu Sans, Arial, sans-serif" font-size="68" font-weight="800" fill="#371E21">฿${amount}</text>
  <text x="540" y="605" text-anchor="middle" font-family="DejaVu Sans, Arial, sans-serif" font-size="27" fill="#7D6568">Sent to ${recipient}</text>

  <rect x="128" y="672" width="824" height="190" rx="26" fill="#FFFFFF" stroke="#EDD6D9" stroke-width="3"/>
  <text x="170" y="726" font-family="DejaVu Sans, Arial, sans-serif" font-size="19" font-weight="800" letter-spacing="2" fill="#927B7E">RECIPIENT</text>
  <rect x="170" y="756" width="68" height="68" rx="18" fill="#FFE1E4"/>
  <text x="204" y="800" text-anchor="middle" font-family="DejaVu Sans, Arial, sans-serif" font-size="23" font-weight="800" fill="#C31F32">TH</text>
  <text x="262" y="784" font-family="DejaVu Sans, Arial, sans-serif" font-size="29" font-weight="800" fill="#392326">${recipient}</text>
  <text x="262" y="821" font-family="DejaVu Sans, Arial, sans-serif" font-size="22" fill="#806C6F">${bank} · ${account}</text>

  <line x1="128" y1="914" x2="952" y2="914" stroke="#ECD8DA" stroke-width="3"/>
  <text x="128" y="965" font-family="DejaVu Sans, Arial, sans-serif" font-size="19" font-weight="800" letter-spacing="2" fill="#927B7E">TRANSFER DETAILS</text>
  <text x="128" y="1031" font-family="DejaVu Sans, Arial, sans-serif" font-size="24" fill="#806C6F">From</text>
  <text x="952" y="1031" text-anchor="end" font-family="DejaVu Sans, Arial, sans-serif" font-size="25" font-weight="700" fill="#4A3437">Anders</text>
  <line x1="128" y1="1068" x2="952" y2="1068" stroke="#E8CED1" stroke-width="2" stroke-dasharray="8 8"/>
  <text x="128" y="1132" font-family="DejaVu Sans, Arial, sans-serif" font-size="25" font-weight="800" fill="#563B3E">Total paid</text>
  <text x="952" y="1132" text-anchor="end" font-family="DejaVu Sans, Arial, sans-serif" font-size="31" font-weight="800" fill="#D21F34">฿${amount}</text>

  <line x1="128" y1="1180" x2="952" y2="1180" stroke="#ECD8DA" stroke-width="3"/>
  <text x="128" y="1233" font-family="DejaVu Sans, Arial, sans-serif" font-size="22" fill="#806C6F">Date and time</text>
  <text x="952" y="1233" text-anchor="end" font-family="DejaVu Sans, Arial, sans-serif" font-size="22" font-weight="700" fill="#4A3437">${escapeXml(date)}</text>
  <text x="128" y="1283" font-family="DejaVu Sans, Arial, sans-serif" font-size="22" fill="#806C6F">Reference</text>
  <text x="952" y="1283" text-anchor="end" font-family="DejaVu Sans Mono, monospace" font-size="20" font-weight="700" fill="#4A3437">${reference}</text>

  <text x="540" y="1332" text-anchor="middle" font-family="DejaVu Sans, Arial, sans-serif" font-size="17" fill="#967C80">Processed securely by AndersPay+ · Not issued by the recipient's bank</text>
</svg>`;
}

export async function renderPaymentSlipPng(data: PaymentSlipData): Promise<Buffer> {
  const svg = buildPaymentSlipSvg(data);

  return await new Promise<Buffer>((resolve, reject) => {
    const converter = spawn("magick", ["-background", "none", "svg:-", "png:-"], {
      stdio: ["pipe", "pipe", "pipe"],
    });
    const chunks: Buffer[] = [];
    const errors: Buffer[] = [];
    const timeout = setTimeout(() => converter.kill("SIGKILL"), 10_000);

    converter.stdout.on("data", (chunk: Buffer) => chunks.push(chunk));
    converter.stderr.on("data", (chunk: Buffer) => errors.push(chunk));
    converter.once("error", (error) => {
      clearTimeout(timeout);
      reject(error);
    });
    converter.once("close", (code) => {
      clearTimeout(timeout);
      const image = Buffer.concat(chunks);
      if (code === 0 && image.length > 0) {
        resolve(image);
        return;
      }
      reject(new Error(`Slip renderer failed (${code ?? "unknown"}): ${Buffer.concat(errors).toString().slice(0, 300)}`));
    });
    converter.stdin.end(svg);
  });
}