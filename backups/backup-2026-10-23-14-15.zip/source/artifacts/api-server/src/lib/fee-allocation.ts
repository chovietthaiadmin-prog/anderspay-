function micros(value: string): bigint {
  if (!/^\d+(\.\d{1,6})?$/.test(value)) throw new Error("INVALID_LEDGER_AMOUNT");
  const [whole, fraction = ""] = value.split(".");
  return BigInt(whole) * 1_000_000n + BigInt(fraction.padEnd(6, "0"));
}

function decimal(value: bigint): string {
  return `${value / 1_000_000n}.${(value % 1_000_000n).toString().padStart(6, "0")}`;
}

export function splitPaymentFee(total: string, referralAvailable: string) {
  const fee = micros(total);
  const available = micros(referralAvailable);
  const referral = available < fee ? available : fee;
  return { referral: decimal(referral), wallet: decimal(fee - referral) };
}

export function recordedFeeSplit(total: string, referral: string | null, legacyRefund = false) {
  // Old refunds were credited wholly to spendable USDT. Old charges, however,
  // did not save their split, so refunding one automatically would be a guess.
  if (referral === null && !legacyRefund) throw new Error("FEE_SOURCE_UNKNOWN");
  const fee = micros(total);
  const reward = micros(referral ?? "0");
  if (reward > fee) throw new Error("INVALID_LEDGER_AMOUNT");
  return { referral: decimal(reward), wallet: decimal(fee - reward) };
}

export function conversionAmounts(amountUsdt: number, rate: number) {
  const usdt = amountUsdt.toFixed(6);
  const thb = (Number(usdt) * rate).toFixed(2);
  if (!Number.isFinite(rate) || rate <= 0) throw new Error("RATE_UNAVAILABLE");
  if (Number(usdt) <= 0 || Number(thb) < 0.01) throw new Error("AMOUNT_TOO_SMALL");
  return { usdt, thb };
}
