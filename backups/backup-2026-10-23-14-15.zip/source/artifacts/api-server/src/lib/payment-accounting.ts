import { db, ordersTable, transactionsTable, usersTable } from "@workspace/db";
import { and, eq, inArray, ne, sql } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import { recordedFeeSplit, splitPaymentFee } from "./fee-allocation";
import { MIN_USDT_BALANCE } from "./fees";

type Transaction = Parameters<Parameters<typeof db.transaction>[0]>[0];

export class PendingPaymentError extends Error {
  constructor(public readonly existingOrderId: string) {
    super("PENDING_ORDER_EXISTS");
  }
}

export async function lockPaymentAccount(tx: Transaction, userId: string) {
  // All payment creators serialize on this account lock. The pending query
  // runs AFTER acquiring it, so a waiting creator sees the preceding insert.
  const [user] = await tx.select().from(usersTable)
    .where(eq(usersTable.id, userId)).limit(1).for("update");
  if (!user) throw new Error("PAYMENT_USER_NOT_FOUND");
  const [pending] = await tx.select({ id: ordersTable.id }).from(ordersTable)
    .where(and(eq(ordersTable.userId, userId), ne(ordersTable.bankName, ""),
      inArray(ordersTable.status, ["pending", "paid"]))).limit(1);
  if (pending) throw new PendingPaymentError(pending.id);
  return user;
}

export async function debitPaymentAccount(tx: Transaction, userId: string, principalThb: string, feeUsdt: string) {
  const user = await lockPaymentAccount(tx, userId);
  const split = splitPaymentFee(feeUsdt, user.referralRewardBalance);
  const [debited] = await tx.update(usersTable).set({
    thbBalance: sql`${usersTable.thbBalance} - ${principalThb}::numeric`,
    referralRewardBalance: sql`${usersTable.referralRewardBalance} - ${split.referral}::numeric`,
    usdtBalance: sql`${usersTable.usdtBalance} - ${split.wallet}::numeric`,
  }).where(and(eq(usersTable.id, userId),
    sql`${usersTable.thbBalance} >= ${principalThb}::numeric`,
    sql`${usersTable.referralRewardBalance} >= ${split.referral}::numeric`,
    sql`${usersTable.usdtBalance} - ${split.wallet}::numeric >= ${MIN_USDT_BALANCE}`,
  )).returning({ id: usersTable.id });
  if (!debited) {
    throw new Error(Number(user.thbBalance) < Number(principalThb)
      ? "INSUFFICIENT_THB_BALANCE" : "INSUFFICIENT_FEE_BALANCE");
  }
  return split;
}

export async function refundPayment(orderUuid: string, database = db) {
  return database.transaction(async (tx) => {
    const [order] = await tx.update(ordersTable)
      .set({ status: "refunded", updatedAt: new Date() })
      .where(and(eq(ordersTable.id, orderUuid), ne(ordersTable.bankName, ""),
        inArray(ordersTable.status, ["pending", "paid"]))).returning();
    if (!order) return null;
    if (!order.userId) return order; // legacy guest payment: no debit to restore

    const ledger = await tx.select().from(transactionsTable)
      .where(and(eq(transactionsTable.refOrderId, order.id),
        eq(transactionsTable.userId, order.userId),
        inArray(transactionsTable.type, ["payment", "payment_fee"])));
    const principal = ledger.filter((row) => row.type === "payment");
    const fees = ledger.filter((row) => row.type === "payment_fee");
    if (principal.length !== 1 || fees.length !== 1) throw new Error("PAYMENT_LEDGER_MISSING");
    const fee = fees[0];
    const split = recordedFeeSplit(fee.amountUsdt, fee.referralAmountUsdt);
    const [credited] = await tx.update(usersTable).set({
      thbBalance: sql`${usersTable.thbBalance} + ${principal[0].amountThb}::numeric`,
      usdtBalance: sql`${usersTable.usdtBalance} + ${split.wallet}::numeric`,
      referralRewardBalance: sql`${usersTable.referralRewardBalance} + ${split.referral}::numeric`,
    }).where(eq(usersTable.id, order.userId)).returning({ id: usersTable.id });
    if (!credited) throw new Error("PAYMENT_USER_NOT_FOUND");
    await tx.insert(transactionsTable).values({
      id: randomUUID(), userId: order.userId, type: "payment_refund",
      amountUsdt: fee.amountUsdt, referralAmountUsdt: split.referral,
      amountThb: principal[0].amountThb, rate: order.exchangeRate, refOrderId: order.id,
    });
    return order;
  });
}

export async function reversePaymentRefund(orderCode: string, database = db) {
  return database.transaction(async (tx) => {
    const [order] = await tx.select().from(ordersTable)
      .where(eq(ordersTable.orderId, orderCode)).limit(1).for("update");
    if (!order) throw new Error("ORDER_NOT_FOUND");
    if (order.status !== "refunded" || order.bankName === "") throw new Error("ORDER_NOT_REFUNDED");
    if (order.userId) {
      const refunds = await tx.select().from(transactionsTable)
        .where(and(eq(transactionsTable.refOrderId, order.id),
          eq(transactionsTable.userId, order.userId), eq(transactionsTable.type, "payment_refund")));
      if (refunds.length !== 1) throw new Error("REFUND_LEDGER_MISSING");
      const refund = refunds[0];
      const split = recordedFeeSplit(refund.amountUsdt, refund.referralAmountUsdt, true);
      const [debited] = await tx.update(usersTable).set({
        thbBalance: sql`${usersTable.thbBalance} - ${refund.amountThb}::numeric`,
        usdtBalance: sql`${usersTable.usdtBalance} - ${split.wallet}::numeric`,
        referralRewardBalance: sql`${usersTable.referralRewardBalance} - ${split.referral}::numeric`,
      }).where(and(eq(usersTable.id, order.userId),
        sql`${usersTable.thbBalance} >= ${refund.amountThb}::numeric`,
        sql`${usersTable.usdtBalance} >= ${split.wallet}::numeric`,
        sql`${usersTable.referralRewardBalance} >= ${split.referral}::numeric`,
      )).returning({ id: usersTable.id });
      if (!debited) throw new Error("REFUND_BALANCE_SPENT");
      await tx.insert(transactionsTable).values({
        id: randomUUID(), userId: order.userId, type: "payment_refund_reversal",
        amountUsdt: refund.amountUsdt, referralAmountUsdt: split.referral,
        amountThb: refund.amountThb, rate: refund.rate, refOrderId: order.id,
      });
    }
    const completedAt = new Date();
    const [completed] = await tx.update(ordersTable)
      .set({ status: "completed", updatedAt: completedAt, confirmedAt: completedAt })
      .where(and(eq(ordersTable.id, order.id), eq(ordersTable.status, "refunded"))).returning();
    if (!completed) throw new Error("ORDER_NOT_REFUNDED");
    return completed;
  });
}
