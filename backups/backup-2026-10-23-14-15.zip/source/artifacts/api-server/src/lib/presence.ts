/**
 * In-memory presence store for the support chat system.
 *
 * Tracks whether a user / admin is actively viewing a conversation so
 * Telegram notifications are only sent when the recipient is NOT watching
 * the chat live in the browser.
 *
 * Entries expire after PRESENCE_TTL_MS if not refreshed (heartbeat from
 * the frontend every 20 s keeps them alive while the tab is open).
 *
 * Also owns the per-conversation Telegram notification cooldown (30 s)
 * so the same conversation can't flood a recipient even when they're away.
 */

// ── Presence store ────────────────────────────────────────────────────────

/** How long a presence entry stays valid without a heartbeat (45 s). */
const PRESENCE_TTL_MS = 45_000;

interface PresenceEntry {
  conversationOpen: boolean;
  /**
   * For admin: the userId of the thread currently being viewed.
   * For regular users: null (they have one fixed thread with admin).
   */
  activeConversationId: string | null;
  updatedAt: number;
}

const presenceStore = new Map<string, PresenceEntry>();

/** Upsert presence for a participant. Called by POST /support/presence. */
export function updatePresence(
  participantId: string,
  conversationOpen: boolean,
  activeConversationId: string | null = null,
): void {
  presenceStore.set(participantId, {
    conversationOpen,
    activeConversationId,
    updatedAt: Date.now(),
  });
}

function isFresh(entry: PresenceEntry): boolean {
  return Date.now() - entry.updatedAt <= PRESENCE_TTL_MS;
}

/**
 * Is a regular user actively viewing their own support chat right now?
 * Returns true only if their presence entry is fresh and conversationOpen.
 */
export function isUserViewingChat(userId: string): boolean {
  const entry = presenceStore.get(userId);
  if (!entry) return false;
  return entry.conversationOpen && isFresh(entry);
}

/**
 * Is any admin actively viewing a specific user's support thread right now?
 * Scans all fresh presence entries for one with matching activeConversationId.
 */
export function isAdminViewingThread(userId: string): boolean {
  for (const entry of presenceStore.values()) {
    if (
      entry.conversationOpen &&
      entry.activeConversationId === userId &&
      isFresh(entry)
    ) {
      return true;
    }
  }
  return false;
}

// ── Friend-chat presence ──────────────────────────────────────────────────

/**
 * Tracks which users are actively viewing a peer-to-peer chat.
 * Key: `<userId>:<friendshipId>` → last ping timestamp.
 * Expires after PRESENCE_TTL_MS if not refreshed.
 */
const friendChatPresence = new Map<string, number>();

/**
 * Record that a user is currently viewing a friendship chat.
 * Called by POST /api/friends/:id/presence (heartbeat every 20 s).
 */
export function updateFriendChatPresence(userId: string, friendshipId: string): void {
  friendChatPresence.set(`${userId}:${friendshipId}`, Date.now());
}

/**
 * Returns true if the user has a fresh presence entry for this friendship.
 * "Fresh" means a heartbeat arrived within the last PRESENCE_TTL_MS.
 */
export function isUserViewingFriendChat(userId: string, friendshipId: string): boolean {
  const last = friendChatPresence.get(`${userId}:${friendshipId}`);
  if (last === undefined) return false;
  return Date.now() - last <= PRESENCE_TTL_MS;
}

// ── Per-conversation Telegram notification cooldown (30 s) ────────────────

/** How long to suppress repeat Telegram pings for the same conversation. */
const NOTIFY_COOLDOWN_MS = 30_000;

const lastNotifiedMap = new Map<string, number>();

/**
 * Returns true if a Telegram notification was already sent for this key
 * within the last 30 seconds.
 * Use `admin:<userId>` for admin-directed notifications and
 * `user:<userId>` for user-directed notifications.
 */
export function isOnNotifCooldown(key: string): boolean {
  const last = lastNotifiedMap.get(key);
  if (last === undefined) return false;
  return Date.now() - last < NOTIFY_COOLDOWN_MS;
}

/** Record that a Telegram notification was just sent for this key. */
export function markNotified(key: string): void {
  lastNotifiedMap.set(key, Date.now());
}
