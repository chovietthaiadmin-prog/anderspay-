import jwt from "jsonwebtoken";
import { randomBytes, randomUUID } from "crypto";
import type { Request } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable } from "@workspace/db";
import { logger } from "./logger";
import { isAdminUser } from "./admin";

// Admins may stay signed in on up to this many devices at once. Everyone
// else is single-device: a new login evicts the previous session.
const MAX_ADMIN_SESSIONS = 3;

let cachedDevSecret: string | undefined;

function getSecret(): string {
  const secret = process.env.JWT_SECRET;
  if (secret) return secret;

  if (!cachedDevSecret) {
    cachedDevSecret = randomBytes(48).toString("base64");
    logger.warn("JWT_SECRET not set — using auto-generated ephemeral secret. Tokens will not survive restarts. Set JWT_SECRET as a Replit Secret for production use.");
  }
  return cachedDevSecret;
}

export interface JwtPayload {
  userId: string;
  sid?: string;
}

export function signToken(userId: string, sid?: string): string {
  const payload: JwtPayload = sid ? { userId, sid } : { userId };
  return jwt.sign(payload, getSecret(), { expiresIn: "90d" });
}

export function verifyToken(token: string): JwtPayload | null {
  try {
    const payload = jwt.verify(token, getSecret()) as JwtPayload;
    return payload;
  } catch {
    return null;
  }
}

export function extractBearerToken(authHeader: string | undefined): string | undefined {
  if (!authHeader?.startsWith("Bearer ")) return undefined;
  return authHeader.slice(7);
}

/**
 * Parse the `session_id` column, which holds a comma-separated list of
 * active session ids (one for regular users, up to MAX_ADMIN_SESSIONS for
 * admins). Legacy single-uuid values parse as a one-element list.
 */
function parseSessionIds(raw: string | null | undefined): string[] {
  if (!raw) return [];
  return raw.split(",").map((s) => s.trim()).filter(Boolean);
}

/**
 * Issue a fresh session: generate a new sessionId and sign a JWT bound to it.
 *
 * Regular users are single-device — a new login replaces any prior session.
 * Admins may keep up to MAX_ADMIN_SESSIONS concurrent device sessions; once
 * the limit is reached the oldest session is evicted (FIFO).
 */
export async function issueSession(userId: string): Promise<string> {
  const sid = randomUUID();
  const [user] = await db
    .select({ phone: usersTable.phone, isAdmin: usersTable.isAdmin, sessionId: usersTable.sessionId })
    .from(usersTable)
    .where(eq(usersTable.id, userId))
    .limit(1);

  const sessionIds =
    user && isAdminUser(user)
      ? [...parseSessionIds(user.sessionId), sid].slice(-MAX_ADMIN_SESSIONS)
      : [sid];

  await db.update(usersTable).set({ sessionId: sessionIds.join(",") }).where(eq(usersTable.id, userId));
  return signToken(userId, sid);
}

/**
 * Authenticate a request: verify JWT signature, then verify the session id
 * still matches the user's current sessionId in the DB. Returns the userId
 * on success, or null if the token is missing/invalid/superseded.
 *
 * Backward-compat: if a user row has no sessionId yet (legacy), tokens
 * without a sid are accepted. Once `issueSession` runs for them, only
 * tokens carrying the matching sid are accepted thereafter.
 */
export async function authenticateRequest(req: Request): Promise<JwtPayload | null> {
  const token = extractBearerToken(req.headers.authorization);
  if (!token) return null;
  const payload = verifyToken(token);
  if (!payload?.userId) return null;
  const [user] = await db
    .select({ sessionId: usersTable.sessionId })
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId))
    .limit(1);
  if (!user) return null;
  const sessionIds = parseSessionIds(user.sessionId);
  if (sessionIds.length > 0) {
    if (!payload.sid || !sessionIds.includes(payload.sid)) return null;
  }
  return payload;
}
