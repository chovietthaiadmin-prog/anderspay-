import { db, ordersTable, usersTable, transactionsTable } from "@workspace/db";
import { and, eq, inArray, sql } from "drizzle-orm";
import { randomUUID } from "crypto";
import { topupFeeUsdt } from "./fees";

/**
 * Atomically transitions an order to "completed" (only if not already completed)
 * AND, when the order is a deposit (bankName === "") with a linked userId,
 * credits the user's USDT balance and writes a "deposit" ledger entry —
 * all in a single database transaction.
 *
 * Concurrency-safe: the conditional WHERE on `status != 'completed'` plus the
 * row lock taken by UPDATE means only one concurrent caller will see rows in
 * `updated`; everyone else gets `null` and crediting cannot run twice.
 *
 * Returns:
 *   - { credited: true, order } when the order was just completed and a deposit was credited
 *   - { credited: false, order } when the order was just completed but is not a creditable deposit
 *   - null when the order didn't transition (already completed, or not found)
 */
export async function completeOrderAndCredit(
  orderUuid: string,
  database = db,
): Promise<{ credited: boolean; order: typeof ordersTable.$inferSelect } | null> {
  return await database.transaction(async (tx) => {
    // Only pending/paid orders may transition to completed. Refunded /
    // expired / completed orders are terminal and must not be re-completed
    // by stale or duplicated callback clicks (e.g. an admin clicking the
    // old "Xác nhận" button after the order was already rejected).
    const confirmedAt = new Date();
    const updated = await tx
      .update(ordersTable)
      .set({ status: "completed", updatedAt: confirmedAt, confirmedAt })
      .where(and(eq(ordersTable.id, orderUuid), inArray(ordersTable.status, ["pending", "paid"])))
      .returning();

    if (updated.length === 0) return null;

    const order = updated[0];
    const isDeposit = order.bankName === "";

    if (!isDeposit) {
      return { credited: false, order };
    }
    if (!order.userId) throw new Error("DEPOSIT_USER_REQUIRED");

    const grossUsdt = parseFloat(order.amountUsdt);
    // Apply per-order topup fee. Net credit = gross - fee. The credit is
    // floored at 0 in the (degenerate) case the gross amount is below the
    // fee itself, so we never accidentally bump the user balance negative.
    const feeUsdt = topupFeeUsdt(grossUsdt);
    const netUsdt = Math.max(0, parseFloat((grossUsdt - feeUsdt).toFixed(6)));
    const netUsdtStr = netUsdt.toFixed(6);
    const feeUsdtStr = feeUsdt.toFixed(6);

    const [credited] = await tx
      .update(usersTable)
      .set({ usdtBalance: sql`${usersTable.usdtBalance} + ${netUsdtStr}::numeric` })
      .where(eq(usersTable.id, order.userId))
      .returning({ id: usersTable.id });
    if (!credited) throw new Error("DEPOSIT_USER_NOT_FOUND");

    // Two ledger entries so the fee is auditable: gross deposit, then a
    // separate `topup_fee` line. This matches what the user sees in their
    // transaction list.
    const ledger: (typeof transactionsTable.$inferInsert)[] = [
      {
        id: randomUUID(),
        userId: order.userId,
        type: "deposit",
        amountUsdt: order.amountUsdt,
        amountThb: "0",
        rate: order.exchangeRate,
        refOrderId: order.id,
      },
    ];
    if (feeUsdt > 0) {
      ledger.push({
        id: randomUUID(),
        userId: order.userId,
        type: "topup_fee",
        amountUsdt: feeUsdtStr,
        amountThb: "0",
        rate: order.exchangeRate,
        refOrderId: order.id,
      });
    }
    await tx.insert(transactionsTable).values(ledger);

    return { credited: true, order };
  });
}
