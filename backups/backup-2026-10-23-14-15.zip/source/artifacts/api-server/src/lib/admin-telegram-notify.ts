/**
 * Admin Telegram Notification Service
 *
 * Sends a Telegram message to the ADMIN's personal Telegram chat whenever a
 * customer posts a new support message.  Includes in-memory rate-limiting so
 * a spam burst (> SPAM_THRESHOLD messages per user within RATE_WINDOW_MS)
 * collapses into a single warning, rather than flooding the admin chat.
 *
 * Env vars consumed:
 *   ADMIN_TELEGRAM_CHAT_ID   – admin's PERSONAL Telegram chat ID (NOT a group)
 *   TELEGRAM_BOT_TOKEN       – bot token used to send the message
 *
 * NOTE: No fallback to TELEGRAM_CHAT_ID (group chat). If ADMIN_TELEGRAM_CHAT_ID
 * is not set the function is a silent no-op — notifications never go to a group.
 */

import { randomUUID } from "crypto";
import { db, usersTable, notificationLogsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { sendTelegramMessage } from "./telegram";
import { isAdminViewingThread, isOnNotifCooldown, markNotified } from "./presence";

// ── Config ────────────────────────────────────────────────────────────────

// Chỉ dùng chat ID cá nhân của admin — không fallback sang group chat.
// Nếu chưa set thì hàm sẽ silent no-op (không gửi vào đâu cả).
const ADMIN_CHAT_ID = process.env.ADMIN_TELEGRAM_CHAT_ID;

/** Messages per user within the window before spam-collapse kicks in. */
const SPAM_THRESHOLD = 3;
/** Window length in ms (1 minute). */
const RATE_WINDOW_MS = 60 * 1_000;

// ── In-memory rate-limit state ────────────────────────────────────────────

interface RateState {
  count: number;
  windowStart: number;
  /** True once we've sent the single spam-warning for this window. */
  warned: boolean;
}
const rateMap = new Map<string, RateState>();

/** Reset stale windows and increment counter.  Returns the updated state. */
function tick(userId: string): RateState {
  const now = Date.now();
  const prev = rateMap.get(userId);
  if (!prev || now - prev.windowStart > RATE_WINDOW_MS) {
    const fresh: RateState = { count: 1, windowStart: now, warned: false };
    rateMap.set(userId, fresh);
    return fresh;
  }
  prev.count++;
  return prev;
}

// ── Main export ───────────────────────────────────────────────────────────

/**
 * Fire-and-forget: call after inserting a new support message.
 * Never throws — errors are swallowed so they cannot affect the HTTP response.
 */
export async function notifyAdminNewSupportMessage(
  userId: string,
  messageText: string,
): Promise<void> {
  try {
    if (!ADMIN_CHAT_ID) return; // silently no-op if not configured

    // ── Smart presence check ───────────────────────────────────────────
    // Skip Telegram if an admin is actively viewing this user's thread.
    if (isAdminViewingThread(userId)) return;

    // ── 30-second per-conversation cooldown ───────────────────────────
    const cooldownKey = `admin:${userId}`;
    if (isOnNotifCooldown(cooldownKey)) return;

    // ── Existing spam-burst collapse (> 3 msgs / min → one warning) ───
    const state = tick(userId);
    if (state.count > SPAM_THRESHOLD && state.warned) return;
    const isSpam = state.count > SPAM_THRESHOLD;
    if (isSpam) state.warned = true;

    // ── Resolve user display info ──────────────────────────────────────
    let userName = "Khách vãng lai";
    let userPhone = "";

    if (!userId.startsWith("guest:")) {
      const [u] = await db
        .select({ phone: usersTable.phone, nickname: usersTable.nickname, name: usersTable.name })
        .from(usersTable)
        .where(eq(usersTable.id, userId))
        .limit(1);
      if (u) {
        userName = u.nickname?.trim() || u.name || u.phone;
        userPhone = u.phone;
      }
    }

    const adminUrl = "https://anderspay.com/support";

    // ── Build short message text (spec: luôn ngắn gọn) ────────────────
    let text: string;

    if (isSpam) {
      text =
        `⚠️ <b>Nhiều tin nhắn mới</b>\n\n` +
        `👤 ${userName}${userPhone ? ` · ${userPhone}` : ""}\n\n` +
        `📌 Khách đang gửi liên tục.\n\n` +
        `👉 <a href="${adminUrl}">Mở anderspay+ để xem</a>`;
    } else {
      const preview =
        messageText.length > 80
          ? messageText.slice(0, 80) + "…"
          : messageText;
      text =
        `🔔 <b>Có tin nhắn mới</b>\n\n` +
        `👤 ${userName}${userPhone ? ` · ${userPhone}` : ""}\n` +
        `💬 "${preview}"\n\n` +
        `👉 <a href="${adminUrl}">Mở anderspay+ để xem</a>`;
    }

    // ── Send & log ─────────────────────────────────────────────────────
    const ok = await sendTelegramMessage(text, ADMIN_CHAT_ID);
    markNotified(cooldownKey);

    await db.insert(notificationLogsTable).values({
      id: randomUUID(),
      type: isSpam ? "admin_spam_warning" : "admin_new_message",
      userId,
      message: messageText.slice(0, 500),
      telegramStatus: ok ? "sent" : "failed",
    });
  } catch {
    // Swallow all errors — notifications must never break the support API.
  }
}
