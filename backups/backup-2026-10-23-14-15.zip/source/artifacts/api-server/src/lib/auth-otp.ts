import { createHmac, randomInt, randomUUID, timingSafeEqual } from "node:crypto";
import { db, emailOtpsTable } from "@workspace/db";
import { and, desc, eq, gt, sql } from "drizzle-orm";

// Reuse the existing challenge history (its email column is a text identity).
// Phone challenges use "phone:<normalized phone>"; purposes separate login
// from account deletion. No database migration or legacy plaintext fallback.
const TTL = 10 * 60_000;
const GAP = 60_000;
const LOCK = 15 * 60_000;
const MAX_ATTEMPTS = 5;
type Failure = { ok: false; status: number; body: { error: string; message: string; retryAfterSec?: number; attemptsLeft?: number } };

export function otpDigest(identity: string, purpose: string, otp: string): string {
  const key = process.env.SESSION_SECRET || process.env.JWT_SECRET;
  if (!key) throw new Error("OTP signing secret is not configured");
  return "hmac:v1:" + createHmac("sha256", key).update(JSON.stringify([identity, purpose, otp])).digest("hex");
}

export function newOtp(): string {
  return randomInt(0, 1_000_000).toString().padStart(6, "0");
}

function failure(error: string, status: number, message: string, extra = {}): Failure {
  return { ok: false, status, body: { error, message, ...extra } };
}

function locked(until: Date, now: number): Failure {
  return failure("locked", 423, "Nhập sai quá 5 lần. Vui lòng thử lại sau 15 phút.",
    { retryAfterSec: Math.max(1, Math.ceil((until.getTime() - now) / 1000)) });
}

export async function issueOtp(identity: string, purpose: string, database: typeof db = db): Promise<Failure | { ok: true; id: string; otp: string }> {
  // Fail closed BEFORE changing history if the signing key is unavailable.
  const otp = newOtp();
  const otpHash = otpDigest(identity, purpose, otp);
  return database.transaction(async (tx) => {
    // Shared PostgreSQL lock: parallel requests and multiple app instances
    // cannot bypass send limits, attempt counters, or the verification lock.
    await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtextextended(${`auth-otp:${identity}`}, 0))`);
    const now = Date.now();
    const recent = await tx.select().from(emailOtpsTable)
      .where(and(eq(emailOtpsTable.email, identity), gt(emailOtpsTable.createdAt, new Date(now - 86_400_000))))
      .orderBy(desc(emailOtpsTable.createdAt));
    const block = recent.find((row) => row.lockedUntil && row.lockedUntil.getTime() > now);
    if (block?.lockedUntil) return locked(block.lockedUntil, now);
    if (recent.length >= 20) {
      return failure("rate_limited", 429, "Đã vượt giới hạn gửi mã trong ngày.",
        { retryAfterSec: Math.max(1, Math.ceil((recent[recent.length - 1].createdAt.getTime() + 86_400_000 - now) / 1000)) });
    }
    const hourly = recent.filter((row) => row.createdAt.getTime() > now - 3_600_000);
    if (hourly.length >= 5) {
      return failure("rate_limited", 429, "Đã gửi quá nhiều mã trong 1 giờ.",
        { retryAfterSec: Math.max(1, Math.ceil((hourly[hourly.length - 1].createdAt.getTime() + 3_600_000 - now) / 1000)) });
    }
    if (recent[0] && now - recent[0].createdAt.getTime() < GAP) {
      return failure("rate_limited", 429, "Vui lòng đợi trước khi gửi lại mã.",
        { retryAfterSec: Math.ceil((recent[0].createdAt.getTime() + GAP - now) / 1000) });
    }
    await tx.update(emailOtpsTable).set({ consumedAt: new Date(now) })
      .where(and(eq(emailOtpsTable.email, identity), eq(emailOtpsTable.purpose, purpose),
        sql`${emailOtpsTable.consumedAt} IS NULL`));
    const id = randomUUID();
    await tx.insert(emailOtpsTable).values({ id, email: identity, purpose, otpHash, expiresAt: new Date(now + TTL) });
    return { ok: true as const, id, otp };
  });
}

export async function invalidateOtp(id: string): Promise<void> {
  await db.update(emailOtpsTable).set({ consumedAt: new Date() }).where(eq(emailOtpsTable.id, id));
}

export async function verifyOtpFor(identity: string, purpose: string, otp: string, database: typeof db = db): Promise<Failure | { ok: true }> {
  const invalid = () => failure("invalid_otp", 400, "Mã không hợp lệ hoặc đã hết hạn.");
  if (!/^\d{6}$/.test(otp)) return invalid();
  const expected = otpDigest(identity, purpose, otp);
  return database.transaction(async (tx) => {
    await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtextextended(${`auth-otp:${identity}`}, 0))`);
    const now = Date.now();
    const [block] = await tx.select().from(emailOtpsTable)
      .where(and(eq(emailOtpsTable.email, identity), gt(emailOtpsTable.lockedUntil, new Date(now))))
      .limit(1);
    if (block?.lockedUntil) return locked(block.lockedUntil, now);
    const [row] = await tx.select().from(emailOtpsTable)
      .where(and(eq(emailOtpsTable.email, identity), eq(emailOtpsTable.purpose, purpose)))
      .orderBy(desc(emailOtpsTable.createdAt)).limit(1);
    if (!row || row.consumedAt || row.expiresAt.getTime() <= now || row.attempts >= MAX_ATTEMPTS) return invalid();
    const actual = Buffer.from(row.otpHash);
    const candidate = Buffer.from(expected);
    if (actual.length !== candidate.length || !timingSafeEqual(actual, candidate)) {
      const attempts = row.attempts + 1;
      const until = attempts >= MAX_ATTEMPTS ? new Date(now + LOCK) : null;
      await tx.update(emailOtpsTable).set({ attempts, lockedUntil: until }).where(eq(emailOtpsTable.id, row.id));
      if (until) return locked(until, now);
      return failure("invalid_otp", 400, "Mã không đúng. Vui lòng thử lại.", { attemptsLeft: MAX_ATTEMPTS - attempts });
    }
    const consumed = await tx.update(emailOtpsTable).set({ consumedAt: new Date(now) })
      .where(and(eq(emailOtpsTable.id, row.id), sql`${emailOtpsTable.consumedAt} IS NULL`))
      .returning({ id: emailOtpsTable.id });
    return consumed.length === 1 ? { ok: true as const } : invalid();
  });
}
