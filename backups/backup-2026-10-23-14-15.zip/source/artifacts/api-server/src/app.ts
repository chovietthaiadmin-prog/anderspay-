import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.disable("etag");
app.use((_req, res, next) => {
  res.set("Cache-Control", "no-store, no-cache, must-revalidate");
  res.set("Pragma", "no-cache");
  next();
});
// Bill / avatar / broadcast uploads now go through JSON-with-base64 instead
// of multipart/form-data, because Replit's edge proxy returns 403 for any
// `multipart/form-data` POST before it reaches us. A 500 KB JPEG becomes
// ~670 KB base64; a 25 MB raw cap → ~34 MB base64. 40 MB gives headroom.
app.use(express.json({ limit: "40mb" }));
app.use(express.urlencoded({ extended: true, limit: "40mb" }));

app.use("/api", router);

export default app;
