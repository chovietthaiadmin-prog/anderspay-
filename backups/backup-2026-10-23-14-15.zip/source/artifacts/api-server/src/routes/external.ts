/**
 * External read-only API — for authorised third-party integrations.
 *
 * Authentication: Authorization: Bearer <ANDERSPAY_API_KEY>
 * All endpoints are read-only (GET only). No mutations are exposed here.
 *
 * Endpoints:
 *   GET /external/transactions   — ledger rows (all users or per-user)
 *   GET /external/fees          — recorded top-up/payment fees
 *   GET /external/orders         — payment/topup orders
 *   GET /external/users          — user list (public fields only; no passwords/hashes)
 */
import { Router } from "express";
import type { Request, Response } from "express";
import { db, transactionsTable, ordersTable, usersTable } from "@workspace/db";
import { desc, eq, and, gte, lte, inArray, notInArray, or, isNull, isNotNull, sql } from "drizzle-orm";
import { TESTER_USER_IDS, TESTER_USER_PHONES } from "../lib/tester-accounts";

const router = Router();

// ---------------------------------------------------------------------------
// Auth helper
// ---------------------------------------------------------------------------

function authoriseExternal(req: Request, res: Response): boolean {
  const key = process.env.ANDERSPAY_API_KEY;
  if (!key) {
    res.status(503).json({ message: "External API not configured", code: "NOT_CONFIGURED" });
    return false;
  }
  const header = req.headers["authorization"] ?? "";
  const provided =
    typeof header === "string" && header.startsWith("Bearer ")
      ? header.slice(7).trim()
      : (req.headers["x-api-key"] as string | undefined)?.trim() ?? "";
  if (!provided || provided !== key) {
    res.status(401).json({ message: "Unauthorized — invalid API key", code: "UNAUTHORIZED" });
    return false;
  }
  return true;
}

// Parse an ISO date string query param; returns undefined if missing/invalid.
function parseDate(raw: unknown): Date | undefined {
  if (typeof raw !== "string" || !raw) return undefined;
  const d = new Date(raw);
  return isNaN(d.getTime()) ? undefined : d;
}

// Clamp pagination params to safe bounds.
function parsePage(rawLimit: unknown, rawOffset: unknown, defaultLimit = 50, maxLimit = 1000) {
  const limit = Math.min(Math.max(parseInt(String(rawLimit ?? defaultLimit), 10) || defaultLimit, 1), maxLimit);
  const offset = Math.max(parseInt(String(rawOffset ?? "0"), 10) || 0, 0);
  return { limit, offset };
}

const EXTERNAL_NETWORKS = ["BEP20", "TRC20", "ERC20"] as const;
const EXTERNAL_STATUSES = ["pending", "confirmed", "failed", "refunded", "reversed", "settled"] as const;
type ExternalNetwork = (typeof EXTERNAL_NETWORKS)[number];
type ExternalStatus = (typeof EXTERNAL_STATUSES)[number];
const EXTERNAL_TRANSACTION_TYPES = ["deposit", "payment_fee"] as const;
type ExternalTransactionType = (typeof EXTERNAL_TRANSACTION_TYPES)[number];

const depositNetwork = sql<string>`
  CASE
    WHEN ${ordersTable.network} IN ('BEP20', 'TRC20', 'ERC20') THEN ${ordersTable.network}
    WHEN ${ordersTable.walletAddress} IN (
      '0x07c27c73d9b3182ccab7ea06a633e5bea2052c10',
      '0xcb0dbaf99e3a4243b4473d6b974235bd0d3fca17'
    ) THEN 'BEP20'
    WHEN ${ordersTable.walletAddress} = 'TU8x5xYV5gnHAakuQPh38DqNk4ofPpnGn3' THEN 'TRC20'
    WHEN ${ordersTable.walletAddress} = '0x6b7Fc3F701180621b187846A591C1fe157722D6D' THEN 'ERC20'
    WHEN ${ordersTable.walletAddress} = 'TRX9mK3vQpL8xN2wYjC7bFdHsAeUo4VmRk' THEN 'TRC20'
    ELSE NULL
  END
`;

function externalWalletCode(network: ExternalNetwork): "USDT_META" | "USDT_SAFEPAL" {
  return network === "BEP20" ? "USDT_META" : "USDT_SAFEPAL";
}

function externalStatus(status: typeof ordersTable.status.enumValues[number]): ExternalStatus {
  switch (status) {
    case "completed":
      return "confirmed";
    case "refunded":
      return "refunded";
    case "expired":
      return "failed";
    default:
      return "pending";
  }
}

function formatUsdt(value: string): string {
  const [whole = "0", fraction = ""] = value.split(".");
  return `${whole}.${fraction.padEnd(8, "0").slice(0, 8)}`;
}

function formatDecimal(value: string, scale: number): string {
  const [whole = "0", fraction = ""] = value.split(".");
  return `${whole}.${fraction.padEnd(scale, "0").slice(0, scale)}`;
}

type ExternalOrderStatus = typeof ordersTable.status.enumValues[number];

type ExternalOrderRow = {
  id: string;
  orderId: string;
  userId: string | null;
  status: ExternalOrderStatus;
  amountThb: string;
  amountUsdt: string;
  exchangeRate: string;
  bankName: string;
  bahtSource: string | null;
  bahtSourceName: string | null;
  accountNumber: string;
  accountName: string;
  createdAt: Date;
  updatedAt: Date;
};

type ExternalFeeRow = {
  type: "topup_fee" | "payment_fee";
  amountUsdt: string;
  amountThb: string;
  rate: string;
};

function formatExternalFee(fee: ExternalFeeRow) {
  return {
    type: fee.type === "payment_fee" ? "payment" as const : "topup" as const,
    currency: "USDT" as const,
    amountUsdt: formatUsdt(fee.amountUsdt),
    amountThb: formatDecimal(fee.amountThb, 2),
    rate: formatDecimal(fee.rate, 6),
  };
}

function formatExternalOrder(row: ExternalOrderRow, fee: ExternalFeeRow | null) {
  const formattedFee = fee ? formatExternalFee(fee) : null;
  return {
    id: row.id,
    orderId: row.orderId,
    userId: row.userId,
    status: row.status,
    amountThb: row.amountThb,
    amountUsdt: row.amountUsdt,
    exchangeRate: row.exchangeRate,
    bankName: row.bankName,
    bahtSource: row.bahtSource,
    bahtSourceName: row.bahtSourceName,
    accountNumber: row.accountNumber,
    accountName: row.accountName,
    fee: formattedFee,
    paymentFee: formattedFee?.type === "payment" ? formattedFee : null,
    topupFee: formattedFee?.type === "topup" ? formattedFee : null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

// ---------------------------------------------------------------------------
// GET /external/transactions
// ---------------------------------------------------------------------------
// Query params:
//   userId   — filter by a specific user id
//   type     — deposit (default), payment_fee, or payment (alias for payment_fee)
//   asset    — USDT
//   network  — comma-separated BEP20,TRC20,ERC20 values
//   status   — comma-separated pending,confirmed,failed,refunded,reversed values
//   from     — ISO datetime lower bound (createdAt >=)
//   to       — ISO datetime upper bound (createdAt <=)
//   updatedSince — ISO datetime lower bound (updatedAt >=)
//   limit    — rows per page (default 50, max 500)
//   offset   — pagination offset (default 0)
// ---------------------------------------------------------------------------
router.get("/external/transactions", async (req, res) => {
  if (!authoriseExternal(req, res)) return;

  const { userId, type, asset, network, status, from, to, updatedSince } = req.query;
  const { limit, offset } = parsePage(req.query.limit, req.query.offset);

  const requestedTypes =
    typeof type === "string" && type
      ? type
          .split(",")
          .map((value) => value.trim().toLowerCase())
          .filter(Boolean)
          .map((value) => (value === "payment" ? "payment_fee" : value))
      : ["deposit"];
  const hasPaymentFee = requestedTypes.includes("payment_fee");
  const hasDeposit = requestedTypes.includes("deposit");

  // Keep the existing deposit feed backward compatible. Payment fees are
  // exposed from the same connected endpoint through type=payment_fee (or
  // type=payment), so Onavixpay does not need a new API key or base URL.
  if (hasPaymentFee && !hasDeposit && requestedTypes.length === 1) {
    const feeConditions = [
      or(
        isNull(transactionsTable.userId),
        and(
          notInArray(transactionsTable.userId, TESTER_USER_IDS),
          notInArray(usersTable.phone, TESTER_USER_PHONES),
        ),
      ),
      eq(transactionsTable.type, "payment_fee"),
    ];
    if (typeof userId === "string" && userId) {
      feeConditions.push(
        or(
          eq(transactionsTable.userId, userId),
          eq(usersTable.uid, userId),
        )!,
      );
    }
    if (typeof asset === "string" && asset && asset.toUpperCase() !== "USDT") {
      res.json({ data: [], limit, offset, count: 0 });
      return;
    }
    if (typeof network === "string" && network) {
      res.json({ data: [], limit, offset, count: 0 });
      return;
    }
    if (typeof status === "string" && status) {
      const statuses = status
        .split(",")
        .map((value) => value.trim().toLowerCase())
        .filter(Boolean);
      if (statuses.length === 0 || statuses.some((value) => value !== "settled")) {
        res.json({ data: [], limit, offset, count: 0 });
        return;
      }
    }
    const fromDate = parseDate(from);
    const toDate = parseDate(to);
    if (fromDate) feeConditions.push(gte(transactionsTable.createdAt, fromDate));
    if (toDate) feeConditions.push(lte(transactionsTable.createdAt, toDate));
    const updatedSinceDate = parseDate(updatedSince);
    if (updatedSinceDate) feeConditions.push(gte(transactionsTable.createdAt, updatedSinceDate));

    const feeRows = await db
      .select({
        id: transactionsTable.id,
        userId: transactionsTable.userId,
        amountUsdt: transactionsTable.amountUsdt,
        amountThb: transactionsTable.amountThb,
        rate: transactionsTable.rate,
        refOrderId: transactionsTable.refOrderId,
        orderId: ordersTable.orderId,
        orderAmountThb: ordersTable.amountThb,
        orderStatus: ordersTable.status,
        createdAt: transactionsTable.createdAt,
      })
      .from(transactionsTable)
      .leftJoin(ordersTable, eq(ordersTable.id, transactionsTable.refOrderId))
      .leftJoin(usersTable, eq(usersTable.id, transactionsTable.userId))
      .where(and(...feeConditions))
      .orderBy(desc(transactionsTable.createdAt), desc(transactionsTable.id))
      .limit(limit)
      .offset(offset);

    res.json({
      data: feeRows.map((row) => {
        const amountUsdt = formatUsdt(row.amountUsdt);
        return {
          id: row.id,
          userId: row.userId,
          type: "payment_fee" as const,
          asset: "USDT" as const,
          network: null,
          walletCode: null,
          amountUsdt,
          grossAmountUsdt: null,
          fee: {
            type: "payment" as const,
            currency: "USDT" as const,
            amountUsdt,
            amountThb: formatDecimal(row.amountThb, 2),
            rate: formatDecimal(row.rate, 6),
          },
          netAmountUsdt: null,
          paymentAmountThb: row.orderAmountThb ? formatDecimal(row.orderAmountThb, 2) : null,
          exchangeRate: formatDecimal(row.rate, 6),
          refOrderId: row.refOrderId,
          orderId: row.orderId,
          txHash: null,
          status: "settled" as const,
          confirmations: null,
          createdAt: row.createdAt.toISOString(),
          confirmedAt: null,
          updatedAt: row.createdAt.toISOString(),
        };
      }),
      limit,
      offset,
      count: feeRows.length,
    });
    return;
  }

  if (requestedTypes.some((value) => !EXTERNAL_TRANSACTION_TYPES.includes(value as ExternalTransactionType))) {
    res.json({ data: [], limit, offset, count: 0 });
    return;
  }

  const conditions = [
    or(
      isNull(ordersTable.userId),
      and(
        notInArray(ordersTable.userId, TESTER_USER_IDS),
        notInArray(usersTable.phone, TESTER_USER_PHONES),
      ),
    ),
    eq(ordersTable.bankName, ""),
  ];
  if (typeof userId === "string" && userId) {
    conditions.push(or(eq(ordersTable.userId, userId), eq(usersTable.uid, userId))!);
  }
  if (!hasDeposit) {
    res.json({ data: [], limit, offset, count: 0 });
    return;
  }
  if (typeof asset === "string" && asset && asset.toUpperCase() !== "USDT") {
    res.json({ data: [], limit, offset, count: 0 });
    return;
  }
  if (typeof network === "string" && network) {
    const networks = network
      .split(",")
      .map((value) => value.trim().toUpperCase())
      .filter((value): value is ExternalNetwork =>
        (EXTERNAL_NETWORKS as readonly string[]).includes(value),
      );
    if (networks.length === 0) {
      res.json({ data: [], limit, offset, count: 0 });
      return;
    }
    conditions.push(inArray(depositNetwork, networks));
  }
  if (typeof status === "string" && status) {
    const statuses = status
      .split(",")
      .map((value) => value.trim().toLowerCase())
      .filter((value): value is ExternalStatus =>
        (EXTERNAL_STATUSES as readonly string[]).includes(value),
      );
    if (statuses.length === 0) {
      res.json({ data: [], limit, offset, count: 0 });
      return;
    }
    const orderStatuses = [];
    if (statuses.includes("pending")) orderStatuses.push("pending", "paid");
    if (statuses.includes("confirmed")) orderStatuses.push("completed");
    if (statuses.includes("refunded")) orderStatuses.push("refunded");
    if (statuses.includes("failed")) orderStatuses.push("expired");
    // reversed is a valid external filter value for forward compatibility,
    // but the current AndersPay order state machine has no such state.
    if (orderStatuses.length === 0) {
      res.json({ data: [], limit, offset, count: 0 });
      return;
    }
    conditions.push(inArray(ordersTable.status, orderStatuses as typeof ordersTable.status.enumValues));
  }
  const fromDate = parseDate(from);
  const toDate = parseDate(to);
  if (fromDate) conditions.push(gte(ordersTable.createdAt, fromDate));
  if (toDate) conditions.push(lte(ordersTable.createdAt, toDate));
  const updatedSinceDate = parseDate(updatedSince);
  if (updatedSinceDate) conditions.push(gte(ordersTable.updatedAt, updatedSinceDate));
  conditions.push(isNotNull(depositNetwork));
  const where = and(...conditions);

  const rows = await db
    .select({
      id: ordersTable.id,
      userId: ordersTable.userId,
      userUid: usersTable.uid,
      type: sql<"deposit">`'deposit'`,
      network: depositNetwork,
      amountUsdt: ordersTable.amountUsdt,
      txHash: ordersTable.txHash,
      confirmations: ordersTable.confirmations,
      status: ordersTable.status,
      createdAt: ordersTable.createdAt,
      confirmedAt: ordersTable.confirmedAt,
      updatedAt: ordersTable.updatedAt,
    })
    .from(ordersTable)
    .leftJoin(usersTable, eq(usersTable.id, ordersTable.userId))
    .where(where)
    .orderBy(desc(ordersTable.updatedAt), desc(ordersTable.id))
    .limit(limit)
    .offset(offset);

  const orderIds = rows.map((row) => row.id);
  const feeRows = orderIds.length
    ? await db
        .select({
          refOrderId: transactionsTable.refOrderId,
          amountUsdt: transactionsTable.amountUsdt,
        })
        .from(transactionsTable)
        .where(
          and(
            inArray(transactionsTable.refOrderId, orderIds),
            eq(transactionsTable.type, "topup_fee"),
          ),
        )
    : [];
  const feesByOrderId = new Map(
    feeRows
      .filter((row): row is typeof row & { refOrderId: string } => Boolean(row.refOrderId))
      .map((row) => [row.refOrderId, formatUsdt(row.amountUsdt)]),
  );

  res.json({
    data: rows.map((row) => {
      const normalizedNetwork = row.network as ExternalNetwork;
      const feeUsdt = feesByOrderId.get(row.id) ?? null;
      const grossAmountUsdt = formatUsdt(row.amountUsdt);
      const netAmountUsdt =
        feeUsdt === null
          ? null
          : formatUsdt((parseFloat(row.amountUsdt) - parseFloat(feeUsdt)).toFixed(6));
      return {
        id: row.id,
        userId: row.userId,
        type: row.type,
        asset: "USDT" as const,
        network: normalizedNetwork,
        walletCode: externalWalletCode(normalizedNetwork),
        amountUsdt: grossAmountUsdt,
        grossAmountUsdt,
        fee: feeUsdt === null
          ? null
          : {
              type: "topup" as const,
              currency: "USDT" as const,
              amountUsdt: feeUsdt,
            },
        netAmountUsdt,
        txHash: row.txHash,
        status: externalStatus(row.status),
        confirmations: row.confirmations,
        createdAt: row.createdAt.toISOString(),
        confirmedAt: row.confirmedAt ? row.confirmedAt.toISOString() : null,
        updatedAt: row.updatedAt.toISOString(),
      };
    }),
    limit,
    offset,
    count: rows.length,
  });
});

// ---------------------------------------------------------------------------
// GET /external/fees
// ---------------------------------------------------------------------------
// Returns only fees that were actually recorded in the ledger. This avoids
// recalculating historical fees from a fee schedule that may change later.
// Query params:
//   userId       — filter by internal user id or member UID
//   type         — topup, payment, or comma-separated values
//   from         — ISO datetime lower bound (createdAt >=)
//   to           — ISO datetime upper bound (createdAt <=)
//   limit        — rows per page (default 50, max 1000)
//   offset       — pagination offset (default 0)
// ---------------------------------------------------------------------------
router.get("/external/fees", async (req, res) => {
  if (!authoriseExternal(req, res)) return;

  const { userId, type, from, to } = req.query;
  const { limit, offset } = parsePage(req.query.limit, req.query.offset);
  const feeTypes = ["topup", "payment"] as const;
  type ExternalFeeType = (typeof feeTypes)[number];
  const ledgerTypes = ["topup_fee", "payment_fee"] as const;

  const conditions = [
    or(
      isNull(transactionsTable.userId),
      and(
        notInArray(transactionsTable.userId, TESTER_USER_IDS),
        notInArray(usersTable.phone, TESTER_USER_PHONES),
      ),
    ),
  ];
  if (typeof userId === "string" && userId) {
    conditions.push(
      or(
        eq(transactionsTable.userId, userId),
        eq(usersTable.uid, userId),
      )!,
    );
  }
  if (typeof type === "string" && type) {
    const requestedTypes = type
      .split(",")
      .map((value) => value.trim().toLowerCase())
      .filter((value): value is ExternalFeeType => (feeTypes as readonly string[]).includes(value));
    if (requestedTypes.length === 0) {
      res.json({ data: [], limit, offset, count: 0 });
      return;
    }
    const requestedLedgerTypes = requestedTypes.map((value) =>
      value === "topup" ? "topup_fee" : "payment_fee",
    ) as typeof ledgerTypes[number][];
    conditions.push(inArray(transactionsTable.type, requestedLedgerTypes));
  } else {
    conditions.push(inArray(transactionsTable.type, [...ledgerTypes]));
  }
  const fromDate = parseDate(from);
  const toDate = parseDate(to);
  if (fromDate) conditions.push(gte(transactionsTable.createdAt, fromDate));
  if (toDate) conditions.push(lte(transactionsTable.createdAt, toDate));

  const rows = await db
    .select({
      id: transactionsTable.id,
      userId: transactionsTable.userId,
      type: transactionsTable.type,
      amountUsdt: transactionsTable.amountUsdt,
      amountThb: transactionsTable.amountThb,
      rate: transactionsTable.rate,
      refOrderId: transactionsTable.refOrderId,
      orderId: ordersTable.orderId,
      createdAt: transactionsTable.createdAt,
    })
    .from(transactionsTable)
    .leftJoin(ordersTable, eq(ordersTable.id, transactionsTable.refOrderId))
    .leftJoin(usersTable, eq(usersTable.id, transactionsTable.userId))
    .where(and(...conditions))
    .orderBy(desc(transactionsTable.createdAt), desc(transactionsTable.id))
    .limit(limit)
    .offset(offset);

  res.json({
    data: rows.map((row) => ({
      id: row.id,
      userId: row.userId,
      type: row.type === "topup_fee" ? "topup" as const : "payment" as const,
      currency: "USDT" as const,
      amountUsdt: formatUsdt(row.amountUsdt),
      amountThb: formatDecimal(row.amountThb, 2),
      rate: formatDecimal(row.rate, 6),
      refOrderId: row.refOrderId,
      orderId: row.orderId,
      // A fee row only exists after AndersPay has recorded the debit. Its
      // ledger state is therefore settled even if the linked payment order
      // is still awaiting administrative fulfillment.
      status: "settled" as const,
      createdAt: row.createdAt.toISOString(),
    })),
    limit,
    offset,
    count: rows.length,
  });
});

// ---------------------------------------------------------------------------
// GET /external/orders
// ---------------------------------------------------------------------------
// Query params:
//   userId   — filter by user id
//   status   — comma-separated statuses (pending,paid,completed,expired,refunded)
//   from     — ISO datetime lower bound (createdAt >=)
//   to       — ISO datetime upper bound (createdAt <=)
//   limit    — default 50, max 500
//   offset   — default 0
// ---------------------------------------------------------------------------
router.get("/external/orders", async (req, res) => {
  if (!authoriseExternal(req, res)) return;

  const { userId, status, from, to } = req.query;
  const { limit, offset } = parsePage(req.query.limit, req.query.offset);

  const conditions = [
    or(
      isNull(ordersTable.userId),
      and(
        notInArray(ordersTable.userId, TESTER_USER_IDS),
        notInArray(usersTable.phone, TESTER_USER_PHONES),
      ),
    ),
  ];
  if (typeof userId === "string" && userId) {
    conditions.push(or(eq(ordersTable.userId, userId), eq(usersTable.uid, userId))!);
  }
  if (typeof status === "string" && status) {
    const statuses = status.split(",").map((s) => s.trim()).filter(Boolean) as any[];
    if (statuses.length > 0) conditions.push(inArray(ordersTable.status, statuses));
  }
  const fromDate = parseDate(from);
  const toDate = parseDate(to);
  if (fromDate) conditions.push(gte(ordersTable.createdAt, fromDate));
  if (toDate) conditions.push(lte(ordersTable.createdAt, toDate));

  const where = and(...conditions);

  const rows = await db
    .select({
      id: ordersTable.id,
      orderId: ordersTable.orderId,
      userId: ordersTable.userId,
      status: ordersTable.status,
      amountThb: ordersTable.amountThb,
      amountUsdt: ordersTable.amountUsdt,
      exchangeRate: ordersTable.exchangeRate,
      bankName: ordersTable.bankName,
      bahtSource: ordersTable.bahtSource,
      bahtSourceName: ordersTable.bahtSourceName,
      accountNumber: ordersTable.accountNumber,
      accountName: ordersTable.accountName,
      createdAt: ordersTable.createdAt,
      updatedAt: ordersTable.updatedAt,
    })
    .from(ordersTable)
    .leftJoin(usersTable, eq(usersTable.id, ordersTable.userId))
    .where(where)
    .orderBy(desc(ordersTable.createdAt))
    .limit(limit)
    .offset(offset);

  const orderIds = rows.map((row) => row.id);
  const feeRows = orderIds.length
    ? await db
        .select({
          refOrderId: transactionsTable.refOrderId,
          type: transactionsTable.type,
          amountUsdt: transactionsTable.amountUsdt,
          amountThb: transactionsTable.amountThb,
          rate: transactionsTable.rate,
          createdAt: transactionsTable.createdAt,
          id: transactionsTable.id,
        })
        .from(transactionsTable)
        .where(
          and(
            inArray(transactionsTable.refOrderId, orderIds),
            inArray(transactionsTable.type, ["topup_fee", "payment_fee"]),
          ),
        )
        .orderBy(desc(transactionsTable.createdAt), desc(transactionsTable.id))
    : [];
  const feesByOrderId = new Map<string, ExternalFeeRow>();
  for (const row of feeRows) {
    if (
      row.refOrderId &&
      (row.type === "topup_fee" || row.type === "payment_fee") &&
      !feesByOrderId.has(row.refOrderId)
    ) {
      feesByOrderId.set(row.refOrderId, {
        type: row.type,
        amountUsdt: row.amountUsdt,
        amountThb: row.amountThb,
        rate: row.rate,
      });
    }
  }

  res.json({
    data: rows.map((row) => formatExternalOrder(row, feesByOrderId.get(row.id) ?? null)),
    limit,
    offset,
    count: rows.length,
  });
});

// ---------------------------------------------------------------------------
// GET /external/orders/:orderId
// ---------------------------------------------------------------------------
// Canonical API-key-protected order detail. The parameter accepts the public
// orderId and the internal order id for backwards-compatible reconciliation.
// The response shape is identical to each item in GET /external/orders.
// ---------------------------------------------------------------------------
router.get("/external/orders/:orderId", async (req, res) => {
  if (!authoriseExternal(req, res)) return;

  const requestedId = req.params.orderId;
  const [row] = await db
    .select({
      id: ordersTable.id,
      orderId: ordersTable.orderId,
      userId: ordersTable.userId,
      status: ordersTable.status,
      amountThb: ordersTable.amountThb,
      amountUsdt: ordersTable.amountUsdt,
      exchangeRate: ordersTable.exchangeRate,
      bankName: ordersTable.bankName,
      bahtSource: ordersTable.bahtSource,
      bahtSourceName: ordersTable.bahtSourceName,
      accountNumber: ordersTable.accountNumber,
      accountName: ordersTable.accountName,
      createdAt: ordersTable.createdAt,
      updatedAt: ordersTable.updatedAt,
    })
    .from(ordersTable)
    .where(
      and(
        or(eq(ordersTable.id, requestedId), eq(ordersTable.orderId, requestedId)),
        or(
          isNull(ordersTable.userId),
          and(
            notInArray(ordersTable.userId, TESTER_USER_IDS),
            notInArray(usersTable.phone, TESTER_USER_PHONES),
          ),
        ),
      ),
    )
    .limit(1);

  if (!row) {
    res.status(404).json({ message: "External order not found", code: "ORDER_NOT_FOUND" });
    return;
  }

  const [fee] = await db
    .select({
      type: transactionsTable.type,
      amountUsdt: transactionsTable.amountUsdt,
      amountThb: transactionsTable.amountThb,
      rate: transactionsTable.rate,
    })
    .from(transactionsTable)
    .where(
      and(
        eq(transactionsTable.refOrderId, row.id),
        inArray(transactionsTable.type, ["topup_fee", "payment_fee"]),
      ),
    )
    .orderBy(desc(transactionsTable.createdAt), desc(transactionsTable.id))
    .limit(1);

  res.json(formatExternalOrder(
    row,
    fee && (fee.type === "topup_fee" || fee.type === "payment_fee")
      ? {
          type: fee.type,
          amountUsdt: fee.amountUsdt,
          amountThb: fee.amountThb,
          rate: fee.rate,
        }
      : null,
  ));
});

// ---------------------------------------------------------------------------
// GET /external/users
// ---------------------------------------------------------------------------
// Returns user list with balances. Sensitive fields (password hash, pin hash,
// session id, OTPs) are never included.
// Query params:
//   limit  — default 50, max 500
//   offset — default 0
// ---------------------------------------------------------------------------
router.get("/external/users", async (req, res) => {
  if (!authoriseExternal(req, res)) return;

  const { limit, offset } = parsePage(req.query.limit, req.query.offset);

  const rows = await db
    .select({
      id: usersTable.id,
      uid: usersTable.uid,
      name: usersTable.name,
      nickname: usersTable.nickname,
      phone: usersTable.phone,
      usdtBalance: usersTable.usdtBalance,
      thbBalance: usersTable.thbBalance,
      referralCount: usersTable.referralCount,
      totalReferralEarned: usersTable.totalReferralEarned,
      createdAt: usersTable.createdAt,
      lastSeenAt: usersTable.lastSeenAt,
      isAdmin: usersTable.isAdmin,
    })
    .from(usersTable)
    .where(
      and(
        notInArray(usersTable.id, TESTER_USER_IDS),
        notInArray(usersTable.phone, TESTER_USER_PHONES),
      ),
    )
    .orderBy(desc(usersTable.createdAt))
    .limit(limit)
    .offset(offset);

  res.json({ data: rows, limit, offset, count: rows.length });
});

// ---------------------------------------------------------------------------
// GET /external/combined
// ---------------------------------------------------------------------------
// Merged feed of orders + ledger transactions — same shape as the admin
// transaction history. Use this when you need all activity in one call
// (e.g. Onavixpay needs the full 278-record view instead of separate tables).
//
// Query params:
//   userId   — filter by a specific user id
//   from     — ISO datetime lower bound (createdAt >=)
//   to       — ISO datetime upper bound (createdAt <=)
//   limit    — rows per page (default 200, max 1000)
//   offset   — pagination offset (default 0)
// ---------------------------------------------------------------------------
router.get("/external/combined", async (req, res) => {
  if (!authoriseExternal(req, res)) return;

  const { userId, from, to } = req.query;
  const { limit, offset } = parsePage(req.query.limit, req.query.offset, 200, 1000);

  const fromDate = parseDate(from);
  const toDate = parseDate(to);

  const orderConditions = [
    or(
      isNull(ordersTable.userId),
      and(
        notInArray(ordersTable.userId, TESTER_USER_IDS),
        notInArray(usersTable.phone, TESTER_USER_PHONES),
      ),
    ),
  ];
  const txConditions = [
    or(
      isNull(transactionsTable.userId),
      and(
        notInArray(transactionsTable.userId, TESTER_USER_IDS),
        notInArray(usersTable.phone, TESTER_USER_PHONES),
      ),
    ),
  ];

  if (typeof userId === "string" && userId) {
    orderConditions.push(eq(ordersTable.userId, userId));
    txConditions.push(eq(transactionsTable.userId, userId));
  }
  if (fromDate) {
    orderConditions.push(gte(ordersTable.createdAt, fromDate));
    txConditions.push(gte(transactionsTable.createdAt, fromDate));
  }
  if (toDate) {
    orderConditions.push(lte(ordersTable.createdAt, toDate));
    txConditions.push(lte(transactionsTable.createdAt, toDate));
  }

  const orderWhere = and(...orderConditions);
  const txWhere = and(...txConditions);

  // Over-fetch both tables up to `limit` then merge-sort in memory.
  const [orderRows, txRows] = await Promise.all([
    db
      .select({
        id: ordersTable.id,
        orderId: ordersTable.orderId,
        userId: ordersTable.userId,
        amountUsdt: ordersTable.amountUsdt,
        amountThb: ordersTable.amountThb,
        rate: ordersTable.exchangeRate,
        bankName: ordersTable.bankName,
        bahtSource: ordersTable.bahtSource,
        bahtSourceName: ordersTable.bahtSourceName,
        accountNumber: ordersTable.accountNumber,
        accountName: ordersTable.accountName,
        status: ordersTable.status,
        createdAt: ordersTable.createdAt,
        userUid: usersTable.uid,
        userName: usersTable.name,
        userNickname: usersTable.nickname,
        userPhone: usersTable.phone,
      })
      .from(ordersTable)
      .leftJoin(usersTable, eq(usersTable.id, ordersTable.userId))
      .where(orderWhere)
      .orderBy(desc(ordersTable.createdAt))
      .limit(limit),
    db
      .select({
        id: transactionsTable.id,
        userId: transactionsTable.userId,
        type: transactionsTable.type,
        amountUsdt: transactionsTable.amountUsdt,
        amountThb: transactionsTable.amountThb,
        rate: transactionsTable.rate,
        refOrderId: transactionsTable.refOrderId,
        createdAt: transactionsTable.createdAt,
        userUid: usersTable.uid,
        userName: usersTable.name,
        userNickname: usersTable.nickname,
        userPhone: usersTable.phone,
      })
      .from(transactionsTable)
      .leftJoin(usersTable, eq(usersTable.id, transactionsTable.userId))
      .where(txWhere)
      .orderBy(desc(transactionsTable.createdAt))
      .limit(limit),
  ]);

  const ordersMapped = orderRows.map((r) => ({
    id: r.id,
    source: "order" as const,
    type: (r.bankName && r.bankName.length > 0 ? "order_payment" : "order_topup") as string,
    orderId: r.orderId,
    userId: r.userId,
    amountUsdt: parseFloat(r.amountUsdt),
    amountThb: parseFloat(r.amountThb),
    rate: parseFloat(r.rate),
    accountNumber: r.accountNumber,
    accountName: r.accountName,
    bahtSource: r.bahtSource,
    bahtSourceName: r.bahtSourceName,
    status: r.status,
    refOrderId: r.orderId,
    createdAt: r.createdAt.toISOString(),
    user: {
      uid: r.userUid,
      name: r.userName,
      nickname: r.userNickname,
      phone: r.userPhone,
    },
  }));

  const txMapped = txRows.map((r) => ({
    id: r.id,
    source: "ledger" as const,
    type: r.type as string,
    orderId: null,
    userId: r.userId,
    amountUsdt: parseFloat(r.amountUsdt),
    amountThb: parseFloat(r.amountThb),
    rate: parseFloat(r.rate),
    accountNumber: null,
    accountName: null,
    status: "settled" as const,
    refOrderId: r.refOrderId,
    createdAt: r.createdAt.toISOString(),
    user: {
      uid: r.userUid,
      name: r.userName,
      nickname: r.userNickname,
      phone: r.userPhone,
    },
  }));

  const merged = [...ordersMapped, ...txMapped]
    .sort((a, b) => (a.createdAt < b.createdAt ? 1 : a.createdAt > b.createdAt ? -1 : 0))
    .slice(offset, offset + limit);

  res.json({
    total: merged.length,
    orderCount: ordersMapped.length,
    ledgerCount: txMapped.length,
    limit,
    offset,
    data: merged,
  });
});

export default router;
