import { Router, type Request } from "express";
import bcrypt from "bcryptjs";
import { randomUUID } from "crypto";
import { db, usersTable, webauthnCredentialsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import {
  generateRegistrationOptions,
  verifyRegistrationResponse,
  generateAuthenticationOptions,
  verifyAuthenticationResponse,
} from "@simplewebauthn/server";
import { authenticateRequest } from "../lib/jwt";

const router = Router();

// In-memory challenge store keyed by userId. WebAuthn challenges are
// short-lived (5 min) and one-shot, so this is fine for a single server
// instance. Move to a DB-backed store if scaling horizontally.
const challenges = new Map<string, { challenge: string; expiresAt: number }>();
const CHALLENGE_TTL_MS = 5 * 60 * 1000;

function setChallenge(userId: string, challenge: string): void {
  challenges.set(userId, { challenge, expiresAt: Date.now() + CHALLENGE_TTL_MS });
}

function takeChallenge(userId: string): string | null {
  const c = challenges.get(userId);
  challenges.delete(userId);
  if (!c) return null;
  if (c.expiresAt < Date.now()) return null;
  return c.challenge;
}

// Build the set of allowed RP IDs / origins.
// In production, only the hostnames in REPLIT_DOMAINS (the deployed domains)
// are trusted. In development we additionally allow the dev domain and
// localhost. Untrusted Host / X-Forwarded-Host headers cannot widen this set.
function allowedHosts(): string[] {
  const set = new Set<string>();
  const add = (raw: string | undefined) => {
    if (!raw) return;
    for (const part of raw.split(",")) {
      const h = part.trim().split(":")[0];
      if (h) set.add(h.toLowerCase());
    }
  };
  add(process.env.REPLIT_DOMAINS);
  if (process.env.NODE_ENV !== "production") {
    add(process.env.REPLIT_DEV_DOMAIN);
    add("localhost");
  }
  return Array.from(set);
}

function rpInfo(req: Request): {
  rpID: string;
  origin: string;
  rpName: string;
  expectedRPID: string[];
  expectedOrigin: string[];
} {
  const allowed = allowedHosts();
  // Derive request host so the browser-facing rpID matches what the client
  // saw. We then validate it against the allowlist; if the host header is
  // spoofed to something outside the list, fall back to the first allowed
  // host so verification fails cleanly rather than accepting a forged RP ID.
  const hostHeader =
    (req.headers["x-forwarded-host"] as string | undefined) ??
    (req.headers.host as string | undefined) ??
    "localhost";
  const reqHost = hostHeader.split(",")[0].trim().split(":")[0].toLowerCase();
  const rpID = allowed.includes(reqHost) ? reqHost : (allowed[0] ?? reqHost);

  const protoHeader =
    (req.headers["x-forwarded-proto"] as string | undefined) ?? "https";
  const proto = protoHeader.split(",")[0].trim();
  const origin = `${proto}://${rpID}`;

  // Allow any of the configured hosts to satisfy verification, so a passkey
  // registered on the dev domain still works on the prod domain only when
  // both are explicitly allowlisted.
  const expectedRPID = allowed.length ? allowed : [rpID];
  const expectedOrigin = expectedRPID.flatMap((h) => [
    `https://${h}`,
    ...(process.env.NODE_ENV !== "production" ? [`http://${h}`, `http://${h}:5173`] : []),
  ]);

  return { rpID, origin, rpName: "AndersPay+", expectedRPID, expectedOrigin };
}

async function requireUser(req: Request) {
  const payload = await authenticateRequest(req);
  if (!payload) return null;
  const [u] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId))
    .limit(1);
  return u ?? null;
}

// ── status ─────────────────────────────────────────────────────────
router.get("/security/status", async (req, res) => {
  const user = await requireUser(req);
  if (!user) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const creds = await db
    .select()
    .from(webauthnCredentialsTable)
    .where(eq(webauthnCredentialsTable.userId, user.id));
  res.json({
    pinEnabled: !!user.pinHash,
    passkeys: creds.map((c) => ({
      id: c.id,
      name: c.name,
      createdAt: c.createdAt,
      lastUsedAt: c.lastUsedAt,
    })),
  });
});

// ── PIN ────────────────────────────────────────────────────────────
router.post("/security/pin", async (req, res) => {
  const user = await requireUser(req);
  if (!user) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const body = req.body as { password?: unknown; pin?: unknown };
  const password = typeof body.password === "string" ? body.password : "";
  const pin = typeof body.pin === "string" ? body.pin : "";
  if (!/^\d{6}$/.test(pin)) {
    res.status(400).json({ error: "invalid_pin" });
    return;
  }
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) {
    res.status(401).json({ error: "wrong_password" });
    return;
  }
  const hash = await bcrypt.hash(pin, 10);
  await db.update(usersTable).set({ pinHash: hash }).where(eq(usersTable.id, user.id));
  res.json({ ok: true });
});

// Brute-force protection for PIN verify. 6-digit PIN has only 1M
// combinations, so we throttle per-user to make online brute-force
// infeasible. After 5 failed attempts, lock for 15 minutes.
const MAX_PIN_ATTEMPTS = 5;
const PIN_LOCKOUT_MS = 15 * 60 * 1000;
const pinAttempts = new Map<string, { count: number; lockedUntil: number }>();

router.post("/security/pin/verify", async (req, res) => {
  const user = await requireUser(req);
  if (!user) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const body = req.body as { pin?: unknown };
  const pin = typeof body.pin === "string" ? body.pin : "";
  if (!user.pinHash) {
    res.status(400).json({ error: "no_pin" });
    return;
  }

  const now = Date.now();
  const state = pinAttempts.get(user.id) ?? { count: 0, lockedUntil: 0 };
  if (state.lockedUntil > now) {
    res.status(429).json({
      error: "too_many_attempts",
      retryAfter: Math.ceil((state.lockedUntil - now) / 1000),
    });
    return;
  }

  const ok = await bcrypt.compare(pin, user.pinHash);
  if (!ok) {
    state.count += 1;
    if (state.count >= MAX_PIN_ATTEMPTS) {
      state.lockedUntil = now + PIN_LOCKOUT_MS;
      state.count = 0;
    }
    pinAttempts.set(user.id, state);
    res.status(401).json({ error: "wrong_pin" });
    return;
  }
  pinAttempts.delete(user.id);
  res.json({ ok: true });
});

router.delete("/security/pin", async (req, res) => {
  const user = await requireUser(req);
  if (!user) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const body = req.body as { password?: unknown };
  const password = typeof body.password === "string" ? body.password : "";
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) {
    res.status(401).json({ error: "wrong_password" });
    return;
  }
  await db.update(usersTable).set({ pinHash: null }).where(eq(usersTable.id, user.id));
  res.json({ ok: true });
});

// ── Passkey registration ───────────────────────────────────────────
router.post("/security/passkey/register/options", async (req, res) => {
  const user = await requireUser(req);
  if (!user) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const { rpID, rpName } = rpInfo(req);
  const existing = await db
    .select({ credentialId: webauthnCredentialsTable.credentialId })
    .from(webauthnCredentialsTable)
    .where(eq(webauthnCredentialsTable.userId, user.id));

  const options = await generateRegistrationOptions({
    rpName,
    rpID,
    userID: new TextEncoder().encode(user.id),
    userName: user.phone,
    userDisplayName: user.nickname ?? user.name,
    attestationType: "none",
    authenticatorSelection: {
      residentKey: "preferred",
      userVerification: "preferred",
    },
    excludeCredentials: existing.map((e) => ({ id: e.credentialId })),
  });
  setChallenge(user.id, options.challenge);
  res.json(options);
});

router.post("/security/passkey/register/verify", async (req, res) => {
  const user = await requireUser(req);
  if (!user) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const body = req.body as { response?: unknown; name?: unknown };
  if (!body.response || typeof body.response !== "object") {
    res.status(400).json({ error: "invalid_input" });
    return;
  }
  const challenge = takeChallenge(user.id);
  if (!challenge) {
    res.status(400).json({ error: "challenge_expired" });
    return;
  }
  const { expectedRPID, expectedOrigin } = rpInfo(req);

  let verification;
  try {
    verification = await verifyRegistrationResponse({
      // SimpleWebAuthn expects the JSON-shaped response from the browser.
      response: body.response as Parameters<typeof verifyRegistrationResponse>[0]["response"],
      expectedChallenge: challenge,
      expectedOrigin,
      expectedRPID,
    });
  } catch {
    res.status(400).json({ error: "verification_failed" });
    return;
  }

  if (!verification.verified || !verification.registrationInfo) {
    res.status(400).json({ error: "verification_failed" });
    return;
  }
  const { credential } = verification.registrationInfo;
  const friendly = typeof body.name === "string" && body.name.trim()
    ? body.name.trim().slice(0, 40)
    : "Passkey";
  await db.insert(webauthnCredentialsTable).values({
    id: randomUUID(),
    userId: user.id,
    credentialId: credential.id,
    publicKey: Buffer.from(credential.publicKey).toString("base64"),
    counter: credential.counter,
    transports: credential.transports ? JSON.stringify(credential.transports) : null,
    name: friendly,
  });
  res.json({ ok: true });
});

// ── Passkey authentication ─────────────────────────────────────────
router.post("/security/passkey/auth/options", async (req, res) => {
  const user = await requireUser(req);
  if (!user) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const { rpID } = rpInfo(req);
  const creds = await db
    .select()
    .from(webauthnCredentialsTable)
    .where(eq(webauthnCredentialsTable.userId, user.id));
  if (creds.length === 0) {
    res.status(400).json({ error: "no_passkeys" });
    return;
  }
  const options = await generateAuthenticationOptions({
    rpID,
    userVerification: "preferred",
    allowCredentials: creds.map((c) => ({
      id: c.credentialId,
      transports: c.transports
        ? (JSON.parse(c.transports) as AuthenticatorTransportFuture[])
        : undefined,
    })),
  });
  setChallenge(user.id, options.challenge);
  res.json(options);
});

router.post("/security/passkey/auth/verify", async (req, res) => {
  const user = await requireUser(req);
  if (!user) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const body = req.body as { response?: unknown };
  if (!body.response || typeof body.response !== "object") {
    res.status(400).json({ error: "invalid_input" });
    return;
  }
  const responseObj = body.response as { id?: unknown };
  const credentialId = typeof responseObj.id === "string" ? responseObj.id : "";
  if (!credentialId) {
    res.status(400).json({ error: "invalid_credential" });
    return;
  }
  const challenge = takeChallenge(user.id);
  if (!challenge) {
    res.status(400).json({ error: "challenge_expired" });
    return;
  }
  const [cred] = await db
    .select()
    .from(webauthnCredentialsTable)
    .where(
      and(
        eq(webauthnCredentialsTable.userId, user.id),
        eq(webauthnCredentialsTable.credentialId, credentialId),
      ),
    )
    .limit(1);
  if (!cred) {
    res.status(404).json({ error: "credential_not_found" });
    return;
  }
  const { expectedRPID, expectedOrigin } = rpInfo(req);

  let verification;
  try {
    verification = await verifyAuthenticationResponse({
      response: body.response as Parameters<typeof verifyAuthenticationResponse>[0]["response"],
      expectedChallenge: challenge,
      expectedOrigin,
      expectedRPID,
      credential: {
        id: cred.credentialId,
        publicKey: new Uint8Array(Buffer.from(cred.publicKey, "base64")),
        counter: cred.counter,
        transports: cred.transports
          ? (JSON.parse(cred.transports) as AuthenticatorTransportFuture[])
          : undefined,
      },
    });
  } catch {
    res.status(400).json({ error: "verification_failed" });
    return;
  }

  if (!verification.verified) {
    res.status(401).json({ error: "verification_failed" });
    return;
  }
  await db
    .update(webauthnCredentialsTable)
    .set({
      counter: verification.authenticationInfo.newCounter,
      lastUsedAt: new Date(),
    })
    .where(eq(webauthnCredentialsTable.id, cred.id));
  res.json({ ok: true });
});

router.delete("/security/passkey/:id", async (req, res) => {
  const user = await requireUser(req);
  if (!user) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const id = req.params.id;
  await db
    .delete(webauthnCredentialsTable)
    .where(
      and(
        eq(webauthnCredentialsTable.userId, user.id),
        eq(webauthnCredentialsTable.id, id),
      ),
    );
  res.json({ ok: true });
});

// SimpleWebAuthn re-export for transports type. Avoids importing
// @simplewebauthn/types separately.
type AuthenticatorTransportFuture =
  | "ble"
  | "cable"
  | "hybrid"
  | "internal"
  | "nfc"
  | "smart-card"
  | "usb";

export default router;
