import { Router } from "express";
import { db, usersTable, announcementsTable } from "@workspace/db";
import { eq, asc } from "drizzle-orm";
import { randomUUID } from "crypto";
import { z } from "zod";
import { authenticateRequest } from "../lib/jwt";
import { isAdminUser } from "../lib/admin";

const router = Router();

const AnnouncementBody = z.object({
  text: z.string().trim().min(1).max(300),
  url: z
    .string()
    .trim()
    .max(500)
    .refine((v) => v === "" || /^https?:\/\//i.test(v), {
      message: "url must start with http:// or https://",
    })
    .nullish(),
  active: z.boolean().optional(),
  sortOrder: z.number().int().optional(),
});

function serialize(row: typeof announcementsTable.$inferSelect) {
  return {
    id: row.id,
    text: row.text,
    url: row.url,
    active: row.active,
    sortOrder: row.sortOrder,
    updatedAt: row.updatedAt.toISOString(),
  };
}

async function requireAdmin(req: Parameters<Parameters<typeof router.get>[1]>[0]) {
  const payload = await authenticateRequest(req);
  if (!payload) return { ok: false as const, status: 401 };
  const [me] = await db.select().from(usersTable).where(eq(usersTable.id, payload.userId)).limit(1);
  if (!me || !isAdminUser(me)) return { ok: false as const, status: 403 };
  return { ok: true as const };
}

// GET /announcements — public: active lines for the marquee ticker.
router.get("/announcements", async (_req, res) => {
  const rows = await db
    .select()
    .from(announcementsTable)
    .where(eq(announcementsTable.active, true))
    .orderBy(asc(announcementsTable.sortOrder), asc(announcementsTable.createdAt));
  res.json({ announcements: rows.map(serialize) });
});

// GET /admin/announcements — admin: all lines, including inactive.
router.get("/admin/announcements", async (req, res): Promise<void> => {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    res.status(auth.status).json({ error: "forbidden" });
    return;
  }
  const rows = await db
    .select()
    .from(announcementsTable)
    .orderBy(asc(announcementsTable.sortOrder), asc(announcementsTable.createdAt));
  res.json({ announcements: rows.map(serialize) });
});

// POST /admin/announcements
router.post("/admin/announcements", async (req, res): Promise<void> => {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    res.status(auth.status).json({ error: "forbidden" });
    return;
  }
  const parsed = AnnouncementBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "invalid_input", details: parsed.error.flatten() });
    return;
  }
  const now = new Date();
  const [row] = await db
    .insert(announcementsTable)
    .values({
      id: randomUUID(),
      text: parsed.data.text,
      url: parsed.data.url ? parsed.data.url : null,
      active: parsed.data.active ?? true,
      sortOrder: parsed.data.sortOrder ?? 0,
      createdAt: now,
      updatedAt: now,
    })
    .returning();
  req.log.info({ announcementId: row.id }, "announcement created");
  res.json(serialize(row));
});

// PUT /admin/announcements/:id
router.put("/admin/announcements/:id", async (req, res): Promise<void> => {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    res.status(auth.status).json({ error: "forbidden" });
    return;
  }
  const parsed = AnnouncementBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "invalid_input", details: parsed.error.flatten() });
    return;
  }
  const [row] = await db
    .update(announcementsTable)
    .set({
      text: parsed.data.text,
      url: parsed.data.url ? parsed.data.url : null,
      active: parsed.data.active ?? true,
      sortOrder: parsed.data.sortOrder ?? 0,
      updatedAt: new Date(),
    })
    .where(eq(announcementsTable.id, req.params.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "not_found" });
    return;
  }
  res.json(serialize(row));
});

// DELETE /admin/announcements/:id
router.delete("/admin/announcements/:id", async (req, res): Promise<void> => {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    res.status(auth.status).json({ error: "forbidden" });
    return;
  }
  const [row] = await db
    .delete(announcementsTable)
    .where(eq(announcementsTable.id, req.params.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "not_found" });
    return;
  }
  req.log.info({ announcementId: row.id }, "announcement deleted");
  res.json({ ok: true });
});

export default router;
