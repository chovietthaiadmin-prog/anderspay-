import { Router } from "express";
import { db, ordersTable, telegramLinksTable, usersTable, transactionsTable } from "@workspace/db";
import { eq, sql, and, inArray } from "drizzle-orm";
import { randomUUID } from "crypto";
import { refundPayment } from "../lib/payment-accounting";
import {
  answerCallbackQuery,
  sendTelegramMessage,
  buildCompletedMessage,
  editMessageRemoveButtons,
  editMessageInlineKeyboard,
  getTelegramChatId,
} from "../lib/telegram";
import { completeOrderAndCredit } from "../lib/wallet-credit";
import { notifyCompletedPaymentSlip } from "../services/payment-slip-notification";

const router = Router();

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const API = () => `https://api.telegram.org/bot${BOT_TOKEN}`;

const BAHT_SOURCES = {
  bbl_bangkok: "BBL Bangkok",
  kasikorn: "Baht Kasikorn",
  krungthai: "KT Krungthai",
  scb: "Siam Bank SCB",
} as const;
type FixedBahtSource = keyof typeof BAHT_SOURCES;

const pendingPartnerInputs = new Map<
  string,
  { orderId: string; chatId: number; adminId: number; messageId?: number; expiresAt: number }
>();

function escapeTelegramHtml(value: string): string {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function pendingKey(chatId: number, adminId: number): string {
  return `${chatId}:${adminId}`;
}

function sourceLabel(source: string | null, sourceName: string | null): string | null {
  if (source === "other") return sourceName?.trim() || null;
  return source ? BAHT_SOURCES[source as FixedBahtSource] ?? sourceName ?? source : null;
}

function sourceKeyboard(orderId: string) {
  return {
    inline_keyboard: [
      [
        { text: "1️⃣ BBL Bangkok", callback_data: `payment_source:bbl_bangkok:${orderId}` },
        { text: "2️⃣ Baht Kasikorn", callback_data: `payment_source:kasikorn:${orderId}` },
      ],
      [
        { text: "3️⃣ KT Krungthai", callback_data: `payment_source:krungthai:${orderId}` },
        { text: "4️⃣ Siam Bank SCB", callback_data: `payment_source:scb:${orderId}` },
      ],
      [{ text: "5️⃣ Đối tác khác", callback_data: `payment_source:other:${orderId}` }],
      [{ text: "❌ Hủy", callback_data: `cancel_payment:${orderId}` }],
    ],
  };
}

function finalSourceKeyboard(orderId: string) {
  return {
    inline_keyboard: [
      [{ text: "✅ Xác nhận lần cuối", callback_data: `payment_source_confirm:${orderId}` }],
      [{ text: "❌ Hủy", callback_data: `cancel_payment:${orderId}` }],
    ],
  };
}

function buildSourceConfirmationText(
  order: typeof ordersTable.$inferSelect,
  sourceName: string,
): string {
  return [
    `💳 <b>XÁC NHẬN NGUỒN BAHT</b>`,
    ``,
    `📋 <b>Mã lệnh:</b> <code>${escapeTelegramHtml(order.orderId)}</code>`,
    `💰 <b>Số tiền:</b> <code>${parseFloat(order.amountThb).toLocaleString("th-TH", { maximumFractionDigits: 2 })}</code> THB`,
    `👤 <b>Tài khoản nhận:</b> ${escapeTelegramHtml(order.accountName)}`,
    `🔢 <b>Số TK:</b> <code>${escapeTelegramHtml(order.accountNumber)}</code>`,
    ``,
    `🏦 <b>Nguồn Baht:</b> ${escapeTelegramHtml(sourceName)}`,
    ``,
    `<i>Kiểm tra lại nguồn tiền trước khi xác nhận lần cuối.</i>`,
  ].join("\n");
}

function getAppUrl(): string {
  const domain = process.env["REPLIT_DOMAINS"]?.split(",")[0]
    || process.env["REPLIT_DEV_DOMAIN"]
    || "";
  return domain ? `https://${domain}` : "https://anderspay.replit.app";
}

function getChromeUrl(): string {
  return `${getAppUrl()}/open.html`;
}

async function replyToUser(
  chatId: number | string,
  text: string,
  extra?: Record<string, unknown>,
) {
  if (!BOT_TOKEN) return;
  await fetch(`${API()}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML", ...extra }),
  }).catch(() => {});
}

// Reply keyboard that asks Telegram to share the user's verified phone.
// Telegram fills in the phone server-side from the user's account, so the
// number cannot be spoofed by the user. The keyboard auto-hides after use.
const SHARE_PHONE_KEYBOARD = {
  reply_markup: {
    keyboard: [[{ text: "📱 Chia sẻ số Telegram của tôi", request_contact: true }]],
    one_time_keyboard: true,
    resize_keyboard: true,
  },
};

const REMOVE_KEYBOARD = { reply_markup: { remove_keyboard: true } };

async function promptForContact(chatId: number | string, firstName: string) {
  await replyToUser(
    chatId,
    `👋 Xin chào <b>${firstName}</b>!\n\n` +
      `🔐 Để liên kết Telegram với tài khoản <b>AndersPay+</b>, ` +
      `hãy bấm nút <b>"📱 Chia sẻ số Telegram của tôi"</b> bên dưới.\n\n` +
      `⚠️ <b>Quan trọng:</b> Số Telegram này phải <b>trùng khớp</b> với số bạn dùng ` +
      `để đăng ký AndersPay+. Nếu khác số, bạn sẽ không đăng ký được.\n\n` +
      `🌐 Mở app: ${getChromeUrl()}`,
    SHARE_PHONE_KEYBOARD,
  );
}

function normalizePhone(raw: string): string {
  let cleaned = raw.replace(/[\s\-()]/g, "");
  if (!cleaned.startsWith("+")) cleaned = `+${cleaned}`;
  // Strip accidental leading zero after + (e.g. +0812... → invalid)
  cleaned = cleaned.replace(/^\+0+(\d)/, "+$1");
  return cleaned;
}

// POST /telegram/webhook — receives updates from Telegram
router.post("/telegram/webhook", async (req, res) => {
  res.sendStatus(200); // Always ack immediately

  const update = req.body as TelegramUpdate;
  // Wrap the entire post-ack handler in try/catch so a thrown error
  // (DB hiccup, malformed callback_data, Telegram API failure, etc.)
  // doesn't silently swallow the update — without this, Telegram
  // callbacks like payment_confirm:* would appear to do nothing in
  // production with no trace of why. We log structured context so
  // we can correlate a stuck order with the failing callback.
  try {
    await handleUpdate(update, req.log);
  } catch (err) {
    req.log.error(
      {
        err,
        cbData: update.callback_query?.data,
        cbId: update.callback_query?.id,
        cbFrom: update.callback_query?.from?.id,
        msgText: update.message?.text?.slice(0, 80),
      },
      "[telegram] webhook handler crashed",
    );
  }
});

async function handleUpdate(update: TelegramUpdate, log: { info: (...a: unknown[]) => void }) {
  log.info(
    {
      kind: update.callback_query ? "callback_query" : update.message ? "message" : "unknown",
      cbData: update.callback_query?.data,
      cbId: update.callback_query?.id,
    },
    "[telegram] webhook update received",
  );

  // Handle messages from users
  const msg = update.message;
  if (msg) {
    const chatId = msg.chat.id;
    const firstName = msg.from?.first_name ?? "bạn";

    // ── Verified contact share (the only accepted way to link) ─────────
    // When the user taps the "Share my Telegram phone" reply-keyboard
    // button, Telegram fills in `contact.phone_number` server-side from
    // the account's verified SIM and sets `contact.user_id` to the
    // sender's id. We require `contact.user_id === from.id` so that a
    // forwarded vCard for someone else's number cannot be used to link
    // a stranger's phone to this chat.
    const contact = msg.contact;
    if (contact && contact.phone_number) {
      if (!msg.from?.id || contact.user_id !== msg.from.id) {
        await replyToUser(
          chatId,
          `❌ <b>Không hợp lệ.</b>\n\n` +
            `Bạn vừa chia sẻ danh bạ của người khác. ` +
            `Hãy bấm đúng nút <b>"📱 Chia sẻ số Telegram của tôi"</b> bên dưới ` +
            `để chia sẻ chính số Telegram của bạn.`,
          SHARE_PHONE_KEYBOARD,
        );
        return;
      }

      const phone = normalizePhone(contact.phone_number);

      // Has this Telegram chat been linked to a different phone before?
      // Tell the user so the change isn't silent.
      const [prevByChat] = await db
        .select()
        .from(telegramLinksTable)
        .where(eq(telegramLinksTable.chatId, String(chatId)))
        .limit(1);
      const isRelink = !!prevByChat;
      const changedPhone = isRelink && prevByChat.phone !== phone;

      await db
        .insert(telegramLinksTable)
        .values({ chatId: String(chatId), phone })
        .onConflictDoUpdate({
          target: telegramLinksTable.chatId,
          set: { phone },
        });

      const baseMsg = changedPhone
        ? `🔄 <b>Đã cập nhật số liên kết.</b>\n\n` +
          `📱 Số cũ: <code>${prevByChat.phone}</code>\n` +
          `📱 Số mới: <code>${phone}</code> ✅ (Telegram xác minh)\n\n`
        : isRelink
          ? `🔄 <b>Số điện thoại đã được liên kết!</b>\n\n` +
            `📱 Số: <code>${phone}</code> ✅ (Telegram xác minh)\n\n`
          : `✅ <b>Liên kết thành công!</b>\n\n` +
            `📱 Số: <code>${phone}</code> ✅ (Telegram xác minh)\n` +
            `👤 Xin chào <b>${firstName}</b>!\n\n`;

      await replyToUser(
        chatId,
        baseMsg +
          `<b>Bước tiếp theo:</b> Mở app AndersPay+ và đăng ký bằng <b>chính số ${phone} này</b>.\n\n` +
          `⚠️ Nếu bạn đăng ký bằng số khác, hệ thống sẽ <b>từ chối</b> ` +
          `vì số đăng ký phải trùng với số Telegram đã xác minh.\n\n` +
          `🌐 <b>Mở app bằng Chrome:</b>\n${getChromeUrl()}\n\n` +
          `⏱ OTP có hiệu lực <b>15 phút</b>.`,
        REMOVE_KEYBOARD,
      );
      return;
    }

    // ── Text commands ──────────────────────────────────────────────────
    const text = (msg.text ?? "").trim();
    if (!text) return;

    // "Đối tác khác" requires a free-form partner name before the final
    // payment confirmation. Keep this state scoped to the Telegram admin
    // chat/user and expire it so an old reply cannot attach to a new order.
    const adminId = msg.from?.id;
    const pendingPartner = adminId
      ? pendingPartnerInputs.get(pendingKey(chatId, adminId))
      : undefined;
    if (pendingPartner) {
      if (pendingPartner.expiresAt < Date.now()) {
        pendingPartnerInputs.delete(pendingKey(chatId, adminId!));
        await replyToUser(chatId, "⌛ Yêu cầu đã hết hạn. Hãy nhấn lại nút xác nhận thanh toán.");
        return;
      }
      if (text === "/cancel") {
        pendingPartnerInputs.delete(pendingKey(chatId, adminId!));
        await replyToUser(chatId, "❌ Đã hủy nhập tên đối tác.");
        return;
      }
      if (text.length < 2 || text.length > 80) {
        await replyToUser(chatId, "⚠️ Tên đối tác phải dài từ 2 đến 80 ký tự. Gõ lại hoặc gõ /cancel để hủy.");
        return;
      }

      const [order] = await db
        .select()
        .from(ordersTable)
        .where(eq(ordersTable.id, pendingPartner.orderId))
        .limit(1);
      pendingPartnerInputs.delete(pendingKey(chatId, adminId!));
      if (!order || order.status === "completed" || order.status === "refunded") {
        await replyToUser(chatId, "ℹ️ Lệnh này không còn chờ xác nhận.");
        return;
      }

      const partnerName = text.trim();
      const [updated] = await db
        .update(ordersTable)
        .set({
          bahtSource: "other",
          bahtSourceName: partnerName,
          updatedAt: new Date(),
        })
        .where(and(eq(ordersTable.id, order.id), inArray(ordersTable.status, ["pending", "paid"])))
        .returning();
      if (!updated) {
        await replyToUser(chatId, "ℹ️ Lệnh đã được xử lý trước đó.");
        return;
      }

      await replyToUser(
        chatId,
        buildSourceConfirmationText(updated, partnerName),
        { reply_markup: finalSourceKeyboard(order.id) },
      );
      return;
    }

    // /id — reply with this chat's ID (useful for setting up group chat IDs)
    if (text === "/id" || text.startsWith("/id@")) {
      await replyToUser(chatId,
        `🆔 <b>Chat ID:</b> <code>${chatId}</code>\n\n` +
        `Loại: ${msg.chat.type ?? "unknown"}\n` +
        (msg.chat.title ? `Tên nhóm: <b>${msg.chat.title}</b>\n` : "") +
        `\nDùng ID này để cấu hình nhóm nhận thông báo.`
      );
      return;
    }

    if (text === "/start" || text.startsWith("/otp")) {
      await promptForContact(chatId, firstName);
      return;
    }

    // Anything else (including a typed phone number) → refuse and show
    // the share-contact button. We DO NOT trust typed phone numbers any
    // more: only the Telegram-verified contact share can create a link.
    const looksLikePhone = /\+?\d[\d\s\-()]{6,}/.test(text);
    if (looksLikePhone) {
      await replyToUser(
        chatId,
        `🔒 <b>Vì lý do bảo mật, không chấp nhận số gõ tay.</b>\n\n` +
          `Hãy bấm nút <b>"📱 Chia sẻ số Telegram của tôi"</b> bên dưới ` +
          `để Telegram tự xác minh số của bạn.\n\n` +
          `⚠️ Số Telegram phải <b>trùng khớp</b> với số bạn dùng đăng ký AndersPay+.`,
        SHARE_PHONE_KEYBOARD,
      );
      return;
    }

    // Fallback — help message with the share button
    await replyToUser(
      chatId,
      `ℹ️ <b>AndersPay+ Bot</b>\n\n` +
        `Để liên kết tài khoản, bấm nút <b>"📱 Chia sẻ số Telegram của tôi"</b> bên dưới.\n\n` +
        `Lệnh khác:\n` +
        `• /start — Hướng dẫn đăng ký\n` +
        `• /id — Lấy chat ID`,
      SHARE_PHONE_KEYBOARD,
    );
    return;
  }

  const cq = update.callback_query;
  if (!cq) return;

  const data = cq.data ?? "";
  const msgChatId = cq.message?.chat.id;
  const msgId = cq.message?.message_id;

  // ═══════════════════════════════════════════════════════════════
  // STAGE 1 — First click: replace buttons with a Xác nhận / Hủy row.
  // The admin sees the same message text so they can verify the order
  // before the irreversible action fires.
  // ═══════════════════════════════════════════════════════════════

  // ── confirm (deposit) — stage 1 ──────────────────────────────
  if (data.startsWith("confirm:")) {
    const orderId = data.slice("confirm:".length);
    const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, orderId)).limit(1);
    if (!order) { await answerCallbackQuery(cq.id, "❌ Không tìm thấy lệnh"); return; }
    if (order.status === "completed") { await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã hoàn thành trước đó"); return; }
    if (order.status === "refunded") {
      await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã bị từ chối — không thể xác nhận");
      if (msgChatId && msgId) await editMessageRemoveButtons(msgChatId, msgId);
      return;
    }
    await answerCallbackQuery(cq.id, "⚠️ Xác nhận hoàn thành lệnh nạp này?");
    if (msgChatId && msgId) {
      await editMessageInlineKeyboard(msgChatId, msgId, [[
        { text: "✅ Có, xác nhận hoàn thành", callback_data: `confirm_yes:${orderId}` },
        { text: "❌ Hủy",                     callback_data: `cancel_deposit:${orderId}` },
      ]]);
    }
    return;
  }

  // ── not_received (deposit) — stage 1 ─────────────────────────
  if (data.startsWith("not_received:")) {
    const orderId = data.slice("not_received:".length);
    const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, orderId)).limit(1);
    if (!order) { await answerCallbackQuery(cq.id, "❌ Không tìm thấy lệnh"); return; }
    if (order.status === "completed") { await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã hoàn thành rồi"); return; }
    await answerCallbackQuery(cq.id, "⚠️ Xác nhận ghi nhận chưa nhận USDT?");
    if (msgChatId && msgId) {
      await editMessageInlineKeyboard(msgChatId, msgId, [[
        { text: "✅ Có, chưa nhận",  callback_data: `not_received_yes:${orderId}` },
        { text: "❌ Hủy",            callback_data: `cancel_deposit:${orderId}` },
      ]]);
    }
    return;
  }

  // ── topup_reject (deposit) — stage 1 ─────────────────────────
  if (data.startsWith("topup_reject:")) {
    const orderId = data.slice("topup_reject:".length);
    const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, orderId)).limit(1);
    if (!order) { await answerCallbackQuery(cq.id, "❌ Không tìm thấy lệnh"); return; }
    if (order.status === "completed") { await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã hoàn thành — không thể từ chối"); return; }
    if (order.status === "refunded") { await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã bị từ chối trước đó"); return; }
    await answerCallbackQuery(cq.id, "⚠️ Xác nhận từ chối bill nạp này?");
    if (msgChatId && msgId) {
      await editMessageInlineKeyboard(msgChatId, msgId, [[
        { text: "✅ Có, từ chối bill", callback_data: `topup_reject_yes:${orderId}` },
        { text: "❌ Hủy",              callback_data: `cancel_deposit:${orderId}` },
      ]]);
    }
    return;
  }

  // ── payment_confirm — stage 1 ─────────────────────────────────
  if (data.startsWith("payment_confirm:")) {
    const orderId = data.slice("payment_confirm:".length);
    const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, orderId)).limit(1);
    if (!order) { await answerCallbackQuery(cq.id, "❌ Không tìm thấy lệnh"); return; }
    if (order.status === "completed") { await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã hoàn thành trước đó"); return; }
    if (order.status === "refunded") { await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã hoàn tiền — không thể xác nhận"); return; }
    await answerCallbackQuery(cq.id, "⚠️ Xác nhận đã chuyển THB cho khách?");
    if (msgChatId && msgId) {
      await editMessageInlineKeyboard(msgChatId, msgId, [[
        { text: "✅ Có, đã chuyển THB", callback_data: `payment_confirm_yes:${orderId}` },
        { text: "❌ Hủy",               callback_data: `cancel_payment:${orderId}` },
      ]]);
    }
    return;
  }

  // ── payment_refund — stage 1 ──────────────────────────────────
  if (data.startsWith("payment_refund:")) {
    const orderId = data.slice("payment_refund:".length);
    const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, orderId)).limit(1);
    if (!order) { await answerCallbackQuery(cq.id, "❌ Không tìm thấy lệnh"); return; }
    if (order.status === "completed") { await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã hoàn thành — không thể hoàn tiền"); return; }
    if (order.status === "refunded") { await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã hoàn tiền trước đó"); return; }
    await answerCallbackQuery(cq.id, "⚠️ Xác nhận hoàn tiền lệnh này?");
    if (msgChatId && msgId) {
      await editMessageInlineKeyboard(msgChatId, msgId, [[
        { text: "✅ Có, hoàn tiền", callback_data: `payment_refund_yes:${orderId}` },
        { text: "❌ Hủy",           callback_data: `cancel_payment:${orderId}` },
      ]]);
    }
    return;
  }

  // ═══════════════════════════════════════════════════════════════
  // CANCEL — restore original action buttons.
  // ═══════════════════════════════════════════════════════════════

  // cancel_deposit: orderId — restore [Xác nhận hoàn thành | Chưa nhận]
  // (photo-based bills sent by sendTelegramPhotoWithButtons only have
  //  [Xác nhận | Từ chối] but the text-based bills sent by
  //  sendTelegramMessageWithButton also use confirm/not_received, so we
  //  restore the two-button deposit row which covers both cases.)
  if (data.startsWith("cancel_deposit:")) {
    const orderId = data.slice("cancel_deposit:".length);
    await answerCallbackQuery(cq.id, "Đã hủy thao tác");
    if (msgChatId && msgId) {
      await editMessageInlineKeyboard(msgChatId, msgId, [[
        { text: "✅ Xác nhận hoàn thành", callback_data: `confirm:${orderId}` },
        { text: "❌ Chưa nhận",            callback_data: `not_received:${orderId}` },
      ]]);
    }
    return;
  }

  // cancel_payment: orderId — restore [Xác nhận đã gửi | Hoàn tiền]
  if (data.startsWith("cancel_payment:")) {
    const orderId = data.slice("cancel_payment:".length);
    if (msgChatId) pendingPartnerInputs.delete(pendingKey(msgChatId, cq.from.id));
    await db
      .update(ordersTable)
      .set({ bahtSource: null, bahtSourceName: null, updatedAt: new Date() })
      .where(and(eq(ordersTable.id, orderId), inArray(ordersTable.status, ["pending", "paid"])));
    await answerCallbackQuery(cq.id, "Đã hủy thao tác");
    if (msgChatId && msgId) {
      await editMessageInlineKeyboard(msgChatId, msgId, [[
        { text: "✅ Xác nhận đã gửi", callback_data: `payment_confirm:${orderId}` },
        { text: "💸 Hoàn tiền",       callback_data: `payment_refund:${orderId}` },
      ]]);
    }
    return;
  }

  // ═══════════════════════════════════════════════════════════════
  // STAGE 2 — Confirmed: execute the irreversible action.
  // ═══════════════════════════════════════════════════════════════

  // ── confirm_yes (deposit) — stage 2 ──────────────────────────
  if (data.startsWith("confirm_yes:")) {
    const orderId = data.slice("confirm_yes:".length);
    const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, orderId)).limit(1);
    if (!order) { await answerCallbackQuery(cq.id, "❌ Không tìm thấy lệnh"); return; }
    if (order.status === "completed") { await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã hoàn thành trước đó"); return; }
    if (order.status === "refunded") {
      await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã bị từ chối/hoàn tiền — không thể xác nhận");
      if (msgChatId && msgId) await editMessageRemoveButtons(msgChatId, msgId);
      return;
    }

    let result;
    try {
      result = await completeOrderAndCredit(orderId);
    } catch (err) {
      if (err instanceof Error && ["DEPOSIT_USER_REQUIRED", "DEPOSIT_USER_NOT_FOUND"].includes(err.message)) {
        await answerCallbackQuery(cq.id, "❌ Bill chưa liên kết tài khoản hợp lệ — cần đối soát, chưa cộng tiền.");
        return;
      }
      throw err;
    }
    if (!result) {
      await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã được xử lý trước đó");
      return;
    }
    // Dispatch before optional alerts: every completed THB payment needs
    // both the user's receipt and the configured administrator's copy.
    void notifyCompletedPaymentSlip(result.order);
    if (msgChatId && msgId) await editMessageRemoveButtons(msgChatId, msgId);
    await answerCallbackQuery(
      cq.id,
      result.credited ? "✅ Đã xác nhận & cộng USDT vào ví khách!" : "✅ Đã xác nhận hoàn thành!",
    );
    await sendTelegramMessage(
      buildCompletedMessage({
        orderId: order.orderId,
        amountUsdt: parseFloat(order.amountUsdt),
        amountThb: parseFloat(order.amountThb),
        bankName: order.bankName,
        accountNumber: order.accountNumber,
        accountName: order.accountName,
      }),
      msgChatId,
    );
    if (result.order.bankName === "" && result.order.userId) {
      const [u] = await db
        .select({
          telegramChatId: usersTable.telegramChatId,
          telegramId: usersTable.telegramId,
          notifPayment: usersTable.notifPayment,
        })
        .from(usersTable).where(eq(usersTable.id, result.order.userId)).limit(1);
      const chatId = u ? getTelegramChatId(u) : null;
      if (chatId && u.notifPayment !== false) {
          const msg = [
            `✅ <b>Nạp USDT thành công!</b>`,
            ``,
            `📋 <b>Mã lệnh:</b> <code>${result.order.orderId}</code>`,
            `💵 <b>Số USDT:</b> <code>${parseFloat(result.order.amountUsdt).toFixed(2)}</code> USDT`,
            ``,
            `Số dư ví đã được cập nhật. Mở <b>AndersPay+</b> để kiểm tra.`,
          ].join("\n");
          sendTelegramMessage(msg, chatId).catch(() => {});
      }
    }
    return;
  }

  // ── not_received_yes (deposit) — stage 2 ─────────────────────
  if (data.startsWith("not_received_yes:")) {
    const orderId = data.slice("not_received_yes:".length);
    const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, orderId)).limit(1);
    if (!order) { await answerCallbackQuery(cq.id, "❌ Không tìm thấy lệnh"); return; }
    if (order.status === "completed") { await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã hoàn thành rồi"); return; }
    if (msgChatId && msgId) await editMessageRemoveButtons(msgChatId, msgId);
    await answerCallbackQuery(cq.id, "⚠️ Đã ghi nhận chưa nhận USDT");
    const now = new Date().toLocaleString("vi-VN", { timeZone: "Asia/Bangkok" });
    await sendTelegramMessage(
      [
        `⚠️ <b>CHƯA NHẬN USDT — AndersPay+</b>`,
        ``,
        `📋 <b>Mã lệnh:</b> <code>${order.orderId}</code>`,
        `📅 <b>Thời gian:</b> ${now} (ICT)`,
        ``,
        `💵 <b>Số USDT:</b> <code>${parseFloat(order.amountUsdt).toFixed(6)}</code> USDT`,
        `💰 <b>THB tương ứng:</b> <code>${parseFloat(order.amountThb).toLocaleString("th-TH", { maximumFractionDigits: 2 })}</code> THB`,
        ``,
        `🏦 <b>Ngân hàng:</b> ${order.bankName}`,
        `🔢 <b>Số TK:</b> <code>${order.accountNumber}</code>`,
        `👤 <b>Chủ TK:</b> ${order.accountName}`,
        ``,
        `🔍 <i>Vui lòng kiểm tra ví USDT và liên hệ khách hàng.</i>`,
      ].join("\n"),
      msgChatId,
    );
    return;
  }

  // ── topup_reject_yes (deposit) — stage 2 ─────────────────────
  if (data.startsWith("topup_reject_yes:")) {
    const orderId = data.slice("topup_reject_yes:".length);
    const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, orderId)).limit(1);
    if (!order) { await answerCallbackQuery(cq.id, "❌ Không tìm thấy lệnh"); return; }
    if (order.status === "completed") { await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã hoàn thành — không thể từ chối"); return; }
    if (order.status === "refunded") { await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã bị từ chối trước đó"); return; }
    if (msgChatId && msgId) await editMessageRemoveButtons(msgChatId, msgId);
    await db
      .update(ordersTable)
      .set({ status: "refunded", updatedAt: new Date() })
      .where(eq(ordersTable.id, orderId));
    await answerCallbackQuery(cq.id, "❌ Đã từ chối — yêu cầu khách nhập lại");
    const now = new Date().toLocaleString("vi-VN", { timeZone: "Asia/Bangkok" });
    await sendTelegramMessage(
      [
        `❌ <b>TỪ CHỐI BILL NẠP USDT — AndersPay+</b>`,
        ``,
        `📋 <b>Mã lệnh:</b> <code>${order.orderId}</code>`,
        `📅 <b>Thời gian:</b> ${now} (ICT)`,
        ``,
        `💵 <b>Số khách nhập:</b> <code>${parseFloat(order.amountUsdt).toFixed(6)}</code> USDT`,
        ``,
        `📝 <b>Lý do:</b> Số USDT khách nhập KHÔNG khớp với số thực nhận trên ví (sau khi trừ phí mạng lưới).`,
        ``,
        `🔁 <i>Khách sẽ thấy thông báo trên app, yêu cầu tạo lệnh mới với số USDT đã trừ phí.</i>`,
      ].join("\n"),
      msgChatId,
    );
    return;
  }

  // ── payment_confirm_yes — stage 2 ────────────────────────────
  if (data.startsWith("payment_confirm_yes:")) {
    const orderId = data.slice("payment_confirm_yes:".length);
    const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, orderId)).limit(1);
    if (!order) { await answerCallbackQuery(cq.id, "❌ Không tìm thấy lệnh"); return; }
    if (order.status === "completed") { await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã hoàn thành trước đó"); return; }
    if (order.status === "refunded") { await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã hoàn tiền — không thể xác nhận"); return; }
    if (!msgChatId || !msgId) {
      await answerCallbackQuery(cq.id, "❌ Không xác định được tin nhắn giao dịch");
      return;
    }
    await editMessageRemoveButtons(msgChatId, msgId);
    await answerCallbackQuery(cq.id, "✅ Bước 1 xong — hãy chọn nguồn Baht");
    await replyToUser(
      msgChatId,
      [
        `🏦 <b>CHỌN NGUỒN BAHT</b>`,
        ``,
        `📋 Mã lệnh: <code>${escapeTelegramHtml(order.orderId)}</code>`,
        `💰 Số tiền: <code>${parseFloat(order.amountThb).toLocaleString("th-TH", { maximumFractionDigits: 2 })}</code> THB`,
        ``,
        `Chọn ví/ngân hàng đã dùng để chuyển tiền:`,
      ].join("\n"),
      { reply_markup: sourceKeyboard(order.id) },
    );
    return;
  }

  // ── payment_source — stage 2: choose the THB source ───────────
  if (data.startsWith("payment_source:")) {
    const [, source, orderId] = data.split(":");
    const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, orderId)).limit(1);
    if (!order) { await answerCallbackQuery(cq.id, "❌ Không tìm thấy lệnh"); return; }
    if (order.status === "completed") { await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã hoàn thành trước đó"); return; }
    if (order.status === "refunded") { await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã hoàn tiền — không thể xác nhận"); return; }
    if (!msgChatId) { await answerCallbackQuery(cq.id, "❌ Không xác định được nhóm Telegram"); return; }

    if (source === "other") {
      pendingPartnerInputs.set(pendingKey(msgChatId, cq.from.id), {
        orderId,
        chatId: msgChatId,
        adminId: cq.from.id,
        messageId: msgId,
        expiresAt: Date.now() + 10 * 60 * 1000,
      });
      await answerCallbackQuery(cq.id, "✍️ Hãy nhập tên đối tác");
      await replyToUser(
        msgChatId,
        `✍️ <b>NHẬP TÊN ĐỐI TÁC</b>\n\n` +
          `Gõ tên đối tác Baht vào tin nhắn tiếp theo (2–80 ký tự).\n` +
          `Gõ <code>/cancel</code> để hủy.`,
      );
      return;
    }

    const sourceName = BAHT_SOURCES[source as FixedBahtSource];
    if (!sourceName) { await answerCallbackQuery(cq.id, "❌ Nguồn Baht không hợp lệ"); return; }
    const [updated] = await db
      .update(ordersTable)
      .set({ bahtSource: source, bahtSourceName: sourceName, updatedAt: new Date() })
      .where(and(eq(ordersTable.id, orderId), inArray(ordersTable.status, ["pending", "paid"])))
      .returning();
    if (!updated) { await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã được xử lý trước đó"); return; }

    if (msgId) await editMessageRemoveButtons(msgChatId, msgId);
    await answerCallbackQuery(cq.id, `✅ Đã chọn ${sourceName}`);
    await replyToUser(
      msgChatId,
      buildSourceConfirmationText(updated, sourceName),
      { reply_markup: finalSourceKeyboard(orderId) },
    );
    return;
  }

  // ── payment_source_confirm — stage 3: execute payment ─────────
  if (data.startsWith("payment_source_confirm:")) {
    const orderId = data.slice("payment_source_confirm:".length);
    const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, orderId)).limit(1);
    if (!order) { await answerCallbackQuery(cq.id, "❌ Không tìm thấy lệnh"); return; }
    if (order.status === "completed") { await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã hoàn thành trước đó"); return; }
    if (order.status === "refunded") { await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã hoàn tiền — không thể xác nhận"); return; }
    const selectedSource = sourceLabel(order.bahtSource, order.bahtSourceName);
    if (!selectedSource) {
      await answerCallbackQuery(cq.id, "⚠️ Hãy chọn nguồn Baht trước");
      return;
    }
    if (msgChatId && msgId) await editMessageRemoveButtons(msgChatId, msgId);

    const [completedOrder] = await db
      .update(ordersTable)
      .set({ status: "completed", updatedAt: new Date() })
      .where(and(eq(ordersTable.id, orderId), inArray(ordersTable.status, ["pending", "paid"])))
      .returning();
    if (!completedOrder) {
      await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã được xử lý trước đó");
      return;
    }
    void notifyCompletedPaymentSlip(completedOrder);
    await answerCallbackQuery(cq.id, `✅ Đã xác nhận thanh toán từ ${selectedSource}`);
    await sendTelegramMessage(
      buildCompletedMessage({
        orderId: order.orderId,
        amountUsdt: parseFloat(order.amountUsdt),
        amountThb: parseFloat(order.amountThb),
        bankName: order.bankName,
        accountNumber: order.accountNumber,
        accountName: order.accountName,
        bahtSourceName: selectedSource,
      }),
      msgChatId,
    );
    if (completedOrder.userId) {
      const [u] = await db
        .select({
          telegramChatId: usersTable.telegramChatId,
          telegramId: usersTable.telegramId,
          notifPayment: usersTable.notifPayment,
        })
        .from(usersTable).where(eq(usersTable.id, completedOrder.userId)).limit(1);
      const chatId = u ? getTelegramChatId(u) : null;
      if (chatId && u.notifPayment !== false) {
        const customerMessage = [
          `✅ <b>Thanh toán THB thành công!</b>`,
          ``,
          `📋 <b>Mã lệnh:</b> <code>${completedOrder.orderId}</code>`,
          `💰 <b>Số tiền:</b> <code>${parseFloat(completedOrder.amountThb).toLocaleString("th-TH", { maximumFractionDigits: 2 })}</code> THB`,
          `🏦 <b>Ngân hàng:</b> ${completedOrder.bankName}`,
          `🔢 <b>Số TK:</b> <code>${completedOrder.accountNumber}</code>`,
          `👤 <b>Chủ TK:</b> ${completedOrder.accountName}`,
          ``,
          `Tiền đã được chuyển vào tài khoản ngân hàng của bạn.`,
        ].join("\n");
        sendTelegramMessage(customerMessage, chatId).catch(() => {});
      }
    }
    return;
  }

  // ── payment_refund_yes — stage 2 ──────────────────────────────
  if (data.startsWith("payment_refund_yes:")) {
    const orderId = data.slice("payment_refund_yes:".length);
    const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, orderId)).limit(1);
    if (!order) { await answerCallbackQuery(cq.id, "❌ Không tìm thấy lệnh"); return; }
    if (order.status === "completed") { await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã hoàn thành — không thể hoàn tiền"); return; }
    if (order.status === "refunded") { await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã hoàn tiền trước đó"); return; }
    let refunded;
    try {
      refunded = await refundPayment(orderId);
    } catch (err) {
      if (err instanceof Error && ["FEE_SOURCE_UNKNOWN", "PAYMENT_LEDGER_MISSING",
        "PAYMENT_USER_NOT_FOUND", "INVALID_LEDGER_AMOUNT"].includes(err.message)) {
        await answerCallbackQuery(cq.id, "❌ Thiếu dữ liệu nguồn phí/bút toán — cần đối soát. Chưa hoàn tiền.");
        return;
      }
      throw err;
    }
    if (!refunded) {
      await answerCallbackQuery(cq.id, "ℹ️ Lệnh đã được xử lý trước đó — không hoàn lần nữa");
      return;
    }
    if (msgChatId && msgId) await editMessageRemoveButtons(msgChatId, msgId);

    await answerCallbackQuery(cq.id, "💸 Đã ghi nhận hoàn tiền");
    const now = new Date().toLocaleString("vi-VN", { timeZone: "Asia/Bangkok" });
    await sendTelegramMessage(
      [
        `💸 <b>HOÀN TIỀN — AndersPay+</b>`,
        ``,
        `📋 <b>Mã lệnh:</b> <code>${order.orderId}</code>`,
        `📅 <b>Thời gian:</b> ${now} (ICT)`,
        ``,
        `💰 <b>THB hoàn:</b> <code>${parseFloat(order.amountThb).toLocaleString("th-TH", { maximumFractionDigits: 2 })}</code> THB`,
        ``,
        `🏦 <b>Ngân hàng:</b> ${order.bankName}`,
        `🔢 <b>Số TK:</b> <code>${order.accountNumber}</code>`,
        `👤 <b>Chủ TK:</b> ${order.accountName}`,
        ``,
        `📝 <b>Lý do gửi khách:</b> Sai số tài khoản và ngân hàng — khách hàng vui lòng kiểm tra lại.`,
        ``,
        `🔁 <i>Khách sẽ thấy thông báo hoàn tiền kèm lý do trên app.</i>`,
      ].join("\n"),
      msgChatId,
    );
    return;
  }
}

// Types
interface TelegramUpdate {
  message?: {
    text?: string;
    chat: { id: number; type?: string; title?: string };
    from?: { id?: number; first_name?: string };
    contact?: {
      phone_number: string;
      first_name?: string;
      last_name?: string;
      user_id?: number;
    };
  };
  callback_query?: {
    id: string;
    data?: string;
    from: { id: number; first_name: string };
    message?: {
      message_id: number;
      chat: { id: number };
    };
  };
}

export default router;
