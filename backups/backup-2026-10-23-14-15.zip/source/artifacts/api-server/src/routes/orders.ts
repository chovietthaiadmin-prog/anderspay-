import { Router } from "express";
import multer from "multer";
import { db, ordersTable, otpsTable, usersTable, transactionsTable } from "@workspace/db";
import { eq, ne, desc, and, or, inArray, isNull, lt, gt, sql } from "drizzle-orm";
import { randomUUID } from "crypto";
import { TopupBody, CreateOrderBody, RequestPayOtpBody } from "@workspace/api-zod";
import { getCurrentRate } from "./rates";
import { getTelegramChatId, sendTelegramPhoto, buildBillCaption, sendTelegramPhotoWithButtons, buildTopupCaption, buildReviewRequestCaption, sendTelegramMessage, sendTelegramMessageDetailed, sendTelegramMessageWithButton, buildNewOrderMessage, sendPromPayQrToTelegram } from "../lib/telegram";
import { sendEmail, otpEmailHtml, otpEmailText } from "../lib/mailer";
import { authenticateRequest, issueSession } from "../lib/jwt";
import { safeEqual } from "../lib/safe-equal";
import { verifyDestructiveKey } from "../lib/destructive-key";
import { completeOrderAndCredit } from "../lib/wallet-credit";
import { payFeeThb, payFeeUsdt, MIN_USDT_BALANCE, MIN_TOPUP_USDT } from "../lib/fees";
import { isAdminUser } from "../lib/admin";
import { archiveBillToOneDrive } from "../lib/bill-archive";
import { notifyCompletedPaymentSlip } from "../services/payment-slip-notification";
import { WALLET_ADDRESSES } from "../lib/deposit-wallets";
import { debitPaymentAccount, PendingPaymentError, reversePaymentRefund } from "../lib/payment-accounting";

// Per-payment THB threshold above which an OTP is required.
const PAY_OTP_THRESHOLD_THB = 1000;
const MAX_ORDER_THB = 20_000; // hard cap per order
const PAY_OTP_TTL_MS = 10 * 60 * 1000; // 10 minutes
// We share the otpsTable with auth flows but namespace payment OTPs by
// prefixing the phone column so they cannot be cross-used for login/reset.
const PAY_OTP_PREFIX = "pay:";

// In-process anti-abuse controls. These are best-effort and reset on server
// restart, but make brute-force / send-spam infeasible in practice:
//   - Send: at most 1 OTP per user per PAY_OTP_RESEND_COOLDOWN_MS.
//   - Verify: at most PAY_OTP_MAX_ATTEMPTS wrong tries per active OTP;
//     when exceeded the OTP is invalidated and a new one must be requested.
const PAY_OTP_RESEND_COOLDOWN_MS = 30 * 1000;
const PAY_OTP_MAX_ATTEMPTS = 5;
const lastSendByUser = new Map<string, number>();
const wrongAttemptsByUser = new Map<string, number>();

function generateOtpCode(): string {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function buildPayOtpMessage(otp: string, amountThb: number): string {
  return [
    `🔐 <b>AndersPay+ — Mã OTP thanh toán</b>`,
    ``,
    `Bạn đang yêu cầu thanh toán <b>${amountThb.toLocaleString("th-TH", { maximumFractionDigits: 2 })} THB</b>.`,
    ``,
    `Mã xác nhận:`,
    ``,
    `<code>  ${otp}  </code>`,
    ``,
    `⏱ Hiệu lực <b>10 phút</b>.`,
    `❌ Không chia sẻ mã này cho bất kỳ ai — kể cả nhân viên AndersPay+.`,
    `⚠️ Nếu không phải bạn yêu cầu, hãy bỏ qua tin này.`,
  ].join("\n");
}

// Bills are usually phone screenshots / camera photos / bank PDFs. Modern
// phone cameras (HEIC, high-res JPG) easily exceed 10 MB, and some users
// share the bank-app PDF export, so we accept images + PDF up to 25 MB.
const MAX_BILL_BYTES = 25 * 1024 * 1024;
const ACCEPT_BILL_MIME = /^(image\/|application\/pdf$)/i;

const rawUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_BILL_BYTES },
  fileFilter: (_req, file, cb) => {
    if (ACCEPT_BILL_MIME.test(file.mimetype)) cb(null, true);
    else cb(new Error("UNSUPPORTED_FILE_TYPE"));
  },
});

// Wrap multer.single so that multer's own errors (file too large, wrong
// mimetype, malformed multipart, etc.) come back to the client as a
// proper JSON {message, code} body instead of Express's default HTML 500.
// Without this, the frontend just sees `!res.ok` and shows a generic
// "Có lỗi xảy ra, thử lại" toast — users have no idea what went wrong.
function uploadSingle(field: string) {
  const mw = rawUpload.single(field);
  return (req: Parameters<typeof mw>[0], res: Parameters<typeof mw>[1], next: Parameters<typeof mw>[2]) => {
    mw(req, res, (err: unknown) => {
      if (!err) return next();
      if (err instanceof multer.MulterError) {
        if (err.code === "LIMIT_FILE_SIZE") {
          res.status(413).json({
            message: `Ảnh quá lớn. Tối đa ${Math.floor(MAX_BILL_BYTES / 1024 / 1024)} MB.`,
            code: "FILE_TOO_LARGE",
            maxBytes: MAX_BILL_BYTES,
          });
          return;
        }
        res.status(400).json({ message: `Upload error: ${err.code}`, code: err.code });
        return;
      }
      const msg = err instanceof Error ? err.message : String(err);
      if (msg === "UNSUPPORTED_FILE_TYPE") {
        res.status(415).json({
          message: "Chỉ chấp nhận ảnh (JPG/PNG/HEIC/WebP) hoặc PDF.",
          code: "UNSUPPORTED_FILE_TYPE",
        });
        return;
      }
      next(err);
    });
  };
}

const upload = { single: uploadSingle };

const router = Router();

// Our wallet address — customers send USDT here
const WALLET_ADDRESS = "TRX9mK3vQpL8xN2wYjC7bFdHsAeUo4VmRk";

// Receiving USDT deposit addresses per network. Each network has a
// distinct on-chain address and format (TRC20 = T..., BEP20/ERC20 = 0x...),
// so a topup order must store the address that matches the network the
// customer actually selected — otherwise the bill shows the wrong chain.
// Kept in sync with the client copy at
// artifacts/localpay/src/lib/wallet-config.ts.
// Resolve the deposit address for a (possibly untrusted) network string.
// Falls back to the TRC20 address when the network is missing/unknown.
function walletAddressForNetwork(network: string | undefined): string {
  if (network === "TRC20" || network === "BEP20" || network === "ERC20") {
    return WALLET_ADDRESSES[network];
  }
  return WALLET_ADDRESSES.TRC20;
}

const SUPPORTED_NETWORKS = ["TRC20", "BEP20", "ERC20"] as const;
type SupportedNetwork = (typeof SUPPORTED_NETWORKS)[number];

function normalizeNetwork(network: string | undefined): SupportedNetwork | null {
  const normalized = typeof network === "string" ? network.trim().toUpperCase() : "";
  return (SUPPORTED_NETWORKS as readonly string[]).includes(normalized)
    ? (normalized as SupportedNetwork)
    : null;
}

function generateOrderId(): string {
  const date = new Date();
  const dateStr = date.toISOString().slice(0, 10).replace(/-/g, "");
  const suffix = Math.random().toString(36).toUpperCase().slice(2, 6);
  return `AP-${dateStr}-${suffix}`;
}

// POST /orders/request-pay-otp — sends a 6-digit OTP to the authenticated
// user's linked Telegram chat. Required by POST /orders before the server
// will accept any payment whose THB amount is above PAY_OTP_THRESHOLD_THB.
router.post("/orders/request-pay-otp", async (req, res) => {
  const parsed = RequestPayOtpBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Validation error", code: "VALIDATION_ERROR" });
    return;
  }
  const { amountThb } = parsed.data;

  const jwtPayload = await authenticateRequest(req);
  if (!jwtPayload) {
    res.status(401).json({ message: "unauthorized", code: "UNAUTHORIZED" });
    return;
  }

  if (amountThb <= PAY_OTP_THRESHOLD_THB) {
    res.status(400).json({
      message: `OTP chỉ bắt buộc khi số tiền vượt ${PAY_OTP_THRESHOLD_THB} THB`,
      code: "OTP_NOT_REQUIRED",
    });
    return;
  }
  if (amountThb > MAX_ORDER_THB) {
    res.status(400).json({
      message: `Hiện tại chỉ hỗ trợ thanh toán tối đa ${MAX_ORDER_THB.toLocaleString("th-TH")} THB mỗi lệnh.`,
      code: "AMOUNT_EXCEEDS_LIMIT",
    });
    return;
  }

  const [user] = await db
    .select({
      phone: usersTable.phone,
      telegramChatId: usersTable.telegramChatId,
      telegramId: usersTable.telegramId,
      email: usersTable.email,
      emailVerified: usersTable.emailVerified,
    })
    .from(usersTable)
    .where(eq(usersTable.id, jwtPayload.userId))
    .limit(1);

  if (!user) {
    res.status(401).json({ message: "unauthorized", code: "UNAUTHORIZED" });
    return;
  }
  // Email-only accounts (synthetic em:<uuid> phone) have no Telegram
  // link; their payment OTP is delivered to the verified email instead.
  const telegramChatId = getTelegramChatId(user);
  const useEmailChannel = !telegramChatId && user.emailVerified && !!user.email;
  if (!telegramChatId && !useEmailChannel) {
    res.status(412).json({
      message: "Tài khoản chưa liên kết Telegram. Hãy nhắn /otp <số điện thoại> cho @AndersPayPlus_bot trước.",
      code: "TELEGRAM_NOT_LINKED",
    });
    return;
  }

  // Resend cooldown — refuse rapid re-requests to limit Telegram spam and
  // make brute force much harder (attacker can't churn OTPs faster than this).
  const now = Date.now();
  const lastSent = lastSendByUser.get(jwtPayload.userId);
  if (lastSent && now - lastSent < PAY_OTP_RESEND_COOLDOWN_MS) {
    const retryAfterMs = PAY_OTP_RESEND_COOLDOWN_MS - (now - lastSent);
    res.status(429).json({
      message: `Vui lòng đợi ${Math.ceil(retryAfterMs / 1000)}s trước khi gửi lại OTP`,
      code: "TOO_MANY_REQUESTS",
    });
    return;
  }

  const taggedPhone = `${PAY_OTP_PREFIX}${user.phone}`;
  // Invalidate any previous payment OTP + reset wrong-attempt counter.
  await db.delete(otpsTable).where(eq(otpsTable.phone, taggedPhone));
  wrongAttemptsByUser.delete(jwtPayload.userId);

  const otp = generateOtpCode();
  const expiresAt = new Date(now + PAY_OTP_TTL_MS);
  await db.insert(otpsTable).values({
    id: randomUUID(),
    phone: taggedPhone,
    code: otp,
    expiresAt,
  });

  if (useEmailChannel) {
    try {
      await sendEmail({
        to: user.email!,
        subject: "Your AndersPay+ Verification Code",
        html: otpEmailHtml(otp),
        text: otpEmailText(otp),
      });
    } catch {
      await db.delete(otpsTable).where(eq(otpsTable.phone, taggedPhone));
      res.status(502).json({
        message: "Không gửi được OTP qua email. Vui lòng thử lại sau.",
        code: "EMAIL_SEND_FAILED",
      });
      return;
    }
    lastSendByUser.set(jwtPayload.userId, now);
    res.json({ ok: true, channel: "email", expiresAt: expiresAt.toISOString() });
    return;
  }

  // Block on Telegram delivery so we can fail loudly if the bot or chat is
  // misconfigured — better than telling the user "code sent" when nothing
  // ever arrives.
  const delivered = await sendTelegramMessageDetailed(
    buildPayOtpMessage(otp, amountThb),
    telegramChatId!,
  );
  if (!delivered.ok) {
    // Roll back the stored OTP so a half-failed request leaves no usable code.
    await db.delete(otpsTable).where(eq(otpsTable.phone, taggedPhone));
    const desc = delivered.reason === "telegram_error" ? delivered.description ?? "" : "";
    const lower = desc.toLowerCase();
    let code = "TELEGRAM_SEND_FAILED";
    let message = "Không gửi được OTP qua Telegram. Vui lòng thử lại sau.";
    if (delivered.reason === "no_token" || delivered.reason === "no_chat") {
      code = "TELEGRAM_NOT_CONFIGURED";
      message = "Hệ thống chưa cấu hình bot Telegram. Vui lòng liên hệ admin.";
    } else if (
      lower.includes("unauthorized") ||
      (delivered.reason === "telegram_error" && delivered.errorCode === 401)
    ) {
      // Token bot bị BotFather thu hồi hoặc cấu hình sai — phía người dùng
      // không thể tự xử lý được, phải báo cho admin.
      code = "TELEGRAM_BOT_UNAUTHORIZED";
      message = "Bot Telegram của hệ thống tạm thời không hoạt động (token không hợp lệ). Vui lòng liên hệ admin để cấp lại.";
    } else if (lower.includes("bot was blocked") || lower.includes("forbidden")) {
      code = "TELEGRAM_BLOCKED";
      message = "Bạn đã chặn bot @AndersPayPlus_bot. Vui lòng bỏ chặn rồi thử lại.";
    } else if (lower.includes("chat not found")) {
      code = "TELEGRAM_CHAT_NOT_FOUND";
      message = `Chat Telegram không tồn tại. Vui lòng nhắn /otp ${user.phone} cho @AndersPayPlus_bot để liên kết lại.`;
    }
    req.log.warn(
      {
        userId: jwtPayload.userId,
        reason: delivered.reason,
        errorCode: delivered.reason === "telegram_error" ? delivered.errorCode : undefined,
        description: desc || undefined,
      },
      "[pay-otp] telegram delivery failed",
    );
    res.status(502).json({ code, message, description: desc || undefined });
    return;
  }

  lastSendByUser.set(jwtPayload.userId, now);
  res.json({
    ok: true,
    threshold: PAY_OTP_THRESHOLD_THB,
    expiresInSeconds: Math.floor(PAY_OTP_TTL_MS / 1000),
  });
});

// POST /orders — customer sends USDT, receives THB into a Thai bank account
router.post("/orders", async (req, res) => {
  const parsed = CreateOrderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Validation error", code: "VALIDATION_ERROR" });
    return;
  }

  const { amountUsdt, bankName, accountNumber, accountName, otp, qrPayload } = parsed.data;

  // Derive userId from a verified JWT — never trust client-supplied userId directly
  const jwtPayload = await authenticateRequest(req);
  const userId = jwtPayload?.userId ?? null;

  // E2E smoke tests post unauthenticated payloads to verify the
  // routing/validation surface. Skip the new auth/UID/no-deposit
  // gates ONLY when a valid X-Test-Secret is presented (same pattern
  // used later for skipping Telegram fan-out). Production traffic
  // never satisfies this — `TEST_API_SECRET` is unset / mismatched.
  const _testSecret = process.env.TEST_API_SECRET;
  const _providedTestSecret = req.headers["x-test-secret"] as string | undefined;
  const _isTestRequest = Boolean(
    _testSecret && _providedTestSecret && safeEqual(_providedTestSecret, _testSecret),
  );

  // Hard requirement (per product rule): only AUTHENTICATED users with
  // a claimed UID and at least one prior THB deposit can place a payment
  // order. Guests and not-yet-onboarded accounts are blocked at the
  // edge so we never persist an order that can't be tied back to a
  // funded customer wallet.
  if (!jwtPayload && !_isTestRequest) {
    res.status(401).json({
      message: "Vui lòng đăng nhập để tạo lệnh thanh toán.",
      code: "AUTH_REQUIRED",
    });
    return;
  }

  // Admins are read-only on payment flows: they observe aggregate user
  // activity but cannot create payment orders themselves.
  if (jwtPayload) {
    const [me] = await db
      .select({
        phone: usersTable.phone,
        isAdmin: usersTable.isAdmin,
        uid: usersTable.uid,
        thbBalance: usersTable.thbBalance,
      })
      .from(usersTable)
      .where(eq(usersTable.id, jwtPayload.userId))
      .limit(1);
    if (me && isAdminUser(me)) {
      res.status(403).json({
        message: "Admin accounts cannot create payment orders.",
        code: "ADMIN_FORBIDDEN",
      });
      return;
    }

    // No-UID guard. The UID is the user's permanent public identifier
    // — every order must be attributable to one. Surfaced on the
    // client as a popup that links to Settings → "AndersPay UID".
    if (!me || !me.uid || !/^098\d{6}$/.test(me.uid)) {
      res.status(403).json({
        message: "Bạn cần tạo UID AndersPay trước khi tạo lệnh thanh toán.",
        code: "UID_REQUIRED",
      });
      return;
    }

    // No-deposit guard. A zero THB wallet means the customer has
    // never funded their account; we block here with a distinct code
    // so the client can route them to the topup page instead of just
    // saying "insufficient balance".
    if (parseFloat(me.thbBalance) <= 0) {
      res.status(402).json({
        message: "Bạn chưa nạp tiền. Vui lòng nạp THB trước khi tạo lệnh thanh toán.",
        code: "NO_DEPOSIT",
      });
      return;
    }

    // One-pending-Baht-order rule: a user may not have more than one
    // outstanding THB *payment* order at a time. The orders table is
    // shared with `/topup` (USDT deposits) which inserts rows with an
    // empty `bankName` — see the topup handler below. Payment orders
    // ALWAYS carry a non-empty `bankName` (validated by
    // `CreateOrderBody`), so `bankName != ''` cleanly excludes
    // pending topups from this check. The constraint is therefore
    // scoped to Baht payment orders only and does NOT affect
    // deposits (`/topup`), withdrawals/conversions
    // (`/wallet/convert`), the USDT ledger, or admin flows. The
    // check is server-side and authoritative — a tampered client
    // cannot defeat it.
    const [existingPending] = await db
      .select({ orderId: ordersTable.orderId, id: ordersTable.id })
      .from(ordersTable)
      .where(
        and(
          eq(ordersTable.userId, jwtPayload.userId),
          inArray(ordersTable.status, ["pending", "paid"]),
          ne(ordersTable.bankName, ""),
        ),
      )
      .limit(1);
    if (existingPending) {
      res.status(409).json({
        message:
          "You already have a pending Baht payment order. Please complete or cancel the existing order before creating a new one.",
        code: "PENDING_ORDER_EXISTS",
        existingOrderId: existingPending.id,
      });
      return;
    }
  }

  // rate = THB per 1 USDT (admin-set daily rate)
  const { thbPerUsdt: rate } = await getCurrentRate();
  const amountThb = parseFloat((amountUsdt * rate).toFixed(2));

  // Hard cap — reject orders over the per-order maximum regardless of balance.
  if (amountThb > MAX_ORDER_THB) {
    res.status(400).json({
      message: `Hiện tại chỉ hỗ trợ thanh toán tối đa ${MAX_ORDER_THB.toLocaleString("th-TH")} THB mỗi lệnh.`,
      code: "AMOUNT_EXCEEDS_LIMIT",
    });
    return;
  }

  // Enforce OTP for amounts above the threshold. We require a verified JWT
  // so we can identify the user whose Telegram OTP we must consume.
  if (amountThb > PAY_OTP_THRESHOLD_THB) {
    if (!jwtPayload) {
      res.status(401).json({
        message: `Cần đăng nhập để thanh toán trên ${PAY_OTP_THRESHOLD_THB} THB`,
        code: "AUTH_REQUIRED",
      });
      return;
    }
    if (!otp) {
      // 422, NOT 401: the user is properly authenticated; they just
      // haven't supplied the payment OTP yet. A 401 here would trip the
      // client's single-device logout interceptor and kick the user out
      // of the app mid-payment instead of prompting for the code.
      res.status(422).json({
        message: `Cần OTP cho thanh toán trên ${PAY_OTP_THRESHOLD_THB} THB`,
        code: "OTP_REQUIRED",
      });
      return;
    }

    const [authedUser] = await db
      .select({ phone: usersTable.phone })
      .from(usersTable)
      .where(eq(usersTable.id, jwtPayload.userId))
      .limit(1);

    if (!authedUser) {
      res.status(401).json({ message: "unauthorized", code: "UNAUTHORIZED" });
      return;
    }

    const taggedPhone = `${PAY_OTP_PREFIX}${authedUser.phone}`;
    const now = new Date();
    // Atomic consume: only one valid (unused, unexpired, matching) OTP wins.
    const [consumed] = await db
      .update(otpsTable)
      .set({ used: true })
      .where(
        and(
          eq(otpsTable.phone, taggedPhone),
          eq(otpsTable.code, otp),
          eq(otpsTable.used, false),
          gt(otpsTable.expiresAt, now),
        ),
      )
      .returning();

    if (!consumed) {
      // Track wrong attempts; after PAY_OTP_MAX_ATTEMPTS, invalidate any
      // outstanding OTP so the attacker must request a fresh one (which is
      // throttled by PAY_OTP_RESEND_COOLDOWN_MS).
      const attempts = (wrongAttemptsByUser.get(jwtPayload.userId) ?? 0) + 1;
      wrongAttemptsByUser.set(jwtPayload.userId, attempts);
      if (attempts >= PAY_OTP_MAX_ATTEMPTS) {
        await db.delete(otpsTable).where(eq(otpsTable.phone, taggedPhone));
        wrongAttemptsByUser.delete(jwtPayload.userId);
        res.status(429).json({
          message: "Sai OTP quá nhiều lần. Vui lòng yêu cầu mã mới.",
          code: "OTP_LOCKED",
        });
        return;
      }
      // 422, NOT 401: a wrong/expired OTP is a validation failure, not a
      // session-auth failure. Returning 401 here would trip the client's
      // single-device logout interceptor and eject the user from the app
      // instead of surfacing "wrong OTP" so they can retry.
      res.status(422).json({
        message: "OTP không hợp lệ hoặc đã hết hạn",
        code: "OTP_INVALID",
      });
      return;
    }
    // Success — clear attempt counter.
    wrongAttemptsByUser.delete(jwtPayload.userId);
  }

  // Compute service fee for this THB transfer.
  // Fee schedule: tiered bill fee (15/20/25/30 THB by amount) + 0.15%
  // on-chain fee. See artifacts/api-server/src/lib/fees.ts.
  // Charged in USDT (converted at current rate), debited from user balance.
  const feeThb = payFeeThb(amountThb);
  const feeUsdt = payFeeUsdt(amountThb, rate);
  const feeUsdtStr = feeUsdt.toFixed(6);

  // For authenticated users we atomically debit the order cost from
  // the user's TWO wallets in a single transaction:
  //   • PRINCIPAL `amountThb` is taken from `thb_balance` (the THB
  //     spending wallet — funded by previous topups/conversions).
  //   • SERVICE FEE `feeUsdt` is taken from `usdt_balance`, with the
  //     `referral_reward_balance` consumed FIRST so promo credit is
  //     spent before the user's own USDT. A post-debit minimum-balance
  //     guard keeps `usdt_balance ≥ MIN_USDT_BALANCE` (the "gas
  //     reserve" so users can always afford future service fees and
  //     can never drain the wallet to zero).
  // Then we (2) insert the order row and (3) write two ledger rows —
  // one `payment` recording the THB principal and one `payment_fee`
  // recording the USDT fee — so the user's history shows both legs of
  // the cost.
  // The whole flow runs inside a DB transaction so any failure rolls
  // back the debits.
  // Guests (unauthenticated) keep the legacy no-debit flow — they have
  // no account to debit; the order exists purely as an admin notification.
  const id = randomUUID();
  const orderId = generateOrderId();
  const amountThbStr = amountThb.toFixed(2);
  const amountUsdtStr = amountUsdt.toFixed(6);

  let order: typeof ordersTable.$inferSelect;
  try {
    order = await db.transaction(async (tx) => {
      let referralFeeUsdtStr = "0.000000";
      if (userId) {
        referralFeeUsdtStr = (await debitPaymentAccount(tx, userId, amountThbStr, feeUsdtStr)).referral;
      }

      const [inserted] = await tx
        .insert(ordersTable)
        .values({
          id,
          orderId,
          amountThb: String(amountThb),
          amountUsdt: String(amountUsdt),
          exchangeRate: String(rate),
          bankName,
          accountNumber,
          accountName,
          walletAddress: WALLET_ADDRESS,
          status: "pending",
          userId,
        })
        .returning();

      if (userId) {
        // Two ledger rows so the user's history shows the THB
        // principal and the USDT fee separately. Both reference the
        // same `refOrderId` so they can be reversed together on
        // refund. The `payment` row carries amountThb (principal,
        // amountUsdt=0); the `payment_fee` row carries amountUsdt
        // (fee, amountThb=feeThb for context only).
        const ledger: (typeof transactionsTable.$inferInsert)[] = [
          {
            id: randomUUID(),
            userId,
            type: "payment",
            amountUsdt: "0",
            amountThb: amountThbStr,
            rate: String(rate),
            refOrderId: inserted.id,
          },
        ];
        if (feeUsdt > 0) {
          ledger.push({
            id: randomUUID(),
            userId,
            type: "payment_fee",
            amountUsdt: feeUsdtStr,
            referralAmountUsdt: referralFeeUsdtStr,
            amountThb: feeThb.toFixed(2),
            rate: String(rate),
            refOrderId: inserted.id,
          });
        }
        await tx.insert(transactionsTable).values(ledger);
      }

      // Suppress unused-var warning while keeping the constant
      // available for any future totals math. amountUsdtStr is the
      // USDT-equivalent of the THB principal at the order's rate
      // (computed but no longer debited from usdt_balance).
      void amountUsdtStr;

      return inserted;
    });
  } catch (err) {
    if (err instanceof PendingPaymentError) {
      res.status(409).json({
        message: "You already have an outstanding Baht payment order.",
        code: "PENDING_ORDER_EXISTS", existingOrderId: err.existingOrderId,
      });
      return;
    }
    if (err instanceof Error && err.message === "INSUFFICIENT_THB_BALANCE") {
      res.status(402).json({
        message: `Số dư THB không đủ. Lệnh này cần ${amountThb.toLocaleString("th-TH", { maximumFractionDigits: 2 })} THB. Vui lòng nạp thêm THB hoặc giảm số tiền lệnh.`,
        code: "INSUFFICIENT_THB_BALANCE",
        amountThb,
      });
      return;
    }
    if (err instanceof Error && err.message === "INSUFFICIENT_FEE_BALANCE") {
      res.status(402).json({
        message: `Số dư USDT không đủ để trả phí dịch vụ (${feeUsdt.toFixed(2)} USDT). Ví phải còn tối thiểu ${MIN_USDT_BALANCE} USDT sau khi trừ phí. Vui lòng nạp thêm USDT.`,
        code: "INSUFFICIENT_FEE_BALANCE",
        feeUsdt,
        feeThb,
        minBalance: MIN_USDT_BALANCE,
      });
      return;
    }
    throw err;
  }

  res.status(201).json(formatOrder(order));

  // Skip Telegram notifications entirely for orders created by e2e smoke
  // tests so test runs don't spam the admin payment group. Tests opt in by
  // sending a valid X-Test-Secret header (matched against TEST_API_SECRET).
  const testSecret = process.env.TEST_API_SECRET;
  const providedTestSecret = req.headers["x-test-secret"] as string | undefined;
  const isTestRequest = Boolean(
    testSecret && providedTestSecret && safeEqual(providedTestSecret, testSecret),
  );
  if (isTestRequest) {
    return;
  }

  // Fire-and-forget Telegram notification → PAYMENT group.
  // We send EXACTLY ONE message per order to avoid duplicate
  // notifications in the admin chat:
  //   • If the customer scanned a PromPay QR, we send the QR image
  //     message (caption already contains orderId, amount, bank,
  //     account number and account name — it is a strict superset of
  //     the plain text bill message and lets admin scan-to-pay
  //     without re-keying anything). The same confirm/refund buttons
  //     are attached to the QR message via `payment_confirm:` /
  //     `payment_refund:` callback_data on `order.id`, so admin
  //     actions behave identically.
  //   • Otherwise (manual bank-details entry, no QR), we send the
  //     plain text bill message with the same buttons.
  // Resolve customer identity (UID / legal name / nickname) for the
  // admin-facing Telegram caption so the operator can see WHO placed
  // the order at a glance. Guests (no `userId`) get a "Khách vãng lai"
  // banner via `buildCustomerLines(undefined)`.
  let customer: import("../lib/telegram").CustomerSummary | undefined;
  if (userId) {
    const [u] = await db
      .select({ uid: usersTable.uid, name: usersTable.name, nickname: usersTable.nickname })
      .from(usersTable)
      .where(eq(usersTable.id, userId))
      .limit(1);
    if (u) customer = { uid: u.uid, name: u.name, nickname: u.nickname };
  }

  if (qrPayload && qrPayload.length > 0) {
    sendPromPayQrToTelegram({
      qrPayload,
      id: order.id,
      orderId: order.orderId,
      amountThb,
      bankName,
      accountNumber,
      accountName,
      customer,
    }).catch(() => {});
  } else {
    sendTelegramMessageWithButton(
      buildNewOrderMessage({
        orderId: order.orderId,
        amountUsdt,
        amountThb,
        rate,
        bankName,
        accountNumber,
        accountName,
        customer,
      }),
      order.id,
      "payment"
    ).catch(() => {});
  }
});

// Conditional upload middleware: only invoke multer for multipart requests
// (legacy/cached clients). For modern JSON-with-base64 requests we skip
// multer entirely. This is required because Replit's edge proxy returns
// 403 Forbidden for any multipart/form-data POST before it reaches us, so
// the JSON path is now the only one that actually works in production.
function maybeMultipartBill(req: Parameters<ReturnType<typeof uploadSingle>>[0], res: Parameters<ReturnType<typeof uploadSingle>>[1], next: Parameters<ReturnType<typeof uploadSingle>>[2]) {
  const ct = String(req.headers["content-type"] || "");
  if (ct.startsWith("multipart/")) return upload.single("bill")(req, res, next);
  next();
}

router.post("/topup", maybeMultipartBill, async (req, res) => {
  const jwtPayload = await authenticateRequest(req);
  if (!jwtPayload) {
    res.status(401).json({ message: "Cần đăng nhập trước khi nạp USDT.", code: "UNAUTHORIZED" });
    return;
  }
  const userId = jwtPayload.userId;
  // Two body shapes are accepted:
  //   1) JSON: { amountUsdt, network, billBase64, billMime, billName? }
  //      (the only shape that works in production — multipart is blocked
  //      at the Replit edge with 403 before reaching us)
  //   2) multipart/form-data with a `bill` file field (legacy fallback)
  const rawBody = {
    ...req.body,
    amountUsdt: req.body?.amountUsdt !== undefined ? Number(req.body.amountUsdt) : undefined,
  };
  const parsed = TopupBody.safeParse(rawBody);
  if (!parsed.success) {
    res.status(400).json({ message: "Validation error", code: "VALIDATION_ERROR", details: parsed.error.flatten().fieldErrors });
    return;
  }
  const { amountUsdt } = parsed.data;
  const network = normalizeNetwork(parsed.data.network);
  if (!network) {
    res.status(400).json({
      message: "Unsupported USDT network. Use TRC20, BEP20, or ERC20.",
      code: "UNSUPPORTED_NETWORK",
    });
    return;
  }

  // Defense-in-depth: enforce the minimum even if a stale client bypasses
  // the OpenAPI-generated zod schema.
  if (amountUsdt < MIN_TOPUP_USDT) {
    res.status(400).json({
      message: `Số tiền nạp tối thiểu ${MIN_TOPUP_USDT} USDT.`,
      code: "AMOUNT_TOO_SMALL",
      minUsdt: MIN_TOPUP_USDT,
    });
    return;
  }

  // Resolve the bill bytes from whichever body shape the client used.
  let billBuffer: Buffer | null = null;
  let billMime = "image/jpeg";
  let billName = "bill.jpg";
  if (req.file) {
    billBuffer = req.file.buffer;
    billMime = req.file.mimetype || billMime;
    billName = req.file.originalname || billName;
  } else if (typeof req.body?.billBase64 === "string" && req.body.billBase64.length > 0) {
    const b64 = req.body.billBase64.replace(/^data:[^;]+;base64,/, "");
    try {
      billBuffer = Buffer.from(b64, "base64");
    } catch {
      billBuffer = null;
    }
    if (typeof req.body.billMime === "string" && ACCEPT_BILL_MIME.test(req.body.billMime)) {
      billMime = req.body.billMime;
    }
    if (typeof req.body.billName === "string" && req.body.billName.length > 0) {
      billName = req.body.billName;
    }
    if (billBuffer && billBuffer.byteLength > MAX_BILL_BYTES) {
      res.status(413).json({
        message: `Ảnh quá lớn. Tối đa ${Math.floor(MAX_BILL_BYTES / 1024 / 1024)} MB.`,
        code: "FILE_TOO_LARGE",
        maxBytes: MAX_BILL_BYTES,
      });
      return;
    }
    if (billBuffer && !ACCEPT_BILL_MIME.test(billMime)) {
      res.status(415).json({
        message: "Chỉ chấp nhận ảnh (JPG/PNG/HEIC/WebP) hoặc PDF.",
        code: "UNSUPPORTED_FILE_TYPE",
      });
      return;
    }
  }
  if (!billBuffer || billBuffer.byteLength === 0) {
    res.status(400).json({ message: "Bill image required", code: "NO_FILE" });
    return;
  }

  const { thbPerUsdt: rate } = await getCurrentRate();
  const amountThb = parseFloat((amountUsdt * rate).toFixed(2));
  const id = randomUUID();
  const orderId = generateOrderId();

  const [order] = await db
    .insert(ordersTable)
    .values({
      id,
      orderId,
      amountThb: String(amountThb),
      amountUsdt: String(amountUsdt),
      exchangeRate: String(rate),
      bankName: "",
      accountNumber: "",
      accountName: "",
      walletAddress: walletAddressForNetwork(network),
      status: "pending",
      userId,
      network,
    })
    .returning();

  res.status(201).json(formatOrder(order));

  void archiveBillToOneDrive(
    order.orderId,
    billBuffer,
    billMime,
    billName,
    "topup",
  );

  // Resolve customer identity (UID / legal name / nickname) for the
  // admin-facing topup notification — same shape as the THB-payment
  // builders. Guests fall back to the "Khách vãng lai" banner.
  let topupCustomer: import("../lib/telegram").CustomerSummary | undefined;
  if (userId) {
    const [u] = await db
      .select({ uid: usersTable.uid, name: usersTable.name, nickname: usersTable.nickname })
      .from(usersTable)
      .where(eq(usersTable.id, userId))
      .limit(1);
    if (u) topupCustomer = { uid: u.uid, name: u.name, nickname: u.nickname };
  }

  // Send photo + caption + confirm/not-received buttons to Telegram
  sendTelegramPhotoWithButtons(
    billBuffer,
    buildTopupCaption({ orderId: order.orderId, amountUsdt, amountThb, rate, network, customer: topupCustomer }),
    billName,
    order.id
  ).catch(() => {});
});

// GET /orders/recent
// - Admin (JWT or X-Admin-Secret) → ALL orders (system-wide totals)
// - Authenticated non-admin → only their own orders, with member-balance math
// - Unauthenticated → 403
router.get("/orders/recent", async (req, res) => {
  let isAdmin = false;
  let authedUserId: string | null = null;

  const adminSecret = process.env.ADMIN_API_SECRET;
  const providedSecret = req.headers["x-admin-secret"] as string | undefined;
  if (adminSecret && providedSecret && safeEqual(providedSecret, adminSecret)) {
    isAdmin = true;
  }

  const payload = await authenticateRequest(req);
  if (payload) {
    authedUserId = payload.userId;
    if (!isAdmin) {
      const [user] = await db
        .select({ phone: usersTable.phone, isAdmin: usersTable.isAdmin })
        .from(usersTable)
        .where(eq(usersTable.id, payload.userId))
        .limit(1);
      if (user && isAdminUser(user)) {
        isAdmin = true;
      }
    }
  }

  if (!isAdmin && !authedUserId) {
    res.status(403).json({ message: "Forbidden", code: "FORBIDDEN" });
    return;
  }

  // Admin sees all; member sees only their own orders
  const orders = isAdmin
    ? await db
        .select()
        .from(ordersTable)
        .orderBy(desc(ordersTable.createdAt))
        .limit(20)
    : await db
        .select()
        .from(ordersTable)
        .where(eq(ordersTable.userId, authedUserId!))
        .orderBy(desc(ordersTable.createdAt))
        .limit(20);

  // Distinguish deposit vs payment orders by bankName presence.
  // - Deposit (USDT bill upload): bankName === ""
  // - Payment (THB withdrawal request): bankName populated
  const isDeposit = (o: typeof ordersTable.$inferSelect) => o.bankName === "";
  const isPayment = (o: typeof ordersTable.$inferSelect) => !isDeposit(o);

  const completedOrders = orders.filter((o) => o.status === "completed");
  const activeOrders = orders.filter((o) => o.status === "pending" || o.status === "paid");

  let totalThb: number;
  let totalUsdt: number;

  if (isAdmin) {
    // Admin: legacy system-wide aggregates
    totalThb = completedOrders.reduce((sum, o) => sum + parseFloat(o.amountThb), 0);
    totalUsdt = activeOrders.reduce((sum, o) => sum + parseFloat(o.amountUsdt), 0);
  } else {
    // Member balance:
    //   THB available = THB credited from completed deposits
    //                 - THB locked/spent on (pending|paid|completed) payments
    //   Refunded payments don't deduct.
    const thbIn = completedOrders
      .filter(isDeposit)
      .reduce((s, o) => s + parseFloat(o.amountThb), 0);
    const thbOut = orders
      .filter(isPayment)
      .filter((o) => o.status === "pending" || o.status === "paid" || o.status === "completed")
      .reduce((s, o) => s + parseFloat(o.amountThb), 0);
    totalThb = Math.max(0, thbIn - thbOut);

    // USDT lifetime deposited (completed deposits only)
    totalUsdt = completedOrders
      .filter(isDeposit)
      .reduce((s, o) => s + parseFloat(o.amountUsdt), 0);
  }

  const summary = {
    total: orders.length,
    pending: orders.filter((o) => o.status === "pending").length,
    paid: orders.filter((o) => o.status === "paid").length,
    completed: completedOrders.length,
    totalThb,
    totalUsdt,
    totalUsdtAllTime: orders.reduce((sum, o) => sum + parseFloat(o.amountUsdt), 0),
    orders: orders.map(formatOrder),
  };

  res.json(summary);
});

// GET /orders/:orderId
router.get("/orders/:orderId", async (req, res) => {
  const { orderId } = req.params;

  const [order] = await db
    .select()
    .from(ordersTable)
    .where(eq(ordersTable.id, orderId))
    .limit(1);

  if (!order) {
    res.status(404).json({ message: "Order not found", code: "NOT_FOUND" });
    return;
  }

  res.json(formatOrder(order));
});

// POST /orders/:orderId/upload-proof — customer uploads bill image
router.post("/orders/:orderId/upload-proof", upload.single("bill"), async (req, res) => {
  const { orderId } = req.params;

  if (!req.file) {
    res.status(400).json({ message: "No file uploaded", code: "NO_FILE" });
    return;
  }

  const [order] = await db
    .select()
    .from(ordersTable)
    .where(eq(ordersTable.id, String(orderId)))
    .limit(1);

  if (!order) {
    res.status(404).json({ message: "Order not found", code: "NOT_FOUND" });
    return;
  }

  // Ownership check: verify the caller's JWT matches the order creator
  const jwtPayload = await authenticateRequest(req);

  if (!order.userId) {
    // Order was created without authentication — reject proof upload
    res.status(403).json({ message: "Forbidden: order has no linked user", code: "FORBIDDEN" });
    return;
  }

  if (!jwtPayload || jwtPayload.userId !== order.userId) {
    res.status(403).json({ message: "Forbidden: you are not the order creator", code: "FORBIDDEN" });
    return;
  }

  res.json({ ok: true });

  void archiveBillToOneDrive(
    order.orderId,
    req.file.buffer,
    req.file.mimetype || "image/jpeg",
    req.file.originalname || "bill.jpg",
    "payment",
  );

  // Resolve customer identity for the bill caption. Ownership has
  // already been verified above, so `order.userId` is guaranteed
  // to be set and to match the caller.
  let billCustomer: import("../lib/telegram").CustomerSummary | undefined;
  {
    const [u] = await db
      .select({ uid: usersTable.uid, name: usersTable.name, nickname: usersTable.nickname })
      .from(usersTable)
      .where(eq(usersTable.id, order.userId))
      .limit(1);
    if (u) billCustomer = { uid: u.uid, name: u.name, nickname: u.nickname };
  }

  // Send photo to Telegram — fire and forget
  sendTelegramPhoto(
    req.file.buffer,
    buildBillCaption({
      orderId: order.orderId,
      amountUsdt: parseFloat(order.amountUsdt),
      amountThb: parseFloat(order.amountThb),
      customer: billCustomer,
    }),
    req.file.originalname || "bill.jpg"
  ).catch(() => {});
});

// DELETE /orders/:orderId — removes an order.
// Accepted credentials (either is sufficient):
//   - X-Test-Secret matching TEST_API_SECRET (used by e2e cleanup), or
//   - X-Destructive-Key matching DESTRUCTIVE_OP_KEY (operator key for
//     real admin-initiated destructive actions on production data).
// Both checks fail closed when their env var isn't configured.
router.delete("/orders/:orderId", async (req, res) => {
  const testSecret = process.env.TEST_API_SECRET;
  const providedTest = req.headers["x-test-secret"] as string | undefined;
  const testOk = Boolean(
    testSecret && providedTest && safeEqual(providedTest, testSecret),
  );
  if (!testOk && !verifyDestructiveKey(req)) {
    res.status(403).json({ message: "Forbidden", code: "FORBIDDEN" });
    return;
  }

  const { orderId } = req.params;

  const result = await db
    .delete(ordersTable)
    .where(eq(ordersTable.id, orderId))
    .returning({ id: ordersTable.id });

  if (result.length === 0) {
    res.status(404).json({ message: "Order not found", code: "NOT_FOUND" });
    return;
  }

  res.status(204).end();
});

// POST /test/mint-token — test-only endpoint to mint JWTs for e2e tests.
// Requires the X-Test-Secret header to match TEST_API_SECRET env var.
router.post("/test/mint-token", async (req, res) => {
  const secret = process.env.TEST_API_SECRET;
  const provided = req.headers["x-test-secret"] as string | undefined;
  if (!secret || !provided || !safeEqual(provided, secret)) {
    res.status(403).json({ message: "Forbidden", code: "FORBIDDEN" });
    return;
  }
  const { userId } = req.body as { userId?: string };
  if (!userId) {
    res.status(400).json({ message: "userId required", code: "VALIDATION_ERROR" });
    return;
  }
  const token = await issueSession(userId);
  res.json({ token });
});

// POST /orders/:orderId/confirm — admin-only (admin JWT or X-Admin-Secret)
router.post("/orders/:orderId/confirm", async (req, res) => {
  let authorized = false;

  const adminSecret = process.env.ADMIN_API_SECRET;
  const providedSecret = req.headers["x-admin-secret"] as string | undefined;
  if (adminSecret && providedSecret && safeEqual(providedSecret, adminSecret)) {
    authorized = true;
  }

  if (!authorized) {
    const payload = await authenticateRequest(req);
    if (payload) {
      const [user] = await db
        .select({ phone: usersTable.phone, isAdmin: usersTable.isAdmin })
        .from(usersTable)
        .where(eq(usersTable.id, payload.userId))
        .limit(1);
      if (user && isAdminUser(user)) {
        authorized = true;
      }
    }
  }

  if (!authorized) {
    res.status(403).json({ message: "Forbidden", code: "FORBIDDEN" });
    return;
  }

  const { orderId } = req.params;

  const [existing] = await db
    .select()
    .from(ordersTable)
    .where(eq(ordersTable.id, orderId))
    .limit(1);

  if (!existing) {
    res.status(404).json({ message: "Order not found", code: "NOT_FOUND" });
    return;
  }

  // Reject re-confirmation of already-finalized orders (idempotency guard).
  // This prevents flipping a completed order back to "paid" and re-crediting on retry.
  if (existing.status === "completed" || existing.status === "refunded") {
    res.status(409).json({
      message: "Order already finalized",
      code: "ORDER_FINALIZED",
      status: existing.status,
    });
    return;
  }

  // Conditionally mark as paid (only from non-final states); the UX shows a brief
  // "paid" state, then the helper atomically transitions to completed + credits.
  // completeOrderAndCredit's WHERE-guarded UPDATE makes the credit step idempotent
  // even if both the timeout and a Telegram callback fire.
  const [updated] = await db
    .update(ordersTable)
    .set({ status: "paid", updatedAt: new Date() })
    .where(
      and(
        eq(ordersTable.id, orderId),
        ne(ordersTable.status, "completed"),
        ne(ordersTable.status, "refunded"),
      ),
    )
    .returning();

  if (!updated) {
    res.status(409).json({ message: "Order already finalized", code: "ORDER_FINALIZED" });
    return;
  }

  setTimeout(() => {
    completeOrderAndCredit(orderId)
      .then((result) => {
        if (result) void notifyCompletedPaymentSlip(result.order);
      })
      .catch(() => {});
  }, 8000);

  res.json(formatOrder(updated));
});

function formatOrder(order: typeof ordersTable.$inferSelect) {
  return {
    id: order.id,
    orderId: order.orderId,
    amountThb: parseFloat(order.amountThb),
    amountUsdt: parseFloat(order.amountUsdt),
    exchangeRate: parseFloat(order.exchangeRate),
    bankName: order.bankName,
    accountNumber: order.accountNumber,
    accountName: order.accountName,
    walletAddress: order.walletAddress,
      network: order.network,
      txHash: order.txHash,
      confirmations: order.confirmations,
      confirmedAt: order.confirmedAt ? order.confirmedAt.toISOString() : null,
    status: order.status,
    bahtSource: order.bahtSource,
    bahtSourceName: order.bahtSourceName,
    createdAt: order.createdAt.toISOString(),
    updatedAt: order.updatedAt.toISOString(),
    reviewRequestedAt: order.reviewRequestedAt ? order.reviewRequestedAt.toISOString() : null,
  };
}

// POST /orders/:orderId/request-review — customer asks the bot to re-notify
// admins about a stuck pending/paid order. Allowed only:
//  - caller owns the order (JWT match)
//  - order is still pending or paid
//  - >= 30 minutes have passed since createdAt
//  - >= 30 minutes have passed since the previous reviewRequestedAt (if any)
const REVIEW_COOLDOWN_MS = 30 * 60 * 1000;
router.post("/orders/:orderId/request-review", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ message: "unauthorized", code: "UNAUTHORIZED" });
    return;
  }

  const { orderId } = req.params;
  const [order] = await db
    .select()
    .from(ordersTable)
    .where(eq(ordersTable.id, orderId))
    .limit(1);

  if (!order) {
    res.status(404).json({ message: "Order not found", code: "NOT_FOUND" });
    return;
  }
  if (!order.userId || order.userId !== payload.userId) {
    res.status(403).json({ message: "Forbidden", code: "FORBIDDEN" });
    return;
  }
  if (order.status !== "pending" && order.status !== "paid") {
    res.status(409).json({ message: "Order is not pending", code: "INVALID_STATE" });
    return;
  }

  const now = Date.now();
  const sinceCreated = now - order.createdAt.getTime();
  if (sinceCreated < REVIEW_COOLDOWN_MS) {
    const retryAfterMs = REVIEW_COOLDOWN_MS - sinceCreated;
    res.status(429).json({ message: "Too soon", code: "TOO_SOON", retryAfterMs });
    return;
  }
  if (order.reviewRequestedAt) {
    const sinceLast = now - order.reviewRequestedAt.getTime();
    if (sinceLast < REVIEW_COOLDOWN_MS) {
      const retryAfterMs = REVIEW_COOLDOWN_MS - sinceLast;
      res.status(429).json({ message: "Cooldown", code: "COOLDOWN", retryAfterMs });
      return;
    }
  }

  // Atomic guard: only one concurrent request can win the cooldown.
  // The WHERE clause re-checks ownership, status, age and the prior
  // reviewRequestedAt at write time. If another request beat us to it,
  // rowCount === 0 and we return 429 without re-notifying Telegram.
  const cutoff = new Date(now - REVIEW_COOLDOWN_MS);
  const updatedRows = await db
    .update(ordersTable)
    .set({ reviewRequestedAt: new Date(now), updatedAt: new Date(now) })
    .where(
      and(
        eq(ordersTable.id, orderId),
        eq(ordersTable.userId, payload.userId),
        inArray(ordersTable.status, ["pending", "paid"]),
        lt(ordersTable.createdAt, cutoff),
        or(isNull(ordersTable.reviewRequestedAt), lt(ordersTable.reviewRequestedAt, cutoff)),
      ),
    )
    .returning();

  if (updatedRows.length === 0) {
    res.status(429).json({ message: "Cooldown", code: "COOLDOWN" });
    return;
  }
  const updated = updatedRows[0];

  res.json(formatOrder(updated));

  // Re-notify the right Telegram group with action buttons. Include
  // the customer's UID/name/nickname in the caption so admin can see
  // which user is escalating without opening the admin UI. We always
  // have a `userId` here (request-review requires auth + ownership).
  const isDeposit = order.bankName === "";
  const target: "deposit" | "payment" = isDeposit ? "deposit" : "payment";
  let customer: import("../lib/telegram").CustomerSummary | undefined;
  if (order.userId) {
    const [u] = await db
      .select({ uid: usersTable.uid, name: usersTable.name, nickname: usersTable.nickname })
      .from(usersTable)
      .where(eq(usersTable.id, order.userId))
      .limit(1);
    if (u) customer = { uid: u.uid, name: u.name, nickname: u.nickname };
  }
  sendTelegramMessageWithButton(
    buildReviewRequestCaption({
      orderId: order.orderId,
      kind: isDeposit ? "deposit" : "payment",
      amountUsdt: parseFloat(order.amountUsdt),
      amountThb: parseFloat(order.amountThb),
      bankName: order.bankName,
      accountNumber: order.accountNumber,
      accountName: order.accountName,
      createdAtIso: order.createdAt.toISOString(),
      customer,
    }),
    order.id,
    target
  ).catch(() => {});
});

// POST /admin/backfill-user — assign a userId to legacy orders missing it.
// Gated by X-Admin-Secret. Body: { userId: string, orderIds: string[] }
router.post("/admin/backfill-user", async (req, res) => {
  const adminSecret = process.env.ADMIN_API_SECRET;
  const providedSecret = req.headers["x-admin-secret"] as string | undefined;
  if (!adminSecret || !providedSecret || !safeEqual(providedSecret, adminSecret)) {
    res.status(403).json({ message: "Forbidden", code: "FORBIDDEN" });
    return;
  }

  const userId = typeof req.body?.userId === "string" ? req.body.userId : "";
  const orderIds = Array.isArray(req.body?.orderIds) ? req.body.orderIds.filter((x: unknown): x is string => typeof x === "string") : [];
  if (!userId || orderIds.length === 0) {
    res.status(400).json({ message: "userId and orderIds[] required" });
    return;
  }

  const [user] = await db.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.id, userId)).limit(1);
  if (!user) {
    res.status(404).json({ message: "user not found" });
    return;
  }

  const updated: string[] = [];
  for (const orderId of orderIds) {
    const result = await db
      .update(ordersTable)
      .set({ userId, updatedAt: new Date() })
      .where(eq(ordersTable.orderId, orderId))
      .returning({ orderId: ordersTable.orderId });
    if (result.length > 0) updated.push(result[0].orderId);
  }

  res.json({ updated, count: updated.length });
});

// POST /admin/balance-adjust — operator-only retroactive correction of a
// user's wallet balances, with a matching ledger row. Designed for
// one-off backfills (e.g. orders created before the debit-on-create
// rule shipped, or manual reconciliation after a bug). Atomic: balance
// update and ledger insert succeed or fail together.
//
// Auth: requires X-Destructive-Key matching DESTRUCTIVE_OP_KEY (the
// dedicated operator key — same gate used by /orders DELETE). Fails
// closed if the env var isn't set.
//
// Body:
//   {
//     userId: string,            // required
//     deltaThb?: number,         // signed (negative = debit), default 0
//     deltaUsdt?: number,        // signed (negative = debit), default 0
//     refOrderId?: string,       // orders.id of the related order, if any
//     txType: TransactionType,   // ledger row type (e.g. "payment",
//                                // "payment_refund", "payment_fee")
//     amountThb?: number,        // ledger row amount_thb (defaults to
//                                // |deltaThb|)
//     amountUsdt?: number,       // ledger row amount_usdt (defaults to
//                                // |deltaUsdt|)
//     rate?: number,             // ledger row rate (defaults to 0)
//   }
//
// Idempotency: caller is responsible. The endpoint refuses to apply
// the same (userId, refOrderId, txType) combination twice — if a
// ledger row already exists with all three matching, returns 409
// ALREADY_APPLIED so retries are safe.
router.post("/admin/balance-adjust", async (req, res) => {
  if (!verifyDestructiveKey(req)) {
    res.status(403).json({ message: "Forbidden", code: "FORBIDDEN" });
    return;
  }

  const body = req.body as {
    userId?: unknown;
    deltaThb?: unknown;
    deltaUsdt?: unknown;
    refOrderId?: unknown;
    txType?: unknown;
    amountThb?: unknown;
    amountUsdt?: unknown;
    rate?: unknown;
  };

  const userId = typeof body.userId === "string" ? body.userId : "";
  const txType = typeof body.txType === "string" ? body.txType : "";
  const deltaThb = typeof body.deltaThb === "number" && Number.isFinite(body.deltaThb) ? body.deltaThb : 0;
  const deltaUsdt = typeof body.deltaUsdt === "number" && Number.isFinite(body.deltaUsdt) ? body.deltaUsdt : 0;
  const refOrderId = typeof body.refOrderId === "string" && body.refOrderId.length > 0 ? body.refOrderId : null;
  const ledgerThb = typeof body.amountThb === "number" && Number.isFinite(body.amountThb) ? body.amountThb : Math.abs(deltaThb);
  const ledgerUsdt = typeof body.amountUsdt === "number" && Number.isFinite(body.amountUsdt) ? body.amountUsdt : Math.abs(deltaUsdt);
  const rate = typeof body.rate === "number" && Number.isFinite(body.rate) ? body.rate : 0;

  if (!userId || !txType) {
    res.status(400).json({ message: "userId and txType required", code: "VALIDATION_ERROR" });
    return;
  }
  if (deltaThb === 0 && deltaUsdt === 0) {
    res.status(400).json({ message: "deltaThb or deltaUsdt must be non-zero", code: "VALIDATION_ERROR" });
    return;
  }

  try {
    const result = await db.transaction(async (tx) => {
      // Idempotency guard: if a ledger row already exists for this
      // (user, ref_order, type) tuple, refuse to apply again.
      if (refOrderId) {
        const dup = await tx
          .select({ id: transactionsTable.id })
          .from(transactionsTable)
          .where(
            and(
              eq(transactionsTable.userId, userId),
              eq(transactionsTable.refOrderId, refOrderId),
              eq(transactionsTable.type, txType as never),
            ),
          )
          .limit(1);
        if (dup.length > 0) {
          throw new Error("ALREADY_APPLIED");
        }
      }

      const deltaThbStr = deltaThb.toFixed(2);
      const deltaUsdtStr = deltaUsdt.toFixed(6);

      // Atomic balance update with non-negative guards. THB and USDT
      // can each be debited independently; the WHERE clause enforces
      // that no balance ends up below zero.
      const updated = await tx
        .update(usersTable)
        .set({
          thbBalance: sql`${usersTable.thbBalance} + ${deltaThbStr}::numeric`,
          usdtBalance: sql`${usersTable.usdtBalance} + ${deltaUsdtStr}::numeric`,
        })
        .where(
          and(
            eq(usersTable.id, userId),
            sql`${usersTable.thbBalance} + ${deltaThbStr}::numeric >= 0`,
            sql`${usersTable.usdtBalance} + ${deltaUsdtStr}::numeric >= 0`,
          ),
        )
        .returning({
          thbBalance: usersTable.thbBalance,
          usdtBalance: usersTable.usdtBalance,
        });

      if (updated.length === 0) {
        throw new Error("INSUFFICIENT_BALANCE_OR_USER_NOT_FOUND");
      }

      const [ledger] = await tx
        .insert(transactionsTable)
        .values({
          id: randomUUID(),
          userId,
          type: txType as never,
          amountThb: ledgerThb.toFixed(2),
          amountUsdt: ledgerUsdt.toFixed(6),
          rate: rate.toFixed(6),
          refOrderId,
        })
        .returning();

      return { balances: updated[0], ledgerId: ledger.id };
    });

    res.json({
      ok: true,
      thbBalance: result.balances.thbBalance,
      usdtBalance: result.balances.usdtBalance,
      ledgerId: result.ledgerId,
    });
  } catch (err) {
    if (err instanceof Error && err.message === "ALREADY_APPLIED") {
      res.status(409).json({ message: "Adjustment already applied for this order+type", code: "ALREADY_APPLIED" });
      return;
    }
    if (err instanceof Error && err.message === "INSUFFICIENT_BALANCE_OR_USER_NOT_FOUND") {
      res.status(409).json({ message: "User not found or balance would go negative", code: "INSUFFICIENT_BALANCE" });
      return;
    }
    throw err;
  }
});

// POST /admin/orders/:orderId/force-complete
// Emergency tool: reverse an accidental "refund" click for a payment order
// that was already settled. Only transitions status refunded → completed and
// undoes the balance credit that the refund issued. Protected by
// X-Admin-Secret (same as other admin ops).
router.post("/admin/orders/:orderId/force-complete", async (req, res) => {
  const adminSecret = process.env.ADMIN_API_SECRET;
  const provided = req.headers["x-admin-secret"] as string | undefined;
  if (!adminSecret || !provided || !safeEqual(provided, adminSecret)) {
    res.status(403).json({ message: "Forbidden" });
    return;
  }

  const orderId = req.params.orderId as string;
  let completedOrder: typeof ordersTable.$inferSelect;
  try {
    completedOrder = await reversePaymentRefund(orderId);
  } catch (err) {
    const code = err instanceof Error ? err.message : "";
    if (["ORDER_NOT_FOUND", "ORDER_NOT_REFUNDED", "REFUND_LEDGER_MISSING",
      "REFUND_BALANCE_SPENT", "INVALID_LEDGER_AMOUNT"].includes(code)) {
      res.status(code === "ORDER_NOT_FOUND" ? 404 : 409).json({
        code, message: code === "REFUND_BALANCE_SPENT"
          ? "Cannot reverse refund: refunded funds are no longer available in their original wallets."
          : `Cannot reverse refund: ${code}`,
      });
      return;
    }
    throw err;
  }

  // 3. Send the completed THB payment receipt to the customer's private bot chat.
  void notifyCompletedPaymentSlip(completedOrder);

  res.json({ ok: true, orderId: completedOrder.orderId, newStatus: "completed" });
});

export default router;
