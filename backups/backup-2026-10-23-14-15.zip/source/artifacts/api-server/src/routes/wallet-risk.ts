import { Router } from "express";
import { CheckWalletRiskResponse } from "@workspace/api-zod";
import { z } from "zod";
import { getWalletOverview, hiddenWalletOverview, unavailableWallet } from "./wallet-overview.js";
import { isOfficialDepositAddress } from "../lib/deposit-wallets";
import { authenticateRequest } from "../lib/jwt";

const router = Router();
const inputSchema = z.object({
  network: z.enum(["bsc", "ethereum", "tron"]),
  address: z.string().trim().min(34).max(42),
});
type Network = z.infer<typeof inputSchema>["network"];
type Severity = "caution" | "high" | "critical";

const chains: Record<Network, string> = { bsc: "56", ethereum: "1", tron: "tron" };
const signals: Record<string, Severity> = {
  blacklist_doubt: "caution",
  mixer: "caution",
  fake_kyc: "caution",
  malicious_mining_activities: "caution",
  darkweb_transactions: "high",
  honeypot_related_address: "high",
  fake_token: "high",
  fake_standard_interface: "high",
  reinit: "high",
  gas_abuse: "high",
  number_of_malicious_contracts_created: "high",
  blackmail_activities: "high",
  cybercrime: "high",
  financial_crime: "high",
  money_laundering: "high",
  phishing_activities: "critical",
  stealing_attack: "critical",
  sanctioned: "critical",
};

type Report = {
  network: Network;
  address: string;
  checkedAt: string;
  goplus: {
    provider: "GoPlus Security";
    status: "checked" | "unavailable";
    checkedAt: string | null;
    level: "no_flags" | Severity | null;
    score: number | null;
    findings: { code: string; severity: Severity }[];
  };
  chainabuse: {
    provider: "Chainabuse";
    status: "checked" | "unavailable" | "not_configured";
    checkedAt: string | null;
    reportCount: number | null;
    reports: {
      id: string;
      category: string;
      createdAt: string;
      checked: boolean;
      trusted: boolean;
    }[];
  };
  comparison: "consistent" | "disagreement" | "incomplete";
};

type GoPlusResult = Report["goplus"];
type ChainabuseResult = Report["chainabuse"];
type WalletResult = ReturnType<typeof unavailableWallet>;
type Cache<T> = Map<string, { expires: number; value: T }>;
const goPlusCache: Cache<GoPlusResult> = new Map();
const chainabuseCache: Cache<ChainabuseResult> = new Map();
const walletCache: Cache<WalletResult> = new Map();
const requests = new Map<string, { until: number; count: number }>();
const CACHE_TTL = 5 * 60_000;

function getCached<T>(cache: Cache<T>, key: string): T | undefined {
  const entry = cache.get(key);
  if (!entry) return undefined;
  if (entry.expires <= Date.now()) {
    cache.delete(key);
    return undefined;
  }
  return entry.value;
}

function setCached<T>(cache: Cache<T>, key: string, value: T) {
  if (cache.size >= 500) cache.delete(cache.keys().next().value!);
  cache.set(key, { expires: Date.now() + CACHE_TTL, value });
}

async function checkGoPlus(network: Network, address: string): Promise<GoPlusResult> {
  const url = `https://api.gopluslabs.io/api/v1/address_security/${encodeURIComponent(address)}?chain_id=${chains[network]}`;
  const response = await fetch(url, {
    headers: { Accept: "application/json" },
    signal: AbortSignal.timeout(12_000),
  });
  if (!response.ok) throw new Error(`GoPlus HTTP ${response.status}`);
  const body = await response.json() as {
    code?: number;
    result?: Record<string, unknown>;
  };
  if (body.code !== 1 || !body.result || Array.isArray(body.result)
    || !Object.keys(signals).some((code) => body.result?.[code] === "0" || body.result?.[code] === "1")) {
    throw new Error("GoPlus returned no usable result");
  }
  const findings = Object.entries(signals)
    .filter(([code]) => body.result?.[code] === "1"
      || (code === "number_of_malicious_contracts_created"
        && Number(body.result?.[code]) > 0))
    .map(([code, severity]) => ({ code, severity }));
  const level = findings.some((item) => item.severity === "critical")
    ? "critical"
    : findings.some((item) => item.severity === "high")
      ? "high"
      : findings.length > 0 ? "caution" : "no_flags";
  // This source-specific heuristic is an indicator, not a probability of fraud.
  const score = level === "critical" ? 95 : level === "high" ? 70 : level === "caution" ? 30 : 0;
  return {
    provider: "GoPlus Security",
    status: "checked",
    checkedAt: new Date().toISOString(),
    level,
    score,
    findings,
  };
}

const chainabuseChains: Record<Network, string> = {
  bsc: "BINANCE",
  ethereum: "ETH",
  tron: "TRON",
};

function chainMatches(network: Network, chain: unknown): boolean {
  if (typeof chain !== "string") return false;
  const aliases: Record<Network, string[]> = {
    bsc: ["BINANCE", "BSC", "BNB"],
    ethereum: ["ETH", "ETHEREUM"],
    tron: ["TRON"],
  };
  return aliases[network].includes(chain.toUpperCase());
}

async function checkChainabuse(
  network: Network,
  address: string,
  apiKey: string,
): Promise<ChainabuseResult> {
  const url = new URL("https://api.chainabuse.com/v0/reports");
  url.searchParams.set("address", address);
  url.searchParams.set("chain", chainabuseChains[network]);
  url.searchParams.set("page", "1");
  url.searchParams.set("perPage", "50");
  const response = await fetch(url, {
    headers: {
      Accept: "application/json",
      Authorization: `Basic ${Buffer.from(`${apiKey}:${apiKey}`).toString("base64")}`,
    },
    signal: AbortSignal.timeout(12_000),
  });
  if (!response.ok) throw new Error(`Chainabuse HTTP ${response.status}`);
  const body = await response.json() as {
    count?: unknown;
    reports?: unknown;
  };
  if (!Array.isArray(body.reports) || typeof body.count !== "number"
    || !Number.isInteger(body.count) || body.count < 0) {
    throw new Error("Chainabuse returned no usable result");
  }

  const matchingReports = body.reports.filter((item): item is Record<string, unknown> => {
    if (!item || typeof item !== "object" || Array.isArray(item)) return false;
    const addresses = (item as { addresses?: unknown }).addresses;
    return Array.isArray(addresses) && addresses.some((entry) => {
      if (!entry || typeof entry !== "object" || Array.isArray(entry)) return false;
      const candidate = entry as { address?: unknown; chain?: unknown };
      return typeof candidate.address === "string"
        && candidate.address.toLowerCase() === address.toLowerCase()
        && chainMatches(network, candidate.chain);
    });
  });
  const reports = matchingReports.map((item) => {
    if (typeof item.id !== "string" || typeof item.scamCategory !== "string"
      || typeof item.createdAt !== "string" || typeof item.checked !== "boolean"
      || typeof item.trusted !== "boolean") {
      throw new Error("Chainabuse returned an invalid report");
    }
    return {
      id: item.id,
      category: item.scamCategory,
      createdAt: item.createdAt,
      checked: item.checked,
      trusted: item.trusted,
    };
  });
  if (body.count > 0 && reports.length === 0) {
    throw new Error("Chainabuse returned reports that could not be matched to the requested address");
  }
  if (body.count === 0 && reports.length > 0) {
    throw new Error("Chainabuse returned reports with an invalid report count");
  }
  return {
    provider: "Chainabuse",
    status: "checked",
    checkedAt: new Date().toISOString(),
    reportCount: body.count,
    reports: reports.slice(0, 5),
  };
}

function compareSources(goplus: GoPlusResult, chainabuse: ChainabuseResult): Report["comparison"] {
  if (goplus.status !== "checked" || goplus.level === null
    || chainabuse.status !== "checked" || chainabuse.reportCount === null) return "incomplete";
  const goplusFlagged = goplus.level !== "no_flags";
  const chainabuseFlagged = (chainabuse.reportCount ?? 0) > 0;
  return goplusFlagged === chainabuseFlagged ? "consistent" : "disagreement";
}

router.post("/wallet-risk/check", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ code: "UNAUTHORIZED", message: "Cần đăng nhập để kiểm tra ví." });
    return;
  }
  const parsed = inputSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ code: "INVALID_INPUT" });
    return;
  }
  const { network, address } = parsed.data;
  // EVM addresses are shared in format, not in history: chain_id is required.
  const valid = network === "tron"
    ? /^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(address)
    : /^0x[a-fA-F0-9]{40}$/.test(address);
  if (!valid) {
    res.status(400).json({ code: "INVALID_ADDRESS" });
    return;
  }

  const key = `${network}:${address.toLowerCase()}`;
  const officialDepositWallet = isOfficialDepositAddress(network, address);
  const apiKey = process.env.CHAINABUSE_API_KEY?.trim();
  const cachedGoPlus = getCached(goPlusCache, key);
  const cachedChainabuse = apiKey ? getCached(chainabuseCache, key) : undefined;
  const cachedWallet = officialDepositWallet ? undefined : getCached(walletCache, key);
  if (cachedGoPlus && (officialDepositWallet || cachedWallet) && (cachedChainabuse || !apiKey)) {
    const chainabuse = cachedChainabuse ?? {
      provider: "Chainabuse" as const,
      status: "not_configured" as const,
      checkedAt: null,
      reportCount: null,
      reports: [],
    };
    res.json(CheckWalletRiskResponse.parse({
      network, address, checkedAt: new Date().toISOString(),
      wallet: officialDepositWallet ? hiddenWalletOverview(network) : cachedWallet, goplus: cachedGoPlus, chainabuse,
      comparison: compareSources(cachedGoPlus, chainabuse),
    }));
    return;
  }

  const client = req.ip ?? "unknown";
  const now = Date.now();
  const window = requests.get(client);
  if (window && window.until > now && window.count >= 10) {
    res.status(429).json({ code: "RATE_LIMITED" });
    return;
  }
  requests.set(client, window && window.until > now
    ? { ...window, count: window.count + 1 }
    : { until: now + 60_000, count: 1 });
  if (requests.size > 1000) {
    for (const [ip, entry] of requests) if (entry.until <= now) requests.delete(ip);
  }

  const [goplusResult, chainabuseResult, walletResult] = await Promise.all([
    cachedGoPlus
      ? Promise.resolve(cachedGoPlus)
      : checkGoPlus(network, address)
        .then((result) => {
          setCached(goPlusCache, key, result);
          return result;
        })
        .catch(() => {
          req.log.warn({ provider: "GoPlus Security" }, "Wallet risk source unavailable");
          return {
            provider: "GoPlus Security" as const,
            status: "unavailable" as const,
            checkedAt: null,
            level: null,
            score: null,
            findings: [],
          };
        }),
    cachedChainabuse
      ? Promise.resolve(cachedChainabuse)
      : !apiKey
        ? Promise.resolve({
          provider: "Chainabuse" as const,
          status: "not_configured" as const,
          checkedAt: null,
          reportCount: null,
          reports: [],
        })
        : checkChainabuse(network, address, apiKey)
          .then((result) => {
            setCached(chainabuseCache, key, result);
            return result;
          })
          .catch(() => {
            req.log.warn({ provider: "Chainabuse" }, "Wallet risk source unavailable");
            return {
              provider: "Chainabuse" as const,
              status: "unavailable" as const,
              checkedAt: null,
              reportCount: null,
              reports: [],
            };
          }),
    officialDepositWallet
      ? Promise.resolve(hiddenWalletOverview(network))
      : cachedWallet ? Promise.resolve(cachedWallet) : getWalletOverview(network, address)
      .then((result) => {
        if (result.status !== "unavailable") setCached(walletCache, key, result);
        return result;
      })
      .catch(() => {
        req.log.warn({ network }, "Wallet overview source unavailable");
        return unavailableWallet(network);
      }),
  ]);

  if (!officialDepositWallet && goplusResult.status !== "checked" && chainabuseResult.status !== "checked"
    && walletResult.status === "unavailable") {
    res.status(503).json({ code: "RISK_SOURCE_UNAVAILABLE" });
    return;
  }

  res.json(CheckWalletRiskResponse.parse({
    network,
    address,
    checkedAt: new Date().toISOString(),
    wallet: walletResult,
    goplus: goplusResult,
    chainabuse: chainabuseResult,
    comparison: compareSources(goplusResult, chainabuseResult),
  }));
});

export default router;