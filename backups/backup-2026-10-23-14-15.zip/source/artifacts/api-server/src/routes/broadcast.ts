import { Router, type Request, type Response, type NextFunction } from "express";
import multer from "multer";
import { db, usersTable, broadcastsTable } from "@workspace/db";
import { eq, and, desc, sql } from "drizzle-orm";
import { randomUUID } from "crypto";
import { authenticateRequest } from "../lib/jwt";
import { isAdminUser, getAdminPhones } from "../lib/admin";
import { getTelegramChatId, sendTelegramMessageDetailed, sendTelegramPhotoDetailed } from "../lib/telegram";
import { logger } from "../lib/logger";

const router = Router();

type Kind = "important" | "promo";
type Audience = "all" | "users";

// Telegram global rate limit is ~30 messages/sec across all chats.
// Stay well below that with a 50 ms gap between messages.
const SEND_GAP_MS = 50;
// Telegram limits a text message to 4096 chars but a photo caption to
// 1024 chars. Keep text-only at 4000 (safe margin) and force a tighter
// cap when an image is attached.
const MAX_BODY_LEN = 4000;
const MAX_CAPTION_LEN = 1024;
const MAX_IMAGE_BYTES = 3 * 1024 * 1024;

// Same memory-storage pattern used by the avatar/support uploads —
// we persist as a base64 data URL so deployments stay stateless.
const ALLOWED_IMAGE_MIME = ["image/jpeg", "image/png", "image/webp", "image/gif"];

const broadcastImageUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_IMAGE_BYTES },
  fileFilter: (_req, file, cb) => {
    cb(null, ALLOWED_IMAGE_MIME.includes(file.mimetype));
  },
});

// Replit's edge proxy returns 403 Forbidden for any multipart/form-data
// POST before it ever reaches us, so in production the broadcast image must
// arrive as base64 inside a JSON body. We still run multer for genuine
// multipart requests (dev / legacy clients), but the JSON path is the one
// that works in the deployed app. Mirrors the topup bill-upload approach.
function maybeMultipartImage(req: Request, res: Response, next: NextFunction): void {
  const ct = String(req.headers["content-type"] || "");
  if (ct.startsWith("multipart/")) {
    broadcastImageUpload.single("image")(req, res, next);
    return;
  }
  next();
}

// Resolve the broadcast image from whichever body shape the client used:
// a multipart file (req.file) or an `imageBase64` JSON field. Returns null
// when no image was provided, or an error payload when validation fails.
function resolveBroadcastImage(
  req: Request,
): { ok: true; image: { buffer: Buffer; mime: string; name: string } | null } | { ok: false; status: number; body: object } {
  const file = (req as { file?: Express.Multer.File }).file;
  if (file) {
    return { ok: true, image: { buffer: file.buffer, mime: file.mimetype, name: file.originalname || "broadcast.jpg" } };
  }
  const body = req.body as { imageBase64?: unknown; imageMime?: unknown; imageName?: unknown };
  if (typeof body?.imageBase64 === "string" && body.imageBase64.length > 0) {
    const raw = body.imageBase64.replace(/^data:[^;]+;base64,/, "");
    let buffer: Buffer;
    try {
      buffer = Buffer.from(raw, "base64");
    } catch {
      return { ok: false, status: 400, body: { error: "invalid_image", message: "Ảnh không hợp lệ." } };
    }
    if (buffer.byteLength === 0) {
      return { ok: false, status: 400, body: { error: "invalid_image", message: "Ảnh không hợp lệ." } };
    }
    if (buffer.byteLength > MAX_IMAGE_BYTES) {
      return {
        ok: false,
        status: 413,
        body: { error: "image_too_big", message: `Ảnh quá lớn. Tối đa ${Math.floor(MAX_IMAGE_BYTES / 1024 / 1024)} MB.` },
      };
    }
    const mime = typeof body.imageMime === "string" && ALLOWED_IMAGE_MIME.includes(body.imageMime) ? body.imageMime : "image/jpeg";
    const name = typeof body.imageName === "string" && body.imageName.length > 0 ? body.imageName : "broadcast.jpg";
    return { ok: true, image: { buffer, mime, name } };
  }
  return { ok: true, image: null };
}

// In-memory lock so two admins can't kick off concurrent mass sends —
// that would double-message users and could trip Telegram's flood
// limits. Acceptable trade-off: in a multi-instance deploy this only
// guards a single instance, but the API runs as one process here.
let broadcastInFlight = false;

async function requireAdmin(req: Parameters<Parameters<typeof router.post>[1]>[0]) {
  const payload = await authenticateRequest(req);
  if (!payload) return { ok: false as const, status: 401, error: "unauthorized" };
  const [me] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId))
    .limit(1);
  if (!me || !isAdminUser(me)) {
    return { ok: false as const, status: 403, error: "forbidden" };
  }
  return { ok: true as const, me };
}

// Resolve which user rows should receive a given broadcast. Centralised
// so the recipient-count endpoint and the actual send share one rule.
async function resolveRecipients(kind: Kind, audience: Audience) {
  const adminPhones = new Set(getAdminPhones());
  const rows = await db
    .select({
      id: usersTable.id,
      phone: usersTable.phone,
      telegramChatId: usersTable.telegramChatId,
      telegramId: usersTable.telegramId,
      isAdmin: usersTable.isAdmin,
      telegramOptIn: usersTable.telegramOptIn,
    })
    .from(usersTable)
    .where(sql`(${usersTable.telegramChatId} IS NOT NULL OR ${usersTable.telegramId} IS NOT NULL)`);

  return rows.filter((u) => {
    if (!getTelegramChatId(u)) return false;
    const isAdmin = u.isAdmin || adminPhones.has(u.phone);
    if (audience === "users" && isAdmin) return false;
    if (kind === "promo" && !u.telegramOptIn) return false;
    return true;
  });
}

// GET /admin/broadcast/recipients?kind=...&audience=...
// Returns the count of users who would receive a given broadcast.
router.get("/admin/broadcast/recipients", async (req, res) => {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    res.status(auth.status).json({ error: auth.error });
    return;
  }
  const kind = (req.query.kind === "promo" ? "promo" : "important") as Kind;
  const audience = (req.query.audience === "users" ? "users" : "all") as Audience;
  const recipients = await resolveRecipients(kind, audience);
  res.json({ count: recipients.length });
});

// GET /admin/broadcast/history — last 50 broadcasts for the audit panel.
router.get("/admin/broadcast/history", async (req, res) => {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    res.status(auth.status).json({ error: auth.error });
    return;
  }
  const rows = await db
    .select()
    .from(broadcastsTable)
    .orderBy(desc(broadcastsTable.createdAt))
    .limit(50);
  res.json({
    items: rows.map((r) => ({
      id: r.id,
      sentByName: r.sentByName,
      kind: r.kind,
      audience: r.audience,
      body: r.body,
      imageDataUrl: r.imageDataUrl,
      total: r.total,
      okCount: r.okCount,
      failCount: r.failCount,
      createdAt: r.createdAt.toISOString(),
    })),
  });
});

// POST /admin/broadcast — multipart/form-data
// Fields: kind, audience, body, image? (file)
// Sends `body` (HTML allowed) plus an optional inline image to the
// resolved Telegram chats, throttled to stay under Telegram's global
// rate limit, and records an audit row.
router.post("/admin/broadcast", maybeMultipartImage, async (req, res) => {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    res.status(auth.status).json({ error: auth.error });
    return;
  }
  const me = auth.me;

  const body = String((req.body as { body?: unknown })?.body ?? "").trim();
  const rawKind = String((req.body as { kind?: unknown })?.kind ?? "");
  const rawAud = String((req.body as { audience?: unknown })?.audience ?? "");

  const imageResult = resolveBroadcastImage(req);
  if (!imageResult.ok) {
    res.status(imageResult.status).json(imageResult.body);
    return;
  }
  const image = imageResult.image;

  // Body must exist unless an image is attached — Telegram allows a
  // photo with no caption but at least one of the two has to be there.
  if (!body && !image) {
    res.status(400).json({ error: "invalid_body", message: "Cần nhập nội dung hoặc đính kèm ảnh." });
    return;
  }
  const cap = image ? MAX_CAPTION_LEN : MAX_BODY_LEN;
  if (body.length > cap) {
    res.status(400).json({
      error: "invalid_body",
      message: image
        ? `Khi gửi kèm ảnh, nội dung không quá ${MAX_CAPTION_LEN} ký tự (giới hạn của Telegram).`
        : `Nội dung không quá ${MAX_BODY_LEN} ký tự.`,
    });
    return;
  }
  const kind: Kind = rawKind === "promo" ? "promo" : "important";

  // "self" → preview to the sender only. Doesn't write history because
  // it's a test message, not a real broadcast.
  if (rawAud === "self") {
    const meChatId = getTelegramChatId(me);
    if (!meChatId) {
      res.status(400).json({ error: "no_chat", message: "Tài khoản admin chưa liên kết Telegram." });
      return;
    }
    const previewBody = body ? `🧪 <b>[GỬI THỬ]</b>\n\n${body}` : `🧪 <b>[GỬI THỬ]</b>`;
    const r = image
      ? await sendTelegramPhotoDetailed(
          image.buffer,
          previewBody,
          image.name,
          image.mime,
           meChatId,
        )
      : await sendTelegramMessageDetailed(previewBody, meChatId);
    if (!r.ok) {
      res.status(502).json({ error: "send_failed", message: r.description ?? "Không gửi được tin thử." });
      return;
    }
    res.json({ ok: true, preview: true });
    return;
  }

  const audience: Audience = rawAud === "users" ? "users" : "all";

  if (broadcastInFlight) {
    res.status(429).json({
      error: "broadcast_in_progress",
      message: "Một đợt gửi khác đang chạy. Vui lòng đợi vài phút.",
    });
    return;
  }

  const recipients = await resolveRecipients(kind, audience);

  // Promo footer is appended to the text body. With an image, this
  // counts toward the 1024-char caption budget — admins are warned
  // by the frontend character counter that already accounts for it.
  const promoFooter = "\n\n— —\n💡 <i>Tắt nhận quảng cáo: vào ứng dụng → Cài đặt → Thông báo Telegram.</i>";
  const finalBody = kind === "promo" && body ? `${body}${promoFooter}` : body;

  // If an image was uploaded, snapshot it as a base64 data URL so the
  // history panel can re-render the thumbnail without us needing an
  // external object store. Captured once, reused across all sends.
  const imageDataUrl = image
    ? `data:${image.mime};base64,${image.buffer.toString("base64")}`
    : null;
  const imageBuffer = image ? image.buffer : null;
  const imageMime = image ? image.mime : "";
  const imageName = image ? image.name : "";

  // Insert the audit row up front with zero counts so the history
  // panel shows the in-flight broadcast immediately. Counts are
  // updated when the background loop finishes.
  const broadcastId = randomUUID();
  await db.insert(broadcastsTable).values({
    id: broadcastId,
    sentByUserId: me.id,
    sentByName: me.nickname?.trim() || me.name,
    kind,
    audience,
    body,
    imageDataUrl,
    total: recipients.length,
    okCount: 0,
    failCount: 0,
  });

  // Long sends to many chats can exceed proxy timeouts. Run the
  // delivery loop after responding so the admin's request doesn't
  // hang for the full duration.
  broadcastInFlight = true;
  setImmediate(async () => {
    let okCount = 0;
    let failCount = 0;
    try {
      for (const r of recipients) {
        const chatId = getTelegramChatId(r);
        if (!chatId) continue;
        const result = imageBuffer
          ? await sendTelegramPhotoDetailed(
              imageBuffer,
              finalBody,
              imageName,
              imageMime,
               chatId,
            )
           : await sendTelegramMessageDetailed(finalBody, chatId);
        if (result.ok) okCount++;
        else {
          failCount++;
          logger.warn(
            { userId: r.id, reason: result.reason, description: result.description },
            "[broadcast] delivery failed",
          );
        }
        await new Promise((resolve) => setTimeout(resolve, SEND_GAP_MS));
      }
      await db
        .update(broadcastsTable)
        .set({ okCount, failCount })
        .where(eq(broadcastsTable.id, broadcastId));
      logger.info(
        { broadcastId, kind, audience, total: recipients.length, okCount, failCount },
        "broadcast_sent",
      );
    } catch (err) {
      logger.error({ err, broadcastId }, "[broadcast] background loop crashed");
    } finally {
      broadcastInFlight = false;
    }
  });

  res.status(202).json({
    ok: true,
    queued: true,
    broadcastId,
    total: recipients.length,
  });
});

// GET /broadcast/opt-in — returns the user's current promo opt-in
// state so the settings toggle can render in the right position on load.
router.get("/broadcast/opt-in", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const [u] = await db
    .select({
      telegramOptIn: usersTable.telegramOptIn,
      notifPayment: usersTable.notifPayment,
      telegramChatId: usersTable.telegramChatId,
      telegramId: usersTable.telegramId,
    })
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId))
    .limit(1);
  if (!u) {
    res.status(404).json({ error: "user_not_found" });
    return;
  }
  res.json({
    telegramOptIn: u.telegramOptIn,
    notifPayment: u.notifPayment,
    linked: !!getTelegramChatId(u),
  });
});

// PATCH /broadcast/opt-in — user updates granular Telegram notification prefs.
// Accepted body keys (all optional, each a boolean):
//   optIn        → telegramOptIn (promo/broadcast)
//   notifPayment → notifPayment  (payment/deposit confirmations)
router.patch("/broadcast/opt-in", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const body = req.body as { optIn?: unknown; notifPayment?: unknown };
  const patch: Partial<{ telegramOptIn: boolean; notifPayment: boolean }> = {};
  if (body.optIn !== undefined) patch.telegramOptIn = Boolean(body.optIn);
  if (body.notifPayment !== undefined) patch.notifPayment = Boolean(body.notifPayment);
  if (Object.keys(patch).length === 0) {
    res.status(400).json({ error: "no_fields" });
    return;
  }
  const [updated] = await db
    .update(usersTable)
    .set(patch)
    .where(eq(usersTable.id, payload.userId))
    .returning({ telegramOptIn: usersTable.telegramOptIn, notifPayment: usersTable.notifPayment });
  if (!updated) {
    res.status(404).json({ error: "user_not_found" });
    return;
  }
  res.json({ ok: true, telegramOptIn: updated.telegramOptIn, notifPayment: updated.notifPayment });
});

// Silence unused-import warnings for helpers we may use later.
void and;
void sql;

export default router;
