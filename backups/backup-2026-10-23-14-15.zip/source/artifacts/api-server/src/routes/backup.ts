import { Router } from "express";
import type { Request, Response } from "express";
import { db, usersTable, backupRunsTable, pool } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { authenticateRequest } from "../lib/jwt";
import { isAdminUser } from "../lib/admin";
import { verifyDestructiveKey } from "../lib/destructive-key";
import {
  runBackup,
  getBackupProgress,
  getBackupSchedule,
  setBackupSchedule,
  getLastRun,
  type BackupScheduleMode,
} from "../lib/backup/run";
import {
  testGithubConnection,
  isGithubConfigured,
  getBackupBranch,
  downloadFileFromBranch,
} from "../lib/backup/github";

const router = Router();

// Shared admin gate for every backup endpoint. Returns null (response
// already sent) when the caller is not an authenticated admin.
async function requireAdmin(req: Request, res: Response): Promise<{ userId: string } | null> {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ message: "unauthorized", code: "UNAUTHORIZED" });
    return null;
  }
  const [me] = await db
    .select({ phone: usersTable.phone, isAdmin: usersTable.isAdmin })
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId))
    .limit(1);
  if (!me || !isAdminUser(me)) {
    res.status(403).json({ message: "Forbidden: admin only", code: "FORBIDDEN" });
    return null;
  }
  return { userId: payload.userId };
}

// POST /admin/backup/run — kick off a backup in the background.
router.post("/admin/backup/run", async (req, res) => {
  if (!(await requireAdmin(req, res))) return;
  if (getBackupProgress().running) {
    res.status(409).json({ message: "Backup đang chạy", code: "BACKUP_RUNNING" });
    return;
  }
  // Fire and forget — progress is polled via /admin/backup/status.
  runBackup("manual").catch(() => {
    // Error already recorded in backup_runs + progress.lastError.
  });
  res.json({ started: true });
});

// GET /admin/backup/status — progress + config + last run summary.
router.get("/admin/backup/status", async (req, res) => {
  if (!(await requireAdmin(req, res))) return;
  const [schedule, lastRun] = await Promise.all([getBackupSchedule(), getLastRun()]);
  const configured = isGithubConfigured();
  res.json({
    progress: getBackupProgress(),
    config: {
      tokenConfigured: configured.token,
      repoConfigured: configured.repo,
      branch: getBackupBranch(),
    },
    schedule,
    lastRun,
  });
});

// GET /admin/backup/history — most recent runs.
router.get("/admin/backup/history", async (req, res) => {
  if (!(await requireAdmin(req, res))) return;
  const rows = await db
    .select()
    .from(backupRunsTable)
    .orderBy(desc(backupRunsTable.startedAt))
    .limit(30);
  res.json({ runs: rows });
});

// POST /admin/backup/test-github — verify token/repo/branch reachability.
router.post("/admin/backup/test-github", async (req, res) => {
  if (!(await requireAdmin(req, res))) return;
  try {
    const result = await testGithubConnection();
    res.json(result);
  } catch (err) {
    res.json({ ok: false, message: err instanceof Error ? err.message : "unknown_error" });
  }
});

// POST /admin/backup/schedule — { mode: "off" | "daily" | "weekly" }
router.post("/admin/backup/schedule", async (req, res) => {
  if (!(await requireAdmin(req, res))) return;
  const mode = req.body?.mode as string;
  if (mode !== "off" && mode !== "daily" && mode !== "weekly") {
    res.status(400).json({ message: "mode must be off | daily | weekly", code: "BAD_MODE" });
    return;
  }
  await setBackupSchedule(mode as BackupScheduleMode);
  res.json({ ok: true, schedule: mode });
});

// POST /admin/backup/restore — prepared for future use (no UI yet).
// Restores DATABASE DATA from a previous backup's SQL dump on GitHub.
// Extremely destructive (truncates + re-inserts all tables), so it is
// double-gated: admin JWT + X-Destructive-Key operator key.
// Body: { fileName: "backup-YYYY-MM-DD-HH-mm.zip" }
router.post("/admin/backup/restore", async (req, res) => {
  if (!(await requireAdmin(req, res))) return;
  if (!verifyDestructiveKey(req)) {
    res.status(403).json({ message: "Missing or invalid X-Destructive-Key", code: "DESTRUCTIVE_KEY_REQUIRED" });
    return;
  }
  const fileName = req.body?.fileName as string;
  if (typeof fileName !== "string" || !/^backup-[\d-]+\.zip$/.test(fileName)) {
    res.status(400).json({ message: "fileName must look like backup-YYYY-MM-DD-HH-mm.zip", code: "BAD_FILE" });
    return;
  }
  try {
    const sqlName = fileName.replace(/\.zip$/, ".sql");
    const sqlBuf = await downloadFileFromBranch(`backups/${sqlName}`);
    const script = sqlBuf.toString("utf8");
    // Sanity check the artifact really is one of our dumps before executing.
    if (!script.startsWith("-- AndersPay+ database data dump")) {
      res.status(400).json({ message: "File tải về không phải bản dump hợp lệ", code: "BAD_DUMP" });
      return;
    }
    req.log?.warn?.({ fileName }, "[backup] RESTORE starting — database data will be replaced");
    await pool.query(script);
    req.log?.warn?.({ fileName }, "[backup] RESTORE completed");
    res.json({ ok: true, restoredFrom: sqlName });
  } catch (err) {
    const message = err instanceof Error ? err.message : "unknown_error";
    req.log?.error?.({ err, fileName }, "[backup] restore failed");
    res.status(500).json({ message, code: "RESTORE_FAILED" });
  }
});

export default router;
