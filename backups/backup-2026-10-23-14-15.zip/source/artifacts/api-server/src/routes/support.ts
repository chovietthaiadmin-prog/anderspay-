import { Router, type Request, type Response, type NextFunction } from "express";
import { randomUUID } from "crypto";
import multer from "multer";
import { db, usersTable, supportMessagesTable } from "@workspace/db";
import { eq, and, desc, sql, gt } from "drizzle-orm";
import { authenticateRequest } from "../lib/jwt";
import { isAdminUser } from "../lib/admin";
import { notifyAdminNewSupportMessage } from "../lib/admin-telegram-notify";
import { sendUserMessage } from "../services/privateTelegramNotification";
import { updatePresence } from "../lib/presence";

const router = Router();

// Inline images for support chat — same shape as avatar upload (memory
// storage, base64 data URL persisted in DB so it survives redeploys).
// 2 MB cap is generous enough for phone screenshots while keeping rows
// reasonable.
const imageUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 2 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = ["image/jpeg", "image/png", "image/webp", "image/gif"];
    cb(null, allowed.includes(file.mimetype));
  },
});

async function requireUser(req: Request) {
  const payload = await authenticateRequest(req);
  if (!payload) return null;
  const [u] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId))
    .limit(1);
  if (!u) return null;
  return { ...u, isAdmin: isAdminUser(u) };
}

const GUEST_PREFIX = "guest:";

// Guest headers are not credentials. Preserve old guest threads for admin
// history, but every customer-side chat operation requires a valid session.
async function requireSupportUser(req: Request, res: Response) {
  const user = await requireUser(req);
  if (!user) {
    res.status(401).json({ error: "unauthorized" });
  }
  return user;
}

async function authenticateSupportUpload(req: Request, res: Response, next: NextFunction): Promise<void> {
  const user = await requireSupportUser(req, res);
  if (!user) return;
  res.locals.supportUser = user;
  next();
}

const MAX_BODY = 2000;

// ── Presence endpoint ──────────────────────────────────────────────

// POST /support/presence — participant reports whether they are actively
// viewing the support chat. Used by the frontend to suppress Telegram
// notifications when the recipient is already watching the conversation.
// Fire-and-forget from the authenticated client.
router.post("/support/presence", async (req, res) => {
  const user = await requireSupportUser(req, res);
  if (!user) return;
  const body = req.body as { conversationOpen?: unknown; activeConversationId?: unknown };
  const conversationOpen = body.conversationOpen === true;
  const activeConversationId =
    typeof body.activeConversationId === "string" ? body.activeConversationId : null;
  updatePresence(user.id, conversationOpen, activeConversationId);
  res.json({ ok: true });
});

// ── User endpoints ─────────────────────────────────────────────────

// GET /support/messages — current authenticated user's thread with admin.
// Marks messages from admin as read.
router.get("/support/messages", async (req, res) => {
  const user = await requireSupportUser(req, res);
  if (!user) return;
  const rows = await db
    .select()
    .from(supportMessagesTable)
    .where(eq(supportMessagesTable.userId, user.id))
    .orderBy(supportMessagesTable.createdAt);

  await db
    .update(supportMessagesTable)
    .set({ readByUser: true })
    .where(
      and(
        eq(supportMessagesTable.userId, user.id),
        eq(supportMessagesTable.fromAdmin, true),
        eq(supportMessagesTable.readByUser, false),
      ),
    );

  res.json({ messages: rows });
});

// GET /support/unread — number of unread admin replies for the participant.
router.get("/support/unread", async (req, res) => {
  const user = await requireSupportUser(req, res);
  if (!user) return;
  const [row] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(supportMessagesTable)
    .where(
      and(
        eq(supportMessagesTable.userId, user.id),
        eq(supportMessagesTable.fromAdmin, true),
        eq(supportMessagesTable.readByUser, false),
      ),
    );
  res.json({ unread: row?.n ?? 0 });
});

// POST /support/messages — participant sends a message to admin.
router.post("/support/messages", async (req, res) => {
  const user = await requireSupportUser(req, res);
  if (!user) return;
  const body = req.body as { body?: unknown };
  const text = typeof body.body === "string" ? body.body.trim() : "";
  if (!text || text.length > MAX_BODY) {
    res.status(400).json({ error: "invalid_body" });
    return;
  }
  const [row] = await db
    .insert(supportMessagesTable)
    .values({
      id: randomUUID(),
      userId: user.id,
      fromAdmin: false,
      body: text,
      readByUser: true,
      readByAdmin: false,
    })
    .returning();
  res.json({ message: row });
  // Fire-and-forget — notify admin; skip if the sender is already an admin.
  if (!user.isAdmin) {
    notifyAdminNewSupportMessage(user.id, text).catch(() => {});
  }
});

// POST /support/messages/image — participant uploads an image. Body
// (caption) is optional. Stored as a base64 data URL in `image_url`.
router.post("/support/messages/image", authenticateSupportUpload, imageUpload.single("image"), async (req, res) => {
  const user = res.locals.supportUser as NonNullable<Awaited<ReturnType<typeof requireUser>>>;
  if (!req.file) {
    res.status(400).json({ error: "no_image" });
    return;
  }
  const caption = typeof (req.body as { body?: unknown })?.body === "string"
    ? ((req.body as { body: string }).body).trim().slice(0, MAX_BODY)
    : "";
  const mime = req.file.mimetype || "image/jpeg";
  const imageUrl = `data:${mime};base64,${req.file.buffer.toString("base64")}`;
  const [row] = await db
    .insert(supportMessagesTable)
    .values({
      id: randomUUID(),
      userId: user.id,
      fromAdmin: false,
      body: caption,
      imageUrl,
      readByUser: true,
      readByAdmin: false,
    })
    .returning();
  res.json({ message: row });
  // Fire-and-forget — notify admin about the new image message.
  if (!user.isAdmin) {
    const notifyText = caption ? `[Hình ảnh] ${caption}` : "[Hình ảnh]";
    notifyAdminNewSupportMessage(user.id, notifyText).catch(() => {});
  }
});

// ── Admin endpoints ────────────────────────────────────────────────

// GET /support/threads — admin only: one row per user with last message
// preview and unread count.
router.get("/support/threads", async (req, res) => {
  const user = await requireUser(req);
  if (!user || !user.isAdmin) {
    res.status(user ? 403 : 401).json({ error: user ? "forbidden" : "unauthorized" });
    return;
  }

  // Aggregate per user: latest message timestamp + body + unread admin count.
  // LEFT JOIN users so guest threads (user_id starts with 'guest:') still
  // appear in the admin inbox without a matching users row.
  const rows = await db.execute<{
    user_id: string;
    name: string | null;
    phone: string | null;
    nickname: string | null;
    avatar_url: string | null;
    last_body: string;
    last_at: Date;
    last_from_admin: boolean;
    unread: number;
  }>(sql`
    SELECT
      m.user_id,
      u.name,
      u.phone,
      u.nickname,
      u.avatar_url,
      m.body          AS last_body,
      m.created_at    AS last_at,
      m.from_admin    AS last_from_admin,
      (
        SELECT COUNT(*)::int
        FROM support_messages m2
        WHERE m2.user_id = m.user_id
          AND m2.from_admin = false
          AND m2.read_by_admin = false
      ) AS unread
    FROM support_messages m
    LEFT JOIN users u ON u.id = m.user_id
    JOIN (
      SELECT user_id, MAX(created_at) AS max_at
      FROM support_messages
      GROUP BY user_id
    ) latest
      ON latest.user_id = m.user_id
     AND latest.max_at  = m.created_at
    ORDER BY m.created_at DESC
  `);

  // drizzle's .execute() return shape varies by driver; normalise.
  const list = (Array.isArray(rows) ? rows : (rows as { rows?: unknown[] }).rows ?? []) as Array<{
    user_id: string;
    name: string | null;
    phone: string | null;
    nickname: string | null;
    avatar_url: string | null;
    last_body: string;
    last_at: Date | string;
    last_from_admin: boolean;
    unread: number;
  }>;

  res.json({
    threads: list.map((r) => ({
      userId: r.user_id,
      name: r.name,
      phone: r.phone,
      nickname: r.nickname,
      avatarUrl: r.avatar_url,
      lastBody: r.last_body,
      lastAt: r.last_at,
      lastFromAdmin: r.last_from_admin,
      unread: Number(r.unread) || 0,
    })),
  });
});

// GET /support/threads/:userId — admin: full thread for one user.
// Marks user-sent messages as read by admin.
router.get("/support/threads/:userId", async (req, res) => {
  const user = await requireUser(req);
  if (!user || !user.isAdmin) {
    res.status(user ? 403 : 401).json({ error: user ? "forbidden" : "unauthorized" });
    return;
  }
  const targetId = req.params.userId;
  const rows = await db
    .select()
    .from(supportMessagesTable)
    .where(eq(supportMessagesTable.userId, targetId))
    .orderBy(supportMessagesTable.createdAt);

  await db
    .update(supportMessagesTable)
    .set({ readByAdmin: true })
    .where(
      and(
        eq(supportMessagesTable.userId, targetId),
        eq(supportMessagesTable.fromAdmin, false),
        eq(supportMessagesTable.readByAdmin, false),
      ),
    );

  res.json({ messages: rows });
});

// POST /support/threads/:userId — admin sends to a specific user.
router.post("/support/threads/:userId", async (req, res) => {
  const user = await requireUser(req);
  if (!user || !user.isAdmin) {
    res.status(user ? 403 : 401).json({ error: user ? "forbidden" : "unauthorized" });
    return;
  }
  const body = req.body as { body?: unknown };
  const text = typeof body.body === "string" ? body.body.trim() : "";
  if (!text || text.length > MAX_BODY) {
    res.status(400).json({ error: "invalid_body" });
    return;
  }
  const targetId = req.params.userId;
  // Guests have no users row — accept the target as-is when namespaced.
  if (!targetId.startsWith(GUEST_PREFIX)) {
    const [target] = await db
      .select({ id: usersTable.id })
      .from(usersTable)
      .where(eq(usersTable.id, targetId))
      .limit(1);
    if (!target) {
      res.status(404).json({ error: "user_not_found" });
      return;
    }
  }
  const [row] = await db
    .insert(supportMessagesTable)
    .values({
      id: randomUUID(),
      userId: targetId,
      fromAdmin: true,
      body: text,
      readByUser: false,
      readByAdmin: true,
    })
    .returning();
  res.json({ message: row });
  // Fire-and-forget — notify user via private Telegram if they have it linked.
  if (!targetId.startsWith(GUEST_PREFIX)) {
    sendUserMessage(targetId, text).catch(() => {});
  }
});

// POST /support/threads/:userId/image — admin sends an image (with
// optional caption) to a specific user.
router.post(
  "/support/threads/:userId/image",
  imageUpload.single("image"),
  async (req, res) => {
    const user = await requireUser(req);
    if (!user || !user.isAdmin) {
      res.status(user ? 403 : 401).json({ error: user ? "forbidden" : "unauthorized" });
      return;
    }
    if (!req.file) {
      res.status(400).json({ error: "no_image" });
      return;
    }
    const targetId = String(req.params.userId ?? "");
    if (!targetId.startsWith(GUEST_PREFIX)) {
      const [target] = await db
        .select({ id: usersTable.id })
        .from(usersTable)
        .where(eq(usersTable.id, targetId))
        .limit(1);
      if (!target) {
        res.status(404).json({ error: "user_not_found" });
        return;
      }
    }
    const rawCaption = (req.body as { body?: unknown })?.body;
    const caption = typeof rawCaption === "string"
      ? rawCaption.trim().slice(0, MAX_BODY)
      : "";
    const mime = req.file.mimetype || "image/jpeg";
    const imageUrl = `data:${mime};base64,${req.file.buffer.toString("base64")}`;
    const [row] = await db
      .insert(supportMessagesTable)
      .values({
        id: randomUUID(),
        userId: targetId,
        fromAdmin: true,
        body: caption,
        imageUrl,
        readByUser: false,
        readByAdmin: true,
      })
      .returning();
    res.json({ message: row });
    // Fire-and-forget — notify user via private Telegram if they have it linked.
    if (!targetId.startsWith(GUEST_PREFIX)) {
      const notifyText = caption ? `[Hình ảnh] ${caption}` : "[Hình ảnh từ hỗ trợ]";
      sendUserMessage(targetId, notifyText).catch(() => {});
    }
  },
);

// DELETE /support/threads/:userId — admin only: wipe the entire chat
// thread for one user (and their image attachments). Used after a
// support case is resolved to reduce DB / image storage.
router.delete("/support/threads/:userId", async (req, res) => {
  const user = await requireUser(req);
  if (!user || !user.isAdmin) {
    res.status(user ? 403 : 401).json({ error: user ? "forbidden" : "unauthorized" });
    return;
  }
  const targetId = String(req.params.userId ?? "");
  if (!targetId) {
    res.status(400).json({ error: "missing_user_id" });
    return;
  }
  const deleted = await db
    .delete(supportMessagesTable)
    .where(eq(supportMessagesTable.userId, targetId))
    .returning({ id: supportMessagesTable.id });
  res.json({ ok: true, deleted: deleted.length });
});

// GET /support/admin/unread-total — admin: total unread customer messages.
router.get("/support/admin/unread-total", async (req, res) => {
  const user = await requireUser(req);
  if (!user || !user.isAdmin) {
    res.status(user ? 403 : 401).json({ error: user ? "forbidden" : "unauthorized" });
    return;
  }
  const [row] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(supportMessagesTable)
    .where(
      and(
        eq(supportMessagesTable.fromAdmin, false),
        eq(supportMessagesTable.readByAdmin, false),
      ),
    );
  res.json({ unread: row?.n ?? 0 });
});

// Suppress unused-import warnings for symbols kept for future use.
void desc;
void gt;

export default router;
