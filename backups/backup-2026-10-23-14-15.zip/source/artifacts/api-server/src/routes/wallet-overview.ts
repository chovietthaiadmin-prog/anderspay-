import { createHash } from "node:crypto";
import { isOfficialDepositAddress, type DepositWalletNetwork } from "../lib/deposit-wallets";

type Network = DepositWalletNetwork;
type Transaction = {
  hash: string;
  timestamp: string;
  from: string;
  to: string;
  symbol: string;
  amount: string | null;
  direction: "in" | "out" | "self";
};
type WalletOverview = {
  provider: string;
  status: "checked" | "partial" | "unavailable" | "hidden";
  checkedAt: string | null;
  nativeSymbol: string;
  nativeBalance: string | null;
  usdtBalance: string | null;
  firstActivityAt: string | null;
  firstActivityKind: "account_activation" | "contract_creation" | "earliest_observed" | null;
  transactions: Transaction[];
};
const USDT: Record<Network, string> = {
  bsc: "0x55d398326f99059fF775485246999027B3197955",
  ethereum: "0xdAC17F958D2ee523a2206206994597C13D831ec7",
  tron: "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t",
};
const symbol: Record<Network, string> = { bsc: "BNB", ethereum: "ETH", tron: "TRX" };
const TRANSACTION_LIMIT = 10;

function object(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("Invalid explorer response");
  return value as Record<string, unknown>;
}

function array(value: unknown): unknown[] {
  if (!Array.isArray(value)) throw new Error("Invalid explorer list");
  return value;
}

function time(value: unknown, unit: "s" | "ms"): string | null {
  const n = Number(value);
  if (!Number.isFinite(n) || n <= 0) return null;
  const date = new Date(unit === "s" ? n * 1000 : n);
  return Number.isNaN(date.getTime()) ? null : date.toISOString();
}

function formatRaw(raw: unknown, decimals: number): string {
  if (typeof raw === "number" && !Number.isSafeInteger(raw)) throw new Error("Explorer amount exceeds safe integer precision");
  const value = String(raw);
  if (!/^\d+$/.test(value)) throw new Error("Invalid balance");
  if (decimals === 0) return value.replace(/^0+(?=\d)/, "");
  const padded = value.padStart(decimals + 1, "0");
  const whole = padded.slice(0, -decimals).replace(/^0+(?=\d)/, "");
  const fraction = padded.slice(-decimals).replace(/0+$/, "");
  return fraction ? `${whole}.${fraction}` : whole;
}

function direction(address: string, from: string, to: string): Transaction["direction"] {
  const self = from.toLowerCase() === address.toLowerCase();
  return self && to.toLowerCase() === address.toLowerCase() ? "self" : self ? "out" : "in";
}

function tronAddress(value: unknown): string {
  if (typeof value !== "string" || !/^41[0-9a-f]{40}$/i.test(value)) return "";
  const bytes = Buffer.from(value, "hex");
  const digest = (buffer: Buffer) => createHash("sha256").update(buffer).digest();
  const payload = Buffer.concat([bytes, digest(digest(bytes)).subarray(0, 4)]);
  const alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  let number = BigInt(`0x${payload.toString("hex")}`), encoded = "";
  while (number > 0n) {
    encoded = alphabet[Number(number % 58n)] + encoded;
    number /= 58n;
  }
  for (const byte of payload) {
    if (byte !== 0) break;
    encoded = `1${encoded}`;
  }
  return encoded;
}

function mergeTransactions(groups: Transaction[][]): Transaction[] {
  const items = groups.flat().sort((a, b) => b.timestamp.localeCompare(a.timestamp));
  const seen = new Set<string>();
  return items.filter((item) => {
    // Prefer a token transfer over a zero-value contract call for the same hash.
    if (seen.has(item.hash)) return false;
    seen.add(item.hash);
    return true;
  }).slice(0, TRANSACTION_LIMIT);
}

async function getJson(url: string): Promise<unknown> {
  const response = await fetch(url, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(12_000) });
  if (!response.ok) throw new Error(`Explorer HTTP ${response.status}`);
  return response.json();
}

async function evmApi(base: string, action: string, address: string, extra: Record<string, string> = {}): Promise<unknown> {
  const url = new URL(base);
  url.searchParams.set("module", "account");
  url.searchParams.set("action", action);
  url.searchParams.set("address", address);
  for (const [key, value] of Object.entries(extra)) url.searchParams.set(key, value);
  const body = object(await getJson(url.toString()));
  if (body.status === "0" && Array.isArray(body.result) && body.result.length === 0) return [];
  if (body.status === "0" && body.result === "No transactions found"
    && ["txlist", "tokentx"].includes(action)) return [];
  if (body.status !== "1") throw new Error(`Explorer ${action} unavailable`);
  return body.result;
}

function evmItems(items: unknown, address: string, token: boolean, network: Network): Transaction[] {
  return array(items).map((value) => {
    const row = object(value);
    const timestamp = time(row.timeStamp, "s");
    if (!timestamp || typeof row.hash !== "string") throw new Error("Invalid explorer transaction");
    const from = typeof row.from === "string" ? row.from : "";
    const to = typeof row.to === "string" ? row.to : "";
    const decimals = token ? Number(row.tokenDecimal) : 18;
    return {
      hash: row.hash,
      timestamp,
      from, to,
      symbol: token ? String(row.tokenSymbol ?? "Token") : symbol[network],
      amount: row.value === "0" && typeof row.input === "string" && row.input !== "0x"
        ? null : Number.isInteger(decimals) && decimals >= 0 && decimals <= 30 && row.value !== undefined
        ? formatRaw(row.value, decimals) : null,
      direction: direction(address, from, to),
    };
  });
}

async function evmOverview(network: "bsc" | "ethereum", address: string, base: string, provider: string): Promise<WalletOverview> {
  const latest = { page: "1", offset: String(TRANSACTION_LIMIT), sort: "desc" };
  const earliest = { page: "1", offset: "1", sort: "asc" };
  const calls = [
    () => evmApi(base, "balance", address, { tag: "latest" }),
    () => evmApi(base, "tokenbalance", address, { contractaddress: USDT[network], tag: "latest" }),
    () => evmApi(base, "txlist", address, latest),
    () => evmApi(base, "tokentx", address, latest),
    () => evmApi(base, "txlist", address, earliest),
    () => evmApi(base, "tokentx", address, earliest),
  ];
  // Keep anonymous explorer requests below the usual free-tier per-second quota.
  const outcomes = await Promise.all(calls.map(async (call, i) => {
    await new Promise((resolve) => setTimeout(resolve, i * 260));
    try { return { ok: true as const, value: await call() }; }
    catch { return { ok: false as const }; }
  }));
  const value = (index: number) => outcomes[index].ok ? outcomes[index].value : null;
  const oldest = [value(4) === null ? [] : evmItems(value(4), address, false, network),
    value(5) === null ? [] : evmItems(value(5), address, true, network)].flat()
    .sort((a, b) => a.timestamp.localeCompare(b.timestamp))[0]?.timestamp ?? null;
  const normal = value(2) === null ? [] : evmItems(value(2), address, false, network);
  const tokens = value(3) === null ? [] : evmItems(value(3), address, true, network);
  const nativeBalance = value(0) === null ? null : formatRaw(value(0), 18);
  const usdtBalance = value(1) === null ? null : formatRaw(value(1), network === "bsc" ? 18 : 6);
  const available = outcomes.filter((outcome) => outcome.ok).length;
  return {
    provider, status: available === 6 ? "checked" : available ? "partial" : "unavailable",
    checkedAt: available ? new Date().toISOString() : null,
    nativeSymbol: symbol[network], nativeBalance, usdtBalance,
    firstActivityAt: outcomes[4].ok && outcomes[5].ok ? oldest : null,
    firstActivityKind: outcomes[4].ok && outcomes[5].ok && oldest ? "earliest_observed" : null,
    transactions: mergeTransactions([tokens, normal]),
  };
}

async function bscOverview(address: string): Promise<WalletOverview> {
  const key = process.env.BINPLORER_API_KEY?.trim() || "freekey";
  const url = (route: string, params: Record<string, string> = {}) => {
    const result = new URL(`https://api.binplorer.com/${route}/${encodeURIComponent(address)}`);
    result.searchParams.set("apiKey", key);
    for (const [name, value] of Object.entries(params)) result.searchParams.set(name, value);
    return result.toString();
  };
  // The shared development key allows only two requests per second.
  const result = await Promise.allSettled([
    getJson(url("getAddressInfo", { token: USDT.bsc })),
    (async () => { await new Promise((resolve) => setTimeout(resolve, 600)); return getJson(url("getAddressTransactions", { limit: String(TRANSACTION_LIMIT), showZeroValues: "true" })); })(),
    (async () => { await new Promise((resolve) => setTimeout(resolve, 1200)); return getJson(url("getAddressHistory", { limit: String(TRANSACTION_LIMIT) })); })(),
  ]);
  const info = result[0].status === "fulfilled" ? object(result[0].value) : null;
  const nativeBalance = info ? formatRaw(object(info.ETH).rawBalance, 18) : null;
  const holdings = info?.tokens ? array(info.tokens) : [];
  const usdt = holdings.find((entry) => String(object(object(entry).tokenInfo).address).toLowerCase() === USDT.bsc.toLowerCase());
  const usdtBalance = info ? usdt ? formatRaw(object(usdt).rawBalance, 18) : "0" : null;
  const contractCreation = info?.contractInfo ? time(object(info.contractInfo).creationTimestamp, "s") : null;
  const normal = result[1].status === "fulfilled" ? array(result[1].value).map((entry) => {
    const row = object(entry);
    const timestamp = time(row.timestamp, "s");
    if (!timestamp || typeof row.hash !== "string") throw new Error("Invalid BNB transaction");
    const from = String(row.from ?? ""), to = String(row.to ?? "");
    return { hash: row.hash, timestamp, from, to, symbol: "BNB",
      amount: row.rawValue == null || (String(row.rawValue) === "0" && typeof row.input === "string" && row.input !== "0x")
        ? null : formatRaw(row.rawValue, 18),
      direction: direction(address, from, to) } satisfies Transaction;
  }) : [];
  const transfers = result[2].status === "fulfilled" ? array(object(result[2].value).operations).map((entry) => {
    const row = object(entry), token = object(row.tokenInfo);
    const timestamp = time(row.timestamp, "s");
    if (!timestamp || typeof row.transactionHash !== "string") throw new Error("Invalid BNB transfer");
    const from = String(row.from ?? ""), to = String(row.to ?? "");
    const decimals = Number(token.decimals);
    return { hash: row.transactionHash, timestamp, from, to, symbol: String(token.symbol ?? "Token"),
      amount: Number.isInteger(decimals) && decimals >= 0 && decimals <= 30
        ? formatRaw(row.value, decimals) : null,
      direction: direction(address, from, to) } satisfies Transaction;
  }) : [];
  const available = result.filter((part) => part.status === "fulfilled").length;
  return {
    provider: "Binplorer", status: available === 3 && contractCreation ? "checked" : available ? "partial" : "unavailable",
    checkedAt: available ? new Date().toISOString() : null,
    nativeSymbol: "BNB", nativeBalance, usdtBalance,
    // Binplorer's public history is time-limited: do not present its oldest page as the wallet's first activity.
    firstActivityAt: contractCreation, firstActivityKind: contractCreation ? "contract_creation" : null,
    transactions: mergeTransactions([transfers, normal]),
  };
}

async function tronOverview(address: string): Promise<WalletOverview> {
  const base = `https://api.trongrid.io/v1/accounts/${encodeURIComponent(address)}`;
  const results = await Promise.allSettled([
    getJson(base),
    getJson(`${base}/transactions?limit=${TRANSACTION_LIMIT}&only_confirmed=true`),
    getJson(`${base}/transactions/trc20?limit=${TRANSACTION_LIMIT}&only_confirmed=true`),
  ]);
  const get = (i: number) => {
    if (results[i].status !== "fulfilled") return null;
    const body = object(results[i].value);
    if (body.success !== true) throw new Error("TronGrid returned an invalid response");
    return array(body.data);
  };
  const account = get(0)?.[0] ? object(get(0)![0]) : null;
  const nativeBalance = account ? formatRaw(account.balance ?? 0, 6) : null;
  const trc20 = account?.trc20 ? array(account.trc20) : [];
  const token = trc20.find((value) => Object.keys(object(value)).some((key) => key === USDT.tron));
  const usdtBalance = account ? formatRaw(token ? object(token)[USDT.tron] : "0", 6) : null;
  const activation = account ? time(account.create_time, "ms") : null;
  const transfers = (get(2) ?? []).map((item) => {
    const row = object(item), tokenInfo = object(row.token_info);
    const timestamp = time(row.block_timestamp, "ms");
    if (!timestamp || typeof row.transaction_id !== "string") throw new Error("Invalid TRON transfer");
    const from = String(row.from ?? ""), to = String(row.to ?? "");
    const decimals = Number(tokenInfo.decimals);
    return { hash: row.transaction_id, timestamp, from, to, symbol: String(tokenInfo.symbol ?? "Token"),
      amount: Number.isInteger(decimals) && decimals >= 0 && decimals <= 30 ? formatRaw(row.value, decimals) : null,
      direction: direction(address, from, to) } satisfies Transaction;
  });
  const normal = (get(1) ?? []).map((item) => {
    const row = object(item), raw = object(row.raw_data), contract = array(raw.contract)[0];
    const details = object(object(contract).parameter);
    const values = object(details.value);
    const timestamp = time(row.block_timestamp, "ms");
    if (!timestamp || typeof row.txID !== "string") throw new Error("Invalid TRON transaction");
    const from = tronAddress(values.owner_address), to = tronAddress(values.to_address);
    const isNative = object(contract).type === "TransferContract";
    return { hash: row.txID, timestamp, from, to, symbol: "TRX",
      amount: isNative ? formatRaw(values.amount, 6) : null,
      direction: direction(address, from, to) } satisfies Transaction;
  });
  const available = results.filter((part) => part.status === "fulfilled").length;
  return {
    provider: "TronGrid", status: available === 3 ? "checked" : available ? "partial" : "unavailable",
    checkedAt: available ? new Date().toISOString() : null,
    nativeSymbol: "TRX", nativeBalance, usdtBalance,
    firstActivityAt: activation, firstActivityKind: activation ? "account_activation" : null,
    transactions: mergeTransactions([transfers, normal]),
  };
}

export async function getWalletOverview(network: Network, address: string): Promise<WalletOverview> {
  if (isOfficialDepositAddress(network, address)) return hiddenWalletOverview(network);
  if (network === "tron") return tronOverview(address);
  if (network === "bsc") {
    const key = process.env.ETHERSCAN_API_KEY?.trim();
    if (key) {
      const report = await evmOverview(network, address,
        `https://api.etherscan.io/v2/api?chainid=56&apikey=${encodeURIComponent(key)}`, "Etherscan");
      if (report.status !== "unavailable") return report;
    }
    return bscOverview(address);
  }
  return evmOverview(network, address, "https://api.routescan.io/v2/network/mainnet/evm/1/etherscan/api", "Routescan");
}

export function hiddenWalletOverview(network: Network): WalletOverview {
  return {
    provider: "AndersPay+",
    status: "hidden",
    checkedAt: null,
    nativeSymbol: symbol[network],
    nativeBalance: null,
    usdtBalance: null,
    firstActivityAt: null,
    firstActivityKind: null,
    transactions: [],
  };
}

export function unavailableWallet(network: Network): WalletOverview {
  return {
    provider: network === "tron" ? "TronGrid" : network === "bsc" ? "Binplorer" : "Routescan",
    status: "unavailable", checkedAt: null, nativeSymbol: symbol[network],
    nativeBalance: null, usdtBalance: null, firstActivityAt: null, firstActivityKind: null, transactions: [],
  };
}