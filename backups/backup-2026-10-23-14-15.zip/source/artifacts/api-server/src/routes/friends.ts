import { Router, json as expressJson } from "express";
import { Readable } from "node:stream";
import { randomUUID } from "crypto";
import { db, usersTable, friendshipsTable, friendMessagesTable, FRIEND_MSG_TTL_MS } from "@workspace/db";
import { eq, or, and, lt, sql, asc, desc } from "drizzle-orm";
import { authenticateRequest } from "../lib/jwt";
import { getTelegramChatId, sendTelegramMessageDetailed } from "../lib/telegram";
import { uploadChatMedia, downloadChatMedia, deleteItem } from "../lib/onedrive";
import {
  updateFriendChatPresence,
  isUserViewingFriendChat,
  isOnNotifCooldown,
  markNotified,
} from "../lib/presence";

const router = Router();

const MAX_MSG_BODY = 2000;
// Large body limit for the upload-in-message endpoint (base64 video can be large)
const uploadJsonParser = expressJson({ limit: "200mb" });

const FRIENDS_URL = "https://anderspay.com/friends";

function escapeHtml(value: string): string {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function notifyFriendRequest(
  receiver: { telegramChatId: string | null; telegramId: string | null },
  requester: { name: string; nickname: string | null; uid: string | null },
): void {
  const chatId = getTelegramChatId(receiver);
  if (!chatId) return;

  const displayName = requester.nickname || requester.name;
  const text =
    `👥 <b>Bạn có lời mời kết bạn mới</b>\n\n` +
    `👤 <b>${escapeHtml(displayName)}</b>\n` +
    `🆔 UID: <code>${escapeHtml(requester.uid ?? "—")}</code>\n\n` +
    `👉 <a href="${FRIENDS_URL}">Mở AndersPay+ để xem và phản hồi</a>`;

  void sendTelegramMessageDetailed(text, chatId).catch(() => {});
}

/** Canonical friendship id between two users: smaller UUID is always requesterId. */
function canonicalPair(a: string, b: string): { requesterId: string; receiverId: string } {
  return a < b ? { requesterId: a, receiverId: b } : { requesterId: b, receiverId: a };
}

/** Resolve friendship row where either column matches userId. */
function friendshipWhere(friendshipId: string, userId: string) {
  return and(
    eq(friendshipsTable.id, friendshipId),
    or(
      eq(friendshipsTable.requesterId, userId),
      eq(friendshipsTable.receiverId, userId)
    )
  );
}

async function requireUser(req: Parameters<typeof authenticateRequest>[0]) {
  const payload = await authenticateRequest(req);
  if (!payload) return null;
  const [u] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId))
    .limit(1);
  return u ?? null;
}

function parseDeletedForUserIds(value: string | null | undefined): string[] {
  if (!value) return [];
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed)
      ? parsed.filter((id): id is string => typeof id === "string")
      : [];
  } catch {
    return [];
  }
}

// ── Search ─────────────────────────────────────────────────────────

/** GET /friends/search?uid=0981234567 */
router.get("/friends/search", async (req, res) => {
  const me = await requireUser(req);
  if (!me) { res.status(401).json({ error: "unauthorized" }); return; }

  const uid = typeof req.query.uid === "string" ? req.query.uid.trim() : "";
  if (!uid) { res.status(400).json({ error: "uid_required" }); return; }
  if (!/^\d{1,9}$/.test(uid)) {
    res.status(400).json({ error: "invalid_uid", message: "UID phải chỉ gồm tối đa 9 chữ số" });
    return;
  }

  const [target] = await db
    .select({ id: usersTable.id, uid: usersTable.uid, name: usersTable.name, nickname: usersTable.nickname, avatarUrl: usersTable.avatarUrl })
    .from(usersTable)
    .where(eq(usersTable.uid, uid))
    .limit(1);

  if (!target) { res.status(404).json({ error: "not_found" }); return; }
  if (target.id === me.id) { res.status(400).json({ error: "cannot_add_self" }); return; }

  const { requesterId, receiverId } = canonicalPair(me.id, target.id);
  const [fs] = await db
    .select()
    .from(friendshipsTable)
    .where(and(eq(friendshipsTable.requesterId, requesterId), eq(friendshipsTable.receiverId, receiverId)))
    .limit(1);

  res.json({
    user: target,
    friendship: fs
      ? { id: fs.id, status: fs.status, iAmRequester: fs.requesterId === me.id }
      : null,
  });
});

// ── Friend list ─────────────────────────────────────────────────────

/** GET /friends */
router.get("/friends", async (req, res) => {
  const me = await requireUser(req);
  if (!me) { res.status(401).json({ error: "unauthorized" }); return; }

  const rows = await db
    .select()
    .from(friendshipsTable)
    .where(
      and(
        eq(friendshipsTable.status, "accepted"),
        or(eq(friendshipsTable.requesterId, me.id), eq(friendshipsTable.receiverId, me.id))
      )
    )
    .orderBy(desc(friendshipsTable.updatedAt));

  const peerIds = rows.map((r) => (r.requesterId === me.id ? r.receiverId : r.requesterId));

  const peers =
    peerIds.length === 0
      ? []
      : await db
          .select({ id: usersTable.id, uid: usersTable.uid, name: usersTable.name, nickname: usersTable.nickname, avatarUrl: usersTable.avatarUrl })
          .from(usersTable)
          .where(sql`${usersTable.id} = ANY(ARRAY[${sql.join(peerIds.map((id) => sql`${id}`), sql`, `)}]::text[])`);

  const peerMap = new Map(peers.map((p) => [p.id, p]));

  res.json(
    rows.map((r) => {
      const peerId = r.requesterId === me.id ? r.receiverId : r.requesterId;
      return { friendship: r, peer: peerMap.get(peerId) ?? null };
    })
  );
});

// ── Recent conversations ─────────────────────────────────────────────

/** GET /friends/recent — the ten most recently active friend chats. */
router.get("/friends/recent", async (req, res): Promise<void> => {
  const me = await requireUser(req);
  if (!me) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }

  const rows = await db.execute<{
    friendship_id: string;
    peer_id: string;
    peer_uid: string | null;
    peer_name: string;
    peer_nickname: string | null;
    peer_avatar_url: string | null;
    last_body: string | null;
    last_image_url: string | null;
    last_media_mime_type: string | null;
    last_at: Date | string;
  }>(sql`
    SELECT
      f.id AS friendship_id,
      peer.id AS peer_id,
      peer.uid AS peer_uid,
      peer.name AS peer_name,
      peer.nickname AS peer_nickname,
      peer.avatar_url AS peer_avatar_url,
      latest.body AS last_body,
      latest.image_url AS last_image_url,
      latest.media_mime_type AS last_media_mime_type,
      latest.created_at AS last_at
    FROM friendships f
    JOIN users peer
      ON peer.id = CASE
        WHEN f.requester_id = ${me.id} THEN f.receiver_id
        ELSE f.requester_id
      END
    JOIN LATERAL (
      SELECT
        fm.body,
        fm.image_url,
        fm.media_mime_type,
        fm.created_at
      FROM friend_messages fm
      WHERE fm.friendship_id = f.id
        AND fm.created_at >= NOW() - INTERVAL '24 hours'
        AND NOT (
          COALESCE(fm.deleted_for_user_ids, '[]')::jsonb ? ${me.id}
        )
      ORDER BY fm.created_at DESC
      LIMIT 1
    ) latest ON true
    WHERE f.status = 'accepted'
      AND (f.requester_id = ${me.id} OR f.receiver_id = ${me.id})
    ORDER BY latest.created_at DESC
    LIMIT 10
  `);

  const list = (Array.isArray(rows) ? rows : (rows as { rows?: unknown[] }).rows ?? []) as Array<{
    friendship_id: string;
    peer_id: string;
    peer_uid: string | null;
    peer_name: string;
    peer_nickname: string | null;
    peer_avatar_url: string | null;
    last_body: string | null;
    last_image_url: string | null;
    last_media_mime_type: string | null;
    last_at: Date | string;
  }>;

  res.json({
    conversations: list.map((row) => ({
      friendshipId: row.friendship_id,
      peer: {
        id: row.peer_id,
        uid: row.peer_uid,
        name: row.peer_name,
        nickname: row.peer_nickname,
        avatarUrl: row.peer_avatar_url,
      },
      lastBody: row.last_body,
      lastImageUrl: row.last_image_url,
      lastMediaMimeType: row.last_media_mime_type,
      lastAt: row.last_at,
    })),
  });
});

// ── Incoming requests ───────────────────────────────────────────────

/** GET /friends/requests */
router.get("/friends/requests", async (req, res) => {
  const me = await requireUser(req);
  if (!me) { res.status(401).json({ error: "unauthorized" }); return; }

  const rows = await db
    .select()
    .from(friendshipsTable)
    .where(and(eq(friendshipsTable.receiverId, me.id), eq(friendshipsTable.status, "pending")))
    .orderBy(desc(friendshipsTable.createdAt));

  const requesterIds = rows.map((r) => r.requesterId);
  const requesters =
    requesterIds.length === 0
      ? []
      : await db
          .select({ id: usersTable.id, uid: usersTable.uid, name: usersTable.name, nickname: usersTable.nickname, avatarUrl: usersTable.avatarUrl })
          .from(usersTable)
          .where(sql`${usersTable.id} = ANY(ARRAY[${sql.join(requesterIds.map((id) => sql`${id}`), sql`, `)}]::text[])`);

  const requesterMap = new Map(requesters.map((u) => [u.id, u]));

  res.json(
    rows.map((r) => ({
      friendship: r,
      requester: requesterMap.get(r.requesterId) ?? null,
    }))
  );
});

// ── Send request ────────────────────────────────────────────────────

/** POST /friends/request  { targetUserId } */
router.post("/friends/request", async (req, res) => {
  const me = await requireUser(req);
  if (!me) { res.status(401).json({ error: "unauthorized" }); return; }

  const targetUserId = typeof req.body?.targetUserId === "string" ? req.body.targetUserId.trim() : "";
  if (!targetUserId) { res.status(400).json({ error: "targetUserId_required" }); return; }
  if (targetUserId === me.id) { res.status(400).json({ error: "cannot_add_self" }); return; }

  const [target] = await db
    .select({
      id: usersTable.id,
      name: usersTable.name,
      nickname: usersTable.nickname,
      uid: usersTable.uid,
      telegramChatId: usersTable.telegramChatId,
      telegramId: usersTable.telegramId,
    })
    .from(usersTable)
    .where(eq(usersTable.id, targetUserId))
    .limit(1);
  if (!target) { res.status(404).json({ error: "user_not_found" }); return; }

  const { requesterId, receiverId } = canonicalPair(me.id, targetUserId);

  const [existing] = await db
    .select()
    .from(friendshipsTable)
    .where(and(eq(friendshipsTable.requesterId, requesterId), eq(friendshipsTable.receiverId, receiverId)))
    .limit(1);

  if (existing) {
    if (existing.status === "accepted") { res.status(409).json({ error: "already_friends", friendship: existing }); return; }
    if (existing.status === "pending") { res.status(409).json({ error: "request_pending", friendship: existing }); return; }
    const [updated] = await db
      .update(friendshipsTable)
      .set({ status: "pending", requesterId: me.id, receiverId: targetUserId, updatedAt: new Date() })
      .where(eq(friendshipsTable.id, existing.id))
      .returning();
    notifyFriendRequest(target, me);
    res.json({ friendship: updated });
    return;
  }

  const [created] = await db
    .insert(friendshipsTable)
    .values({ id: randomUUID(), requesterId: me.id, receiverId: targetUserId, status: "pending" })
    .returning();

  notifyFriendRequest(target, me);
  res.json({ friendship: created });
});

// ── Accept / Decline ────────────────────────────────────────────────

/** POST /friends/:id/accept */
router.post("/friends/:id/accept", async (req, res) => {
  const me = await requireUser(req);
  if (!me) { res.status(401).json({ error: "unauthorized" }); return; }

  const [fs] = await db.select().from(friendshipsTable).where(friendshipWhere(req.params.id, me.id)).limit(1);

  if (!fs) { res.status(404).json({ error: "not_found" }); return; }
  if (fs.receiverId !== me.id) { res.status(403).json({ error: "only_receiver_can_accept" }); return; }
  if (fs.status !== "pending") { res.status(409).json({ error: "not_pending" }); return; }

  const [updated] = await db
    .update(friendshipsTable)
    .set({ status: "accepted", updatedAt: new Date() })
    .where(eq(friendshipsTable.id, fs.id))
    .returning();

  res.json({ friendship: updated });
});

/** POST /friends/:id/decline */
router.post("/friends/:id/decline", async (req, res) => {
  const me = await requireUser(req);
  if (!me) { res.status(401).json({ error: "unauthorized" }); return; }

  const [fs] = await db.select().from(friendshipsTable).where(friendshipWhere(req.params.id, me.id)).limit(1);

  if (!fs) { res.status(404).json({ error: "not_found" }); return; }
  if (fs.receiverId !== me.id) { res.status(403).json({ error: "only_receiver_can_decline" }); return; }
  if (fs.status !== "pending") { res.status(409).json({ error: "not_pending" }); return; }

  const [updated] = await db
    .update(friendshipsTable)
    .set({ status: "declined", updatedAt: new Date() })
    .where(eq(friendshipsTable.id, fs.id))
    .returning();

  res.json({ friendship: updated });
});

// ── Remove friend ───────────────────────────────────────────────────

/** DELETE /friends/:id */
router.delete("/friends/:id", async (req, res) => {
  const me = await requireUser(req);
  if (!me) { res.status(401).json({ error: "unauthorized" }); return; }

  const [fs] = await db.select().from(friendshipsTable).where(friendshipWhere(req.params.id, me.id)).limit(1);

  if (!fs) { res.status(404).json({ error: "not_found" }); return; }

  await db.delete(friendMessagesTable).where(eq(friendMessagesTable.friendshipId, fs.id));
  await db.delete(friendshipsTable).where(eq(friendshipsTable.id, fs.id));

  res.json({ ok: true });
});

// ── Friend-chat presence heartbeat ──────────────────────────────────

/**
 * POST /friends/:id/presence
 * Called by the frontend every 20 s while the user has the chat open.
 * No body required. Returns 204.
 */
router.post("/friends/:id/presence", async (req, res) => {
  const me = await requireUser(req);
  if (!me) { res.status(401).json({ error: "unauthorized" }); return; }

  const [fs] = await db
    .select({ id: friendshipsTable.id })
    .from(friendshipsTable)
    .where(friendshipWhere(req.params.id, me.id))
    .limit(1);

  if (!fs) { res.status(404).json({ error: "not_found" }); return; }

  updateFriendChatPresence(me.id, fs.id);
  res.status(204).end();
});

// ── Peer messages ───────────────────────────────────────────────────

const ttlCutoff = () => new Date(Date.now() - FRIEND_MSG_TTL_MS);

/** GET /friends/:id/messages */
router.get("/friends/:id/messages", async (req, res) => {
  const me = await requireUser(req);
  if (!me) { res.status(401).json({ error: "unauthorized" }); return; }

  const [fs] = await db.select().from(friendshipsTable).where(friendshipWhere(req.params.id, me.id)).limit(1);

  if (!fs || fs.status !== "accepted") { res.status(403).json({ error: "not_friends" }); return; }

  const cutoff = ttlCutoff();

  // Clean expired messages (fire-and-forget)
  db.delete(friendMessagesTable)
    .where(and(eq(friendMessagesTable.friendshipId, fs.id), lt(friendMessagesTable.createdAt, cutoff)))
    .catch(() => {});

  const messages = await db
    .select()
    .from(friendMessagesTable)
    .where(and(eq(friendMessagesTable.friendshipId, fs.id), sql`${friendMessagesTable.createdAt} >= ${cutoff}`))
    .orderBy(asc(friendMessagesTable.createdAt));

  // "Delete for me" is represented as a user-id list on the message.
  // Keep the DB row (and its OneDrive media) intact for everyone else.
  const visibleMessages = messages
    .filter((message) => !parseDeletedForUserIds(message.deletedForUserIds).includes(me.id))
    .map(({ deletedForUserIds: _deletedForUserIds, ...message }) => message);

  res.json({ messages: visibleMessages, ttlMs: FRIEND_MSG_TTL_MS });
});

/**
 * POST /friends/:id/messages/delete
 * Body: { messageIds: string[], mode: "me" | "everyone" }
 *
 * "me" hides selected messages only for the current user.
 * "everyone" removes selected message records from AndersPay+ for both users.
 * Neither mode deletes media already stored on OneDrive or sends a notification.
 */
router.post("/friends/:id/messages/delete", async (req, res) => {
  const me = await requireUser(req);
  if (!me) { res.status(401).json({ error: "unauthorized" }); return; }

  const [fs] = await db
    .select()
    .from(friendshipsTable)
    .where(friendshipWhere(req.params.id, me.id))
    .limit(1);

  if (!fs || fs.status !== "accepted") {
    res.status(403).json({ error: "not_friends" });
    return;
  }

  const messageIds = Array.isArray(req.body?.messageIds)
    ? req.body.messageIds.filter((id: unknown): id is string => typeof id === "string").slice(0, 100)
    : [];
  const mode = req.body?.mode === "everyone" ? "everyone" : req.body?.mode === "me" ? "me" : null;

  if (messageIds.length === 0) {
    res.status(400).json({ error: "message_ids_required" });
    return;
  }
  if (!mode) {
    res.status(400).json({ error: "delete_mode_required" });
    return;
  }

  const selected = await db
    .select({ id: friendMessagesTable.id })
    .from(friendMessagesTable)
    .where(
      and(
        eq(friendMessagesTable.friendshipId, fs.id),
        sql`${friendMessagesTable.id} = ANY(ARRAY[${sql.join(messageIds.map((id: string) => sql`${id}`), sql`, `)}]::text[])`,
      ),
    );

  const validIds = selected.map((message) => message.id);
  if (validIds.length === 0) {
    res.json({ deletedCount: 0 });
    return;
  }

  if (mode === "everyone") {
    // Deliberately do not call deleteItem(): OneDrive media is retained.
    await db
      .delete(friendMessagesTable)
      .where(
        and(
          eq(friendMessagesTable.friendshipId, fs.id),
          sql`${friendMessagesTable.id} = ANY(ARRAY[${sql.join(validIds.map((id) => sql`${id}`), sql`, `)}]::text[])`,
        ),
      );
  } else {
    const rows = await db
      .select({
        id: friendMessagesTable.id,
        deletedForUserIds: friendMessagesTable.deletedForUserIds,
      })
      .from(friendMessagesTable)
      .where(
        and(
          eq(friendMessagesTable.friendshipId, fs.id),
          sql`${friendMessagesTable.id} = ANY(ARRAY[${sql.join(validIds.map((id) => sql`${id}`), sql`, `)}]::text[])`,
        ),
      );

    await Promise.all(
      rows.map((message) => {
        const deletedFor = new Set(parseDeletedForUserIds(message.deletedForUserIds));
        deletedFor.add(me.id);
        return db
          .update(friendMessagesTable)
          .set({ deletedForUserIds: JSON.stringify([...deletedFor]) })
          .where(eq(friendMessagesTable.id, message.id));
      }),
    );
  }

  res.json({ deletedCount: validIds.length, mode });
});

/**
 * POST /friends/:id/messages
 *
 * Text message:  { body: string }
 * Media message: { base64: string, mimeType: string, body?: string }  ← uploads to OneDrive
 *
 * Uses a large body limit (200 MB) to support video uploads via base64.
 */
router.post("/friends/:id/messages", uploadJsonParser, async (req, res) => {
  const me = await requireUser(req);
  if (!me) { res.status(401).json({ error: "unauthorized" }); return; }

  const [fs] = await db.select().from(friendshipsTable).where(friendshipWhere(req.params.id, me.id)).limit(1);

  if (!fs || fs.status !== "accepted") { res.status(403).json({ error: "not_friends" }); return; }

  const body = typeof req.body?.body === "string" ? req.body.body.trim() : "";
  const base64 = typeof req.body?.base64 === "string" ? req.body.base64 : "";
  const mimeType = typeof req.body?.mimeType === "string" ? req.body.mimeType : "";

  if (!body && !base64) { res.status(400).json({ error: "body_or_media_required" }); return; }
  if (body.length > MAX_MSG_BODY) { res.status(400).json({ error: "body_too_long" }); return; }

  const cutoff = ttlCutoff();

  // Prune expired messages on write
  await db
    .delete(friendMessagesTable)
    .where(and(eq(friendMessagesTable.friendshipId, fs.id), lt(friendMessagesTable.createdAt, cutoff)));

  let mediaUrl: string | null = null;
  let mediaMimeType: string | null = null;

  // Upload to OneDrive if media is attached
  if (base64 && mimeType) {
    try {
      const { itemId } = await uploadChatMedia(fs.id, base64, mimeType);
      // Serve via our proxy endpoint so auth is enforced
      mediaUrl = `/api/friends/${fs.id}/media/${encodeURIComponent(itemId)}`;
      mediaMimeType = mimeType;
    } catch (err) {
      req.log.error({ err }, "OneDrive upload failed");
      res.status(502).json({ error: "media_upload_failed", message: err instanceof Error ? err.message : "Upload error" });
      return;
    }
  }

  const [msg] = await db
    .insert(friendMessagesTable)
    .values({
      id: randomUUID(),
      friendshipId: fs.id,
      senderId: me.id,
      body: body || null,
      imageUrl: mediaUrl,
      mediaMimeType,
    })
    .returning();

  res.json({ message: msg });

  // ── Telegram notification (fire-and-forget) ──────────────────────
  // Find the recipient (the other participant in the friendship).
  const recipientId = fs.requesterId === me.id ? fs.receiverId : fs.requesterId;

  // Skip if the recipient is currently viewing this chat (presence heartbeat active).
  if (!isUserViewingFriendChat(recipientId, fs.id)) {
    const cooldownKey = `friend:${fs.id}:${recipientId}`;
    if (!isOnNotifCooldown(cooldownKey)) {
      const [recipient] = await db
        .select({
          telegramChatId: usersTable.telegramChatId,
          telegramId: usersTable.telegramId,
          name: usersTable.name,
          nickname: usersTable.nickname,
        })
        .from(usersTable)
        .where(eq(usersTable.id, recipientId))
        .limit(1);

      const recipientChatId = recipient ? getTelegramChatId(recipient) : null;
      if (recipientChatId) {
        const senderName = escapeHtml(me.nickname ?? me.name);
        const preview = body
          ? escapeHtml(body.length > 60 ? body.slice(0, 60) + "…" : body)
          : mediaUrl
            ? (mediaMimeType?.startsWith("video/") ? "🎥 [Video]" : "🖼 [Ảnh]")
            : "";
        const text =
          `💬 <b>Tin nhắn mới từ ${senderName}</b>\n\n` +
          (preview ? `${preview}\n\n` : "") +
          `👉 <a href="${FRIENDS_URL}">Mở AndersPay+ để xem</a>`;

        markNotified(cooldownKey);
        void sendTelegramMessageDetailed(text, recipientChatId).catch(() => {});
      }
    }
  }
});

// ── Media proxy (OneDrive) ──────────────────────────────────────────

/**
 * GET /friends/:id/media/:itemId
 *
 * Validates friendship membership, then streams the media through this API.
 * Keeping the response same-origin lets the browser load protected media
 * without exposing storage details or requiring a second cross-origin request.
 */
router.get("/friends/:id/media/:itemId", async (req, res) => {
  const me = await requireUser(req);
  if (!me) { res.status(401).json({ error: "unauthorized" }); return; }

  const [fs] = await db.select().from(friendshipsTable).where(friendshipWhere(req.params.id, me.id)).limit(1);
  if (!fs || fs.status !== "accepted") { res.status(403).json({ error: "not_friends" }); return; }

  try {
    const itemId = decodeURIComponent(req.params.itemId);
    const mediaResponse = await downloadChatMedia(itemId);
    if (!mediaResponse.ok || !mediaResponse.body) {
      req.log.warn(
        { itemId, upstreamStatus: mediaResponse.status },
        "Friend chat media is unavailable",
      );
      res.status(404).json({ error: "media_not_found" });
      return;
    }

    const contentType = mediaResponse.headers.get("content-type")?.split(";")[0];
    const contentLength = mediaResponse.headers.get("content-length");
    if (contentType) res.setHeader("Content-Type", contentType);
    if (contentLength) res.setHeader("Content-Length", contentLength);
    res.setHeader("Content-Disposition", "inline");
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Cache-Control", "private, max-age=300");
    Readable.fromWeb(mediaResponse.body as any).pipe(res);
  } catch (err) {
    req.log.warn(
      { err, itemId: req.params.itemId },
      "Friend chat media proxy failed",
    );
    res.status(404).json({ error: "media_not_found" });
  }
});

export default router;
