import { Router } from "express";
import { db, usersTable, transactionsTable } from "@workspace/db";
import { eq, desc, and, notInArray, sql } from "drizzle-orm";
import { randomUUID } from "crypto";
import { z } from "zod";
import { authenticateRequest } from "../lib/jwt";
import { getCurrentRate } from "./rates";
import { MIN_USDT_BALANCE } from "../lib/fees";
import { isAdminUser } from "../lib/admin";
import { TESTER_USER_IDS, TESTER_USER_PHONES } from "../lib/tester-accounts";
import { conversionAmounts } from "../lib/fee-allocation";

const router = Router();

router.get("/wallet", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ message: "unauthorized", code: "UNAUTHORIZED" });
    return;
  }

  // Heartbeat: this endpoint is polled every ~5s while the user has the app
  // open (home + wallet pages), so it's a cheap signal for "online".
  // Fire-and-forget so it never blocks the response.
  db.update(usersTable)
    .set({ lastSeenAt: new Date() })
    .where(eq(usersTable.id, payload.userId))
    .catch(() => {});

  const [user] = await db
    .select({
      phone: usersTable.phone,
      usdtBalance: usersTable.usdtBalance,
      thbBalance: usersTable.thbBalance,
      isAdmin: usersTable.isAdmin,
    })
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId))
    .limit(1);

  if (!user) {
    res.status(404).json({ message: "user not found", code: "NOT_FOUND" });
    return;
  }

  const isAdmin = isAdminUser(user);
  // For the admin cockpit aggregation we must exclude BOTH founding
  // admins (env-pinned phones) AND any user the DB has flagged as admin
  // — otherwise a promoted operator's balances would distort the
  // "total funds" panel meant to show member-side liquidity only.
  const adminPhones = (process.env.ADMIN_PHONES ?? "")
    .split(",").map((p) => p.trim()).filter(Boolean);
  const memberOnly = and(
    eq(usersTable.isAdmin, false),
    notInArray(usersTable.id, TESTER_USER_IDS),
    notInArray(usersTable.phone, TESTER_USER_PHONES),
    adminPhones.length > 0
      ? sql`${usersTable.phone} not in (${sql.join(adminPhones.map((p) => sql`${p}`), sql`, `)})`
      : sql`true`,
  );

  // Admin sees the SUM of all non-admin users' balances (a cockpit view of
  // total funds in the system) plus a real-time feed of every member's
  // transactions, each tagged with the owning user's UID/name so the admin
  // can tell who did what at a glance. Admin's own rows are excluded.
  if (isAdmin) {
    const aggBuilder = db
      .select({
        usdt: sql<string>`coalesce(sum(${usersTable.usdtBalance}), 0)`,
        thb: sql<string>`coalesce(sum(${usersTable.thbBalance}), 0)`,
      })
      .from(usersTable);
    const [agg] = await aggBuilder.where(memberOnly);

    const txBuilder = db
      .select({
        id: transactionsTable.id,
        type: transactionsTable.type,
        amountUsdt: transactionsTable.amountUsdt,
        referralAmountUsdt: transactionsTable.referralAmountUsdt,
        amountThb: transactionsTable.amountThb,
        rate: transactionsTable.rate,
        refOrderId: transactionsTable.refOrderId,
        createdAt: transactionsTable.createdAt,
        userUid: usersTable.uid,
        userName: usersTable.name,
      })
      .from(transactionsTable)
      .innerJoin(usersTable, eq(usersTable.id, transactionsTable.userId));
    const allTxs = await txBuilder
      .where(memberOnly)
      .orderBy(desc(transactionsTable.createdAt))
      .limit(100);

    res.json({
      usdtBalance: parseFloat(agg?.usdt ?? "0"),
      thbBalance: parseFloat(agg?.thb ?? "0"),
      transactions: allTxs.map((t) => ({
        id: t.id,
        type: t.type,
        amountUsdt: parseFloat(t.amountUsdt),
        referralAmountUsdt: t.referralAmountUsdt === null ? null : Number(t.referralAmountUsdt),
        amountThb: parseFloat(t.amountThb),
        rate: parseFloat(t.rate),
        refOrderId: t.refOrderId,
        createdAt: t.createdAt.toISOString(),
        userUid: t.userUid,
        userName: t.userName,
      })),
      isAdminAggregate: true,
    });
    return;
  }

  const txs = await db
    .select()
    .from(transactionsTable)
    .where(eq(transactionsTable.userId, payload.userId))
    .orderBy(desc(transactionsTable.createdAt))
    .limit(30);

  res.json({
    usdtBalance: parseFloat(user.usdtBalance),
    thbBalance: parseFloat(user.thbBalance),
    transactions: txs.map((t) => ({
      id: t.id,
      type: t.type,
      amountUsdt: parseFloat(t.amountUsdt),
      referralAmountUsdt: t.referralAmountUsdt === null ? null : Number(t.referralAmountUsdt),
      amountThb: parseFloat(t.amountThb),
      rate: parseFloat(t.rate),
      refOrderId: t.refOrderId,
      createdAt: t.createdAt.toISOString(),
    })),
  });
});

const ConvertBody = z.object({
  amountUsdt: z.coerce.number().positive().finite(),
});

router.post("/wallet/convert", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ message: "unauthorized", code: "UNAUTHORIZED" });
    return;
  }

  const parsed = ConvertBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Validation error", code: "VALIDATION_ERROR" });
    return;
  }
  const amountUsdt = parsed.data.amountUsdt;
  if (amountUsdt < 0.000001) {
    res.status(400).json({ message: "Amount too small", code: "AMOUNT_TOO_SMALL" });
    return;
  }

  const { thbPerUsdt: rate } = await getCurrentRate();
  if (!rate || rate <= 0) {
    res.status(503).json({ message: "Rate unavailable", code: "RATE_UNAVAILABLE" });
    return;
  }
  let amounts;
  try {
    amounts = conversionAmounts(amountUsdt, rate);
  } catch (err) {
    if (err instanceof Error && err.message === "AMOUNT_TOO_SMALL") {
      res.status(400).json({
        message: "Số tiền đổi phải nhận được ít nhất 0.01 THB.",
        code: "AMOUNT_TOO_SMALL", minThb: 0.01,
      });
      return;
    }
    throw err;
  }
  const amountUsdtStr = amounts.usdt;
  const amountThbStr = amounts.thb;
  const amountThb = Number(amountThbStr);
  const rateStr = rate.toFixed(6);

  // Atomic: conditional debit + ledger inserts in one transaction.
  // The WHERE guard on usdtBalance prevents overspending under concurrency.
  let result: { usdtBalance: string; thbBalance: string } | null = null;
  try {
    result = await db.transaction(async (tx) => {
      // Conversion is free, but the user must keep at least MIN_USDT_BALANCE
      // USDT after the debit (the "USDT gas reserve" used to pay future
      // service fees). The single WHERE clause enforces both no-overdraft
      // and the minimum-balance invariant atomically.
      const debited = await tx
        .update(usersTable)
        .set({
          usdtBalance: sql`${usersTable.usdtBalance} - ${amountUsdtStr}::numeric`,
          thbBalance: sql`${usersTable.thbBalance} + ${amountThbStr}::numeric`,
        })
        .where(
          and(
            eq(usersTable.id, payload.userId),
            sql`${usersTable.usdtBalance} - ${amountUsdtStr}::numeric >= ${MIN_USDT_BALANCE}`,
          ),
        )
        .returning({
          usdtBalance: usersTable.usdtBalance,
          thbBalance: usersTable.thbBalance,
        });

      if (debited.length === 0) {
        throw new Error("INSUFFICIENT_BALANCE");
      }

      await tx.insert(transactionsTable).values([
        {
          id: randomUUID(),
          userId: payload.userId,
          type: "convert_out",
          amountUsdt: amountUsdtStr,
          amountThb: "0",
          rate: rateStr,
          refOrderId: null,
        },
        {
          id: randomUUID(),
          userId: payload.userId,
          type: "convert_in",
          amountUsdt: "0",
          amountThb: amountThbStr,
          rate: rateStr,
          refOrderId: null,
        },
      ]);

      return debited[0];
    });
  } catch (err) {
    if (err instanceof Error && err.message === "INSUFFICIENT_BALANCE") {
      res.status(400).json({
        message: `Số dư USDT không đủ. Phải giữ tối thiểu ${MIN_USDT_BALANCE} USDT trong ví sau khi đổi.`,
        code: "INSUFFICIENT_BALANCE",
        minBalance: MIN_USDT_BALANCE,
      });
      return;
    }
    throw err;
  }

  res.json({
    ok: true,
    amountUsdt: Number(amountUsdtStr),
    amountThb,
    rate,
    usdtBalance: parseFloat(result!.usdtBalance),
    thbBalance: parseFloat(result!.thbBalance),
  });
});

export default router;
