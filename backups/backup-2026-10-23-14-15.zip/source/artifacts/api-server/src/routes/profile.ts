import { Router } from "express";
import multer from "multer";
import { db, usersTable } from "@workspace/db";
import { eq, and, isNull } from "drizzle-orm";
import { authenticateRequest } from "../lib/jwt";
import { UpdateNicknameBody, UpdateEmailBody, SetUidBody } from "@workspace/api-zod";

const router = Router();

// Avatars are stored as base64 data URLs directly in the user row so they
// survive container restarts / redeploys (local disk is ephemeral on Replit).
// 1 MB upload cap keeps the DB row reasonable.
const avatarUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 1 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = ["image/jpeg", "image/png", "image/webp", "image/gif"];
    cb(null, allowed.includes(file.mimetype));
  },
});

// PATCH /api/profile/name
// Body: { name }
// Auth: Bearer JWT
// Set-once: rejects with 409 if user has already updated their legal name
// (i.e. `nameUpdatedAt` is set). The original registration name does NOT
// count as a use of the one-time edit.
router.patch("/profile/name", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const raw = (req.body as { name?: unknown }).name;
  if (typeof raw !== "string") {
    res.status(400).json({ error: "invalid_name" });
    return;
  }
  const trimmed = raw.trim();
  if (trimmed.length < 2 || trimmed.length > 60) {
    res.status(400).json({ error: "invalid_name" });
    return;
  }

  const [current] = await db
    .select({ nameUpdatedAt: usersTable.nameUpdatedAt })
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId))
    .limit(1);
  if (!current) {
    res.status(404).json({ error: "user not found" });
    return;
  }
  if (current.nameUpdatedAt) {
    res.status(409).json({
      error: "name_already_updated",
      message: "Họ tên thật đã được cập nhật và không thể thay đổi thêm.",
    });
    return;
  }

  const [user] = await db
    .update(usersTable)
    .set({ name: trimmed, nameUpdatedAt: new Date() })
    .where(eq(usersTable.id, payload.userId))
    .returning();
  res.json({
    ok: true,
    name: user.name,
    nameUpdatedAt: user.nameUpdatedAt?.toISOString() ?? null,
  });
});

// PATCH /api/profile/nickname
// Body: { nickname }
// Auth: Bearer JWT
router.patch("/profile/nickname", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const parsed = UpdateNicknameBody.safeParse(req.body);
  if (!parsed.success || !parsed.data.nickname.trim()) {
    res.status(400).json({ error: "nickname required", details: parsed.success ? undefined : parsed.error.flatten().fieldErrors });
    return;
  }
  const trimmed = parsed.data.nickname.trim().slice(0, 30);
  const [user] = await db
    .update(usersTable)
    .set({ nickname: trimmed })
    .where(eq(usersTable.id, payload.userId))
    .returning();
  if (!user) {
    res.status(404).json({ error: "user not found" });
    return;
  }
  res.json({ ok: true, nickname: user.nickname });
});

// POST /api/profile/avatar
// Form: avatar (file)
// Auth: Bearer JWT
router.post("/profile/avatar", avatarUpload.single("avatar"), async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  if (!req.file) {
    res.status(400).json({ error: "No image file provided" });
    return;
  }

  const mime = req.file.mimetype || "image/jpeg";
  const b64 = req.file.buffer.toString("base64");
  const avatarUrl = `data:${mime};base64,${b64}`;

  const [user] = await db
    .update(usersTable)
    .set({ avatarUrl })
    .where(eq(usersTable.id, payload.userId))
    .returning();

  if (!user) {
    res.status(404).json({ error: "user not found" });
    return;
  }

  res.json({ ok: true, avatarUrl: user.avatarUrl });
});

// PATCH /api/profile/email
router.patch("/profile/email", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const parsed = UpdateEmailBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "valid email required", details: parsed.error.flatten().fieldErrors });
    return;
  }
  const email = parsed.data.email.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    res.status(400).json({ error: "invalid_email" });
    return;
  }
  const [user] = await db
    .update(usersTable)
    .set({ email, emailVerified: false, emailVerifiedAt: null })
    .where(eq(usersTable.id, payload.userId))
    .returning();
  if (!user) {
    res.status(404).json({ error: "user not found" });
    return;
  }
  res.json({ ok: true, email: user.email });
});

// PATCH /api/profile/dob
// Body: { dob: "YYYY-MM-DD" | null }   (null clears it)
router.patch("/profile/dob", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const raw = (req.body as { dob?: unknown }).dob;
  let dob: string | null = null;
  if (raw !== null && raw !== undefined && raw !== "") {
    if (typeof raw !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
      res.status(400).json({ error: "invalid_dob" });
      return;
    }
    const d = new Date(raw + "T00:00:00Z");
    // Reject impossible calendar dates (e.g. 2024-02-31) — JS Date silently
    // normalises them, so we round-trip back to YYYY-MM-DD and require equality.
    const roundTrip = Number.isNaN(d.getTime()) ? "" : d.toISOString().slice(0, 10);
    const year = d.getUTCFullYear();
    if (roundTrip !== raw || year < 1900 || d.getTime() > Date.now()) {
      res.status(400).json({ error: "invalid_dob" });
      return;
    }
    dob = raw;
  }
  const [user] = await db
    .update(usersTable)
    .set({ dob })
    .where(eq(usersTable.id, payload.userId))
    .returning();
  if (!user) {
    res.status(404).json({ error: "user not found" });
    return;
  }
  res.json({ ok: true, dob: user.dob });
});

// PATCH /api/profile/uid
// Body: { uid: "098XXXXXX" } — exactly 9 digits, must start with 098.
//
// PERMANENT: a user may set their UID exactly once. Once stored, the
// `uid` column is locked — the route returns 409 `uid_permanent` on
// any subsequent attempt. The frontend mirrors this lock, but server
// enforcement is the source of truth so a tampered client cannot
// bypass it. Still returns 409 `uid_taken` if another user already
// holds the requested UID.
router.patch("/profile/uid", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const parsed = SetUidBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "invalid_uid", details: parsed.error.flatten().fieldErrors });
    return;
  }
  const uid = parsed.data.uid.trim();
  // Server-side format check (defence in depth — the Zod schema above
  // already enforces the same regex, but we re-check after .trim()).
  if (!/^098\d{6}$/.test(uid)) {
    res.status(400).json({ error: "invalid_uid" });
    return;
  }

  // Permanence guard: refuse to overwrite an existing UID. We read
  // the current row first so we can return a clear error, then write
  // with a `WHERE uid IS NULL` predicate so the update is atomic
  // even under concurrent requests from the same account.
  const [current] = await db
    .select({ uid: usersTable.uid })
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId))
    .limit(1);
  if (!current) {
    res.status(404).json({ error: "user not found" });
    return;
  }
  if (current.uid && /^098\d{6}$/.test(current.uid)) {
    res.status(409).json({
      error: "uid_permanent",
      message: "Your UID is permanent and cannot be changed.",
    });
    return;
  }

  try {
    const [user] = await db
      .update(usersTable)
      .set({ uid })
      .where(and(eq(usersTable.id, payload.userId), isNull(usersTable.uid)))
      .returning();
    if (!user) {
      // Lost the race: another request set the UID between our SELECT
      // and UPDATE. Treat as permanent for consistency.
      res.status(409).json({
        error: "uid_permanent",
        message: "Your UID is permanent and cannot be changed.",
      });
      return;
    }
    res.json({ ok: true, uid: user.uid });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "";
    if (msg.includes("unique") || msg.includes("duplicate")) {
      res.status(409).json({ error: "uid_taken", message: "This UID already exists. Please choose another UID." });
      return;
    }
    throw err;
  }
});

// GET /api/referral/info — returns the authenticated user's referral
// stats so the Settings → Referral card can render them. The user's own
// AndersPay UID doubles as the referral code (no separate ID).
router.get("/referral/info", async (req, res) => {
  const payload = await authenticateRequest(req);
  if (!payload) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  const [user] = await db
    .select({
      uid: usersTable.uid,
      referredBy: usersTable.referredBy,
      referralRewardBalance: usersTable.referralRewardBalance,
      totalReferralEarned: usersTable.totalReferralEarned,
      referralCount: usersTable.referralCount,
    })
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId))
    .limit(1);
  if (!user) {
    res.status(404).json({ error: "user not found" });
    return;
  }
  res.json({
    uid: user.uid,
    referredBy: user.referredBy,
    referralRewardBalance: parseFloat(user.referralRewardBalance),
    totalReferralEarned: parseFloat(user.totalReferralEarned),
    referralCount: user.referralCount,
    rewardPerReferral: 10,
  });
});

export default router;
