/**
 * receipt-redesign/Current.tsx
 *
 * Static baseline snapshot of the LocalPay "completed THB payment" receipt
 * as rendered by artifacts/localpay/src/pages/status.tsx when
 * order.status === "completed" and the order is a THB payment (not a deposit).
 *
 * All external dependencies (router, API, auth, translations, UI primitives,
 * fee helpers) are stubbed with realistic static data so this component is
 * fully self-contained and imports NOTHING from artifacts/localpay.
 */

import "./_group.css";
import { CheckCircle2 } from "lucide-react";

// ─── Static order fixture ──────────────────────────────────────────────────

const ORDER = {
  id:            "a3f1b2c4-d5e6-7890-abcd-ef1234567890",
  status:        "completed" as const,
  amountThb:     3500,
  amountUsdt:    97.36,
  exchangeRate:  35.95,
  accountName:   "Somchai Jaidee",
  accountNumber: "0123456789",
  bankName:      "Kasikorn Bank",
  createdAt:     "2025-05-04T09:15:00.000Z",
  updatedAt:     "2025-05-04T09:17:42.000Z",
  walletAddress: "",  // THB payment — no deposit wallet address
};

// ─── Fee helper stub ───────────────────────────────────────────────────────
// Mirrors artifacts/localpay/src/lib/fees.ts payFeeUsdt logic.

function billFeeThb(amountThb: number): number {
  if (amountThb <= 0) return 0;
  const tiers = [
    { upTo: 1000, fee: 15 },
    { upTo: 5000, fee: 20 },
    { upTo: 10000, fee: 25 },
  ] as const;
  for (const tier of tiers) {
    if (amountThb < tier.upTo) return tier.fee;
  }
  return 30;
}

function onchainFeeThb(amountThb: number): number {
  return Math.round(amountThb * 0.0015 * 100) / 100;
}

function payFeeThb(amountThb: number): number {
  return parseFloat((billFeeThb(amountThb) + onchainFeeThb(amountThb)).toFixed(6));
}

function payFeeUsdt(amountThb: number, rate: number): number {
  if (rate <= 0) return 0;
  return parseFloat((payFeeThb(amountThb) / rate).toFixed(6));
}

// ─── Date helpers ─────────────────────────────────────────────────────────

function formatBillDate(iso: string): string {
  const d = new Date(iso);
  const time = d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false });
  const date = d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  return `${time} ${date}`;
}

function shortId(id: string): string {
  if (!id) return "";
  const clean = id.replace(/-/g, "");
  return `${clean.slice(0, 7)}...${clean.slice(-4)}`;
}

// ─── Row sub-component ────────────────────────────────────────────────────

function Row({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="lp-row">
      <span className="lp-row-label">{label}</span>
      <span className={`lp-row-value${mono ? " lp-row-value-mono" : ""}`}>{value}</span>
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────

export default function Current() {
  const order = ORDER;

  const feeUsdt = payFeeUsdt(order.amountThb, order.exchangeRate);

  return (
    // Outer wrapper applies LocalPay dark-theme tokens via _group.css
    <div className="lp-receipt-scope" style={{ minHeight: "100vh", padding: "0 1rem" }}>
      {/* Phone-width centering column */}
      <div style={{ maxWidth: 390, margin: "0 auto", paddingBottom: "2rem", paddingTop: "2rem" }}>

        {/* ── Success badge + hero amount ── */}
        <div
          style={{
            display:        "flex",
            flexDirection:  "column",
            alignItems:     "center",
            paddingTop:     "1rem",
            gap:            "0.75rem",
            marginBottom:   "1.5rem",
          }}
        >
          {/* Green pill badge */}
          <div
            style={{
              display:       "flex",
              alignItems:    "center",
              gap:           "0.5rem",
              padding:       "0.5rem 1rem",
              borderRadius:  "9999px",
              background:    "rgba(34,197,94,0.10)",
              border:        "1px solid rgba(34,197,94,0.30)",
            }}
          >
            <CheckCircle2 style={{ width: "1.25rem", height: "1.25rem", color: "#4ade80" }} />
            <span style={{ fontSize: "0.875rem", fontWeight: 700, color: "#4ade80" }}>
              Payment successful
            </span>
          </div>

          {/* Hero amount */}
          <h1
            style={{
              fontSize:      "3rem",
              fontWeight:    800,
              letterSpacing: "-0.02em",
              color:         "hsl(var(--foreground))",
              margin:        0,
              fontVariantNumeric: "tabular-nums",
            }}
          >
            -{order.amountThb.toLocaleString("en-US", { maximumFractionDigits: 2 })}
            {" "}
            <span style={{ fontSize: "1.875rem", color: "hsl(var(--foreground))", opacity: 0.85 }}>
              ฿
            </span>
          </h1>
        </div>

        {/* ── Receipt card ── */}
        <div className="lp-card lp-card-divide" style={{ marginBottom: "1.5rem" }}>
          <Row label="Recipient"      value={order.accountName} />
          <Row
            label="Fee"
            value={`${feeUsdt.toFixed(2)} USDT`}
            mono
          />
          <Row label="Date"           value={formatBillDate(order.createdAt)} />
          <Row label="Internal ID"    value={shortId(order.id)} mono />
          <Row label="Account Number" value={order.accountNumber} mono />
          <Row label="Bank"           value={order.bankName} />
          <Row label="Confirmed at"   value={formatBillDate(order.updatedAt)} />
        </div>

        {/* ── Action buttons ── */}
        <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
          <button className="lp-btn-primary" type="button">
            Back to home
          </button>
          <button className="lp-btn-outline" type="button">
            Open wallet
          </button>
        </div>

      </div>
    </div>
  );
}
