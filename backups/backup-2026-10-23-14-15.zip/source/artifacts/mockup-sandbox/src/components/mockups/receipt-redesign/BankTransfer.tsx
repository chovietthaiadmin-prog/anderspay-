import "./_group.css";
import "./bank-transfer.css";
import andersPayLogo from "./anderspay-logo.png";
import {
  ArrowUpRight,
  Check,
  CheckCircle2,
  Copy,
  FileCheck2,
  LockKeyhole,
  ShieldCheck,
} from "lucide-react";

const PAYMENT = {
  recipient: "Nattapong Srisuk",
  bank: "SCB",
  account: "•••• 4821",
  amount: "฿3,500.00",
  date: "04 May 2025",
  time: "16:17 ICT",
  reference: "AP-250504-091542",
  verification: "APX7-K4M2-91QF",
};

function DetailRow({
  label,
  value,
  mono = false,
}: {
  label: string;
  value: string;
  mono?: boolean;
}) {
  return (
    <div className="ap-detail-row">
      <span className="ap-detail-label">{label}</span>
      <span className={`ap-detail-value${mono ? " ap-mono" : ""}`}>{value}</span>
    </div>
  );
}

export default function BankTransfer() {
  return (
    <main className="ap-page">
      <div className="ap-receipt" aria-label="AndersPay Plus completed payment receipt">
        <header className="ap-header">
          <div className="ap-brand">
            <img className="ap-brand-logo" src={andersPayLogo} alt="AndersPay+" />
            <span className="ap-brand-name">AndersPay<span>+</span></span>
          </div>
          <span className="ap-receipt-label">Payment receipt</span>
        </header>

        <div className="ap-paper-watermark" aria-hidden="true">
          <svg viewBox="0 0 520 600" role="presentation">
            <g className="ap-security-lines" fill="none" stroke="currentColor">
              <path d="M28 502h464M52 472h416M78 442h364" />
              <path d="M104 442V285l156-118 156 118v157" />
              <path d="M128 442V299l132-100 132 100v143" />
              <path d="M152 442V312l108-82 108 82v130" />
              <path d="M176 442V326l84-64 84 64v116" />
              <path d="M199 442V341l61-46 61 46v101" />
              <path d="M224 442V356l36-27 36 27v86" />
              <path d="M66 206h388M105 176h310M145 146h230" />
              <circle cx="260" cy="280" r="184" />
              <circle cx="260" cy="280" r="214" />
              <circle cx="260" cy="280" r="244" />
              <path d="M260 20v520M40 280h440M104 124l312 312M104 436l312-312" />
            </g>
          </svg>
        </div>

        <section className="ap-confirmed">
          <div className="ap-check-ring">
            <CheckCircle2 aria-hidden="true" />
          </div>
          <p className="ap-eyebrow">Payment completed</p>
          <h1>{PAYMENT.amount}</h1>
          <p className="ap-subtitle">Sent to {PAYMENT.recipient}</p>
          <div className="ap-status-chip">
            <Check size={14} strokeWidth={3} aria-hidden="true" />
            Confirmed
          </div>
        </section>

        <section className="ap-recipient-card">
          <div className="ap-card-kicker">Recipient</div>
          <div className="ap-recipient-line">
            <div className="ap-recipient-avatar" aria-hidden="true">NS</div>
            <div>
              <p className="ap-recipient-name">{PAYMENT.recipient}</p>
              <p className="ap-recipient-account">{PAYMENT.bank} · {PAYMENT.account}</p>
            </div>
            <ArrowUpRight className="ap-transfer-icon" size={18} aria-hidden="true" />
          </div>
        </section>

        <section className="ap-details" aria-label="Payment details">
          <div className="ap-section-title">
            <span>Payment details</span>
            <span className="ap-thb-tag">THB</span>
          </div>
          <DetailRow label="From" value="Anders" />
          <div className="ap-total-row">
            <span>Total paid</span>
            <strong>{PAYMENT.amount}</strong>
          </div>
        </section>

        <section className="ap-meta">
          <DetailRow label="Date and time" value={`${PAYMENT.date}, ${PAYMENT.time}`} />
          <DetailRow label="Reference" value={PAYMENT.reference} mono />
        </section>

        <section className="ap-verify">
          <div className="ap-verify-icon"><ShieldCheck size={19} aria-hidden="true" /></div>
          <div className="ap-verify-copy">
            <div className="ap-verify-heading">
              <strong>Receipt integrity check</strong>
              <span className="ap-verified-pill"><Check size={11} strokeWidth={3} /> Verified</span>
            </div>
            <p>Keep this receipt for your records. To confirm it came from AndersPay+, quote the reference below to our support team.</p>
            <code>{PAYMENT.verification}</code>
          </div>
          <FileCheck2 className="ap-doc-icon" size={20} aria-hidden="true" />
        </section>

        <footer className="ap-footer">
          <div className="ap-footer-rule" />
          <div className="ap-footer-note"><LockKeyhole size={13} /> Securely processed by AndersPay+</div>
          <p>AndersPay+ is a payment service. This receipt confirms the payment details shown above and is not issued by the recipient’s bank.</p>
          <button className="ap-copy-button" type="button">
            <Copy size={15} aria-hidden="true" /> Copy reference
          </button>
        </footer>
      </div>
    </main>
  );
}