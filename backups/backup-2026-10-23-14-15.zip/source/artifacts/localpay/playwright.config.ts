import { defineConfig, devices } from "@playwright/test";

export default defineConfig({
  testDir: "./e2e",
  // 60 s: beforeAll waits up to 9 s for the seed order to reach "completed"
  timeout: 60000,
  retries: 0,
  reporter: "list",
  globalSetup: "./e2e/global-setup.ts",
  use: {
    // Use the shared reverse proxy so the browser can reach both the
    // frontend (/) and the API server (/api) from the same origin.
    baseURL: "http://localhost:80",
    viewport: { width: 400, height: 720 },
    ignoreHTTPSErrors: true,
  },
  // Ensure both servers are running before tests start.
  // reuseExistingServer:true reuses the active Replit dev workflows.
  webServer: [
    {
      command: "PORT=23366 BASE_PATH=/ pnpm --filter @workspace/localpay run dev",
      url: "http://localhost:23366",
      reuseExistingServer: true,
      timeout: 30000,
    },
    {
      command: "pnpm --filter @workspace/api-server run dev",
      url: "http://localhost:8080/api/healthz",
      reuseExistingServer: true,
      timeout: 30000,
    },
  ],
  projects: [
    {
      name: "chromium",
      use: { ...devices["Desktop Chrome"] },
    },
  ],
});
