import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

createRoot(document.getElementById("root")!).render(<App />);

// Register the service worker so Chrome / Edge / Brave consider the app
// installable and fire `beforeinstallprompt`. Scoped to BASE_URL so it
// works whether the app is mounted at "/" or under a subpath.
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    const base = import.meta.env.BASE_URL.replace(/\/$/, "");
    navigator.serviceWorker
      .register(`${base}/sw.js`, { scope: `${base}/` })
      .catch(() => {
        // Silent: SW is purely an install-criteria nicety; failure is harmless.
      });
  });
}
