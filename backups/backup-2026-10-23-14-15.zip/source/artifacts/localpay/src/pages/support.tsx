import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import {
  MessageCircle,
  ChevronRight,
  Inbox,
  Image as ImageIcon,
  type LucideIcon,
} from "lucide-react";
import { useLang } from "@/lib/use-lang";
import { useAuth } from "@/lib/auth";
import { Card, CardContent } from "@/components/ui/card";
import InlineAuth from "@/components/inline-auth";
import SupportChatModal from "@/components/support-chat";
import { getMyUnread, getAdminUnread } from "@/lib/support-chat";
import { getRecentConversations, type RecentConversation } from "@/lib/friends-api";
import { FriendsPanel } from "@/pages/friends";

export default function Support() {
  const { t, lang } = useLang();
  const { user, token } = useAuth();
  const [, setLocation] = useLocation();
  const [chatOpen, setChatOpen] = useState(false);
  const [unread, setUnread] = useState(0);
  const [recentConversations, setRecentConversations] = useState<RecentConversation[]>([]);
  const [recentLoading, setRecentLoading] = useState(false);

  // Only signed-in users poll their private support thread.
  useEffect(() => {
    if (chatOpen) return;
    if (!token) {
      setUnread(0);
      return;
    }
    let cancelled = false;
    const fetchUnread = async () => {
      const n = user?.isAdmin
        ? await getAdminUnread(token)
        : await getMyUnread(token);
      if (!cancelled) setUnread(n);
    };
    void fetchUnread();
    const i = setInterval(() => { void fetchUnread(); }, 10000);
    return () => { cancelled = true; clearInterval(i); };
  }, [token, user?.isAdmin, chatOpen]);

  // When closing chat, refresh count immediately.
  useEffect(() => {
    if (chatOpen) setUnread(0);
  }, [chatOpen]);

  // Keep the Messenger landing page's recent friend conversations fresh.
  useEffect(() => {
    if (!token) {
      setRecentConversations([]);
      return;
    }
    let cancelled = false;
    const loadRecent = async () => {
      setRecentLoading(true);
      try {
        const rows = await getRecentConversations(token);
        if (!cancelled) setRecentConversations(rows);
      } catch {
        if (!cancelled) setRecentConversations([]);
      } finally {
        if (!cancelled) setRecentLoading(false);
      }
    };
    void loadRecent();
    const i = setInterval(() => { void loadRecent(); }, 10_000);
    return () => {
      cancelled = true;
      clearInterval(i);
    };
  }, [token]);

  const supportItems: {
    icon: LucideIcon;
    label: string;
    desc: string;
    color: string;
    bg: string;
    href?: string;
    onClick?: () => void;
    badge?: number;
  }[] = [
    {
      icon: user?.isAdmin ? Inbox : MessageCircle,
      label: user?.isAdmin ? t.support.adminInbox : t.support.messages,
      desc: t.support.messagesDesc,
      color: "text-emerald-400",
      bg: "bg-emerald-400/10",
      onClick: () => setChatOpen(true),
      badge: unread,
    },
    {
      icon: MessageCircle,
      label: t.support.chat,
      desc: t.support.chatDesc,
      color: "text-primary",
      bg: "bg-primary/10",
      href: "https://t.me/anderspay",
    },
  ];

  const formatRecentTime = (iso: string) => {
    const date = new Date(iso);
    const diff = Date.now() - date.getTime();
    if (diff < 60_000) return t.friends.justNow;
    if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}m`;
    if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)}h`;
    return date.toLocaleDateString([], { day: "2-digit", month: "2-digit" });
  };

  const recentPreview = (conversation: RecentConversation) =>
    conversation.lastBody?.trim() ||
    (conversation.lastImageUrl ? t.support.recentImage : "—");

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col gap-6 pb-24"
      >
        <div className="pt-8 pb-2">
          <h1 className="text-2xl font-bold">{t.support.title}</h1>
          <p className="text-muted-foreground text-sm">{t.support.subtitle}</p>
        </div>

        {(recentLoading || recentConversations.length > 0) && (
          <div className="flex flex-col gap-3">
            <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">
              {t.support.recentTitle}
            </p>
            <Card className="bg-card border-border overflow-hidden">
              <CardContent className="p-0 divide-y divide-border">
                {recentLoading && recentConversations.length === 0
                  ? Array.from({ length: 3 }).map((_, index) => (
                      <div key={index} className="flex items-center gap-3 p-3.5">
                        <div className="h-10 w-10 shrink-0 animate-pulse rounded-full bg-secondary/70" />
                        <div className="flex-1 space-y-2">
                          <div className="h-3 w-28 animate-pulse rounded bg-secondary/70" />
                          <div className="h-2.5 w-44 animate-pulse rounded bg-secondary/50" />
                        </div>
                      </div>
                    ))
                  : recentConversations.map((conversation) => {
                      const peer = conversation.peer;
                      const name = peer.nickname?.trim() || peer.name;
                      return (
                        <button
                          key={conversation.friendshipId}
                          type="button"
                          onClick={() => setLocation(`/friends?chat=${encodeURIComponent(conversation.friendshipId)}`)}
                          className="flex w-full items-center gap-3 p-3.5 text-left transition-colors hover:bg-secondary/30"
                        >
                          {peer.avatarUrl ? (
                            <img
                              src={peer.avatarUrl}
                              alt=""
                              className="h-10 w-10 shrink-0 rounded-full border border-primary/20 object-cover"
                            />
                          ) : (
                            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-primary/30 bg-primary/15 font-bold text-primary">
                              {name.charAt(0).toUpperCase()}
                            </div>
                          )}
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2">
                              <p className="min-w-0 flex-1 truncate text-sm font-semibold">{name}</p>
                              <span className="shrink-0 text-[10px] text-muted-foreground">
                                {formatRecentTime(conversation.lastAt)}
                              </span>
                            </div>
                            <p className="truncate text-xs text-muted-foreground">
                              {recentPreview(conversation)}
                            </p>
                          </div>
                          {conversation.lastImageUrl && !conversation.lastBody && (
                            <ImageIcon className="h-4 w-4 shrink-0 text-muted-foreground" />
                          )}
                          <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
                        </button>
                      );
                    })}
              </CardContent>
            </Card>
          </div>
        )}

        {user && token && (
          <div>
            <FriendsPanel
              embedded
              onOpenChat={(_, friendshipId) => {
                setLocation(`/friends?chat=${encodeURIComponent(friendshipId)}`);
              }}
            />
          </div>
        )}

        {!user || !token ? (
          <div className="flex flex-col gap-3" data-testid="support-login-required">
            <p className="text-sm text-muted-foreground">
              {lang === "vi"
                ? "Đăng nhập để nhắn tin và sử dụng các chức năng hỗ trợ."
                : "Sign in to send messages and use support features."}
            </p>
            <InlineAuth />
          </div>
        ) : (
        <div className="flex flex-col gap-3">
          <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">
            {t.support.contact}
          </p>
          {supportItems.map(({ icon: Icon, label, desc, color, bg, href, onClick, badge }) => {
            const inner = (
              <Card className="bg-card border-border hover:border-primary/40 transition-colors cursor-pointer">
                <CardContent className="p-4 flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${bg} relative`}>
                    <Icon className={`w-5 h-5 ${color}`} />
                    {badge && badge > 0 ? (
                      <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold rounded-full min-w-[18px] h-[18px] px-1 flex items-center justify-center">
                        {badge > 99 ? "99+" : badge}
                      </span>
                    ) : null}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm">{label}</p>
                    <p className="text-xs text-muted-foreground truncate">{desc}</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </CardContent>
              </Card>
            );
            if (href) {
              return (
                <a key={label} href={href} target="_blank" rel="noopener noreferrer" className="block">
                  {inner}
                </a>
              );
            }
            return (
              <button key={label} onClick={onClick} className="block w-full text-left">
                {inner}
              </button>
            );
          })}
        </div>
        )}

      </motion.div>

      <SupportChatModal open={chatOpen} onClose={() => setChatOpen(false)} />
    </>
  );
}
