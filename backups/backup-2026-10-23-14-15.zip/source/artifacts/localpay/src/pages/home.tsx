import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Activity, User, TrendingUp, Clock, ChevronDown, ChevronUp, Wallet, ArrowDownToLine, ArrowRightLeft, AlertCircle, Users, ChevronRight, TrendingUp as TrendingUpIcon, Megaphone, UserRound } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

import { useGetExchangeRate, useGetRecentOrders, getGetExchangeRateQueryKey, getGetRecentOrdersQueryKey } from "@workspace/api-client-react";
import { useLang } from "@/lib/use-lang";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import AuthModal from "@/components/auth-modal";
import AboutDialog from "@/components/about-dialog";
import RateManager from "@/components/rate-manager";
import AnnouncementTicker from "@/components/announcement-ticker";
import RateChart from "@/components/rate-chart";
import WalletRiskChecker from "@/components/wallet-risk-checker";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface AdminUserLite {
  id: string;
  uid: string | null;
  name: string;
  nickname: string | null;
  phone: string;
  avatarUrl: string | null;
  online: boolean;
  isAdmin: boolean;
}
interface AdminUsersResp {
  onlineCount: number;
  total: number;
  users: AdminUserLite[];
}

const REVIEW_COOLDOWN_MS = 30 * 60 * 1000;
const API_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

export default function Home() {
  const [, setLocation] = useLocation();
  const { t } = useLang();
  const { user, token } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [authOpen, setAuthOpen] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [assetsOpen, setAssetsOpen] = useState(false);
  const [openSection, setOpenSection] = useState<"completed" | "pending" | null>(null);
  const [reviewingId, setReviewingId] = useState<string | null>(null);
  const [rateOpen, setRateOpen] = useState(false);
  // Which user list the admin opened by tapping the Online / Total cards.
  // null = closed, "online" = filter by online, "all" = full member list.
  const [usersDialog, setUsersDialog] = useState<"online" | "all" | null>(null);

  const isAdmin = !!user?.isAdmin;

  // Admin-only: poll the directory so the home page surfaces live online
  // counts + the most-recently-seen users without leaving the dashboard.
  const adminUsersQuery = useQuery<AdminUsersResp>({
    queryKey: ["admin", "users", "home"],
    enabled: isAdmin && !!token,
    refetchInterval: 5000,
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/admin/users`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("admin_users_failed");
      return res.json();
    },
  });

  async function requestReview(orderUuid: string) {
    if (!token) return;
    setReviewingId(orderUuid);
    try {
      const res = await fetch(`${API_BASE}/api/orders/${orderUuid}/request-review`, {
        method: "POST",
        headers: { "Authorization": `Bearer ${token}` },
      });
      if (res.ok) {
        toast({ title: t.status.reviewSent, description: t.status.reviewSentDesc });
        queryClient.invalidateQueries({ queryKey: getGetRecentOrdersQueryKey() });
      } else if (res.status === 429) {
        const data = await res.json().catch(() => ({})) as { retryAfterMs?: number };
        const mins = Math.max(1, Math.ceil((data.retryAfterMs ?? 0) / 60000));
        toast({ title: t.status.reviewCooldown.replace("{minutes}", String(mins)), variant: "destructive" });
      } else {
        toast({ title: t.status.reviewError, variant: "destructive" });
      }
    } catch {
      toast({ title: t.status.reviewError, variant: "destructive" });
    } finally {
      setReviewingId(null);
    }
  }

  function canRequestReview(order: { createdAt: string; status: string; reviewRequestedAt?: string | null }): boolean {
    if (order.status !== "pending" && order.status !== "paid") return false;
    const now = Date.now();
    if (now - new Date(order.createdAt).getTime() < REVIEW_COOLDOWN_MS) return false;
    if (order.reviewRequestedAt && now - new Date(order.reviewRequestedAt).getTime() < REVIEW_COOLDOWN_MS) return false;
    return true;
  }

  const { data: exchangeRate } = useGetExchangeRate({
    query: {
      queryKey: getGetExchangeRateQueryKey(),
      refetchInterval: 30000,
    },
  });

  const { data: recent, isLoading: recentLoading } = useGetRecentOrders({
    query: { queryKey: getGetRecentOrdersQueryKey(), refetchInterval: 2000 },
  });

  // Wallet balances (USDT held + THB available after conversion).
  // Only fetched when the user is logged in; mirrors the pattern used in wallet.tsx.
  const walletQuery = useQuery<{ usdtBalance: number; thbBalance: number }>({
    queryKey: ["wallet", "home"],
    enabled: !!token,
    refetchInterval: 5000,
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/wallet`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("wallet_load_failed");
      return res.json();
    },
  });
  const walletUsdt = walletQuery.data?.usdtBalance ?? 0;
  const walletThb = walletQuery.data?.thbBalance ?? 0;

  const rate = exchangeRate?.thbPerUsdt ?? 0;
  const totalThb = recent?.totalThb ?? 0;
  const totalUsdt = recent?.totalUsdt ?? 0;
  const completedCount = recent?.completed ?? 0;
  const pendingCount = recent?.pending ?? 0;

  // Orders that still hold USDT (pending/paid = not yet converted)
  const usdtOrders = (recent?.orders ?? []).filter(
    (o) => o.status === "pending" || o.status === "paid"
  );

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col gap-4 pb-28"
      >
        {/* Header */}
        <div className="flex items-center gap-3 pt-6 pb-1">
          <button
            type="button"
            onClick={() => setAboutOpen(true)}
            className="flex items-center gap-3 flex-1 min-w-0 -ml-1 pl-1 py-1 rounded-xl hover:bg-secondary/40 active:bg-secondary/60 transition-colors text-left"
            title={t.about.openLabel}
            aria-label={t.about.openLabel}
          >
            <img
              src="/anderspay-logo.png"
              alt="AndersPay+"
              className="w-11 h-11 rounded-full object-cover shadow-lg shadow-primary/20 shrink-0"
            />
            <div className="flex-1 min-w-0">
              <h1 className="font-extrabold leading-none tracking-[-0.02em] text-[22px] flex items-center">
                <span className="text-accent">Anders</span>
                <span className="text-primary">Pay</span>
                <span
                  className="ml-0.5 text-[14px] font-black relative -top-1.5 text-accent"
                  style={{ textShadow: "0 1px 0 rgba(0,0,0,0.35)" }}
                >
                  +
                </span>
              </h1>
              <div className="mt-1.5 flex items-center gap-1.5">
                <span className="block h-px w-3 bg-gradient-to-r from-primary to-transparent" />
                <p className="text-muted-foreground text-[10px] font-semibold tracking-[0.16em] uppercase truncate">
                  {t.home.subtitle}
                </p>
              </div>
            </div>
          </button>
          {user ? (
            <button
              onClick={() => setAuthOpen(true)}
              className="w-10 h-10 rounded-full overflow-hidden border-2 border-primary/40 hover:border-primary transition-colors shrink-0 shadow shadow-primary/20"
              title={user.nickname ?? user.name}
            >
              {user.avatarUrl ? (
                <img
                  src={user.avatarUrl.startsWith("http") || user.avatarUrl.startsWith("data:") ? user.avatarUrl : `${import.meta.env.BASE_URL.replace(/\/$/, "")}${user.avatarUrl}`}
                  alt="avatar"
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                  <span className="text-sm font-bold text-white uppercase">
                    {(user.nickname ?? user.name).charAt(0)}
                  </span>
                </div>
              )}
            </button>
          ) : (
            <button
              onClick={() => setAuthOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary text-white text-[11px] font-bold hover:bg-primary/90 transition-colors shadow shadow-primary/30"
            >
              <User className="w-3 h-3" />
              {t.auth.login}
            </button>
          )}
        </div>

        {/* Scrolling ad line (admin-editable) */}
        <AnnouncementTicker />

        {/* THB Balance card — premium */}
        <div className="relative overflow-hidden rounded-2xl border border-accent/20 bg-gradient-to-br from-accent/10 via-background to-card shadow-lg shadow-background">
          {/* Ambient glow blobs */}
          <div className="pointer-events-none absolute -top-10 -left-10 w-40 h-40 rounded-full bg-accent/10 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-12 right-0 w-48 h-48 rounded-full bg-primary/10 blur-3xl" />
          {/* Hair-line top shimmer */}
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-400/50 to-transparent" />

          <div className="relative px-5 pt-5 pb-4">
            {/* Row: label + USDT-in-wallet badge */}
            <div className="flex items-center justify-between mb-3">
              <p className="text-[10px] uppercase tracking-[0.22em] text-amber-400/50 font-semibold">
                {t.home.balanceLabel}
              </p>
              {user && walletUsdt > 0 && (
                <span className="flex items-center gap-1 rounded-full border border-white/10 bg-white/5 px-2.5 py-0.5 text-[10px] text-muted-foreground/70">
                  <Wallet className="w-2.5 h-2.5" />
                  {walletUsdt.toLocaleString("th-TH", { maximumFractionDigits: 4 })} USDT
                </span>
              )}
            </div>

            {/* Main balance number */}
            <div className="flex items-start gap-1.5 mb-5">
              <span className="mt-2 text-2xl font-light leading-none text-amber-300/50 select-none">฿</span>
              {walletQuery.isFetching && !!token ? (
                <div className="h-14 w-44 animate-pulse rounded-xl bg-white/5" />
              ) : (
                <motion.span
                  key={walletThb}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.35 }}
                  className={`text-[3.6rem] font-black leading-none tracking-tight tabular-nums drop-shadow-[0_0_24px_rgba(251,191,36,0.25)] ${user ? "text-amber-300" : "text-white/15"}`}
                >
                  {user
                    ? walletThb.toLocaleString("th-TH", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
                    : "0.00"}
                </motion.span>
              )}
            </div>

            {/* Divider */}
            <div className="h-px bg-gradient-to-r from-transparent via-white/8 to-transparent mb-3" />

            {/* Rate row */}
            <div className="flex items-center gap-2">
              <Activity className="w-3 h-3 shrink-0 animate-pulse text-primary/60" />
              <span className="text-[11px] text-muted-foreground/60 flex-1">{t.home.liveRate}</span>
              {exchangeRate ? (
                <span className="rounded-full border border-primary/25 bg-primary/10 px-3 py-0.5 text-[11px] font-mono font-bold text-primary tabular-nums">
                  1 USDT = {rate.toFixed(2)} ฿
                </span>
              ) : (
                <div className="h-5 w-28 animate-pulse rounded-full bg-white/5" />
              )}
            </div>
          </div>
        </div>

        {/* USDT/THB market trend chart */}
        <RateChart />

        {/* Quick actions — hidden for admin */}
        {!user?.isAdmin && (
          <div className="grid grid-cols-2 items-stretch gap-3">
            <button
              onClick={() => setLocation("/topup")}
              className="flex h-full min-h-[124px] flex-col items-center gap-2 rounded-2xl border border-border bg-card px-2.5 py-3 transition-all hover:border-primary/40 hover:bg-primary/5 active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/70"
            >
              <div className="flex h-9 w-9 items-center justify-center rounded-full border border-primary/20 bg-primary/10">
                <ArrowDownToLine className="h-4 w-4 text-primary" />
              </div>
              <div className="flex flex-col items-center gap-1">
                <span className="flex items-center justify-center text-center text-xs font-bold leading-tight">
                  {t.topup.btnLabel}
                </span>
                <span className="flex items-center justify-center text-center text-[10px] leading-tight text-muted-foreground">
                  {t.topup.btnHint}
                </span>
              </div>
            </button>
            <button
              onClick={() => setLocation("/wallet")}
              className="flex h-full min-h-[124px] flex-col items-center gap-2 rounded-2xl border border-border bg-card px-2.5 py-3 transition-all hover:border-accent/40 hover:bg-accent/5 active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/70"
            >
              <div className="flex h-9 w-9 items-center justify-center rounded-full border border-accent/20 bg-accent/10">
                <ArrowRightLeft className="h-4 w-4 text-accent" />
              </div>
              <div className="flex flex-col items-center gap-1">
                <span className="flex items-center justify-center text-center text-xs font-bold leading-tight">
                  {t.home.depositUsdt}
                </span>
                <span className="flex items-center justify-center text-center text-[10px] leading-tight text-muted-foreground">
                  USDT → THB
                </span>
              </div>
            </button>
          </div>
        )}

        {/* My Assets card */}
        <Card className="border-border bg-card overflow-hidden">
          <button
            className="w-full text-left"
            onClick={() => setAssetsOpen((v) => !v)}
          >
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-accent/10 border border-accent/20 flex items-center justify-center shrink-0">
                <Wallet className="w-5 h-5 text-accent" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold">{t.home.myAssets}</p>
                <p className="text-xs text-muted-foreground">{t.home.myAssetsHint}</p>
              </div>
              <div className="ml-1 text-muted-foreground">
                {assetsOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </div>
            </CardContent>
          </button>

          <AnimatePresence>
            {assetsOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="overflow-hidden"
              >
                <div className="border-t border-border/60 px-4 py-3 flex flex-col gap-3">
                  {/* Wallet balances — visible only when expanded + logged in */}
                  {user && (
                    <div className="grid grid-cols-2 gap-2">
                      <div className="rounded-xl bg-accent/10 border border-accent/20 px-3 py-2.5">
                        <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">
                          {t.wallet.balanceUsdt}
                        </p>
                        <p className="text-lg font-bold tabular-nums font-mono text-accent mt-0.5">
                          {walletUsdt.toLocaleString("en-US", { maximumFractionDigits: 4 })}
                          <span className="text-[10px] ml-1 font-normal">USDT</span>
                        </p>
                      </div>
                      <div className="rounded-xl bg-green-500/10 border border-green-500/20 px-3 py-2.5">
                        <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">
                          {t.wallet.balanceThb}
                        </p>
                        <p className="text-lg font-bold tabular-nums font-mono text-green-400 mt-0.5">
                          {walletThb.toLocaleString("th-TH", { maximumFractionDigits: 2 })}
                          <span className="text-[10px] ml-1 font-normal">THB</span>
                        </p>
                      </div>
                    </div>
                  )}
                  {usdtOrders.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-3">{t.home.noAssets}</p>
                  ) : (
                    usdtOrders.map((order) => (
                      <div
                        key={order.id}
                        className="flex items-center gap-3 py-2 border-b border-border/30 last:border-0 cursor-pointer hover:bg-secondary/30 rounded-lg px-2 -mx-2 transition-colors"
                        onClick={() => setLocation(`/status/${order.id}`)}
                      >
                        <div className={`w-2 h-2 rounded-full shrink-0 ${
                          order.status === "paid" ? "bg-blue-400 animate-pulse" : "bg-yellow-400 animate-pulse"
                        }`} />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs text-muted-foreground font-mono">{order.orderId}</p>
                          <p className="text-xs text-muted-foreground">
                            {order.status === "paid" ? t.status.paid : t.status.pending}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-bold tabular-nums font-mono text-accent">
                            {Number(order.amountUsdt).toFixed(4)} USDT
                          </p>
                          <p className="text-xs text-muted-foreground">
                            → {Number(order.amountThb).toLocaleString("th-TH", { maximumFractionDigits: 0 })} THB
                          </p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </Card>

        <WalletRiskChecker />

        {/* Admin-only dashboard widgets: broadcast shortcut + rate
            update shortcut + online users */}
        {isAdmin && (
          <>
            <button
              type="button"
              onClick={() => setLocation("/admin/broadcast")}
              className="w-full text-left rounded-xl border border-accent/40 bg-gradient-to-r from-accent/15 to-accent/5 hover:from-accent/25 hover:to-accent/10 active:scale-[0.99] transition-all p-4 flex items-center gap-3"
            >
              <div className="w-11 h-11 rounded-full bg-accent/20 border border-accent/40 flex items-center justify-center shrink-0">
                <Megaphone className="w-5 h-5 text-accent" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-accent">{t.broadcast.homeBtn}</p>
                <p className="text-[11px] text-muted-foreground truncate">
                  {t.broadcast.homeBtnHint}
                </p>
              </div>
              <ChevronRight className="w-5 h-5 text-accent shrink-0" />
            </button>

            <Card className="border-border bg-card overflow-hidden relative">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-accent to-accent/40" />
              <CardContent className="p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-accent/10 border border-accent/20 flex items-center justify-center shrink-0">
                  <TrendingUpIcon className="w-5 h-5 text-accent" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold">{t.rateManager.title}</p>
                  <p className="text-[11px] text-muted-foreground truncate">
                    {exchangeRate ? `1 USDT = ${rate.toFixed(4)} THB` : t.rateManager.subtitle}
                  </p>
                </div>
                <Button
                  size="sm"
                  className="h-9 px-4 text-xs font-bold bg-accent text-accent-foreground hover:bg-accent/90"
                  onClick={() => setRateOpen(true)}
                >
                  {t.rateManager.setRate}
                </Button>
              </CardContent>
            </Card>

            <div className="grid grid-cols-2 gap-3">
              {/* Tapping either card opens the full user list filtered
                  accordingly (online-only vs everyone), sorted A→Z by
                  display name. */}
              <button
                type="button"
                onClick={() => setLocation("/admin/users")}
                className="text-left rounded-xl border border-border bg-card hover:bg-secondary/30 active:scale-[0.99] transition-colors p-4"
              >
                <div className="flex items-center gap-2 mb-1">
                  <Users className="w-3 h-3 text-accent" />
                  <span className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">
                    {t.adminUsers.manageUsers}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <p className="text-base font-bold text-accent leading-tight">
                    {t.adminUsers.manageUsersHint}
                  </p>
                  <ChevronRight className="w-5 h-5 text-accent shrink-0" />
                </div>
              </button>
              <button
                type="button"
                onClick={() => setUsersDialog("all")}
                className="text-left rounded-xl border border-border bg-card hover:bg-secondary/30 active:scale-[0.99] transition-colors p-4"
              >
                <div className="flex items-center gap-2 mb-1">
                  <Users className="w-3 h-3 text-muted-foreground" />
                  <span className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">
                    {t.adminUsers.total}
                  </span>
                </div>
                <p className="text-3xl font-bold tabular-nums font-mono">
                  {adminUsersQuery.data?.total ?? 0}
                </p>
              </button>
            </div>

            <Card className="bg-card border-border">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-muted-foreground" />
                    <h2 className="text-sm font-bold">{t.adminUsers.title}</h2>
                  </div>
                  <button
                    onClick={() => setLocation("/admin/users")}
                    className="text-xs text-primary font-medium hover:underline"
                  >
                    {t.home.seeAll}
                  </button>
                </div>
                {adminUsersQuery.isLoading ? (
                  <div className="flex flex-col gap-2">
                    {[0, 1, 2].map((i) => (
                      <div key={i} className="h-10 bg-secondary/40 animate-pulse rounded-lg" />
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col">
                    {(adminUsersQuery.data?.users ?? [])
                      .filter((u) => !u.isAdmin)
                      .slice()
                      .sort((a, b) => {
                        const an = (a.nickname?.trim() || a.name).toLocaleLowerCase("vi");
                        const bn = (b.nickname?.trim() || b.name).toLocaleLowerCase("vi");
                        return an.localeCompare(bn, "vi");
                      })
                      .slice(0, 6)
                      .map((u) => {
                        const display = u.nickname?.trim() || u.name;
                        const initials = display
                          .split(" ").filter(Boolean).map((w) => w[0]).join("").slice(0, 2).toUpperCase();
                        return (
                          <div key={u.id} className="flex items-center gap-3 py-2 border-b border-border/30 last:border-0">
                            <div className="relative shrink-0">
                              {u.avatarUrl ? (
                                <img
                                  src={u.avatarUrl.startsWith("http") || u.avatarUrl.startsWith("data:") ? u.avatarUrl : `${API_BASE}${u.avatarUrl}`}
                                  alt=""
                                  className="w-8 h-8 rounded-full object-cover"
                                />
                              ) : (
                                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white text-[10px] font-bold">
                                  {initials || "?"}
                                </div>
                              )}
                              <span className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-card ${u.online ? "bg-green-400" : "bg-muted"}`} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-1.5 min-w-0">
                                <p className="text-xs font-bold truncate">{display}</p>
                                {u.uid && (
                                  <span className="text-[9px] font-mono font-semibold px-1 py-0.5 rounded bg-secondary/60 text-muted-foreground shrink-0">
                                    #{u.uid}
                                  </span>
                                )}
                              </div>
                              <p className="text-[10px] text-muted-foreground font-mono truncate">{u.phone}</p>
                            </div>
                            {u.online && (
                              <span className="text-[10px] text-green-400 font-semibold shrink-0">●</span>
                            )}
                          </div>
                        );
                      })}
                    {(adminUsersQuery.data?.users ?? []).filter((u) => !u.isAdmin).length === 0 && (
                      <p className="text-xs text-muted-foreground text-center py-3">{t.adminUsers.empty}</p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

          </>
        )}

        {/* Quick stats — clickable to filter list below (hidden for admin) */}
        {!isAdmin && (
        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => setOpenSection((s) => (s === "completed" ? null : "completed"))}
            className={`text-left transition-all active:scale-95 rounded-xl ${
              openSection === "completed" ? "ring-2 ring-green-500/60" : ""
            }`}
          >
            <Card className="bg-card border-border">
              <CardContent className="p-4 flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-green-500/10 flex items-center justify-center shrink-0">
                  <TrendingUp className="w-4 h-4 text-green-400" />
                </div>
                <div>
                  <p className="text-xl font-bold tabular-nums">{completedCount}</p>
                  <p className="text-xs text-muted-foreground">{t.home.completed}</p>
                </div>
              </CardContent>
            </Card>
          </button>
          <button
            type="button"
            onClick={() => setOpenSection((s) => (s === "pending" ? null : "pending"))}
            className={`text-left transition-all active:scale-95 rounded-xl ${
              openSection === "pending" ? "ring-2 ring-yellow-500/60" : ""
            }`}
          >
            <Card className="bg-card border-border">
              <CardContent className="p-4 flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-yellow-500/10 flex items-center justify-center shrink-0">
                  <Clock className="w-4 h-4 text-yellow-400" />
                </div>
                <div>
                  <p className="text-xl font-bold tabular-nums">{pendingCount}</p>
                  <p className="text-xs text-muted-foreground">{t.home.pending}</p>
                </div>
              </CardContent>
            </Card>
          </button>
        </div>
        )}

        {/* Filtered list under the chosen stat card */}
        <AnimatePresence initial={false}>
          {!isAdmin && openSection && recent && (
            <motion.div
              key={openSection}
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden"
            >
              {(() => {
                const list = recent.orders.filter((o) =>
                  openSection === "completed"
                    ? o.status === "completed"
                    : o.status === "pending" || o.status === "paid"
                );
                if (list.length === 0) {
                  return (
                    <Card className="bg-card border-border">
                      <CardContent className="p-4">
                        <p className="text-sm text-muted-foreground text-center">
                          {openSection === "completed" ? t.home.noCompleted : t.home.noPending}
                        </p>
                      </CardContent>
                    </Card>
                  );
                }
                return (
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">
                        {openSection === "completed" ? t.home.completed : t.home.pending}
                      </p>
                      <button
                        onClick={() => setLocation("/history")}
                        className="text-xs text-primary font-medium hover:underline"
                      >
                        {t.home.seeAll}
                      </button>
                    </div>
                    {list.slice(0, 10).map((order) => {
                      const isDone = order.status === "completed";
                      const dotClass = isDone
                        ? "bg-green-400"
                        : order.status === "paid"
                        ? "bg-blue-400 animate-pulse"
                        : "bg-yellow-400 animate-pulse";
                      const amountClass = isDone ? "text-green-400" : "text-accent";
                      const showReview = canRequestReview(order);
                      return (
                        <Card
                          key={order.id}
                          className="bg-card border-border hover:border-primary/40 transition-colors"
                        >
                          <CardContent
                            className="p-3 flex items-center gap-3 cursor-pointer"
                            onClick={() => setLocation(`/status/${order.id}`)}
                          >
                            <div className={`w-2 h-2 rounded-full shrink-0 ${dotClass}`} />
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-semibold tabular-nums truncate">
                                {Number(order.amountUsdt).toFixed(4)} USDT
                              </p>
                              <p className="text-xs text-muted-foreground">{order.orderId}</p>
                            </div>
                            <span className={`text-sm font-bold tabular-nums font-mono ${amountClass}`}>
                              {Number(order.amountThb).toLocaleString("th-TH", { maximumFractionDigits: 0 })} THB
                            </span>
                          </CardContent>
                          {showReview && (
                            <div className="px-3 pb-3 -mt-1">
                              <Button
                                variant="outline"
                                size="sm"
                                disabled={reviewingId === order.id}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  void requestReview(order.id);
                                }}
                                className="w-full h-9 text-xs gap-2 border-yellow-500/40 text-yellow-300 hover:bg-yellow-500/10 hover:text-yellow-200"
                              >
                                <AlertCircle className="w-3.5 h-3.5" />
                                {reviewingId === order.id ? "..." : t.status.requestReview}
                              </Button>
                            </div>
                          )}
                        </Card>
                      );
                    })}
                  </div>
                );
              })()}
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      <AuthModal open={authOpen} onClose={() => setAuthOpen(false)} />
      <AboutDialog open={aboutOpen} onOpenChange={setAboutOpen} />
      <RateManager open={rateOpen} onClose={() => setRateOpen(false)} />

      {/* Member list popup — opens when admin taps the Online or Total
          card. Filters by online status when invoked from the Online
          card and shows everyone (still excluding admins) from the
          Total card. Sorted A→Z by display name using locale-aware
          comparison so Vietnamese diacritics order correctly. */}
      <Dialog open={usersDialog !== null} onOpenChange={(o) => !o && setUsersDialog(null)}>
        <DialogContent className="max-w-md p-0 gap-0 overflow-hidden">
          <DialogHeader className="px-5 pt-5 pb-3 border-b border-border">
            <DialogTitle className="flex items-center gap-2 text-base">
              {usersDialog === "online" ? (
                <>
                  <Users className="w-4 h-4 text-green-400" />
                  {t.adminUsers.online}
                </>
              ) : (
                <>
                  <Users className="w-4 h-4 text-muted-foreground" />
                  {t.adminUsers.total}
                </>
              )}
            </DialogTitle>
          </DialogHeader>
          <div className="max-h-[60vh] overflow-y-auto px-3 py-2">
            {(() => {
              const all = (adminUsersQuery.data?.users ?? []).filter((u) => !u.isAdmin);
              const filtered = usersDialog === "online" ? all.filter((u) => u.online) : all;
              const sorted = [...filtered].sort((a, b) => {
                const an = (a.nickname?.trim() || a.name).toLocaleLowerCase("vi");
                const bn = (b.nickname?.trim() || b.name).toLocaleLowerCase("vi");
                return an.localeCompare(bn, "vi", { sensitivity: "base" });
              });
              if (sorted.length === 0) {
                return (
                  <p className="text-xs text-muted-foreground text-center py-8">
                    {t.adminUsers.empty}
                  </p>
                );
              }
              return sorted.map((u) => {
                const display = u.nickname?.trim() || u.name;
                const initials = display
                  .split(" ").filter(Boolean).map((w) => w[0]).join("").slice(0, 2).toUpperCase();
                return (
                  <div key={u.id} className="flex items-center gap-3 py-2.5 px-2 border-b border-border/30 last:border-0">
                    <div className="relative shrink-0">
                      {u.avatarUrl ? (
                        <img
                          src={u.avatarUrl.startsWith("http") || u.avatarUrl.startsWith("data:") ? u.avatarUrl : `${API_BASE}${u.avatarUrl}`}
                          alt=""
                          className="w-9 h-9 rounded-full object-cover"
                        />
                      ) : (
                        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white text-[11px] font-bold">
                          {initials || "?"}
                        </div>
                      )}
                      <span className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-card ${u.online ? "bg-green-400" : "bg-muted"}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <p className="text-sm font-bold truncate">{display}</p>
                        {u.uid && (
                          <span className="text-[9px] font-mono font-semibold px-1 py-0.5 rounded bg-secondary/60 text-muted-foreground shrink-0">
                            #{u.uid}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-muted-foreground font-mono truncate">{u.phone}</p>
                    </div>
                    {u.online && (
                      <span className="text-[10px] text-green-400 font-semibold shrink-0">●</span>
                    )}
                  </div>
                );
              });
            })()}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
