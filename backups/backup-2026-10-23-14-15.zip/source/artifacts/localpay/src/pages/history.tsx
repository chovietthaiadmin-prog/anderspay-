import { useState } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Clock, CheckCircle2, XCircle, RefreshCw, ArrowUpRight, ArrowDownToLine, ArrowRightLeft, AlertTriangle, ChevronDown } from "lucide-react";
import { useGetRecentOrders, getGetRecentOrdersQueryKey } from "@workspace/api-client-react";
import { useLang } from "@/lib/use-lang";
import { Card, CardContent } from "@/components/ui/card";
import { topupFeeUsdt } from "@/lib/fees";

type Tab = "deposit" | "payment";

export default function History() {
  const [, setLocation] = useLocation();
  const { t } = useLang();
  const [tab, setTab] = useState<Tab>("deposit");
  const [rejectedOpen, setRejectedOpen] = useState(false);

  const statusConfig = {
    pending:   { color: "text-yellow-400", bg: "bg-yellow-400/10", icon: Clock,        label: t.history.statusPending },
    paid:      { color: "text-blue-400",   bg: "bg-blue-400/10",   icon: RefreshCw,    label: t.history.statusPaid },
    completed: { color: "text-green-400",  bg: "bg-green-400/10",  icon: CheckCircle2, label: t.history.statusCompleted },
    expired:   { color: "text-red-400",    bg: "bg-red-400/10",    icon: XCircle,      label: t.history.statusExpired },
    refunded:  { color: "text-orange-400", bg: "bg-orange-400/10", icon: RefreshCw,    label: t.history.statusRefunded },
  } as const;

  const { data: summary, isLoading } = useGetRecentOrders({
    query: { queryKey: getGetRecentOrdersQueryKey(), refetchInterval: 10000 }
  });

  // Deposit (USDT top-up): bankName === ""; Payment (THB withdrawal): bankName populated.
  const filtered = (summary?.orders ?? []).filter((o) =>
    tab === "deposit" ? o.bankName === "" : o.bankName !== ""
  );
  const rejectedDeposits = (summary?.orders ?? []).filter(
    (o) => o.status === "refunded" && !o.bankName,
  );
  const rejectedCount = rejectedDeposits.length;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col gap-4 pb-24"
    >
      <div className="pt-8 pb-2">
        <h1 className="text-2xl font-bold">{t.history.title}</h1>
        <p className="text-muted-foreground text-sm">{t.history.subtitle}</p>
      </div>

      {/* Rejected USDT top-ups belong with transaction history. */}
      <Card className="bg-card border-border overflow-hidden">
        <button
          type="button"
          onClick={() => setRejectedOpen((v) => !v)}
          className="w-full flex items-center gap-4 p-4 text-left hover:bg-secondary/30 transition-colors"
        >
          <div className="w-10 h-10 rounded-full bg-orange-500/15 border border-orange-500/30 flex items-center justify-center shrink-0 relative">
            <AlertTriangle className="w-5 h-5 text-orange-300" />
            {rejectedCount > 0 ? (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold rounded-full min-w-[18px] h-[18px] px-1 flex items-center justify-center">
                {rejectedCount > 99 ? "99+" : rejectedCount}
              </span>
            ) : null}
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-sm">{t.support.rejectedDeposits}</p>
            <p className="text-xs text-muted-foreground truncate">
              {t.support.rejectedDepositsDesc}
            </p>
          </div>
          <ChevronDown
            className={`w-4 h-4 text-muted-foreground transition-transform ${rejectedOpen ? "rotate-180" : ""}`}
          />
        </button>
        <AnimatePresence initial={false}>
          {rejectedOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden border-t border-border"
            >
              <div className="p-3 bg-secondary/20 flex flex-col gap-2">
                {rejectedCount === 0 ? (
                  <p className="text-xs text-muted-foreground text-center py-3">
                    {t.support.rejectedDepositsEmpty}
                  </p>
                ) : (
                  rejectedDeposits.map((order) => (
                    <button
                      key={order.id}
                      type="button"
                      onClick={() => setLocation(`/status/${order.id}`)}
                      className="w-full text-left rounded-xl border border-orange-500/30 bg-orange-500/5 px-3 py-2.5 hover:bg-orange-500/10 transition-colors active:scale-[0.99]"
                    >
                      <p className="text-xs font-semibold text-orange-200 truncate">
                        {order.orderId} · {Number(order.amountUsdt).toFixed(4)} USDT
                      </p>
                      <p className="text-[10px] text-orange-100/60 mt-0.5">
                        {t.support.rejectedDepositsItemHint}
                      </p>
                    </button>
                  ))
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </Card>

      {summary && (
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: t.history.total,     value: summary.total,     color: "text-foreground" },
            { label: t.history.completed, value: summary.completed, color: "text-green-400" },
            { label: t.history.pending,   value: summary.pending,   color: "text-yellow-400" },
          ].map(({ label, value, color }) => (
            <Card key={label} className="bg-card border-border">
              <CardContent className="p-3 text-center">
                <p className={`text-2xl font-bold tabular-nums ${color}`}>{value}</p>
                <p className="text-[11px] text-muted-foreground mt-1">{label}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Tab switcher: USDT top-ups vs THB payments */}
      <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-card border border-border">
        <button
          type="button"
          onClick={() => setTab("deposit")}
          className={`flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-bold transition-all ${
            tab === "deposit"
              ? "bg-primary/15 text-primary border border-primary/30"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <ArrowDownToLine className="w-4 h-4" />
          {t.history.tabDeposit}
        </button>
        <button
          type="button"
          onClick={() => setTab("payment")}
          className={`flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-bold transition-all ${
            tab === "payment"
              ? "bg-accent/15 text-accent border border-accent/30"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <ArrowRightLeft className="w-4 h-4" />
          {t.history.tabPayment}
        </button>
      </div>

      <div className="flex flex-col gap-3">
        {isLoading && (
          <div className="flex flex-col gap-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-20 bg-card rounded-xl animate-pulse" />
            ))}
          </div>
        )}

        {!isLoading && filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 gap-3">
            <Clock className="w-12 h-12 text-muted-foreground/30" />
            <p className="text-muted-foreground text-sm">
              {tab === "deposit" ? t.history.emptyDeposit : t.history.emptyPayment}
            </p>
          </div>
        )}

        {filtered.map((order) => {
          const cfg = statusConfig[order.status as keyof typeof statusConfig] ?? statusConfig.pending;
          const StatusIcon = cfg.icon;
          const isDeposit = tab === "deposit";
          return (
            <motion.div
              key={order.id}
              whileTap={{ scale: 0.98 }}
              onClick={() => setLocation(`/status/${order.id}`)}
              className="cursor-pointer"
            >
              <Card className="bg-card border-border hover:border-primary/40 transition-colors">
                <CardContent className="p-4 flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${cfg.bg}`}>
                    <StatusIcon className={`w-5 h-5 ${cfg.color}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-mono text-xs text-muted-foreground">{order.orderId}</p>
                    {isDeposit ? (
                      <p className="font-bold text-sm text-accent font-mono">
                        {order.amountUsdt.toFixed(4)} USDT
                      </p>
                    ) : (
                      <p className="font-bold text-sm">
                        {order.amountThb.toLocaleString()} THB
                      </p>
                    )}
                  </div>
                  <div className="text-right shrink-0">
                    {isDeposit ? (() => {
                      // Show net USDT credited (gross − topup fee), not the
                      // THB equivalent — deposits don't convert to THB.
                      const fee = topupFeeUsdt(order.amountUsdt);
                      const net = Math.max(0, order.amountUsdt - fee);
                      return (
                        <p className="text-green-400 font-mono font-bold text-sm">
                          +{net.toFixed(2)} USDT
                        </p>
                      );
                    })() : (
                      <p className="text-xs text-muted-foreground truncate max-w-[140px]">
                        {order.accountName || order.bankName}
                      </p>
                    )}
                    <span className={`text-[11px] font-medium ${cfg.color}`}>{cfg.label}</span>
                  </div>
                  <ArrowUpRight className="w-4 h-4 text-muted-foreground shrink-0" />
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}
