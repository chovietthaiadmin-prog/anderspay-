import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ArrowLeft,
  DatabaseBackup,
  Github,
  CheckCircle2,
  XCircle,
  Loader2,
  Clock,
  CalendarClock,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { useLang } from "@/lib/use-lang";
import { useAuth } from "@/lib/auth";
import { Card, CardContent } from "@/components/ui/card";

const API_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

interface BackupProgress {
  running: boolean;
  phase: string;
  percent: number;
  startedAt: string | null;
  lastError: string | null;
}

interface BackupStatusResponse {
  progress: BackupProgress;
  config: { tokenConfigured: boolean; repoConfigured: boolean; branch: string };
  schedule: "off" | "daily" | "weekly";
  lastRun: BackupRunRow | null;
}

interface BackupRunRow {
  id: string;
  trigger: string;
  status: string;
  sizeBytes: number | null;
  fileCount: number | null;
  commitSha: string | null;
  branch: string | null;
  fileName: string | null;
  error: string | null;
  durationMs: number | null;
  startedAt: string;
  finishedAt: string | null;
}

function formatBytes(n: number | null): string {
  if (n == null) return "—";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

function formatWhen(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleString(undefined, {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function AdminBackup() {
  const [, setLocation] = useLocation();
  const { t } = useLang();
  const b = t.adminBackup;
  const { user, token } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();

  const [testing, setTesting] = useState(false);
  const [starting, setStarting] = useState(false);
  const [savingSched, setSavingSched] = useState(false);

  const authHeaders: Record<string, string> = token
    ? { Authorization: `Bearer ${token}` }
    : {};

  const statusQuery = useQuery<BackupStatusResponse>({
    queryKey: ["admin-backup-status"],
    enabled: !!user?.isAdmin && !!token,
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/admin/backup/status`, { headers: authHeaders });
      if (!res.ok) throw new Error(b.loadError);
      return res.json();
    },
    refetchInterval: (query) => (query.state.data?.progress.running ? 1500 : 15000),
  });

  const historyQuery = useQuery<{ runs: BackupRunRow[] }>({
    queryKey: ["admin-backup-history"],
    enabled: !!user?.isAdmin && !!token,
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/admin/backup/history`, { headers: authHeaders });
      if (!res.ok) throw new Error(b.loadError);
      return res.json();
    },
    refetchInterval: statusQuery.data?.progress.running ? 4000 : false,
  });

  const status = statusQuery.data;
  const running = status?.progress.running ?? false;
  const configured = !!status && status.config.tokenConfigured && status.config.repoConfigured;

  const phaseLabel = (phase: string): string => {
    switch (phase) {
      case "starting":
        return b.phasePreparing;
      case "database_export":
        return b.phaseDumping;
      case "collect_files":
      case "archiving":
        return b.phaseArchiving;
      case "github_push":
        return b.phaseUploading;
      case "done":
        return b.phaseDone;
      case "failed":
        return b.phaseError;
      default:
        return phase;
    }
  };

  const startBackup = async () => {
    if (starting || running) return;
    setStarting(true);
    try {
      const res = await fetch(`${API_BASE}/api/admin/backup/run`, {
        method: "POST",
        headers: authHeaders,
      });
      if (res.status === 409) {
        toast({ description: b.alreadyRunning });
      } else if (!res.ok) {
        const data = await res.json().catch(() => null);
        toast({ variant: "destructive", description: data?.message || b.testFail });
      } else {
        toast({ description: b.started });
      }
      await qc.invalidateQueries({ queryKey: ["admin-backup-status"] });
    } finally {
      setStarting(false);
    }
  };

  const testGithub = async () => {
    if (testing) return;
    setTesting(true);
    try {
      const res = await fetch(`${API_BASE}/api/admin/backup/test-github`, {
        method: "POST",
        headers: authHeaders,
      });
      const data = await res.json().catch(() => null);
      if (data?.ok) {
        toast({ description: `${b.testOk}${data.message ? ` — ${data.message}` : ""}` });
      } else {
        toast({ variant: "destructive", description: `${b.testFail}${data?.message ? `: ${data.message}` : ""}` });
      }
    } finally {
      setTesting(false);
    }
  };

  const saveSchedule = async (mode: "off" | "daily" | "weekly") => {
    if (savingSched || status?.schedule === mode) return;
    setSavingSched(true);
    try {
      const res = await fetch(`${API_BASE}/api/admin/backup/schedule`, {
        method: "POST",
        headers: { ...authHeaders, "Content-Type": "application/json" },
        body: JSON.stringify({ mode }),
      });
      if (res.ok) {
        toast({ description: b.schedSaved });
        await qc.invalidateQueries({ queryKey: ["admin-backup-status"] });
      } else {
        const data = await res.json().catch(() => null);
        toast({ variant: "destructive", description: data?.message || b.testFail });
      }
    } finally {
      setSavingSched(false);
    }
  };

  if (!user?.isAdmin) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-sm text-muted-foreground">403</p>
      </div>
    );
  }

  const runs = historyQuery.data?.runs ?? [];

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-background/90 backdrop-blur border-b border-border">
        <div className="flex items-center gap-3 px-4 py-3 max-w-lg mx-auto">
          <button
            onClick={() => setLocation("/settings")}
            className="w-9 h-9 rounded-full flex items-center justify-center hover:bg-secondary/50 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1">
            <h1 className="text-base font-bold">{b.title}</h1>
            <p className="text-xs text-muted-foreground">{b.subtitle}</p>
          </div>
          <DatabaseBackup className="w-5 h-5 text-accent" />
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 pt-4 flex flex-col gap-4">
        {/* Config warning */}
        {status && !configured && (
          <Card className="bg-yellow-500/10 border-yellow-500/30">
            <CardContent className="p-3">
              <p className="text-xs text-yellow-300">{b.notConfigured}</p>
            </CardContent>
          </Card>
        )}

        {/* Actions */}
        <Card className="bg-card border-border">
          <CardContent className="p-4 flex flex-col gap-3">
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <Github className="w-3.5 h-3.5" />
                {b.branch}: <span className="text-foreground font-mono">{status?.config.branch ?? "backup"}</span>
              </span>
              <span className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" />
                {b.lastRun}: {formatWhen(status?.lastRun?.finishedAt ?? status?.lastRun?.startedAt ?? null)}
              </span>
            </div>

            {/* Progress bar while running */}
            {running && status && (
              <div className="flex flex-col gap-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1.5 text-accent">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    {phaseLabel(status.progress.phase)}
                  </span>
                  <span className="font-mono">{status.progress.percent}%</span>
                </div>
                <div className="h-2 rounded-full bg-secondary overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-primary to-accent"
                    animate={{ width: `${status.progress.percent}%` }}
                    transition={{ duration: 0.4 }}
                  />
                </div>
              </div>
            )}

            {status?.progress.lastError && !running && (
              <p className="text-xs text-red-400 break-all">{status.progress.lastError}</p>
            )}

            <button
              onClick={startBackup}
              disabled={running || starting || !configured}
              className="w-full py-3 rounded-xl bg-primary text-white text-sm font-bold disabled:opacity-40 hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
            >
              {running || starting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  {b.backupRunning}
                </>
              ) : (
                <>
                  <DatabaseBackup className="w-4 h-4" />
                  {b.backupNow}
                </>
              )}
            </button>
            <button
              onClick={testGithub}
              disabled={testing}
              className="w-full py-2.5 rounded-xl border border-border text-sm font-medium hover:bg-secondary/40 disabled:opacity-40 transition-colors flex items-center justify-center gap-2"
            >
              {testing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Github className="w-4 h-4" />}
              {testing ? b.testing : b.testGithub}
            </button>
          </CardContent>
        </Card>

        {/* Schedule */}
        <div className="flex flex-col gap-2">
          <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium flex items-center gap-1.5">
            <CalendarClock className="w-3.5 h-3.5" />
            {b.scheduleTitle}
          </p>
          <Card className="bg-card border-border">
            <CardContent className="p-0 flex">
              {(["off", "daily", "weekly"] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => saveSchedule(mode)}
                  disabled={savingSched}
                  className={`flex-1 py-2.5 text-xs font-bold transition-colors rounded-none first:rounded-l-xl last:rounded-r-xl ${
                    status?.schedule === mode
                      ? "bg-primary text-white"
                      : "text-muted-foreground hover:bg-secondary/50"
                  }`}
                >
                  {mode === "off" ? b.schedOff : mode === "daily" ? b.schedDaily : b.schedWeekly}
                </button>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* History */}
        <div className="flex flex-col gap-2">
          <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">
            {b.historyTitle}
          </p>
          {historyQuery.isError || statusQuery.isError ? (
            <p className="text-xs text-red-400">{b.loadError}</p>
          ) : runs.length === 0 ? (
            <p className="text-xs text-muted-foreground py-4 text-center">{b.empty}</p>
          ) : (
            <Card className="bg-card border-border">
              <CardContent className="p-0 divide-y divide-border">
                {runs.map((run) => (
                  <div key={run.id} className="flex items-center gap-3 p-3">
                    {run.status === "success" ? (
                      <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0" />
                    ) : run.status === "failed" ? (
                      <XCircle className="w-4 h-4 text-red-400 shrink-0" />
                    ) : (
                      <Loader2 className="w-4 h-4 text-accent animate-spin shrink-0" />
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium truncate font-mono">
                        {run.fileName || run.id.slice(0, 8)}
                      </p>
                      <p className="text-[11px] text-muted-foreground">
                        {formatWhen(run.startedAt)} · {run.trigger}
                        {run.fileCount != null && ` · ${run.fileCount} ${b.files}`}
                      </p>
                      {run.error && (
                        <p className="text-[11px] text-red-400 truncate">{run.error}</p>
                      )}
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-xs font-mono">{formatBytes(run.sizeBytes)}</p>
                      <p className="text-[11px] text-muted-foreground">
                        {run.status === "success"
                          ? b.statusSuccess
                          : run.status === "failed"
                            ? b.statusFailed
                            : b.statusRunning}
                      </p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
