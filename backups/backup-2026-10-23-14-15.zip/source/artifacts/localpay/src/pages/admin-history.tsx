import { useState } from "react";
import { useLocation, useSearch } from "wouter";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import {
  ArrowLeft,
  ShieldCheck,
  ArrowDownToLine,
  ArrowRightLeft,
  Minus,
  Plus,
  Activity,
  X,
  Send,
} from "lucide-react";
import { useLang } from "@/lib/use-lang";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";

const API_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

type TxType =
  | "deposit"
  | "convert_out"
  | "convert_in"
  | "topup_fee"
  | "payment_fee"
  | "payment"
  | "payment_refund"
  | "payment_refund_reversal"
  | "referral_reward"
  | "order_topup"
  | "order_payment";

type OrderStatus = "pending" | "paid" | "completed" | "expired" | "refunded" | "settled";
type HistoryCategory = "topup" | "convert" | "payment";

const CATEGORY_TYPES: Record<HistoryCategory, TxType[]> = {
  topup: ["deposit", "topup_fee", "order_topup"],
  convert: ["convert_in", "convert_out"],
  payment: ["payment", "payment_fee", "payment_refund", "payment_refund_reversal", "order_payment"],
};

interface AdminTx {
  id: string;
  code: string;
  source: "order" | "ledger";
  userId: string | null;
  type: TxType;
  amountUsdt: number;
  amountThb: number;
  rate: number;
  bahtSource: string | null;
  bahtSourceName: string | null;
  refOrderId: string | null;
  status: OrderStatus;
  createdAt: string;
  user: {
    uid: string | null;
    name: string | null;
    nickname: string | null;
    phone: string | null;
    avatarUrl: string | null;
  };
}

interface AdminTxResponse {
  total: number;
  orderCount?: number;
  ledgerCount?: number;
  transactions: AdminTx[];
}

function relativeTime(iso: string, t: ReturnType<typeof useLang>["t"]): string {
  const a = t.adminUsers;
  const diffMs = Date.now() - new Date(iso).getTime();
  const sec = Math.max(0, Math.floor(diffMs / 1000));
  if (sec < 60) return a.lastSeenJustNow;
  const min = Math.floor(sec / 60);
  if (min < 60) return a.lastSeenMinutes.replace("{n}", String(min));
  const hr = Math.floor(min / 60);
  if (hr < 24) return a.lastSeenHours.replace("{n}", String(hr));
  const day = Math.floor(hr / 24);
  return a.lastSeenDays.replace("{n}", String(day));
}

function localDateTime(iso: string): string {
  return new Date(iso).toLocaleString(undefined, {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
}

function Initials({ name }: { name: string }) {
  const ch = name
    .split(" ")
    .filter(Boolean)
    .map((w) => w[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
  return (
    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold text-xs shrink-0">
      {ch || "?"}
    </div>
  );
}

export default function AdminHistory() {
  const [, setLocation] = useLocation();
  const search = useSearch();
  const { t, lang } = useLang();
  const { user, token } = useAuth();
  const { toast } = useToast();
  const a = t.adminHistory;
  const [reporting, setReporting] = useState(false);
  const [category, setCategory] = useState<HistoryCategory>("topup");

  const sendReport = async () => {
    if (!token || reporting) return;
    setReporting(true);
    try {
      const res = await fetch(`${API_BASE}/api/admin/transactions/report`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ category }),
      });
      if (res.ok) {
        toast({ title: a.reportSent });
      } else {
        toast({ title: a.reportFailed, variant: "destructive" });
      }
    } catch {
      toast({ title: a.reportFailed, variant: "destructive" });
    } finally {
      setReporting(false);
    }
  };

  // Optional ?userId=<uuid> filter — set by the "Sao kê" button on the
  // admin-users page. When present, the feed shows only that user's
  // activity (orders + ledger entries) so admins can audit a single
  // member without scrolling through everyone else. The optional
  // `name` query param lets the banner render even when the user
  // has zero matching transactions (no row to derive a display name
  // from).
  const searchParams = new URLSearchParams(search);
  const filterUserId = searchParams.get("userId");
  const filterUserName = searchParams.get("name");

  if (!user?.isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center pt-20 gap-3 text-center">
        <ShieldCheck className="w-10 h-10 text-muted-foreground/40" />
        <p className="text-sm text-muted-foreground">Admin only</p>
      </div>
    );
  }

  // The server applies the userId filter when provided, so the
  // statement view sees the user's full history (not just rows that
  // fall inside the most-recent 300-row global window).
  const query = useQuery<AdminTxResponse>({
    queryKey: ["admin", "transactions", filterUserId ?? "all"],
    enabled: !!token,
    refetchInterval: 5000,
    queryFn: async () => {
      const qs = new URLSearchParams({ limit: "300" });
      if (filterUserId) qs.set("userId", filterUserId);
      const res = await fetch(`${API_BASE}/api/admin/transactions?${qs.toString()}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("admin_transactions_failed");
      return res.json();
    },
  });

  const data = query.data;

  // Prefer the explicit `?name=` from the admin-users link so the
  // banner works even when the user has zero transactions. Fall
  // back to the first matching row when navigating in directly.
  const derivedName = filterUserId
    ? data?.transactions.find((tx) => tx.userId === filterUserId)?.user
    : null;
  const filteredName =
    filterUserName ||
    derivedName?.nickname?.trim() ||
    derivedName?.name ||
    derivedName?.uid ||
    "—";

  const typeMeta: Record<TxType, { label: string; color: string; bg: string; icon: typeof Plus; sign: "+" | "-" | "" }> = {
    deposit:         { label: a.typeDeposit,        color: "text-green-400",  bg: "bg-green-400/10",  icon: ArrowDownToLine, sign: "+" },
    convert_in:      { label: a.typeConvertIn,      color: "text-green-400",  bg: "bg-green-400/10",  icon: ArrowRightLeft,  sign: "+" },
    convert_out:     { label: a.typeConvertOut,     color: "text-blue-400",   bg: "bg-blue-400/10",   icon: ArrowRightLeft,  sign: "-" },
    topup_fee:       { label: a.typeTopupFee,       color: "text-orange-400", bg: "bg-orange-400/10", icon: Minus,           sign: "-" },
    payment_fee:     { label: a.typePaymentFee,     color: "text-orange-400", bg: "bg-orange-400/10", icon: Minus,           sign: "-" },
    payment:         { label: a.typePayment,        color: "text-blue-400",   bg: "bg-blue-400/10",   icon: Minus,           sign: "-" },
    payment_refund:  { label: a.typePaymentRefund,  color: "text-green-400",  bg: "bg-green-400/10",  icon: Plus,            sign: "+" },
    payment_refund_reversal: { label: lang === "vi" ? "Đảo khoản hoàn" : "Refund reversal", color: "text-red-400", bg: "bg-red-400/10", icon: Minus, sign: "-" },
    referral_reward: { label: a.typeReferralReward, color: "text-green-400",  bg: "bg-green-400/10",  icon: Plus,            sign: "+" },
    order_topup:     { label: a.typeOrderTopup,     color: "text-green-400",  bg: "bg-green-400/10",  icon: ArrowDownToLine, sign: "+" },
    order_payment:   { label: a.typeOrderPayment,   color: "text-blue-400",   bg: "bg-blue-400/10",   icon: ArrowRightLeft,  sign: "-" },
  };

  const statusMeta: Record<OrderStatus, { label: string; cls: string }> = {
    pending:   { label: a.statusPending,   cls: "bg-yellow-400/15 text-yellow-300" },
    paid:      { label: a.statusPaid,      cls: "bg-blue-400/15 text-blue-300" },
    completed: { label: a.statusCompleted, cls: "bg-green-400/15 text-green-300" },
    expired:   { label: a.statusExpired,   cls: "bg-muted text-muted-foreground" },
    refunded:  { label: a.statusRefunded,  cls: "bg-red-400/15 text-red-300" },
    settled:   { label: a.statusSettled,   cls: "bg-green-400/15 text-green-300" },
  };

  const visibleTransactions =
    data?.transactions.filter((tx) => CATEGORY_TYPES[category].includes(tx.type)) ?? [];

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col gap-4 pb-28 pt-6"
    >
      <div className="flex items-center gap-3">
        <button
          onClick={() => setLocation("/")}
          className="w-9 h-9 rounded-full bg-secondary/40 hover:bg-secondary flex items-center justify-center"
          aria-label="back"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div className="flex-1 min-w-0">
          <h1 className="text-lg font-bold leading-tight">{a.title}</h1>
          <p className="text-[11px] text-muted-foreground">{a.subtitle}</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <Activity className="w-3 h-3" />
            {data?.transactions.length ?? 0}
          </div>
          <button
            onClick={() => void sendReport()}
            disabled={reporting || !data || visibleTransactions.length === 0}
            title={a.reportBtn}
            aria-label={a.reportBtn}
            className="w-8 h-8 rounded-full bg-primary/10 hover:bg-primary/20 text-primary flex items-center justify-center disabled:opacity-40 transition-colors"
          >
            {reporting
              ? <span className="w-3.5 h-3.5 border-2 border-primary/40 border-t-primary rounded-full animate-spin" />
              : <Send className="w-3.5 h-3.5" />
            }
          </button>
        </div>
      </div>

      {filterUserId && (
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-accent/10 border border-accent/30">
          <p className="flex-1 text-xs text-accent font-semibold truncate">
            {a.filterBanner.replace("{name}", filteredName)}
          </p>
          <button
            onClick={() => setLocation("/admin/history")}
            className="text-[10px] font-semibold text-muted-foreground hover:text-foreground inline-flex items-center gap-1 px-2 py-1 rounded hover:bg-secondary/40"
            data-testid="clear-statement-filter"
          >
            <X className="w-3 h-3" />
            {a.clearFilter}
          </button>
        </div>
      )}

      <div className="grid grid-cols-3 gap-1.5 rounded-xl bg-secondary/30 p-1">
        {([
          { key: "topup", label: a.categoryTopup, icon: ArrowDownToLine },
          { key: "convert", label: a.categoryConvert, icon: ArrowRightLeft },
          { key: "payment", label: a.categoryPayment, icon: Minus },
        ] as const).map(({ key, label, icon: CategoryIcon }) => {
          const selected = category === key;
          const count = data?.transactions.filter((tx) => CATEGORY_TYPES[key].includes(tx.type)).length ?? 0;
          return (
            <button
              key={key}
              type="button"
              onClick={() => setCategory(key)}
              className={`min-w-0 rounded-lg px-2 py-2 text-[10px] font-semibold transition-colors ${
                selected
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:bg-secondary hover:text-foreground"
              }`}
              aria-pressed={selected}
            >
              <span className="flex items-center justify-center gap-1">
                <CategoryIcon className="h-3 w-3 shrink-0" />
                <span className="truncate">{label}</span>
                <span className={selected ? "opacity-80" : "opacity-60"}>({count})</span>
              </span>
            </button>
          );
        })}
      </div>

      {query.isLoading ? (
        <div className="flex flex-col gap-2">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="h-16 bg-card animate-pulse rounded-xl" />
          ))}
        </div>
      ) : query.isError ? (
        <p className="text-sm text-red-400 text-center py-6">{a.loadError}</p>
      ) : data && visibleTransactions.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-6">{a.empty}</p>
      ) : (
        <div className="flex flex-col gap-2">
          {visibleTransactions.map((tx) => {
            const meta = typeMeta[tx.type] ?? typeMeta.deposit;
            const Icon = meta.icon;
            const display = tx.user.nickname?.trim() || tx.user.name || (tx.userId ? "—" : a.guest);
            const showUsdt = tx.amountUsdt > 0;
            const showThb = tx.amountThb > 0;
            const st = statusMeta[tx.status] ?? statusMeta.settled;
            return (
              <Card key={tx.id} className="bg-card border-border">
                <CardContent className="p-3 flex items-center gap-3">
                  <div className="relative shrink-0">
                    {tx.user.avatarUrl ? (
                      <img
                        src={
                          tx.user.avatarUrl.startsWith("http") || tx.user.avatarUrl.startsWith("data:")
                            ? tx.user.avatarUrl
                            : `${API_BASE}${tx.user.avatarUrl}`
                        }
                        alt=""
                        className="w-10 h-10 rounded-full object-cover"
                      />
                    ) : (
                      <Initials name={display} />
                    )}
                    <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-2 border-card flex items-center justify-center ${meta.bg}`}>
                      <Icon className={`w-2.5 h-2.5 ${meta.color}`} />
                    </div>
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <p className="font-bold text-sm truncate">{display}</p>
                      {tx.user.uid && (
                        <span className="text-[9px] font-mono font-semibold px-1.5 py-0.5 rounded bg-secondary/60 text-muted-foreground">
                          #{tx.user.uid}
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-muted-foreground flex items-center gap-1 flex-wrap">
                      <span className={`font-semibold ${meta.color}`}>{meta.label}</span>
                      <span className={`px-1.5 py-0.5 rounded text-[9px] font-semibold ${st.cls}`}>
                        {st.label}
                      </span>
                      <span>·</span>
                      <span title={relativeTime(tx.createdAt, t)}>
                        {localDateTime(tx.createdAt)}
                      </span>
                    </p>
                    <p className="text-[10px] font-mono text-muted-foreground/70 truncate">
                      {tx.code}
                    </p>
                    {tx.bahtSourceName && tx.type === "order_payment" && (
                      <p className="text-[10px] text-amber-300 truncate">
                        Nguồn Baht: {tx.bahtSourceName}
                      </p>
                    )}
                  </div>

                  <div className="text-right shrink-0">
                    {showUsdt && (
                      <p className={`text-xs font-mono tabular-nums font-bold ${meta.color}`}>
                        {meta.sign}
                        {tx.amountUsdt.toLocaleString("en-US", { maximumFractionDigits: 4 })}
                        <span className="text-[9px] ml-1">USDT</span>
                      </p>
                    )}
                    {showThb && (
                      <p className={`text-xs font-mono tabular-nums font-bold ${meta.color}`}>
                        {meta.sign}
                        {tx.amountThb.toLocaleString("th-TH", { maximumFractionDigits: 2 })}
                        <span className="text-[9px] ml-1">THB</span>
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </motion.div>
  );
}
