import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ArrowLeft, Users, Circle, ShieldCheck, ShieldOff, X,
  Trash2, Send, FileText, MessageCircle, ChevronRight,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { useLang } from "@/lib/use-lang";
import { useAuth } from "@/lib/auth";
import SupportChatModal from "@/components/support-chat";

const API_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

interface AdminUser {
  id: string;
  uid: string | null;
  name: string;
  nickname: string | null;
  phone: string;
  avatarUrl: string | null;
  usdtBalance: number;
  thbBalance: number;
  lastSeenAt: string | null;
  createdAt: string;
  online: boolean;
  isAdmin: boolean;
  isFoundingAdmin?: boolean;
}

interface AdminUsersResponse {
  onlineCount: number;
  total: number;
  users: AdminUser[];
}

function relativeLastSeen(iso: string | null, t: ReturnType<typeof useLang>["t"]): string {
  const a = t.adminUsers;
  if (!iso) return a.lastSeenNever;
  const diffMs = Date.now() - new Date(iso).getTime();
  const sec = Math.max(0, Math.floor(diffMs / 1000));
  if (sec < 60) return a.lastSeenJustNow;
  const min = Math.floor(sec / 60);
  if (min < 60) return a.lastSeenMinutes.replace("{n}", String(min));
  const hr = Math.floor(min / 60);
  if (hr < 24) return a.lastSeenHours.replace("{n}", String(hr));
  const day = Math.floor(hr / 24);
  return a.lastSeenDays.replace("{n}", String(day));
}

function absoluteLastSeen(iso: string | null, lang: string): string | null {
  if (!iso) return null;
  return new Intl.DateTimeFormat(lang === "vi" ? "vi-VN" : "en-GB", {
    timeZone: "Asia/Bangkok",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(new Date(iso));
}

function Avatar({ user, size = 36 }: { user: AdminUser; size?: number }) {
  const display = user.nickname?.trim() || user.name;
  const ch = display
    .split(" ")
    .filter(Boolean)
    .map((w) => w[0])
    .join("")
    .slice(0, 2)
    .toUpperCase() || "?";
  const px = `${size}px`;
  const text = size <= 32 ? "text-xs" : "text-sm";
  return user.avatarUrl ? (
    <img
      src={
        user.avatarUrl.startsWith("http") || user.avatarUrl.startsWith("data:")
          ? user.avatarUrl
          : `${API_BASE}${user.avatarUrl}`
      }
      alt=""
      style={{ width: px, height: px }}
      className="rounded-full object-cover shrink-0"
    />
  ) : (
    <div
      style={{ width: px, height: px }}
      className={`rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold shrink-0 ${text}`}
    >
      {ch}
    </div>
  );
}

// ── Compact user row ────────────────────────────────────────────────────────

function UserRow({
  u,
  t,
  lang,
  onOpen,
}: {
  u: AdminUser;
  t: ReturnType<typeof useLang>["t"];
  lang: string;
  onOpen: () => void;
}) {
  const a = t.adminUsers;
  const display = u.nickname?.trim() || u.name;
  const exactLastSeen = absoluteLastSeen(u.lastSeenAt, lang);
  return (
    <button
      onClick={onOpen}
      className="w-full flex items-center gap-3 px-4 py-3 hover:bg-secondary/30 active:bg-secondary/50 transition-colors text-left"
    >
      {/* avatar + online dot */}
      <div className="relative shrink-0">
        <Avatar user={u} size={38} />
        <span
          className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-card ${
            u.online ? "bg-green-400" : "bg-muted"
          }`}
        />
      </div>

      {/* name / phone */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 flex-wrap leading-none mb-0.5">
          <span className="text-sm font-semibold truncate">{display}</span>
          {u.isFoundingAdmin && (
            <span className="text-[8px] uppercase font-bold px-1 py-0.5 rounded bg-primary/20 text-primary leading-none">
              founder
            </span>
          )}
          {u.isAdmin && !u.isFoundingAdmin && (
            <span className="text-[8px] uppercase font-bold px-1 py-0.5 rounded bg-accent/20 text-accent leading-none">
              {a.adminBadge}
            </span>
          )}
        </div>
        <p className="text-[11px] text-muted-foreground font-mono leading-none">{u.phone}</p>
        <p
          className={`mt-1 truncate text-[10px] leading-none ${
            u.online ? "text-green-400" : "text-muted-foreground/80"
          }`}
          title={exactLastSeen ? `${a.lastSeen}: ${exactLastSeen}` : a.lastSeenNever}
        >
          {u.online ? `● ${a.online}` : `${a.lastSeen}: ${relativeLastSeen(u.lastSeenAt, t)}`}
        </p>
      </div>

      {/* balance + chevron */}
      <div className="text-right shrink-0 flex flex-col items-end gap-0.5">
        <p className="text-[11px] font-mono tabular-nums text-accent leading-none">
          {u.usdtBalance.toLocaleString("en-US", { maximumFractionDigits: 2 })}
          <span className="text-[9px] ml-0.5 text-muted-foreground">U</span>
        </p>
        <p className="text-[11px] font-mono tabular-nums text-green-400 leading-none">
          {u.thbBalance.toLocaleString("th-TH", { maximumFractionDigits: 0 })}
          <span className="text-[9px] ml-0.5 text-muted-foreground">฿</span>
        </p>
      </div>
      <ChevronRight className="w-3.5 h-3.5 text-muted-foreground/50 shrink-0" />
    </button>
  );
}

// ── User detail bottom sheet ────────────────────────────────────────────────

function UserSheet({
  u,
  meId,
  t,
  lang,
  onClose,
  onChat,
  onStatement,
  onToggleRole,
  onDelete,
}: {
  u: AdminUser;
  meId: string;
  t: ReturnType<typeof useLang>["t"];
  lang: string;
  onClose: () => void;
  onChat: () => void;
  onStatement: () => void;
  onToggleRole: () => void;
  onDelete: () => void;
}) {
  const a = t.adminUsers;
  const display = u.nickname?.trim() || u.name;
  const isMe = u.id === meId;
  const canToggle = !u.isFoundingAdmin && !isMe;
  const canDelete = !u.isFoundingAdmin && !isMe && !u.isAdmin;
  const exactLastSeen = absoluteLastSeen(u.lastSeenAt, lang);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end justify-center"
      onClick={onClose}
    >
      <motion.div
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        transition={{ type: "spring", stiffness: 320, damping: 32 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md bg-card border-t border-border rounded-t-2xl overflow-hidden"
        style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
      >
        {/* drag handle */}
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full bg-muted-foreground/30" />
        </div>

        {/* user info */}
        <div className="px-4 pt-2 pb-4 flex items-center gap-3 border-b border-border">
          <div className="relative shrink-0">
            <Avatar user={u} size={52} />
            <span
              className={`absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-card ${
                u.online ? "bg-green-400" : "bg-muted"
              }`}
            />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap mb-0.5">
              <p className="font-bold text-base truncate">{display}</p>
              {u.isFoundingAdmin && (
                <span className="text-[9px] uppercase font-bold px-1.5 py-0.5 rounded bg-primary/20 text-primary">
                  founder
                </span>
              )}
              {u.isAdmin && !u.isFoundingAdmin && (
                <span className="text-[9px] uppercase font-bold px-1.5 py-0.5 rounded bg-accent/20 text-accent">
                  {a.adminBadge}
                </span>
              )}
              {isMe && (
                <span className="text-[9px] uppercase font-bold px-1.5 py-0.5 rounded bg-secondary text-muted-foreground">
                  {a.youBadge}
                </span>
              )}
            </div>
            <p className="text-xs text-muted-foreground font-mono">{u.phone}</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">
              {u.online ? (
                <span className="text-green-400 font-semibold">● {a.online}</span>
              ) : (
                <span>
                  {a.lastSeen}: {relativeLastSeen(u.lastSeenAt, t)}
                  {exactLastSeen && <span className="ml-1 text-muted-foreground/60">· {exactLastSeen}</span>}
                </span>
              )}
            </p>
          </div>
          <div className="text-right shrink-0">
            <p className="text-xs font-mono tabular-nums text-accent">
              {u.usdtBalance.toLocaleString("en-US", { maximumFractionDigits: 4 })} USDT
            </p>
            <p className="text-xs font-mono tabular-nums text-green-400">
              {u.thbBalance.toLocaleString("th-TH", { maximumFractionDigits: 2 })} THB
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full hover:bg-secondary flex items-center justify-center text-muted-foreground shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* actions */}
        <div className="p-4 flex flex-col gap-2">
          {/* Chat */}
          <button
            onClick={onChat}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-primary/10 hover:bg-primary/15 transition-colors"
          >
            <MessageCircle className="w-4 h-4 text-primary shrink-0" />
            <span className="text-sm font-semibold text-primary">Nhắn tin hỗ trợ</span>
          </button>

          {/* Statement */}
          <button
            onClick={onStatement}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-secondary/40 hover:bg-secondary/70 transition-colors"
          >
            <FileText className="w-4 h-4 text-foreground shrink-0" />
            <span className="text-sm font-semibold">{a.statementBtn}</span>
          </button>

          {/* Promote / Demote */}
          {canToggle && (
            <button
              onClick={onToggleRole}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${
                u.isAdmin
                  ? "bg-red-500/10 hover:bg-red-500/15"
                  : "bg-accent/10 hover:bg-accent/15"
              }`}
            >
              {u.isAdmin ? (
                <ShieldOff className="w-4 h-4 text-red-400 shrink-0" />
              ) : (
                <ShieldCheck className="w-4 h-4 text-accent shrink-0" />
              )}
              <span className={`text-sm font-semibold ${u.isAdmin ? "text-red-400" : "text-accent"}`}>
                {u.isAdmin ? a.demote : a.promote}
              </span>
            </button>
          )}

          {/* Delete */}
          {canDelete && (
            <button
              onClick={onDelete}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-red-500/10 hover:bg-red-500/15 transition-colors"
            >
              <Trash2 className="w-4 h-4 text-red-400 shrink-0" />
              <span className="text-sm font-semibold text-red-400">{a.deleteBtn}</span>
            </button>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}

// ── Key-protected confirmation dialog (shared for role + delete + wipe) ─────

function ConfirmDialog({
  icon,
  iconClass,
  title,
  desc,
  subtitle,
  onClose,
  onConfirm,
  confirmLabel,
  confirmClass,
  opKey,
  setOpKey,
  submitting,
  feedback,
  borderClass,
}: {
  icon: React.ReactNode;
  iconClass: string;
  title: string;
  titleClass?: string;
  desc: string;
  subtitle?: string;
  onClose: () => void;
  onConfirm: () => void;
  confirmLabel: string;
  confirmClass: string;
  opKey: string;
  setOpKey: (v: string) => void;
  submitting: boolean;
  feedback: { kind: "ok" | "err"; msg: string } | null;
  borderClass?: string;
  a: ReturnType<typeof useLang>["t"]["adminUsers"];
}) {
  const a = arguments[0].a as ReturnType<typeof useLang>["t"]["adminUsers"];
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[60] bg-black/70 backdrop-blur-sm flex items-start justify-center p-4 pt-20 overflow-y-auto"
      onClick={() => !submitting && onClose()}
    >
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 20, opacity: 0 }}
        className={`w-full max-w-sm bg-card border rounded-2xl p-5 flex flex-col gap-4 ${borderClass ?? "border-border"}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start gap-3">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${iconClass}`}>
            {icon}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-base font-bold">{title}</h3>
            <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{desc}</p>
            {subtitle && <p className="text-xs font-semibold mt-2 truncate">{subtitle}</p>}
          </div>
          <button
            onClick={onClose}
            disabled={submitting}
            className="w-7 h-7 rounded-full hover:bg-secondary flex items-center justify-center text-muted-foreground"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <input
          type="password"
          autoComplete="off"
          value={opKey}
          onChange={(e) => setOpKey(e.target.value)}
          placeholder={a.keyPlaceholder}
          disabled={submitting}
          className="w-full px-3 py-2.5 rounded-lg bg-background border border-border text-sm font-mono focus:outline-none focus:border-primary"
          onKeyDown={(e) => { if (e.key === "Enter") onConfirm(); }}
        />
        {feedback && (
          <p className={`text-xs font-semibold ${feedback.kind === "ok" ? "text-green-400" : "text-red-400"}`}>
            {feedback.msg}
          </p>
        )}
        <div className="flex gap-2">
          <button
            onClick={onClose}
            disabled={submitting}
            className="flex-1 py-2.5 rounded-lg bg-secondary/60 text-foreground hover:bg-secondary transition-colors text-sm font-semibold disabled:opacity-50"
          >
            {a.cancel}
          </button>
          <button
            onClick={onConfirm}
            disabled={submitting || !opKey.trim()}
            className={`flex-1 py-2.5 rounded-lg text-sm font-bold text-white transition-colors disabled:opacity-50 ${confirmClass}`}
          >
            {submitting ? a.working : confirmLabel}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ── Main page ───────────────────────────────────────────────────────────────

export default function AdminUsers() {
  const [, setLocation] = useLocation();
  const { t, lang } = useLang();
  const { user, token } = useAuth();
  const a = t.adminUsers;
  const qc = useQueryClient();
  const { toast } = useToast();

  // Sheet state
  const [sheetUser, setSheetUser] = useState<AdminUser | null>(null);

  // Chat state
  const [chatUser, setChatUser] = useState<AdminUser | null>(null);

  // Role-toggle dialog
  const [target, setTarget] = useState<AdminUser | null>(null);
  const [opKey, setOpKey] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<{ kind: "ok" | "err"; msg: string } | null>(null);

  // Wipe dialog
  const [wipeOpen, setWipeOpen] = useState(false);
  const [wipeKey, setWipeKey] = useState("");
  const [wipeSubmitting, setWipeSubmitting] = useState(false);
  const [wipeFeedback, setWipeFeedback] = useState<{ kind: "ok" | "err"; msg: string } | null>(null);

  // Delete dialog
  const [deleteTarget, setDeleteTarget] = useState<AdminUser | null>(null);
  const [deleteKey, setDeleteKey] = useState("");
  const [deleteSubmitting, setDeleteSubmitting] = useState(false);
  const [deleteFeedback, setDeleteFeedback] = useState<{ kind: "ok" | "err"; msg: string } | null>(null);

  const [backupSubmitting, setBackupSubmitting] = useState(false);

  if (!user?.isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center pt-20 gap-3 text-center">
        <ShieldCheck className="w-10 h-10 text-muted-foreground/40" />
        <p className="text-sm text-muted-foreground">Admin only</p>
      </div>
    );
  }

  const query = useQuery<AdminUsersResponse>({
    queryKey: ["admin", "users"],
    enabled: !!token,
    refetchInterval: 5000,
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/admin/users`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("admin_users_failed");
      return res.json();
    },
  });
  const data = query.data;

  async function sendBackupNow() {
    if (backupSubmitting) return;
    setBackupSubmitting(true);
    try {
      const res = await fetch(`${API_BASE}/api/admin/balance-backup/run`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      });
      const body = (await res.json().catch(() => ({}))) as { ok?: boolean; reason?: string };
      if (res.ok && body.ok) toast({ title: a.sendBackupSuccess });
      else if (body.reason === "no_chat_id") toast({ title: a.sendBackupNoChat, variant: "destructive" });
      else toast({ title: a.sendBackupFailed, variant: "destructive" });
    } catch {
      toast({ title: a.sendBackupFailed, variant: "destructive" });
    } finally {
      setBackupSubmitting(false);
    }
  }

  function closeDialog() { setTarget(null); setOpKey(""); setSubmitting(false); setFeedback(null); }
  function closeWipe() { setWipeOpen(false); setWipeKey(""); setWipeSubmitting(false); setWipeFeedback(null); }
  function closeDelete() { setDeleteTarget(null); setDeleteKey(""); setDeleteSubmitting(false); setDeleteFeedback(null); }

  async function submitRoleChange() {
    if (!target || !opKey.trim() || submitting) return;
    setSubmitting(true); setFeedback(null);
    const desired = !target.isAdmin;
    try {
      const res = await fetch(`${API_BASE}/api/admin/users/${target.id}/role`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}`, "X-Destructive-Key": opKey.trim() },
        body: JSON.stringify({ isAdmin: desired }),
      });
      if (!res.ok) {
        const body = (await res.json().catch(() => ({}))) as { code?: string };
        setFeedback({ kind: "err", msg: body.code === "FOUNDING_ADMIN" ? a.errFoundingAdmin : body.code === "DESTRUCTIVE_KEY_REQUIRED" ? a.errBadKey : a.errGeneric });
        setSubmitting(false); return;
      }
      setFeedback({ kind: "ok", msg: desired ? a.successPromoted : a.successDemoted });
      await qc.invalidateQueries({ queryKey: ["admin", "users"] });
      setTimeout(() => closeDialog(), 900);
    } catch { setFeedback({ kind: "err", msg: a.errGeneric }); setSubmitting(false); }
  }

  async function submitWipe() {
    if (!wipeKey.trim() || wipeSubmitting) return;
    setWipeSubmitting(true); setWipeFeedback(null);
    try {
      const res = await fetch(`${API_BASE}/api/admin/balances/wipe`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "X-Destructive-Key": wipeKey.trim() },
      });
      if (!res.ok) {
        const body = (await res.json().catch(() => ({}))) as { code?: string };
        setWipeFeedback({ kind: "err", msg: body.code === "DESTRUCTIVE_KEY_REQUIRED" ? a.errBadKey : a.errGeneric });
        setWipeSubmitting(false); return;
      }
      const body = (await res.json()) as { affected: number; total: number };
      setWipeFeedback({ kind: "ok", msg: a.wipeBalancesSuccess.replace("{affected}", String(body.affected)).replace("{total}", String(body.total)) });
      await qc.invalidateQueries({ queryKey: ["admin", "users"] });
      setTimeout(() => closeWipe(), 1400);
    } catch { setWipeFeedback({ kind: "err", msg: a.errGeneric }); setWipeSubmitting(false); }
  }

  async function submitDelete() {
    if (!deleteTarget || !deleteKey.trim() || deleteSubmitting) return;
    setDeleteSubmitting(true); setDeleteFeedback(null);
    try {
      const res = await fetch(`${API_BASE}/api/admin/users/${deleteTarget.id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}`, "X-Destructive-Key": deleteKey.trim() },
      });
      if (!res.ok) {
        const body = (await res.json().catch(() => ({}))) as { code?: string };
        setDeleteFeedback({ kind: "err", msg: body.code === "FOUNDING_ADMIN" ? a.errFoundingAdmin : body.code === "CANNOT_DELETE_ADMIN" ? a.errDeleteAdmin : body.code === "DESTRUCTIVE_KEY_REQUIRED" ? a.errBadKey : a.errGeneric });
        setDeleteSubmitting(false); return;
      }
      setDeleteFeedback({ kind: "ok", msg: a.deleteSuccess });
      await qc.invalidateQueries({ queryKey: ["admin", "users"] });
      setTimeout(() => closeDelete(), 900);
    } catch { setDeleteFeedback({ kind: "err", msg: a.errGeneric }); setDeleteSubmitting(false); }
  }

  const sortedUsers = [...(data?.users ?? [])].sort((a, b) => {
    const an = (a.nickname?.trim() || a.name).toLocaleLowerCase("vi");
    const bn = (b.nickname?.trim() || b.name).toLocaleLowerCase("vi");
    return an.localeCompare(bn, "vi");
  });

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col gap-4 pb-28 pt-6"
      >
        {/* Header */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setLocation("/settings")}
            className="w-9 h-9 rounded-full bg-secondary/40 hover:bg-secondary flex items-center justify-center"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="text-lg font-bold leading-tight">{a.title}</h1>
            <p className="text-[11px] text-muted-foreground">{a.subtitle}</p>
          </div>
        </div>

        {/* Stats + tools in one compact row */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-card border border-border flex-1">
            <Circle className="w-2 h-2 fill-green-400 text-green-400 animate-pulse shrink-0" />
            <span className="text-xs text-muted-foreground">{a.online}</span>
            <span className="text-sm font-bold text-green-400 ml-auto tabular-nums">{data?.onlineCount ?? 0}</span>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-card border border-border flex-1">
            <Users className="w-3 h-3 text-muted-foreground shrink-0" />
            <span className="text-xs text-muted-foreground">{a.total}</span>
            <span className="text-sm font-bold ml-auto tabular-nums">{data?.total ?? 0}</span>
          </div>
          <button
            onClick={sendBackupNow}
            disabled={backupSubmitting}
            title={a.sendBackupBtn}
            className="w-10 h-10 rounded-lg bg-accent/10 hover:bg-accent/20 text-accent border border-accent/30 flex items-center justify-center disabled:opacity-50 transition-colors shrink-0"
          >
            <Send className="w-4 h-4" />
          </button>
          <button
            onClick={() => { setWipeOpen(true); setWipeKey(""); setWipeFeedback(null); }}
            title={a.wipeBalancesBtn}
            className="w-10 h-10 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 flex items-center justify-center transition-colors shrink-0"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>

        {/* User list */}
        {query.isLoading ? (
          <div className="flex flex-col gap-1">
            {[0, 1, 2, 4].map((i) => (
              <div key={i} className="h-14 bg-card animate-pulse rounded-xl" />
            ))}
          </div>
        ) : query.isError ? (
          <p className="text-sm text-red-400 text-center py-6">{a.loadError}</p>
        ) : sortedUsers.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-6">{a.empty}</p>
        ) : (
          <div className="bg-card border border-border rounded-xl overflow-hidden divide-y divide-border/60">
            {sortedUsers.map((u) => (
              <UserRow
                key={u.id}
                u={u}
                t={t}
                lang={lang}
                onOpen={() => setSheetUser(u)}
              />
            ))}
          </div>
        )}
      </motion.div>

      {/* User detail sheet */}
      <AnimatePresence>
        {sheetUser && (
          <UserSheet
            u={sheetUser}
            meId={user.id}
            t={t}
            lang={lang}
            onClose={() => setSheetUser(null)}
            onChat={() => {
              setSheetUser(null);
              setChatUser(sheetUser);
            }}
            onStatement={() => {
              const display = sheetUser.nickname?.trim() || sheetUser.name || sheetUser.uid || "";
              const qs = new URLSearchParams({ userId: sheetUser.id });
              if (display) qs.set("name", display);
              setSheetUser(null);
              setLocation(`/admin/history?${qs.toString()}`);
            }}
            onToggleRole={() => {
              setTarget(sheetUser);
              setOpKey(""); setFeedback(null);
              setSheetUser(null);
            }}
            onDelete={() => {
              setDeleteTarget(sheetUser);
              setDeleteKey(""); setDeleteFeedback(null);
              setSheetUser(null);
            }}
          />
        )}
      </AnimatePresence>

      {/* Support chat modal — admin view pre-selected to this user */}
      {chatUser && (
        <SupportChatModal
          open={true}
          onClose={() => setChatUser(null)}
          initialUserId={chatUser.id}
          initialUserName={chatUser.nickname?.trim() || chatUser.name || chatUser.phone}
        />
      )}

      {/* Role-toggle dialog */}
      <AnimatePresence>
        {target && (
          <ConfirmDialog
            icon={target.isAdmin ? <ShieldOff className="w-5 h-5" /> : <ShieldCheck className="w-5 h-5" />}
            iconClass={target.isAdmin ? "bg-red-500/15 text-red-400" : "bg-accent/15 text-accent"}
            title={target.isAdmin ? a.demoteTitle : a.promoteTitle}
            desc={target.isAdmin ? a.demoteDesc : a.promoteDesc}
            subtitle={`${target.nickname?.trim() || target.name} · ${target.phone}`}
            onClose={closeDialog}
            onConfirm={submitRoleChange}
            confirmLabel={a.confirm}
            confirmClass={target.isAdmin ? "bg-red-500 hover:bg-red-500/90" : "bg-accent hover:bg-accent/90"}
            opKey={opKey}
            setOpKey={setOpKey}
            submitting={submitting}
            feedback={feedback}
            a={a}
          />
        )}
      </AnimatePresence>

      {/* Wipe balances dialog */}
      <AnimatePresence>
        {wipeOpen && (
          <ConfirmDialog
            icon={<Trash2 className="w-5 h-5" />}
            iconClass="bg-red-500/15 text-red-400"
            title={a.wipeBalancesTitle}
            desc={a.wipeBalancesDesc}
            onClose={closeWipe}
            onConfirm={submitWipe}
            confirmLabel={a.wipeBalancesConfirm}
            confirmClass="bg-red-500 hover:bg-red-500/90"
            opKey={wipeKey}
            setOpKey={setWipeKey}
            submitting={wipeSubmitting}
            feedback={wipeFeedback}
            borderClass="border-red-500/40"
            a={a}
          />
        )}
      </AnimatePresence>

      {/* Delete member dialog */}
      <AnimatePresence>
        {deleteTarget && (
          <ConfirmDialog
            icon={<Trash2 className="w-5 h-5" />}
            iconClass="bg-red-500/15 text-red-400"
            title={a.deleteTitle}
            desc={a.deleteDesc}
            subtitle={`${deleteTarget.nickname?.trim() || deleteTarget.name} · ${deleteTarget.phone}`}
            onClose={closeDelete}
            onConfirm={submitDelete}
            confirmLabel={a.deleteConfirm}
            confirmClass="bg-red-500 hover:bg-red-500/90"
            opKey={deleteKey}
            setOpKey={setDeleteKey}
            submitting={deleteSubmitting}
            feedback={deleteFeedback}
            borderClass="border-red-500/40"
            a={a}
          />
        )}
      </AnimatePresence>
    </>
  );
}
