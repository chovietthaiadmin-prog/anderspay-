import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  UserPlus,
  Users,
  MessageCircle,
  Check,
  X,
  UserMinus,
  ChevronLeft,
  Send,
  ImageIcon,
  Smile,
  CheckSquare,
  Trash2,
  Square,
  FileImage,
  Film,
  RefreshCw,
  Clock3,
  ShieldCheck,
} from "lucide-react";
import { useLang } from "@/lib/use-lang";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  searchByUid,
  getFriends,
  getFriendRequests,
  sendFriendRequest,
  acceptRequest,
  declineRequest,
  removeFriend,
  getMessages,
  deleteMessages,
  sendMessage,
  sendMediaMessage,
  fetchMediaObjectUrl,
  pingChatPresence,
  type FriendUser,
  type FriendEntry,
  type RequestEntry,
  type SearchResult,
  type PeerMessage,
  type UploadProgress,
} from "@/lib/friends-api";

const POLL_MS = 3000;
const DEFAULT_FRIEND_MSG_TTL_MS = 24 * 60 * 60 * 1000;

// Accepted media types for file picker
const ACCEPT_MEDIA = "image/*,video/*";

// Quick emoji set
const QUICK_EMOJIS = ["😂", "❤️", "😍", "🥰", "😊", "🔥", "👏", "🎉", "😭", "💯", "🙏", "😘"];

function Avatar({
  user,
  size = 10,
}: {
  user: Pick<FriendUser, "avatarUrl" | "name">;
  size?: number;
}) {
  const dim = `w-${size} h-${size}`;
  const cls = `${dim} rounded-full flex items-center justify-center shrink-0 overflow-hidden bg-primary/20 border border-primary/30 relative`;
  return (
    <div className="relative shrink-0">
      {user.avatarUrl ? (
        <img src={user.avatarUrl} alt={user.name} className={`${dim} rounded-full object-cover border border-primary/20`} />
      ) : (
        <div className={cls}>
          <span className="text-primary font-bold text-sm select-none">
            {(user.name ?? "?")[0].toUpperCase()}
          </span>
        </div>
      )}
    </div>
  );
}

function displayName(u: Pick<FriendUser, "name" | "nickname">): string {
  return u.nickname ?? u.name;
}

function ChatMedia({
  imageUrl,
  token,
  isVideo,
  onOpen,
}: {
  imageUrl: string;
  token: string;
  isVideo: boolean;
  onOpen: (url: string) => void;
}) {
  const [objectUrl, setObjectUrl] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);
  const [retryKey, setRetryKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    let createdUrl: string | null = null;
    setObjectUrl(null);
    setFailed(false);

    fetchMediaObjectUrl(imageUrl, token)
      .then((url) => {
        createdUrl = url;
        if (cancelled) {
          URL.revokeObjectURL(url);
        } else {
          setObjectUrl(url);
        }
      })
      .catch(() => {
        if (!cancelled) setFailed(true);
      });

    return () => {
      cancelled = true;
      if (createdUrl) URL.revokeObjectURL(createdUrl);
    };
  }, [imageUrl, token, retryKey]);

  if (failed) {
    return (
      <div className="flex min-h-[148px] w-[220px] flex-col items-center justify-center gap-2 bg-gradient-to-br from-zinc-800 to-zinc-950 px-4 text-center text-white">
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10">
          {isVideo ? <Film className="h-5 w-5 text-white/75" /> : <FileImage className="h-5 w-5 text-white/75" />}
        </div>
        <p className="text-xs font-medium text-white/85">Không thể hiển thị tệp</p>
        <button
          type="button"
          onClick={(event) => {
            event.stopPropagation();
            setRetryKey((value) => value + 1);
          }}
          className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1.5 text-[11px] font-semibold text-white transition-colors hover:bg-white/20"
        >
          <RefreshCw className="h-3 w-3" />
          Thử lại
        </button>
      </div>
    );
  }

  if (!objectUrl) {
    return (
      <div className="flex min-h-[148px] w-[220px] flex-col items-center justify-center gap-2 bg-secondary/60 text-muted-foreground">
        <RefreshCw className="h-5 w-5 animate-spin opacity-60" />
        <span className="text-[11px]">Đang tải…</span>
      </div>
    );
  }

  if (isVideo) {
    return (
      <video
        src={objectUrl}
        controls
        playsInline
        className="block w-full"
        style={{ maxHeight: 320 }}
        onError={() => setFailed(true)}
      />
    );
  }

  return (
    <img
      src={objectUrl}
      alt="Ảnh trong tin nhắn"
      className="block w-full cursor-pointer object-cover"
      style={{ maxHeight: 320 }}
      onClick={() => onOpen(objectUrl)}
      onError={() => setFailed(true)}
    />
  );
}

// ── Chat view ──────────────────────────────────────────────────────────────

function Chat({
  friend,
  friendshipId,
  myId,
  token,
  onBack,
  t,
}: {
  friend: FriendUser;
  friendshipId: string;
  myId: string;
  token: string;
  onBack: () => void;
  t: ReturnType<typeof useLang>["t"];
}) {
  const [messages, setMessages] = useState<PeerMessage[]>([]);
  const [ttlMs, setTtlMs] = useState(DEFAULT_FRIEND_MSG_TTL_MS);
  const [now, setNow] = useState(() => Date.now());
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [showEmoji, setShowEmoji] = useState(false);
  // Pending file to upload (stored as File, not base64, to support large videos)
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  // Local object URL for thumbnail preview (revoked on clear)
  const [thumbUrl, setThumbUrl] = useState<string | null>(null);
  // Upload progress state
  const [uploadProgress, setUploadProgress] = useState<UploadProgress | null>(null);
  const [selectionMode, setSelectionMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const emojiRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const ft = t.friends;

  // Poll messages
  useEffect(() => {
    let cancelled = false;
    const poll = () =>
      getMessages(friendshipId, token)
        .then(({ messages: msgs, ttlMs: serverTtlMs }) => {
          if (cancelled) return;
          setMessages(msgs);
          if (Number.isFinite(serverTtlMs) && serverTtlMs > 0) setTtlMs(serverTtlMs);
        })
        .catch(() => {});
    poll();
    const id = setInterval(poll, POLL_MS);
    return () => { cancelled = true; clearInterval(id); };
  }, [friendshipId, token]);

  // Keep the expiration countdown under each message accurate to the second.
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  // Presence heartbeat — tells the server the user is actively viewing
  // this chat so Telegram notifications are suppressed while they're here.
  useEffect(() => {
    pingChatPresence(friendshipId, token);          // ping immediately on open
    const id = setInterval(() => pingChatPresence(friendshipId, token), 20_000);
    return () => clearInterval(id);
  }, [friendshipId, token]);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  // Close emoji picker on outside click
  useEffect(() => {
    if (!showEmoji) return;
    function onOutside(e: MouseEvent) {
      if (emojiRef.current && !emojiRef.current.contains(e.target as Node)) setShowEmoji(false);
    }
    document.addEventListener("mousedown", onOutside);
    return () => document.removeEventListener("mousedown", onOutside);
  }, [showEmoji]);

  // Auto-resize textarea
  useEffect(() => {
    if (!inputRef.current) return;
    inputRef.current.style.height = "auto";
    inputRef.current.style.height = `${Math.min(inputRef.current.scrollHeight, 120)}px`;
  }, [draft]);

  // Revoke object URL when pending file is cleared
  useEffect(() => {
    return () => { if (thumbUrl) URL.revokeObjectURL(thumbUrl); };
  }, [thumbUrl]);

  function clearPendingFile() {
    setPendingFile(null);
    if (thumbUrl) { URL.revokeObjectURL(thumbUrl); setThumbUrl(null); }
  }

  async function handleSend() {
    const body = draft.trim();
    if ((!body && !pendingFile) || sending) return;
    setSending(true);
    setUploadProgress(null);
    try {
      if (pendingFile) {
        const { message } = await sendMediaMessage(
          friendshipId,
          pendingFile,
          token,
          body,
          (p) => setUploadProgress(p)
        );
        setDraft("");
        clearPendingFile();
        setMessages((prev) => [...prev, message]);
      } else {
        const { message } = await sendMessage(friendshipId, body, token);
        setDraft("");
        setMessages((prev) => [...prev, message]);
      }
    } catch {
      toast({ title: pendingFile ? ft.imageError : ft.sendError, variant: "destructive" });
    } finally {
      setSending(false);
      setUploadProgress(null);
      inputRef.current?.focus();
    }
  }

  async function handleLike() {
    if (sending) return;
    setSending(true);
    try {
      const { message } = await sendMessage(friendshipId, ft.likeEmoji, token);
      setMessages((prev) => [...prev, message]);
    } catch {
      toast({ title: ft.sendError, variant: "destructive" });
    } finally {
      setSending(false);
    }
  }

  function handleFilePick(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    clearPendingFile();
    setPendingFile(file);
    setThumbUrl(URL.createObjectURL(file));
    e.target.value = "";
  }

  function insertEmoji(emoji: string) {
    setDraft((d) => d + emoji);
    setShowEmoji(false);
    inputRef.current?.focus();
  }

  function toggleSelectionMode() {
    setSelectionMode((current) => {
      if (current) setSelectedIds(new Set());
      return !current;
    });
  }

  function toggleMessageSelection(messageId: string) {
    setSelectedIds((current) => {
      const next = new Set(current);
      if (next.has(messageId)) next.delete(messageId);
      else next.add(messageId);
      return next;
    });
  }

  async function handleDeleteSelected(mode: "me" | "everyone") {
    if (selectedIds.size === 0 || sending) return;
    setSending(true);
    const ids = [...selectedIds];
    try {
      await deleteMessages(friendshipId, ids, mode, token);
      setMessages((current) => current.filter((message) => !selectedIds.has(message.id)));
      setSelectedIds(new Set());
      setSelectionMode(false);
      toast({ title: ft.deleteSuccess });
    } catch {
      toast({ title: ft.deleteError, variant: "destructive" });
    } finally {
      setSending(false);
    }
  }

  const isVideo = (mime: string | null) => mime?.startsWith("video/") ?? false;
  const canSend = (draft.trim().length > 0 || pendingFile !== null) && !sending;

  function timeLabel(iso: string) {
    const diff = now - new Date(iso).getTime();
    const m = Math.floor(diff / 60000);
    if (m < 1) return ft.justNow;
    if (m < 60) return `${m}m`;
    return `${Math.floor(m / 60)}h`;
  }

  function expiryLabel(iso: string) {
    const remainingSeconds = Math.max(
      0,
      Math.ceil((new Date(iso).getTime() + ttlMs - now) / 1000),
    );
    const hours = Math.floor(remainingSeconds / 3600);
    const minutes = Math.floor((remainingSeconds % 3600) / 60);
    const seconds = remainingSeconds % 60;
    return `${ft.expiresIn} ${hours.toString().padStart(2, "0")}:${minutes
      .toString()
      .padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
  }

  // Group consecutive messages from same sender
  const grouped = messages.map((msg, i) => {
    const prev = messages[i - 1];
    const next = messages[i + 1];
    const isFirst = !prev || prev.senderId !== msg.senderId;
    const isLast = !next || next.senderId !== msg.senderId;
    return { msg, isFirst, isLast };
  });

  return (
    <div className="flex h-full min-h-0 flex-col bg-background pb-[calc(5rem+env(safe-area-inset-bottom))]">
      {/* ── Header ── */}
      <div className="flex shrink-0 items-center gap-3 border-b border-border/60 bg-card/90 px-3 py-3 shadow-[0_8px_24px_rgba(0,0,0,0.08)] backdrop-blur-xl">
        <button
          onClick={onBack}
          className="flex h-10 w-10 -ml-1 items-center justify-center rounded-full border border-border/70 bg-secondary/40 transition-colors hover:bg-secondary"
          aria-label={ft.tabFriends}
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-2.5 flex-1 min-w-0">
          <Avatar user={friend} size={10} />
          <div className="flex-1 min-w-0">
            <p className="truncate text-[15px] font-bold leading-tight">{displayName(friend)}</p>
            <p className="mt-0.5 truncate text-[11px] text-muted-foreground">
              {friend.uid ?? ft.ttlNote}
            </p>
          </div>
        </div>
        {selectionMode && (
          <span className="text-xs font-semibold text-primary whitespace-nowrap">
            {selectedIds.size} {ft.selected}
          </span>
        )}
        <div className="flex shrink-0 items-center gap-1">
          <button
            onClick={toggleSelectionMode}
            className={`flex h-10 w-10 items-center justify-center rounded-full border transition-colors ${
              selectionMode
                ? "border-primary/30 bg-primary/10 text-primary"
                : "border-border/70 bg-secondary/40 text-muted-foreground hover:bg-secondary hover:text-foreground"
            }`}
            title={selectionMode ? ft.cancelSelection : ft.selectMessages}
          >
            {selectionMode ? <X className="w-[18px] h-[18px]" /> : <CheckSquare className="w-[18px] h-[18px]" />}
          </button>
        </div>
      </div>

      {selectionMode && selectedIds.size > 0 && (
        <div className="flex items-center gap-2 px-3 py-2 border-b border-border/60 bg-secondary/20 shrink-0">
          <Trash2 className="w-4 h-4 text-destructive shrink-0" />
          <button
            onClick={() => void handleDeleteSelected("me")}
            disabled={sending}
            className="flex-1 rounded-lg border border-border px-2 py-1.5 text-xs font-semibold hover:bg-secondary/60 transition-colors disabled:opacity-50"
          >
            {ft.deleteForMe}
          </button>
          <button
            onClick={() => void handleDeleteSelected("everyone")}
            disabled={sending}
            className="flex-1 rounded-lg bg-destructive text-destructive-foreground px-2 py-1.5 text-xs font-semibold hover:bg-destructive/90 transition-colors disabled:opacity-50"
          >
            {ft.deleteForEveryone}
          </button>
        </div>
      )}

      {/* ── Messages ── */}
      <div className="flex min-h-0 flex-1 flex-col gap-0.5 overflow-y-auto bg-[radial-gradient(circle_at_top,hsl(var(--primary)/0.06),transparent_38%)] px-3 py-4">
        {messages.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center px-6 py-12 text-center">
            <div className="mb-5 rounded-full border border-primary/15 bg-primary/10 p-2 shadow-[0_16px_40px_hsl(var(--primary)/0.12)]">
              <Avatar user={friend} size={16} />
            </div>
            <div>
              <p className="text-lg font-black">{displayName(friend)}</p>
              {friend.uid && <p className="text-xs text-muted-foreground">{friend.uid}</p>}
            </div>
            <p className="mt-3 max-w-[250px] text-sm leading-relaxed text-muted-foreground">{ft.noMessages}</p>
            <div className="mt-5 flex items-center gap-2 rounded-full border border-border/70 bg-card/80 px-3 py-1.5 text-[11px] text-muted-foreground shadow-sm">
              <Clock3 className="h-3.5 w-3.5 text-primary" />
              {ft.ttlNote}
            </div>
          </div>
        ) : (
          <>
            <div className="flex justify-center mb-2">
              <span className="flex items-center gap-1.5 rounded-full border border-border/60 bg-card/80 px-3 py-1.5 text-[11px] text-muted-foreground shadow-sm">
                <Clock3 className="h-3 w-3 text-primary" />
                {ft.ttlNote}
              </span>
            </div>
            {grouped.map(({ msg, isFirst, isLast }) => {
              const isMe = msg.senderId === myId;
              const msgIsVideo = isVideo(msg.mediaMimeType);
              return (
                <div
                  key={msg.id}
                  onClick={() => selectionMode && toggleMessageSelection(msg.id)}
                  className={`flex items-end gap-2 ${isMe ? "flex-row-reverse" : "flex-row"} ${isFirst ? "mt-2" : "mt-0.5"} ${selectionMode ? "cursor-pointer" : ""}`}
                >
                  {selectionMode && (
                    <button
                      onClick={(event) => {
                        event.stopPropagation();
                        toggleMessageSelection(msg.id);
                      }}
                      className={`shrink-0 rounded-full ${selectedIds.has(msg.id) ? "text-primary" : "text-muted-foreground/60"}`}
                      aria-label={selectedIds.has(msg.id) ? "Deselect message" : "Select message"}
                    >
                      {selectedIds.has(msg.id) ? <CheckSquare className="w-5 h-5" /> : <Square className="w-5 h-5" />}
                    </button>
                  )}
                  {!isMe && (
                    <div className="w-7 shrink-0">
                      {isLast ? <Avatar user={friend} size={7} /> : null}
                    </div>
                  )}
                  <div className={`flex flex-col gap-0.5 max-w-[72%] ${isMe ? "items-end" : "items-start"}`}>
                    {/* Media attachment */}
                     {msg.imageUrl && (
                      <div
                        className={`overflow-hidden ${isMe ? "rounded-2xl rounded-br-sm" : "rounded-2xl rounded-bl-sm"}`}
                        style={{ maxWidth: 240 }}
                      >
                         <ChatMedia
                           imageUrl={msg.imageUrl}
                           token={token}
                           isVideo={msgIsVideo}
                           onOpen={(url) => window.open(url, "_blank", "noopener,noreferrer")}
                         />
                      </div>
                    )}
                    {/* Text bubble */}
                    {msg.body && (
                      <div
                        className={`px-3 py-2 text-sm break-words leading-snug ${
                          isMe
                            ? "bg-primary text-primary-foreground rounded-2xl rounded-br-sm"
                            : "rounded-2xl rounded-bl-sm border border-border/70 bg-card text-card-foreground shadow-sm"
                        }`}
                      >
                        <p className="whitespace-pre-wrap">{msg.body}</p>
                      </div>
                    )}
                    <p className={`text-[10px] text-muted-foreground/60 px-1 ${isMe ? "text-right" : "text-left"}`}>
                      {timeLabel(msg.createdAt)} · {expiryLabel(msg.createdAt)}
                    </p>
                  </div>
                </div>
              );
            })}
          </>
        )}
        <div ref={bottomRef} />
      </div>

      {/* ── Upload progress bar ── */}
      <AnimatePresence>
        {uploadProgress && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="px-4 py-2 border-t border-border/60 shrink-0 space-y-1"
          >
            <div className="flex justify-between text-[11px] text-muted-foreground">
              <span>Loading…</span>
              <span>{uploadProgress.percent}%</span>
            </div>
            <div className="h-1.5 rounded-full bg-secondary overflow-hidden">
              <motion.div
                className="h-full bg-primary rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${uploadProgress.percent}%` }}
                transition={{ ease: "linear", duration: 0.3 }}
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Media preview strip ── */}
      <AnimatePresence>
        {thumbUrl && pendingFile && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            className="px-3 py-2 border-t border-border/60 shrink-0 flex items-center gap-2"
          >
            <div className="relative inline-block">
              {isVideo(pendingFile.type) ? (
                <video
                  src={thumbUrl}
                  className="h-20 w-auto rounded-xl object-cover bg-black"
                  muted
                />
              ) : (
                <img src={thumbUrl} alt="preview" className="h-20 w-auto rounded-xl object-cover" />
              )}
              <button
                onClick={clearPendingFile}
                className="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-foreground text-background flex items-center justify-center shadow"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
            <div className="text-[11px] text-muted-foreground min-w-0">
              <p className="truncate font-medium">{pendingFile.name}</p>
               <p>{(pendingFile.size / 1024 / 1024).toFixed(1)} MB</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Input bar (Messenger-style) ── */}
      <div className="flex shrink-0 items-end gap-2 border-t border-border/60 bg-card/95 px-2.5 py-3 shadow-[0_-10px_30px_rgba(0,0,0,0.08)] backdrop-blur-xl">
        {/* Left action buttons */}
        <div className="flex items-center gap-1 shrink-0">
          {/* Media picker (images + videos) */}
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={sending}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-primary transition-colors hover:bg-primary/15 disabled:opacity-40"
            title="Send photo or video"
          >
            <ImageIcon className="w-5 h-5" />
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept={ACCEPT_MEDIA}
            className="hidden"
            onChange={handleFilePick}
          />

          {/* Emoji picker */}
          <div className="relative" ref={emojiRef}>
            <button
              onClick={() => setShowEmoji((v) => !v)}
              className="flex h-9 w-9 items-center justify-center rounded-full bg-secondary/70 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
              title="Emoji"
            >
              <Smile className="w-5 h-5" />
            </button>
            <AnimatePresence>
              {showEmoji && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9, y: 4 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9, y: 4 }}
                  className="absolute bottom-full left-0 mb-2 bg-card border border-border rounded-2xl shadow-xl p-2 z-50 grid grid-cols-6 gap-1"
                  style={{ minWidth: 200 }}
                >
                  {QUICK_EMOJIS.map((e) => (
                    <button key={e} onClick={() => insertEmoji(e)} className="text-xl p-1.5 rounded-lg hover:bg-secondary/60 transition-colors">
                      {e}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Text input (pill) */}
        <div className="flex-1 min-w-0">
          <textarea
            ref={inputRef}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder={ft.messagePlaceholder}
            rows={1}
            maxLength={2000}
            disabled={sending}
            className="w-full resize-none overflow-hidden rounded-[20px] border border-border/70 bg-background/70 px-4 py-2 text-sm leading-snug shadow-inner transition-all placeholder:text-muted-foreground/60 focus:border-primary/40 focus:outline-none focus:ring-2 focus:ring-primary/15 disabled:opacity-60"
            style={{ minHeight: 38, maxHeight: 120 }}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); void handleSend(); }
            }}
          />
        </div>

        {/* Right: send or like */}
        {canSend ? (
          <button
            onClick={() => void handleSend()}
            disabled={sending}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-[0_8px_20px_hsl(var(--primary)/0.3)] transition-all hover:bg-primary/90 disabled:opacity-50"
          >
            {sending ? (
              <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
              </svg>
            ) : (
              <Send className="w-4 h-4 translate-x-px" />
            )}
          </button>
        ) : (
          <button
            onClick={() => void handleLike()}
            disabled={sending}
            className="shrink-0 text-2xl leading-none px-1 hover:scale-125 transition-transform disabled:opacity-50"
            title="Like"
          >
            👍
          </button>
        )}
      </div>
    </div>
  );
}

// ── Search panel ─────────────────────────────────────────────────────────

function SearchPanel({
  token,
  onFriendAdded,
  onClose,
  t,
}: {
  token: string;
  onFriendAdded: () => void;
  onClose: () => void;
  t: ReturnType<typeof useLang>["t"];
}) {
  const ft = t.friends;
  const [uid, setUid] = useState("");
  const [result, setResult] = useState<SearchResult | null>(null);
  const [searching, setSearching] = useState(false);
  const [requesting, setRequesting] = useState(false);
  const { toast } = useToast();

  async function handleSearch() {
    const q = uid.trim();
    if (!q) return;
    setSearching(true);
    setResult(null);
    try {
      const r = await searchByUid(q, token);
      setResult(r);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "";
      if (msg === "not_found" || msg === "cannot_add_self") {
        toast({ title: msg === "cannot_add_self" ? ft.cannotAddSelf : ft.notFound, variant: "destructive" });
      } else {
        toast({ title: ft.searchError, variant: "destructive" });
      }
    } finally {
      setSearching(false);
    }
  }

  async function handleRequest() {
    if (!result) return;
    setRequesting(true);
    try {
      await sendFriendRequest(result.user.id, token);
      toast({ title: ft.requestSent });
      onFriendAdded();
      setUid("");
      setResult(null);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "";
      const already = msg === "already_friends" || msg === "request_pending";
      toast({
        title: already ? ft.alreadyFriends : ft.requestError,
        variant: already ? "default" : "destructive",
      });
    } finally {
      setRequesting(false);
    }
  }

  const fs = result?.friendship;
  const canRequest = result && (!fs || fs.status === "declined");

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl border border-primary/20 bg-card/80 p-4 space-y-3"
    >
      <div className="flex items-center gap-2">
        <Search className="w-4 h-4 text-primary" />
        <div className="flex-1 min-w-0">
          <h3 className="font-bold text-sm">{ft.addFriend}</h3>
          <p className="text-[11px] text-muted-foreground">{ft.searchHint}</p>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 rounded-full text-muted-foreground hover:bg-secondary/70 hover:text-foreground transition-colors"
          aria-label={ft.cancelSelection}
        >
          <X className="w-4 h-4" />
        </button>
      </div>
      <div className="flex gap-2">
        <Input
          value={uid}
          onChange={(e) => {
            const digits = e.target.value.replace(/\D/g, "").slice(0, 9);
            setUid(digits);
          }}
          placeholder={ft.uidPlaceholder}
          inputMode="numeric"
          maxLength={9}
          className="flex-1"
          onKeyDown={(e) => { if (e.key === "Enter") void handleSearch(); }}
        />
        <Button onClick={() => void handleSearch()} disabled={searching || !uid.trim()}>
          <Search className="w-4 h-4 mr-1" />
          {searching ? "…" : ft.searchButton}
        </Button>
      </div>
      <AnimatePresence>
        {result && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-3 p-3 rounded-xl border border-border bg-secondary/30"
          >
            <Avatar user={result.user} />
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm truncate">{displayName(result.user)}</p>
              {result.user.uid && (
                <p className="text-[11px] text-muted-foreground">{result.user.uid}</p>
              )}
              {fs && (
                <p className="text-[11px] text-amber-400 mt-0.5">
                  {fs.status === "accepted"
                    ? ft.alreadyFriends
                    : fs.status === "pending"
                    ? fs.iAmRequester
                      ? ft.requestSentStatus
                      : ft.requestReceived
                    : ft.declined}
                </p>
              )}
            </div>
            {canRequest && (
              <Button size="sm" onClick={() => void handleRequest()} disabled={requesting}>
                <UserPlus className="w-4 h-4 mr-1" />
                {ft.addBtn}
              </Button>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────

type Tab = "friends" | "requests";

type FriendsPageProps = {
  embedded?: boolean;
  onOpenChat?: (friend: FriendUser, friendshipId: string) => void;
};

export function FriendsPanel({ embedded = false, onOpenChat }: FriendsPageProps) {
  const { t } = useLang();
  const ft = t.friends;
  const { user, token } = useAuth();
  const { toast } = useToast();

  const [tab, setTab] = useState<Tab>("friends");
  const [showAddFriend, setShowAddFriend] = useState(false);
  const [friends, setFriends] = useState<FriendEntry[]>([]);
  const [requests, setRequests] = useState<RequestEntry[]>([]);
  const [chatTarget, setChatTarget] = useState<{ friend: FriendUser; friendshipId: string } | null>(null);
  const [loading, setLoading] = useState(true);
  const [requestedChatId, setRequestedChatId] = useState<string | null>(() => {
    if (typeof window === "undefined") return null;
    return new URLSearchParams(window.location.search).get("chat");
  });

  const loadAll = useCallback(() => {
    if (!token) return;
    Promise.all([getFriends(token), getFriendRequests(token)])
      .then(([f, r]) => { setFriends(f); setRequests(r); })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [token]);

  useEffect(() => {
    loadAll();
    const id = setInterval(loadAll, 10_000);
    return () => clearInterval(id);
  }, [loadAll]);

  // Messenger's recent-conversation list opens a specific friend chat through
  // this query parameter. Resolve it only after the friend list is available.
  useEffect(() => {
    if (!requestedChatId || loading) return;
    const target = friends.find(({ friendship, peer }) => friendship.id === requestedChatId && !!peer);
    if (target?.peer) {
      setChatTarget({ friend: target.peer, friendshipId: target.friendship.id });
      setRequestedChatId(null);
    }
  }, [friends, loading, requestedChatId]);

  async function handleAccept(fs: RequestEntry) {
    if (!token) return;
    try {
      await acceptRequest(fs.friendship.id, token);
      toast({ title: ft.accepted });
      loadAll();
    } catch {
      toast({ title: ft.acceptError, variant: "destructive" });
    }
  }

  async function handleDecline(fs: RequestEntry) {
    if (!token) return;
    try {
      await declineRequest(fs.friendship.id, token);
      loadAll();
    } catch {
      toast({ title: ft.declineError, variant: "destructive" });
    }
  }

  async function handleRemove(entry: FriendEntry) {
    if (!token) return;
    try {
      await removeFriend(entry.friendship.id, token);
      setFriends((prev) => prev.filter((f) => f.friendship.id !== entry.friendship.id));
    } catch {
      toast({ title: ft.removeError, variant: "destructive" });
    }
  }

  if (!user || !token) {
    return (
      <div className="flex flex-col items-center justify-center h-full gap-3 px-8 text-center">
        <Users className="w-12 h-12 text-muted-foreground/40" />
        <p className="text-muted-foreground text-sm">{ft.loginRequired}</p>
      </div>
    );
  }

  // Chat view occupies full screen
  if (chatTarget) {
    return (
      <div className="flex flex-col h-[calc(100dvh-2rem)] min-h-0 max-w-[480px] mx-auto">
        <Chat
          friend={chatTarget.friend}
          friendshipId={chatTarget.friendshipId}
          myId={user.id}
          token={token}
          onBack={() => setChatTarget(null)}
          t={t}
        />
      </div>
    );
  }

  return (
    <div
      className={`relative mx-auto flex min-h-full max-w-[480px] flex-col space-y-4 overflow-hidden ${
        embedded ? "w-full px-0 pb-0 pt-0" : "px-4 pb-24 pt-5"
      }`}
    >
      <div className="pointer-events-none absolute -right-24 -top-28 h-64 w-64 rounded-full bg-primary/10 blur-3xl" />

      {/* Header */}
      <div className="relative flex items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl border border-primary/20 bg-primary/10 text-primary shadow-[0_10px_30px_hsl(var(--primary)/0.12)]">
            <MessageCircle className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-2xl font-black tracking-tight">{ft.title}</h1>
            <p className="mt-0.5 text-xs text-muted-foreground">{ft.subtitle}</p>
          </div>
        </div>
        <button
          onClick={() => setShowAddFriend((current) => !current)}
          className={`flex h-11 items-center justify-center gap-2 rounded-2xl px-3.5 text-sm font-bold transition-all ${
            showAddFriend
              ? "border border-primary/25 bg-primary/10 text-primary"
              : "bg-primary text-primary-foreground shadow-[0_10px_24px_hsl(var(--primary)/0.25)] hover:bg-primary/90"
          }`}
          title={ft.addFriend}
        >
          {showAddFriend ? <X className="h-4 w-4" /> : <UserPlus className="h-4 w-4" />}
          <span className="hidden min-[370px]:inline">{showAddFriend ? ft.cancelSelection : ft.addFriend}</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="relative grid grid-cols-2 gap-1 rounded-2xl border border-border/60 bg-secondary/35 p-1.5 shadow-inner">
        {(["friends", "requests"] as Tab[]).map((id) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`relative flex items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-bold transition-all ${
              tab === id
                ? "border border-border/70 bg-card text-foreground shadow-[0_6px_18px_rgba(0,0,0,0.12)]"
                : "border border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            {id === "friends" ? <Users className="h-4 w-4" /> : <UserPlus className="h-4 w-4" />}
            <span>{id === "friends" ? ft.tabFriends : ft.tabRequests}</span>
            {id === "requests" && requests.length > 0 && (
              <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1.5 text-[10px] font-black text-primary-foreground">
                {requests.length}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* UID search — opened from the Add friend button beside the tabs */}
      <AnimatePresence initial={false}>
        {showAddFriend && (
          <SearchPanel
            token={token}
            onFriendAdded={loadAll}
            onClose={() => setShowAddFriend(false)}
            t={t}
          />
        )}
      </AnimatePresence>

      {/* Content */}
      <AnimatePresence mode="wait">
        {tab === "friends" ? (
          <motion.div
            key="friends"
            initial={{ opacity: 0, x: -12 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 12 }}
            className="space-y-2.5"
          >
            {loading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="flex items-center gap-3 rounded-2xl border border-border/50 bg-card/70 p-3.5">
                  <div className="h-12 w-12 shrink-0 animate-pulse rounded-full bg-secondary/70" />
                  <div className="flex-1 space-y-2">
                    <div className="h-3.5 w-2/5 animate-pulse rounded-full bg-secondary/80" />
                    <div className="h-2.5 w-3/5 animate-pulse rounded-full bg-secondary/50" />
                  </div>
                  <div className="h-9 w-9 animate-pulse rounded-full bg-secondary/60" />
                </div>
              ))
            ) : friends.length === 0 ? (
              <div className="flex flex-col items-center rounded-[24px] border border-dashed border-border/80 bg-card/55 px-6 py-12 text-center shadow-[0_18px_50px_rgba(0,0,0,0.08)]">
                <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-3xl border border-primary/20 bg-primary/10 text-primary">
                  <Users className="h-7 w-7" />
                </div>
                <p className="max-w-[270px] text-sm leading-relaxed text-muted-foreground">{ft.noFriends}</p>
                <button
                  onClick={() => setShowAddFriend(true)}
                  className="mt-5 flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground shadow-[0_10px_22px_hsl(var(--primary)/0.22)]"
                >
                  <UserPlus className="h-4 w-4" />
                  {ft.addFriend}
                </button>
              </div>
            ) : (
              friends.map(({ friendship, peer }) => {
                if (!peer) return null;
                return (
                  <motion.div
                    key={friendship.id}
                    layout
                    className="group flex items-center gap-2 rounded-2xl border border-border/70 bg-card/80 p-3 shadow-[0_8px_28px_rgba(0,0,0,0.08)] transition-all hover:border-primary/20 hover:bg-card"
                  >
                    <button
                      className="flex min-w-0 flex-1 items-center gap-3 text-left"
                      onClick={() => {
                        if (onOpenChat) {
                          onOpenChat(peer, friendship.id);
                        } else {
                          setChatTarget({ friend: peer, friendshipId: friendship.id });
                        }
                      }}
                    >
                      <Avatar user={peer} size={12} />
                      <div className="flex-1 min-w-0">
                        <p className="truncate text-[15px] font-bold">{displayName(peer)}</p>
                        {peer.uid && (
                          <p className="mt-1 truncate text-[11px] text-muted-foreground">UID · {peer.uid}</p>
                        )}
                      </div>
                      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary transition-transform group-hover:scale-105">
                        <MessageCircle className="h-4 w-4" />
                      </span>
                    </button>
                    <button
                      onClick={() => void handleRemove({ friendship, peer })}
                      className="flex h-9 w-8 items-center justify-center rounded-full text-muted-foreground/60 transition-colors hover:bg-destructive/10 hover:text-destructive"
                      title={ft.deleteForMe}
                    >
                      <UserMinus className="h-4 w-4" />
                    </button>
                  </motion.div>
                );
              })
            )}
          </motion.div>
        ) : (
          <motion.div
            key="requests"
            initial={{ opacity: 0, x: 12 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -12 }}
            className="space-y-2.5"
          >
            {loading ? (
              Array.from({ length: 2 }).map((_, i) => (
                <div key={i} className="flex items-center gap-3 rounded-2xl border border-border/50 bg-card/70 p-3.5">
                  <div className="h-12 w-12 shrink-0 animate-pulse rounded-full bg-secondary/70" />
                  <div className="flex-1 space-y-2">
                    <div className="h-3.5 w-1/2 animate-pulse rounded-full bg-secondary/80" />
                    <div className="h-2.5 w-1/3 animate-pulse rounded-full bg-secondary/50" />
                  </div>
                </div>
              ))
            ) : requests.length === 0 ? (
              <div className="flex flex-col items-center rounded-[24px] border border-dashed border-border/80 bg-card/55 px-6 py-12 text-center">
                <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-3xl border border-border/70 bg-secondary/60 text-muted-foreground">
                  <ShieldCheck className="h-7 w-7" />
                </div>
                <p className="text-sm text-muted-foreground">{ft.noRequests}</p>
              </div>
            ) : (
              requests.map(({ friendship, requester }) => {
                if (!requester) return null;
                return (
                  <motion.div
                    key={friendship.id}
                    layout
                    className="flex items-center gap-3 rounded-2xl border border-border/70 bg-card/80 p-3.5 shadow-[0_8px_28px_rgba(0,0,0,0.08)]"
                  >
                    <Avatar user={requester} size={12} />
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm truncate">{displayName(requester)}</p>
                      {requester.uid && (
                        <p className="text-[11px] text-muted-foreground">{requester.uid}</p>
                      )}
                    </div>
                    <div className="flex gap-1.5 shrink-0">
                      <button
                        onClick={() => void handleDecline({ friendship, requester })}
                        className="flex h-9 w-9 items-center justify-center rounded-full border border-border bg-secondary/40 transition-colors hover:bg-destructive/10 hover:text-destructive"
                      >
                        <X className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => void handleAccept({ friendship, requester })}
                        className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-[0_8px_18px_hsl(var(--primary)/0.22)] transition-colors hover:bg-primary/90"
                      >
                        <Check className="w-4 h-4" />
                      </button>
                    </div>
                  </motion.div>
                );
              })
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function FriendsPage() {
  return <FriendsPanel />;
}
