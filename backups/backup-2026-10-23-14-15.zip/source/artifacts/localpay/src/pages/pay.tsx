import { useMemo, useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Activity, CreditCard, WalletMinimal, ScanLine, X, ShieldCheck, Send, Building2, User as UserIcon, Phone as PhoneIcon, Coins } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import QrScannerModal from "@/components/qr-scanner-modal";
import { type PromPayInfo } from "@/lib/parse-promptpay-qr";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from "@/components/ui/input-otp";

import {
  useGetExchangeRate,
  useCreateOrder,
  useGetRecentOrders,
  useRequestPayOtp,
  getGetExchangeRateQueryKey,
  getGetRecentOrdersQueryKey,
} from "@workspace/api-client-react";
import { MIN_USDT_BALANCE } from "@/lib/fees";
import { isWithinWorkingHours } from "@/lib/working-hours";
import NightDelayWarning from "@/components/night-delay-warning";

const PAY_OTP_THRESHOLD_THB = 1000;
import { useLang } from "@/lib/use-lang";
import { useAuth } from "@/lib/auth";
import InlineAuth from "@/components/inline-auth";
import { ShieldAlert } from "lucide-react";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  WorkingHoursStatusPill,
  WorkingHoursWarningBanner,
} from "@/components/working-hours-notice";

const API_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const THAI_BANKS = [
  "PromPay",
  "TrueMoney Wallet",
  "Bangkok Bank (BBL)",
  "Kasikorn Bank (KBank)",
  "Krungthai Bank (KTB)",
  "SCB (Siam Commercial Bank)",
  "Bank of Ayudhya (Krungsri)",
  "TMBThanachart Bank (TTB)",
  "Kiatnakin Phatra Bank (KKP)",
  "CIMB Thai",
  "UOB Thailand",
  "Citibank Thailand",
  "Tisco Bank",
  "LH Bank",
  "Land and Houses Bank",
  "Islamic Bank of Thailand (IBANK)",
  "Government Savings Bank (GSB)",
  "Government Housing Bank (GHB)",
  "Bank for Agriculture (BAAC)",
  "Export-Import Bank (EXIM)",
];

export default function Pay() {
  const [, setLocation] = useLocation();
  const { t, lang } = useLang();
  const { user, token } = useAuth();
  const [scannerOpen, setScannerOpen] = useState(false);
  const [qrBanner, setQrBanner] = useState<PromPayInfo | null>(null);
  const [qrPreview, setQrPreview] = useState<{ info: PromPayInfo; raw: string } | null>(null);
  const [previewAmount, setPreviewAmount] = useState<string>("");
  const [qrPayload, setQrPayload] = useState<string | null>(null);
  // OTP step state
  const [otpOpen, setOtpOpen] = useState(false);
  const [otpCode, setOtpCode] = useState("");
  const [otpError, setOtpError] = useState<string | null>(null);
  const [pendingValues, setPendingValues] = useState<{
    amountUsdt: number;
    amountThb: number;
    bankName: string;
    accountNumber: string;
    accountName: string;
    qrPayload?: string;
  } | null>(null);
  // Banner shown when the server rejects with PENDING_ORDER_EXISTS.
  // `pendingOrderId` lets us link the user to the existing order's
  // status page so they can complete or cancel it.
  const [pendingOrderError, setPendingOrderError] = useState(false);
  const [pendingOrderId, setPendingOrderId] = useState<string | null>(null);
  // Hard pre-flight blocks surfaced as modals (server returns 401/402/403
  // with these codes — see artifacts/api-server/src/routes/orders.ts).
  // Each modal links the user directly to the page that resolves the
  // blocker (Settings → claim UID, or Topup → fund THB wallet) so the
  // recovery path is one click.
  const [uidRequiredOpen, setUidRequiredOpen] = useState(false);
  const [noDepositOpen, setNoDepositOpen] = useState(false);

  const { data: exchangeRate } = useGetExchangeRate({
    query: {
      queryKey: getGetExchangeRateQueryKey(),
      refetchInterval: 30000,
    },
  });

  const { data: recent } = useGetRecentOrders({
    query: { queryKey: getGetRecentOrdersQueryKey(), refetchInterval: 5000 },
  });

  // Spendable THB balance = the user's converted wallet balance (incremented
  // only when they explicitly press "convert USDT → THB"). Pending/un-converted
  // USDT must NOT inflate the available-to-spend amount here.
  const walletQuery = useQuery<{ usdtBalance: number; thbBalance: number }>({
    queryKey: ["wallet", "pay"],
    enabled: !!token,
    refetchInterval: 5000,
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/wallet`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("wallet_load_failed");
      return res.json();
    },
  });
  const totalThb = walletQuery.data?.thbBalance ?? 0;
  const rate = exchangeRate?.thbPerUsdt ?? 0;

  const formSchema = z.object({
    amountThb: z.coerce.number().min(1, "Tối thiểu 1 THB").max(20_000, "Tối đa 20.000 THB mỗi lệnh"),
    bankName: z.string().min(1, t.home.validationBank),
    accountNumber: z.string().min(6, t.home.validationAccount),
    accountName: z.string().min(2, t.home.validationName),
  });

  type FormValues = z.infer<typeof formSchema>;

  const { mutate: createOrder, isPending } = useCreateOrder({
    mutation: {
      onSuccess: (data) => {
        setOtpOpen(false);
        setOtpCode("");
        setPendingValues(null);
        setLocation(`/status/${data.id}`);
      },
      onError: (err: unknown) => {
        // Handle OTP- and fee-specific errors from /api/orders
        const e = err as { status?: number; data?: { code?: string; message?: string; existingOrderId?: string } };
        const code = e?.data?.code;
        if (code === "OTP_INVALID" || code === "OTP_REQUIRED") {
          setOtpError(t.payOtp.invalidCode);
          return;
        }
        if (code === "OTP_LOCKED") {
          setOtpError(t.payOtp.invalidCode);
          setOtpCode("");
          return;
        }
        if (code === "INSUFFICIENT_FEE_BALANCE" || code === "INSUFFICIENT_THB_BALANCE") {
          // Two distinct insufficient-balance errors from /api/orders:
          //   • INSUFFICIENT_THB_BALANCE — principal can't be covered
          //     by the user's THB wallet
          //   • INSUFFICIENT_FEE_BALANCE — service fee can't be covered
          //     by the user's USDT wallet (post-debit min-reserve guard)
          // Show the matching localized message in the OTP modal if
          // open, otherwise via a window-level alert fallback for the
          // non-OTP (small-amount) path.
          const msg =
            code === "INSUFFICIENT_THB_BALANCE"
              ? t.payFee.insufficientThb
              : t.payFee.insufficient;
          setOtpError(msg);
          if (!otpOpen) {
            window.alert(msg);
          }
          return;
        }
        // One-pending-Baht-order rule (server-enforced 409). Surface a
        // clear, non-destructive notice and offer to jump to the
        // existing order's status page.
        if (code === "PENDING_ORDER_EXISTS") {
          setOtpOpen(false);
          setPendingOrderId(e.data?.existingOrderId ?? null);
          setPendingOrderError(true);
          return;
        }
        // Pre-flight blockers — show the matching modal with a CTA
        // that takes the user directly to the page that fixes it.
        if (code === "UID_REQUIRED") {
          setOtpOpen(false);
          setUidRequiredOpen(true);
          return;
        }
        if (code === "NO_DEPOSIT") {
          setOtpOpen(false);
          setNoDepositOpen(true);
          return;
        }
        // Auth required (server-enforced 401). The form is normally
        // gated behind <InlineAuth /> for guests, but a token can also
        // expire mid-session, so surface a clear notice here too.
        if (code === "AUTH_REQUIRED") {
          setOtpOpen(false);
          window.alert(t.payFee.loginRequired);
          return;
        }
        // Catch-all: any other / unknown failure (unexpected code, 5xx,
        // network error) MUST still surface feedback. Without this the OTP
        // modal would sit silently after submit and look frozen — exactly
        // the symptom we're fixing. Prefer the server's message; fall back
        // to a generic one. Show it inside the modal if open, else alert.
        const fallbackMsg =
          (typeof e?.data?.message === "string" && e.data.message.trim()) ||
          t.payOtp.genericError;
        if (otpOpen) {
          setOtpError(fallbackMsg);
        } else {
          window.alert(fallbackMsg);
        }
      },
    },
  });

  const { mutate: requestPayOtp, isPending: requestingOtp } = useRequestPayOtp({
    mutation: {
      onSuccess: () => {
        setOtpError(null);
        setOtpCode("");
        setOtpOpen(true);
      },
      onError: (err: unknown) => {
        const e = err as { status?: number; data?: { code?: string; message?: string } };
        const code = e?.data?.code;
        if (e?.status === 412 || code === "TELEGRAM_NOT_LINKED") {
          setOtpError(t.payOtp.noTelegram);
          setOtpOpen(true);
          return;
        }
        // Prefer the server's localized message when it gives a specific
        // diagnosis (bot blocked / chat not found / not configured / …);
        // fall back to the generic translation only when nothing useful
        // came back from the API.
        const serverMsg = typeof e?.data?.message === "string" ? e.data.message : "";
        setOtpError(serverMsg || t.payOtp.sendError);
        setOtpOpen(true);
      },
    },
  });

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      amountThb: undefined,
      bankName: "",
      accountNumber: "",
      accountName: "",
    },
  });

  const amountThb = form.watch("amountThb");
  const requiredUsdt = useMemo(() => {
    if (!rate || !amountThb) return 0;
    return amountThb / rate;
  }, [amountThb, rate]);

  const remaining = totalThb - (amountThb || 0);

  function handleQrResult(info: PromPayInfo, raw: string) {
    setQrPreview({ info, raw });
    setPreviewAmount(info.amount && info.amount > 0 ? String(info.amount) : "");
  }

  function applyQrPreview() {
    if (!qrPreview) return;
    const { info, raw } = qrPreview;
    const amt = parseFloat(previewAmount);
    if (!Number.isFinite(amt) || amt <= 0) return;
    form.setValue("bankName", "PromPay", { shouldValidate: true });
    // Keep the raw numeric identifier for the bank transfer payload. The
    // formatted display value (for example 081-234-5678) is presentation-only
    // and must not be sent as the PromptPay account number.
    form.setValue("accountNumber", info.promptPayId, { shouldValidate: true });
    // accountName is required by the form schema (min 2). Many personal
    // PromPay QRs (e.g. KBank phone-number QRs) don't include a merchant
    // name, so fall back to a synthesised label that always satisfies the
    // schema. Without this the submit button silently fails because the
    // accountName field is hidden when a QR was scanned.
    const fallbackName = info.merchantName?.trim() || `PromPay ${info.displayId}`;
    form.setValue("accountName", fallbackName, { shouldValidate: true });
    form.setValue("amountThb", amt, { shouldValidate: true });
    setQrBanner(info);
    setQrPayload(raw);
    setQrPreview(null);
    setPreviewAmount("");
  }

  // Pending form values held back while the night-delay warning is open.
  // Set by `onSubmit` when the user is creating an order outside working
  // hours (23:00 – 08:00 ICT); cleared on cancel or after the user
  // confirms via the modal and the real submit flow runs.
  const [nightPendingValues, setNightPendingValues] = useState<FormValues | null>(null);

  function onSubmit(values: FormValues) {
    // Show the night-delay warning the first time the user submits
    // outside the 08:00–23:00 working window. After they press
    // "Continue" we re-enter `onSubmit` via `nightPendingValues` and
    // skip the gate, so the rest of the flow (OTP / direct create) is
    // unchanged.
    if (!isWithinWorkingHours() && nightPendingValues == null) {
      setNightPendingValues(values);
      return;
    }
    if (nightPendingValues != null) {
      setNightPendingValues(null);
    }

    // Convert THB → USDT for the API
    const amountUsdt = rate > 0 ? values.amountThb / rate : 0;
    const payload = {
      amountUsdt: parseFloat(amountUsdt.toFixed(6)),
      amountThb: values.amountThb,
      bankName: values.bankName,
      accountNumber: values.accountNumber,
      accountName: values.accountName,
      qrPayload: qrPayload ?? undefined,
    };

    if (values.amountThb > PAY_OTP_THRESHOLD_THB) {
      // Hold the values until user enters the OTP, then submit with otp.
      setPendingValues(payload);
      setOtpError(null);
      setOtpCode("");
      requestPayOtp({ data: { amountThb: values.amountThb } });
      return;
    }

    createOrder({
      data: {
        amountUsdt: payload.amountUsdt,
        bankName: payload.bankName,
        accountNumber: payload.accountNumber,
        accountName: payload.accountName,
        qrPayload: payload.qrPayload,
      },
    });
  }

  function submitWithOtp() {
    if (!pendingValues) return;
    if (otpCode.length !== 6) {
      setOtpError(t.payOtp.invalidCode);
      return;
    }
    setOtpError(null);
    createOrder({
      data: {
        amountUsdt: pendingValues.amountUsdt,
        bankName: pendingValues.bankName,
        accountNumber: pendingValues.accountNumber,
        accountName: pendingValues.accountName,
        qrPayload: pendingValues.qrPayload,
        otp: otpCode,
      },
    });
  }

  function resendOtp() {
    if (!pendingValues) return;
    setOtpError(null);
    setOtpCode("");
    requestPayOtp({ data: { amountThb: pendingValues.amountThb } });
  }

  if (user?.isAdmin) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col items-center justify-center gap-4 pt-24 pb-28 text-center"
      >
        <div className="w-16 h-16 rounded-full bg-accent/10 border border-accent/20 flex items-center justify-center">
          <ShieldAlert className="w-8 h-8 text-accent" />
        </div>
        <div>
          <p className="font-bold text-base">{lang === "vi" ? "Tính năng không khả dụng" : "Feature unavailable"}</p>
          <p className="text-xs text-muted-foreground mt-1">
            {lang === "vi" ? "Tài khoản admin không thể thực hiện thanh toán." : "Admin accounts cannot make payments."}
          </p>
        </div>
      </motion.div>
    );
  }

  return (
    <>
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col gap-4 pb-28"
    >
      {/* Header */}
      <div className="flex items-center gap-3 pt-6 pb-1">
        <div className="w-10 h-10 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
          <CreditCard className="w-5 h-5 text-primary" />
        </div>
        <div className="flex-1">
          <h1 className="text-xl font-bold">{t.nav.payment}</h1>
          <p className="text-muted-foreground text-xs">{t.home.subtitle}</p>
        </div>
        <div className="flex flex-col items-end gap-1 shrink-0">
          {exchangeRate && (
            <div className="flex items-center gap-1.5 text-xs text-accent font-mono font-bold">
              <Activity className="w-3 h-3 animate-pulse" />
              1 USDT = {rate.toFixed(2)} THB
            </div>
          )}
          <WorkingHoursStatusPill />
        </div>
      </div>

      {/* Outside-hours notice — non-blocking, only shown when closed */}
      <WorkingHoursWarningBanner />

      {/* One-pending-Baht-order rule: server returns 409
          PENDING_ORDER_EXISTS when this user already has an
          outstanding THB payment order. We surface a clean,
          dark-mode amber banner with a direct link to the existing
          order so the user can complete or cancel it. The form
          stays mounted so the user keeps their typed values. */}
      {pendingOrderError && (
        <div
          role="alert"
          className="rounded-xl border border-amber-500/40 bg-gradient-to-r from-amber-500/15 to-amber-500/5 px-3.5 py-3 flex items-start gap-2.5"
        >
          <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-500/40 flex items-center justify-center shrink-0">
            <ShieldAlert className="w-4 h-4 text-amber-300" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-[12px] font-bold text-amber-200">
              {t.payPending.title}
            </p>
            <p className="text-[11px] text-amber-100/85 leading-relaxed mt-0.5">
              {t.payPending.desc}
            </p>
            <div className="flex flex-wrap gap-2 mt-2">
              {pendingOrderId && (
                <button
                  type="button"
                  onClick={() => setLocation(`/status/${pendingOrderId}`)}
                  className="text-[11px] font-bold text-amber-300 underline underline-offset-2 hover:text-amber-200"
                >
                  {t.payPending.viewBtn}
                </button>
              )}
              <button
                type="button"
                onClick={() => {
                  setPendingOrderError(false);
                  setPendingOrderId(null);
                }}
                className="text-[11px] text-amber-300/80 hover:text-amber-200"
              >
                {t.payPending.dismissBtn}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Guest preview hint — show that the form is visible but locked */}
      {(!user || !token) && (
        <div className="flex items-start gap-3 p-3 rounded-xl bg-accent/10 border border-accent/30">
          <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center shrink-0 mt-0.5">
            <Activity className="w-4 h-4 text-accent" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold text-accent">
              {lang === "vi" ? "Đăng nhập để gửi lệnh" : "Login to send order"}
            </p>
            <p className="text-[11px] text-muted-foreground mt-0.5 leading-snug">
              {lang === "vi"
                ? "Bạn có thể xem trước các chức năng thanh toán bên dưới. Đăng nhập/Đăng ký để gửi lệnh thật."
                : "You can preview the payment fields below. Login/Register to actually send an order."}
            </p>
          </div>
        </div>
      )}

      {/* THB Balance + form — always visible (members and guests can preview) */}
      <>

      <Card className="border-border bg-card overflow-hidden relative">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-green-500 to-green-400 opacity-60" />
        <CardContent className="p-4">
          <p className="text-xs uppercase tracking-widest text-muted-foreground font-medium mb-1">
            {t.home.balanceLabel}
          </p>
          <div className="flex items-end gap-2">
            <span className={`text-3xl font-bold tabular-nums font-mono transition-colors ${remaining < 0 ? "text-red-400" : "text-green-400"}`}>
              {remaining.toLocaleString("th-TH", { maximumFractionDigits: 2 })}
            </span>
            <span className={`text-base font-bold mb-0.5 transition-colors ${remaining < 0 ? "text-red-400/70" : "text-green-400/70"}`}>THB</span>
          </div>
          {amountThb > 0 && (
            <p className="text-xs text-muted-foreground mt-1">
              {totalThb.toLocaleString("th-TH", { maximumFractionDigits: 2 })} − {amountThb.toLocaleString("th-TH", { maximumFractionDigits: 2 })}
            </p>
          )}
        </CardContent>
      </Card>

      {/* No balance hint — shown above the form, doesn't hide it */}
      {totalThb === 0 && (
        <div className="flex items-start gap-3 p-3 rounded-xl bg-primary/10 border border-primary/20">
          <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
            <WalletMinimal className="w-4 h-4 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold text-primary">{t.home.noBalance}</p>
            <p className="text-[11px] text-muted-foreground mt-0.5 leading-snug">{t.home.noBalanceHint}</p>
          </div>
        </div>
      )}

      {/* Form — always visible so customers can preview all payment fields */}
      <Card className="border-border bg-card overflow-hidden relative">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary to-accent opacity-60" />
        <CardContent className="p-5">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
              <fieldset disabled={!user || !token} className="space-y-5">

              {/* THB amount input */}
              <FormField
                control={form.control}
                name="amountThb"
                render={({ field }) => (
                  <FormItem>
                    <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium mb-2">
                      {t.home.thbAmountLabel}
                    </p>
                    <FormControl>
                      <div className="relative">
                        <Input
                          type="number"
                          step="1"
                          inputMode="numeric"
                          className="h-16 text-3xl font-bold tabular-nums pl-4 pr-20 bg-input border-border focus-visible:ring-primary rounded-xl"
                          placeholder="0"
                          {...field}
                        />
                        <div className="absolute right-4 top-1/2 -translate-y-1/2 text-green-400 font-bold text-sm">
                          THB
                        </div>
                      </div>
                    </FormControl>
                    <FormMessage />
                    {/* Per-order limit notice */}
                    <p className="text-[11px] text-muted-foreground/60 flex items-center gap-1 mt-1">
                      <span className="inline-block w-1.5 h-1.5 rounded-full bg-muted-foreground/40 shrink-0" />
                      {lang === "vi"
                        ? "Giới hạn hiện tại: tối đa 20.000 THB / lệnh"
                        : lang === "zh"
                        ? "当前限额：每笔最多 20,000 泰铢"
                        : "Current limit: max 20,000 THB per order"}
                    </p>
                  </FormItem>
                )}
              />

              {/* Service-fee preview is intentionally hidden here — it spooked
                  users at order time. Fees are itemized on the completed
                  payment receipt (status page) in USDT instead. */}

              <Separator className="bg-border" />

              {/* Bank details */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-semibold">{t.home.bankDetails}</h3>
                    <p className="text-xs text-muted-foreground">{t.home.bankDetailsHint}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setScannerOpen(true)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-primary/10 border border-primary/20 text-primary text-xs font-semibold hover:bg-primary/20 transition-colors shrink-0"
                  >
                    <ScanLine className="w-4 h-4" />
                    {t.scan.scanBtn}
                  </button>
                </div>

                {/* QR fill banner */}
                <AnimatePresence>
                  {qrBanner && (
                    <motion.div
                      initial={{ opacity: 0, y: -8, height: 0 }}
                      animate={{ opacity: 1, y: 0, height: "auto" }}
                      exit={{ opacity: 0, y: -8, height: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="flex items-start gap-3 p-3 rounded-xl bg-green-500/10 border border-green-500/20">
                        <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center shrink-0 mt-0.5">
                          <ScanLine className="w-4 h-4 text-green-400" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold text-green-400">{t.scan.fillFromQr}</p>
                          <p className="text-xs text-muted-foreground mt-0.5 truncate">
                            {qrBanner.type === "phone" ? t.scan.promptPayPhone : t.scan.promptPayId}: {qrBanner.displayId}
                          </p>
                          {qrBanner.amount && (
                            <p className="text-xs text-accent font-mono mt-0.5">{t.scan.amountFromQr}: {qrBanner.amount.toLocaleString()} THB</p>
                          )}
                        </div>
                        <button type="button" onClick={() => setQrBanner(null)} className="text-muted-foreground hover:text-foreground shrink-0">
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Bank / account / name fields are only shown for the
                    legacy manual flow. When the customer scanned a PromPay
                    QR, all of these are auto-filled (bank = "PromPay",
                    account = QR id, name = merchant) and we hide them so
                    they only need to confirm the THB amount. */}
                {!qrBanner && (
                  <>
                    <FormField
                      control={form.control}
                      name="bankName"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <SelectTrigger className="bg-input border-border h-12">
                                <SelectValue placeholder={t.home.selectBank} />
                              </SelectTrigger>
                              <SelectContent className="max-h-64">
                                {THAI_BANKS.map((bank) => (
                                  <SelectItem key={bank} value={bank}>{bank}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="accountNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Input
                              type="tel"
                              inputMode="numeric"
                              className="bg-input border-border h-12 tabular-nums"
                              placeholder={t.home.accountNumber}
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="accountName"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Input
                              className="bg-input border-border h-12"
                              placeholder={t.home.accountName}
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </>
                )}
              </div>

              {remaining < 0 && (
                <p className="text-xs text-red-400 text-center -mt-2">
                  {t.home.insufficientBalance}
                </p>
              )}

              <Button
                type="submit"
                className="w-full h-14 text-lg font-bold rounded-xl"
                disabled={isPending || !exchangeRate || remaining < 0 || !user || !token}
              >
                {!user
                  ? (lang === "vi" ? "Đăng nhập để gửi lệnh" : "Login to send order")
                  : isPending
                    ? t.home.processing
                    : t.home.createPayment}
              </Button>
              </fieldset>
            </form>
          </Form>
        </CardContent>
      </Card>

      {/* Auth panel for guests — placed below preview so they can review fields first */}
      {(!user || !token) && <InlineAuth />}

      </>
    </motion.div>

    <QrScannerModal
      open={!!user && !!token && scannerOpen}
      onClose={() => setScannerOpen(false)}
      onResult={handleQrResult}
    />

    <Dialog open={!!user && !!token && !!qrPreview} onOpenChange={(o) => { if (!o) { setQrPreview(null); setPreviewAmount(""); } }}>
      <DialogContent className="sm:max-w-md bg-card border-border p-0 overflow-hidden max-h-[90vh] overflow-y-auto">
        <div className="bg-gradient-to-br from-primary/15 via-primary/5 to-transparent px-5 pt-6 pb-4 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-full bg-green-500/15 border border-green-500/30 flex items-center justify-center shrink-0">
              <ScanLine className="w-5 h-5 text-green-400" />
            </div>
            <div className="flex-1 min-w-0">
              <DialogTitle className="text-base">{t.scan.previewTitle}</DialogTitle>
              <DialogDescription className="text-xs mt-0.5">{t.scan.previewSubtitle}</DialogDescription>
            </div>
          </div>
        </div>

        {qrPreview && (
          <div className="px-5 py-4 flex flex-col gap-3">
            <div className="flex items-start gap-3 p-3 rounded-xl bg-secondary/40 border border-border">
              <div className="w-9 h-9 rounded-full bg-primary/15 flex items-center justify-center shrink-0">
                <Building2 className="w-4 h-4 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">{t.scan.previewBank}</p>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="text-base">🇹🇭</span>
                  <p className="text-sm font-semibold">PromPay</p>
                  <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-primary/15 text-primary border border-primary/30">
                    {t.scan.previewThailand}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 rounded-xl bg-secondary/40 border border-border">
              <div className="w-9 h-9 rounded-full bg-primary/15 flex items-center justify-center shrink-0">
                {qrPreview.info.type === "phone" ? (
                  <PhoneIcon className="w-4 h-4 text-primary" />
                ) : (
                  <CreditCard className="w-4 h-4 text-primary" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">
                  {qrPreview.info.type === "phone" ? t.scan.promptPayPhone : t.scan.promptPayId}
                </p>
                <p className="text-base font-mono font-bold mt-0.5 allow-select break-all">{qrPreview.info.displayId}</p>
              </div>
            </div>

            {qrPreview.info.merchantName && (
              <div className="flex items-start gap-3 p-3 rounded-xl bg-secondary/40 border border-border">
                <div className="w-9 h-9 rounded-full bg-primary/15 flex items-center justify-center shrink-0">
                  <UserIcon className="w-4 h-4 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">{t.scan.previewMerchant}</p>
                  <p className="text-sm font-semibold mt-0.5 break-words">{qrPreview.info.merchantName}</p>
                </div>
              </div>
            )}

            {/* Amount input — always editable. Pre-filled if QR had amount,
                empty otherwise. Customer must enter a positive THB amount. */}
            <div className="flex flex-col gap-2 p-3 rounded-xl bg-accent/10 border border-accent/30">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-full bg-accent/20 flex items-center justify-center shrink-0">
                  <Coins className="w-4 h-4 text-accent" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[11px] uppercase tracking-wider text-accent/80 font-medium">{t.scan.previewAmount}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">
                    {qrPreview.info.amount && qrPreview.info.amount > 0
                      ? t.scan.previewAmountFromQr
                      : t.scan.previewAmountManual}
                  </p>
                </div>
              </div>
              <div className="flex items-stretch gap-2">
                <Input
                  type="number"
                  inputMode="decimal"
                  min={1}
                  step="0.01"
                  value={previewAmount}
                  onChange={(e) => setPreviewAmount(e.target.value)}
                  placeholder="0.00"
                  className="h-11 text-lg font-mono font-bold flex-1 bg-background"
                  autoFocus={!(qrPreview.info.amount && qrPreview.info.amount > 0)}
                />
                <span className="flex items-center px-3 rounded-md bg-accent/20 text-accent text-sm font-bold">THB</span>
              </div>
            </div>

            <div className="flex flex-col gap-2 pt-1">
              <Button
                type="button"
                onClick={applyQrPreview}
                disabled={!(parseFloat(previewAmount) > 0)}
                className="w-full h-11 bg-primary hover:bg-primary/90 text-white font-bold disabled:opacity-40"
              >
                <Send className="w-4 h-4 mr-2" />
                {t.scan.previewConfirm}
              </Button>
              <button
                type="button"
                onClick={() => { setQrPreview(null); setPreviewAmount(""); setScannerOpen(true); }}
                className="w-full h-10 rounded-md text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
              >
                {t.scan.previewRescan}
              </button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>

    <Dialog
      open={otpOpen}
      onOpenChange={(o) => {
        if (!o && !isPending) {
          setOtpOpen(false);
          setOtpCode("");
          setOtpError(null);
        }
      }}
    >
      <DialogContent className="sm:max-w-md bg-card border-border">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/15 border border-primary/30 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1">
              <DialogTitle className="text-base">{t.payOtp.title}</DialogTitle>
              <DialogDescription className="text-xs mt-0.5">
                {t.payOtp.subtitleAbove1k}
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        {pendingValues && (
          <div className="rounded-xl bg-input/40 border border-border px-3 py-2.5 text-xs flex items-center justify-between">
            <span className="text-muted-foreground">{t.home.thbAmountLabel}</span>
            <span className="font-mono font-bold text-green-400 tabular-nums">
              {pendingValues.amountThb.toLocaleString("th-TH", { maximumFractionDigits: 2 })} THB
            </span>
          </div>
        )}

        {requestingOtp ? (
          <div className="flex items-center justify-center gap-2 py-4 text-xs text-muted-foreground">
            <Send className="w-4 h-4 animate-pulse" />
            {t.payOtp.sending}
          </div>
        ) : otpError && (otpError === t.payOtp.noTelegram || otpError === t.payOtp.sendError) ? (
          <p className="text-xs text-red-400 leading-snug py-2">{otpError}</p>
        ) : (
          <>
            <p className="text-[11px] text-accent flex items-center gap-1.5 -mb-1">
              <Send className="w-3 h-3" />
              {t.payOtp.sentTo}
            </p>
            <p className="text-xs text-muted-foreground">{t.payOtp.enterCode}</p>
            <div className="flex justify-center py-2">
              <InputOTP
                maxLength={6}
                value={otpCode}
                onChange={(v) => {
                  setOtpCode(v);
                  setOtpError(null);
                }}
              >
                <InputOTPGroup>
                  {[0, 1, 2, 3, 4, 5].map((i) => (
                    <InputOTPSlot
                      key={i}
                      index={i}
                      className="h-12 w-10 text-lg font-bold"
                    />
                  ))}
                </InputOTPGroup>
              </InputOTP>
            </div>
            {/* Surface ANY submit-time error here, not just invalid-OTP.
                Errors like INSUFFICIENT_THB_BALANCE / INSUFFICIENT_FEE_BALANCE
                are set into otpError by the createOrder onError handler while
                this modal is open; if we only rendered invalidCode the user
                would tap submit and see nothing happen — a "frozen" screen.
                The noTelegram / sendError request-failure messages are
                rendered separately above, so exclude them here. */}
            {otpError &&
              otpError !== t.payOtp.noTelegram &&
              otpError !== t.payOtp.sendError && (
                <p className="text-xs text-red-400 text-center -mt-1">{otpError}</p>
              )}
            <p className="text-[11px] text-muted-foreground/80 leading-snug text-center">
              {t.payOtp.reason}
            </p>
          </>
        )}

        <div className="flex gap-2 pt-1">
          <Button
            type="button"
            variant="outline"
            className="flex-1 h-11"
            onClick={() => {
              setOtpOpen(false);
              setOtpCode("");
              setOtpError(null);
            }}
            disabled={isPending}
          >
            {t.payOtp.cancel}
          </Button>
          {!requestingOtp && otpError !== t.payOtp.noTelegram && (
            <Button
              type="button"
              variant="outline"
              className="h-11 px-3"
              onClick={resendOtp}
              disabled={requestingOtp || isPending}
            >
              {t.payOtp.resend}
            </Button>
          )}
          <Button
            type="button"
            className="flex-1 h-11 font-bold"
            onClick={submitWithOtp}
            disabled={
              isPending ||
              requestingOtp ||
              otpCode.length !== 6 ||
              otpError === t.payOtp.noTelegram
            }
          >
            {isPending ? t.payOtp.submitting : t.payOtp.submit}
          </Button>
        </div>
      </DialogContent>
    </Dialog>

    {/* UID required — blocks order creation until the user claims an
        AndersPay UID in Settings. Top-aligned (`items-start pt-20`) per
        the project's modal-with-input placement rule even though this
        modal is read-only, so it stays consistent with sibling dialogs
        on the bottom-tab layout. */}
    <Dialog open={uidRequiredOpen} onOpenChange={setUidRequiredOpen}>
      <DialogContent className="sm:max-w-md bg-card border-border">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-amber-400" />
            {t.payBlock.uidTitle}
          </DialogTitle>
          <DialogDescription className="text-sm text-muted-foreground leading-relaxed pt-2">
            {t.payBlock.uidDesc}
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col gap-2 pt-2">
          <Button
            type="button"
            onClick={() => {
              setUidRequiredOpen(false);
              setLocation("/settings");
            }}
            className="bg-accent text-accent-foreground hover:bg-accent/90"
          >
            {t.payBlock.uidCta}
          </Button>
          <Button
            type="button"
            variant="ghost"
            onClick={() => setUidRequiredOpen(false)}
          >
            {t.payBlock.cancel}
          </Button>
        </div>
      </DialogContent>
    </Dialog>

    {/* No deposit yet — blocks order creation until the user funds
        their THB wallet (via topup → convert). */}
    <Dialog open={noDepositOpen} onOpenChange={setNoDepositOpen}>
      <DialogContent className="sm:max-w-md bg-card border-border">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-amber-400" />
            {t.payBlock.noDepositTitle}
          </DialogTitle>
          <DialogDescription className="text-sm text-muted-foreground leading-relaxed pt-2">
            {t.payBlock.noDepositDesc}
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col gap-2 pt-2">
          <Button
            type="button"
            onClick={() => {
              setNoDepositOpen(false);
              setLocation("/topup");
            }}
            className="bg-accent text-accent-foreground hover:bg-accent/90"
          >
            {t.payBlock.noDepositCta}
          </Button>
          <Button
            type="button"
            variant="ghost"
            onClick={() => setNoDepositOpen(false)}
          >
            {t.payBlock.cancel}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
    <NightDelayWarning
      open={nightPendingValues != null}
      onCancel={() => setNightPendingValues(null)}
      onContinue={() => {
        const v = nightPendingValues;
        if (!v) return;
        // Keep the value set so the gate in `onSubmit` short-circuits;
        // `onSubmit` itself clears it before proceeding.
        onSubmit(v);
      }}
    />
    </>
  );
}
