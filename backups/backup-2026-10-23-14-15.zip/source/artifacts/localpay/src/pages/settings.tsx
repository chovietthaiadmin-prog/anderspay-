import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "wouter";
import {
  Globe, Bell, Shield, ChevronRight, ChevronDown, User,
  LogOut, TrendingUp, Camera, Pencil, Check, X,
  Mail, ShieldCheck, Phone, Calendar, IdCard, Cake, Users, Hash, Copy,
  Trash2, AlertTriangle, DatabaseBackup,
  HelpCircle, FileText,
} from "lucide-react";
import { useLang } from "@/lib/use-lang";
import { useAuth } from "@/lib/auth";
import { useTheme } from "@/components/theme-provider";
import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import RateManager from "@/components/rate-manager";
import SecurityCard from "@/components/security-card";
import ShareAppCard from "@/components/share-app-card";
import ReferralCard from "@/components/referral-card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from "@/components/ui/input-otp";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
type ResourceKey = "faq" | "guide" | "privacy";

function Avatar({ src, name, size = 64 }: { src?: string | null; name?: string; size?: number }) {
  const initials = (name ?? "?")
    .split(" ")
    .map((w) => w[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  if (src) {
    const url = src.startsWith("http") || src.startsWith("data:") ? src : `${BASE}${src}`;
    return (
      <img
        src={url}
        alt="avatar"
        style={{ width: size, height: size }}
        className="rounded-full object-cover border-2 border-primary/30"
      />
    );
  }
  return (
    <div
      style={{ width: size, height: size }}
      className="rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold border-2 border-primary/30"
    >
      <span style={{ fontSize: size * 0.36 }}>{initials}</span>
    </div>
  );
}

export default function Settings() {
  const { t, lang, setLang } = useLang();
  const { theme, setTheme } = useTheme();
  const { user, token, logout, updateName, updateNickname, updateAvatar, updateEmail, updateDob, setUid, requestDeleteOtp, deleteAccount, emailChangeSendOtp, emailChangeVerify } = useAuth();

  // Permanent account deletion: 3-stage flow.
  //  - "confirm": "Are you sure?" yes/no.
  //  - "otp":     OTP input after the user said yes — server has sent a
  //               6-digit code to the linked Telegram chat.
  //  - null:      idle.
  const [logoutConfirmOpen, setLogoutConfirmOpen] = useState(false);
  const [deleteStage, setDeleteStage] = useState<null | "confirm" | "otp">(null);
  const [deleteOtp, setDeleteOtp] = useState("");
  const [deleteSubmitting, setDeleteSubmitting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const closeDelete = () => {
    setDeleteStage(null);
    setDeleteOtp("");
    setDeleteError(null);
    setDeleteSubmitting(false);
  };

  const startDeleteOtp = async () => {
    setDeleteSubmitting(true);
    setDeleteError(null);
    try {
      await requestDeleteOtp();
      setDeleteStage("otp");
    } catch (e) {
      setDeleteError(e instanceof Error ? e.message : t.settings.deleteAccountFailed);
    } finally {
      setDeleteSubmitting(false);
    }
  };

  const submitDelete = async () => {
    if (!/^\d{6}$/.test(deleteOtp.trim())) {
      setDeleteError(t.settings.deleteAccountOtpInvalid);
      return;
    }
    setDeleteSubmitting(true);
    setDeleteError(null);
    try {
      await deleteAccount(deleteOtp.trim());
      toast({ title: t.settings.deleteAccountDone });
      closeDelete();
      setLocation("/");
    } catch (e) {
      setDeleteError(e instanceof Error ? e.message : t.settings.deleteAccountFailed);
      setDeleteSubmitting(false);
    }
  };
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const [notifications, setNotifications] = useState(true);
  // Telegram broadcast opt-in. We fetch the saved value from the
  // server on mount so the toggle reflects what the API has, and PATCH
  // back optimistically when the user flips it.
  const [telegramOptIn, setTelegramOptIn] = useState(true);
  const [notifPayment, setNotifPayment] = useState(true);
  const [telegramLinked, setTelegramLinked] = useState(false);
  const [tgNotifOpen, setTgNotifOpen] = useState(false);
  useEffect(() => {
    if (!token) return;
    fetch(`${BASE}/api/broadcast/opt-in`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((r) => (r.ok ? r.json() : null))
      .then((data: { telegramOptIn?: boolean; notifPayment?: boolean; linked?: boolean } | null) => {
        if (!data) return;
        if (typeof data.telegramOptIn === "boolean") setTelegramOptIn(data.telegramOptIn);
        if (typeof data.notifPayment === "boolean") setNotifPayment(data.notifPayment);
        if (typeof data.linked === "boolean") setTelegramLinked(data.linked);
      })
      .catch(() => {});
  }, [token]);
  async function patchTgPref(patch: { optIn?: boolean; notifPayment?: boolean }) {
    try {
      const res = await fetch(`${BASE}/api/broadcast/opt-in`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(patch),
      });
      if (!res.ok) toast({ title: t.broadcast.optInFailed, variant: "destructive" });
    } catch {
      toast({ title: t.broadcast.optInFailed, variant: "destructive" });
    }
  }
  async function setTelegramOptInRemote(next: boolean) {
    setTelegramOptIn(next);
    await patchTgPref({ optIn: next }).catch(() => setTelegramOptIn(!next));
  }
  async function setNotifPaymentRemote(next: boolean) {
    setNotifPayment(next);
    await patchTgPref({ notifPayment: next }).catch(() => setNotifPayment(!next));
  }
  const [rateOpen, setRateOpen] = useState(false);
  const [resourceOpen, setResourceOpen] = useState<ResourceKey | null>(null);

  const [editingNick, setEditingNick] = useState(false);
  const [nickValue, setNickValue] = useState(user?.nickname ?? "");
  const [savingNick, setSavingNick] = useState(false);

  const [editNameOpen, setEditNameOpen] = useState(false);
  const [nameValue, setNameValue] = useState(user?.name ?? "");
  const [savingName, setSavingName] = useState(false);
  const nameAlreadyEdited = !!user?.nameUpdatedAt;

  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [securityOpen, setSecurityOpen] = useState(false);
  const [emailValue, setEmailValue] = useState(user?.email ?? "");
  const [savingEmail, setSavingEmail] = useState(false);
  const [emailChangeOpen, setEmailChangeOpen] = useState(false);
  const [emailChangeStep, setEmailChangeStep] = useState<"email" | "otp">("email");
  const [emailChangeOtp, setEmailChangeOtp] = useState("");
  const [emailChangeError, setEmailChangeError] = useState<string | null>(null);

  const [accountOpen, setAccountOpen] = useState(false);
  const [dobValue, setDobValue] = useState(user?.dob ?? "");
  const [savingDob, setSavingDob] = useState(false);

  const [uidValue, setUidValue] = useState("");
  const [savingUid, setSavingUid] = useState(false);

  useEffect(() => { setEmailValue(user?.email ?? ""); }, [user?.email]);
  useEffect(() => { setDobValue(user?.dob ?? ""); }, [user?.dob]);

  const displayName = user?.nickname ?? user?.name ?? "";

  const handleSaveNickname = async () => {
    if (!nickValue.trim() || nickValue.trim().length < 2) {
      toast({ title: t.settings.nicknameTooShort, variant: "destructive" });
      return;
    }
    setSavingNick(true);
    try {
      await updateNickname(nickValue.trim());
      toast({ title: t.settings.nicknameSaved });
      setEditingNick(false);
    } catch {
      toast({ title: "Lỗi", description: "Không thể lưu nickname", variant: "destructive" });
    } finally {
      setSavingNick(false);
    }
  };

  const handleSaveEmail = async () => {
    const trimmed = emailValue.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) {
      toast({ title: t.settings.emailInvalid, variant: "destructive" });
      return;
    }
    setSavingEmail(true);
    try {
      await updateEmail(trimmed);
      toast({ title: t.settings.emailSaved });
    } catch {
      toast({ title: "Error", variant: "destructive" });
    } finally {
      setSavingEmail(false);
    }
  };

  const handleEmailChangeSend = async () => {
    const trimmed = emailValue.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) {
      setEmailChangeError(t.settings.emailInvalid);
      return;
    }
    setSavingEmail(true);
    setEmailChangeError(null);
    try {
      await emailChangeSendOtp(trimmed);
      setEmailChangeStep("otp");
    } catch (e) {
      setEmailChangeError(e instanceof Error ? e.message : t.settings.emailChangeFailed);
    } finally {
      setSavingEmail(false);
    }
  };

  const handleEmailChangeVerify = async () => {
    if (!/^\d{6}$/.test(emailChangeOtp)) {
      setEmailChangeError(t.auth.emailOtpInvalid);
      return;
    }
    setSavingEmail(true);
    setEmailChangeError(null);
    try {
      await emailChangeVerify(emailValue.trim().toLowerCase(), emailChangeOtp);
      toast({ title: t.settings.emailChangeSuccess });
      setEmailChangeOpen(false);
      setEmailChangeStep("email");
      setEmailChangeOtp("");
      setEmailChangeError(null);
    } catch (e) {
      const name = e instanceof Error ? e.name : "";
      if (name === "locked") {
        setEmailChangeError(t.auth.emailOtpLocked);
      } else {
        setEmailChangeError(e instanceof Error ? e.message : t.settings.emailChangeFailed);
      }
    } finally {
      setSavingEmail(false);
    }
  };

  const handleSetUid = async () => {
    // Permanence guard on the client. Server is the source of truth
    // (returns `uid_permanent` 409), but blocking here avoids a
    // confusing round-trip when the UID is already locked.
    if (user?.uid && /^098\d{6}$/.test(user.uid)) {
      toast({ title: t.settings.uidAlreadySet, variant: "destructive" });
      return;
    }
    const v = uidValue.trim();
    if (!/^098\d{6}$/.test(v)) {
      toast({ title: t.settings.uidInvalid, variant: "destructive" });
      return;
    }
    if (!window.confirm(t.settings.uidConfirm)) return;
    setSavingUid(true);
    try {
      await setUid(v);
      toast({ title: t.settings.uidSaved });
      setUidValue("");
    } catch (err) {
      const msg = err instanceof Error ? err.message : "";
      const desc =
        msg === "uid_taken" ? t.settings.uidTaken
        : msg === "uid_permanent" ? t.settings.uidAlreadySet
        : t.settings.uidError;
      toast({ title: desc, variant: "destructive" });
    } finally {
      setSavingUid(false);
    }
  };

  const handleCopyUid = async (uid: string) => {
    try {
      await navigator.clipboard.writeText(uid);
      toast({ title: t.settings.uidCopied });
    } catch {
      // ignore
    }
  };

  const handleSaveName = async () => {
    const v = nameValue.trim();
    if (v.length < 2 || v.length > 60) {
      toast({ title: t.settings.realNameInvalid, variant: "destructive" });
      return;
    }
    if (v === user?.name) {
      setEditNameOpen(false);
      return;
    }
    if (!window.confirm(t.settings.realNameConfirm)) return;
    setSavingName(true);
    try {
      await updateName(v);
      toast({ title: t.settings.realNameSaved });
      setEditNameOpen(false);
    } catch (err) {
      const code = err instanceof Error ? err.name : "";
      const desc = code === "name_already_updated"
        ? t.settings.realNameAlreadyUpdated
        : t.settings.realNameError;
      toast({ title: desc, variant: "destructive" });
    } finally {
      setSavingName(false);
    }
  };

  const handleSaveDob = async () => {
    const v = dobValue.trim();
    if (v && !/^\d{4}-\d{2}-\d{2}$/.test(v)) {
      toast({ title: t.settings.dobInvalid, variant: "destructive" });
      return;
    }
    setSavingDob(true);
    try {
      await updateDob(v || null);
      toast({ title: t.settings.dobSaved });
    } catch {
      toast({ title: t.settings.dobInvalid, variant: "destructive" });
    } finally {
      setSavingDob(false);
    }
  };

  const formatJoinDate = (iso?: string) => {
    if (!iso) return "—";
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return "—";
    return d.toLocaleDateString(lang === "vi" ? "vi-VN" : "en-GB", { day: "2-digit", month: "2-digit", year: "numeric" });
  };

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingAvatar(true);
    try {
      await updateAvatar(file);
      toast({ title: t.settings.avatarUploaded });
    } catch {
      toast({ title: "Lỗi", description: "Không thể tải ảnh lên", variant: "destructive" });
    } finally {
      setUploadingAvatar(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const renderResourceContent = (key: ResourceKey) => {
    if (key === "faq") {
      return (
        <div className="flex flex-col gap-3">
          {t.support.faqs.map((f, i) => (
            <div key={i} className="border-l-2 border-primary/40 py-1 pl-3">
              <p className="mb-1 text-sm font-semibold">{f.q}</p>
              <p className="text-xs leading-relaxed text-muted-foreground">{f.a}</p>
            </div>
          ))}
        </div>
      );
    }
    if (key === "guide") {
      return (
        <ol className="flex flex-col gap-2.5">
          {t.support.guideSteps.map((s, i) => (
            <li key={i} className="flex items-start gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-bold text-white">
                {i + 1}
              </span>
              <span className="pt-0.5 text-xs leading-relaxed text-muted-foreground">{s}</span>
            </li>
          ))}
        </ol>
      );
    }
    return (
      <ul className="flex flex-col gap-2">
        {t.support.privacyPoints.map((p, i) => (
          <li key={i} className="flex items-start gap-2">
            <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
            <span className="text-xs leading-relaxed text-muted-foreground">{p}</span>
          </li>
        ))}
      </ul>
    );
  };

  // kept for local push-notification toggle (browser-level, future use)
  void notifications; void setNotifications;

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col gap-6 pb-24"
      >
        <div className="pt-8 pb-2">
          <h1 className="text-2xl font-bold">{t.settings.title}</h1>
          <p className="text-muted-foreground text-sm">{t.settings.subtitle}</p>
        </div>

        {/* Profile Card — only shown when logged in */}
        {user && (
          <div className="flex flex-col gap-3">
            <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">
              {t.settings.profile}
            </p>
            <Card className="bg-card border-border overflow-hidden">
              <CardContent className="p-4 flex flex-col gap-4">
                {/* Avatar row */}
                <div className="flex items-center gap-4">
                  <div className="relative shrink-0">
                    <Avatar src={user.avatarUrl} name={user.name} size={64} />
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      disabled={uploadingAvatar}
                      className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-primary flex items-center justify-center border-2 border-background"
                    >
                      {uploadingAvatar
                        ? <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        : <Camera className="w-3 h-3 text-white" />
                      }
                    </button>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleAvatarChange}
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    {/* Display name / nickname */}
                    <AnimatePresence mode="wait">
                      {editingNick ? (
                        <motion.div
                          key="edit"
                          initial={{ opacity: 0, y: -4 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -4 }}
                          className="flex items-center gap-2"
                        >
                          <Input
                            value={nickValue}
                            onChange={(e) => setNickValue(e.target.value)}
                            placeholder={t.settings.nicknamePlaceholder}
                            maxLength={30}
                            className="h-8 text-sm"
                            autoFocus
                            onKeyDown={(e) => {
                              if (e.key === "Enter") handleSaveNickname();
                              if (e.key === "Escape") setEditingNick(false);
                            }}
                          />
                          <button
                            onClick={handleSaveNickname}
                            disabled={savingNick}
                            className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center shrink-0"
                          >
                            {savingNick
                              ? <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                              : <Check className="w-4 h-4 text-white" />
                            }
                          </button>
                          <button
                            onClick={() => { setEditingNick(false); setNickValue(user.nickname ?? ""); }}
                            className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center shrink-0"
                          >
                            <X className="w-4 h-4 text-muted-foreground" />
                          </button>
                        </motion.div>
                      ) : (
                        <motion.div
                          key="display"
                          initial={{ opacity: 0, y: 4 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: 4 }}
                          className="flex items-center gap-2"
                        >
                          <span className="font-semibold text-base truncate">
                            {displayName || <span className="text-muted-foreground italic text-sm">{t.settings.nicknamePlaceholder}</span>}
                          </span>
                          <button
                            onClick={() => { setNickValue(user.nickname ?? ""); setEditingNick(true); }}
                            className="w-6 h-6 rounded-md bg-secondary flex items-center justify-center shrink-0"
                          >
                            <Pencil className="w-3 h-3 text-muted-foreground" />
                          </button>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {/* Real name hidden hint */}
                    {user.nickname && (
                      <p className="text-xs text-muted-foreground mt-0.5 truncate">
                        {t.settings.nicknameHint}
                      </p>
                    )}
                    {!user.nickname && !editingNick && (
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {t.settings.nicknameHint}
                      </p>
                    )}
                  </div>
                </div>

                {/* Meta info */}
                <div className="flex flex-col gap-1 pt-1 border-t border-border">
                  {user.phone && (
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">SĐT</span>
                      <span className="font-mono text-foreground/80">{user.phone}</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Language Selector — kept directly below the profile section */}
        <div className="flex flex-col gap-3">
          <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">{t.settings.language}</p>
          <Card className="bg-card border-border">
            <CardContent className="p-2">
              <div className="grid grid-cols-3 gap-1.5">
                {(["vi", "en", "zh", "ar", "ko", "ru"] as const).map((l) => {
                  const flag = l === "vi" ? "🇻🇳" : l === "en" ? "🇬🇧" : l === "zh" ? "🇨🇳" : l === "ar" ? "🇸🇦" : l === "ko" ? "🇰🇷" : "🇷🇺";
                  const label = l === "vi" ? "Tiếng Việt" : l === "en" ? "English" : l === "zh" ? "中文" : l === "ar" ? "العربية" : l === "ko" ? "한국어" : "Русский";
                  return (
                    <button
                      key={l}
                      onClick={() => setLang(l)}
                      className={`py-2 px-1 rounded-xl text-xs font-bold transition-all flex flex-col items-center gap-0.5 ${
                        lang === l
                          ? "bg-primary text-white shadow-sm"
                          : "text-muted-foreground hover:bg-secondary/50"
                      }`}
                    >
                      <span className="text-base leading-none">{flag}</span>
                      <span className="truncate w-full text-center">{label}</span>
                    </button>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Theme Selector */}
        <div className="flex flex-col gap-3">
          <div>
            <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">{t.settings.theme}</p>
            <p className="mt-1 text-xs text-muted-foreground/70">{t.settings.themeDesc}</p>
          </div>
          <Card className="bg-card border-border">
            <CardContent className="p-2">
              <div className="grid grid-cols-2 gap-1.5">
                <button
                  onClick={() => setTheme("dark")}
                  className={`py-3 px-2 rounded-xl text-xs font-bold transition-all flex flex-col items-center gap-1.5 ${
                    theme === "dark"
                      ? "bg-primary text-white shadow-sm"
                      : "text-muted-foreground hover:bg-secondary/50"
                  }`}
                >
                  <div className="w-5 h-5 rounded-full border-2 border-primary/30 bg-[#000000] flex overflow-hidden">
                    <div className="w-1/2 h-full bg-[#ff3b3b]" />
                    <div className="w-1/2 h-full bg-[#fbbf24]" />
                  </div>
                  <span className="truncate w-full text-center">{t.settings.themeOriginal}</span>
                </button>
                <button
                  onClick={() => setTheme("navy")}
                  className={`py-3 px-2 rounded-xl text-xs font-bold transition-all flex flex-col items-center gap-1.5 ${
                    theme === "navy"
                      ? "bg-primary text-white shadow-sm"
                      : "text-muted-foreground hover:bg-secondary/50"
                  }`}
                >
                  <div className="w-5 h-5 rounded-full border-2 border-[#1769FF]/30 bg-[#0B1F3A] flex overflow-hidden">
                    <div className="w-1/2 h-full bg-[#1769FF]" />
                    <div className="w-1/2 h-full bg-[#F5F7FA]" />
                  </div>
                  <span className="truncate w-full text-center">{t.settings.themeNavy}</span>
                </button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* AndersPay UID — for P2P transfers */}
        {user && (
          <div className="flex flex-col gap-3">
            <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">
              {t.settings.uidSection}
            </p>
            <Card className="bg-card border-border overflow-hidden">
              <CardContent className="p-4 flex flex-col gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                    <Hash className="w-4 h-4 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{t.settings.uidLabel}</p>
                    <p className="text-xs text-muted-foreground">{t.settings.uidDesc}</p>
                  </div>
                </div>

                {user.uid && /^098\d{6}$/.test(user.uid) ? (
                  // Permanent: locked display, no input. Once stored,
                  // the UID cannot be edited / reset / changed /
                  // transferred. The server enforces this too via
                  // 409 `uid_permanent`.
                  <>
                    <div className="flex items-center gap-2 p-3 rounded-lg bg-secondary/40 border border-border">
                      <span className="font-mono text-lg font-bold tracking-wider text-primary flex-1 allow-select">
                        {user.uid}
                      </span>
                      <span className="px-2 py-0.5 rounded-full bg-green-500/15 border border-green-500/30 text-[10px] font-bold text-green-300 uppercase tracking-wider">
                        {t.settings.uidPermanent}
                      </span>
                      <button
                        onClick={() => handleCopyUid(user.uid!)}
                        className="w-8 h-8 rounded-md bg-secondary flex items-center justify-center shrink-0 hover:bg-secondary/70"
                        aria-label="copy"
                      >
                        <Copy className="w-3.5 h-3.5 text-muted-foreground" />
                      </button>
                    </div>
                    <div className="flex items-start gap-2 p-2.5 rounded-md bg-yellow-500/10 border border-yellow-500/30">
                      <ShieldCheck className="w-3.5 h-3.5 text-yellow-400 shrink-0 mt-0.5" />
                      <p className="text-[11px] leading-relaxed text-yellow-200/90">
                        {t.settings.uidWarn}
                      </p>
                    </div>
                  </>
                ) : (
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center gap-2">
                      <Input
                        value={uidValue}
                        onChange={(e) => {
                          const digits = e.target.value.replace(/\D/g, "").slice(0, 9);
                          setUidValue(digits);
                        }}
                        placeholder="098xxxxxx"
                        inputMode="numeric"
                        maxLength={9}
                        className="h-10 font-mono text-base tracking-wider flex-1"
                      />
                      <button
                        onClick={handleSetUid}
                        disabled={savingUid || !/^098\d{6}$/.test(uidValue)}
                        className="h-10 px-4 rounded-md bg-primary text-white font-bold text-sm disabled:opacity-40 disabled:cursor-not-allowed"
                      >
                        {savingUid ? t.settings.uidSaving : t.settings.uidSetBtn}
                      </button>
                    </div>
                    <div className="flex items-start gap-2 p-2.5 rounded-md bg-red-500/10 border border-red-500/40">
                      <AlertTriangle className="w-3.5 h-3.5 text-red-400 shrink-0 mt-0.5" />
                      <p className="text-[11px] leading-relaxed text-red-200/90 font-semibold">
                        {t.settings.uidWarn}
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {/* Daily Rate Manager — admin only */}
        {user?.isAdmin && (
          <div className="flex flex-col gap-3">
            <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">
              {t.rateManager.title}
            </p>
            <Card className="bg-card border-border overflow-hidden">
              <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-accent to-accent/20" />
              <CardContent className="p-0">
                <button
                  onClick={() => setRateOpen(true)}
                  className="flex items-center gap-4 p-4 w-full hover:bg-secondary/30 transition-colors border-b border-border"
                >
                  <div className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 bg-accent/10">
                    <TrendingUp className="w-4 h-4 text-accent" />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="text-sm font-medium">{t.rateManager.menuLabel}</p>
                    <p className="text-xs text-muted-foreground">{t.rateManager.menuDesc}</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </button>
                <button
                  onClick={() => setLocation("/admin/users")}
                  className="flex items-center gap-4 p-4 w-full hover:bg-secondary/30 transition-colors border-b border-border"
                >
                  <div className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 bg-green-500/10">
                    <Users className="w-4 h-4 text-green-400" />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="text-sm font-medium">{t.adminUsers.menuLabel}</p>
                    <p className="text-xs text-muted-foreground">{t.adminUsers.menuDesc}</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </button>
                <button
                  onClick={() => setLocation("/admin/backup")}
                  className="flex items-center gap-4 p-4 w-full hover:bg-secondary/30 transition-colors"
                >
                  <div className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 bg-blue-500/10">
                    <DatabaseBackup className="w-4 h-4 text-blue-400" />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="text-sm font-medium">{t.adminBackup.menuLabel}</p>
                    <p className="text-xs text-muted-foreground">{t.adminBackup.menuDesc}</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </button>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Telegram notification preferences — shown to all logged-in users */}
        {user && (
          <div className="flex flex-col gap-3">
            <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">
              {t.broadcast.tgNotifSection}
            </p>
            <Card className="bg-card border-border overflow-hidden">
              <CardContent className="p-0">
                {/* Header row — click to expand/collapse */}
                <button
                  type="button"
                  onClick={() => setTgNotifOpen((v) => !v)}
                  className="flex items-center gap-4 p-4 w-full hover:bg-secondary/30 transition-colors"
                >
                  <div className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 bg-[#229ED9]/10">
                    {/* Telegram paper-plane icon */}
                    <svg viewBox="0 0 24 24" className="w-4 h-4 fill-[#229ED9]" xmlns="http://www.w3.org/2000/svg">
                      <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12l-6.871 4.326-2.962-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.537-.194 1.006.131.833.941z"/>
                    </svg>
                  </div>
                  <div className="flex-1 text-left">
                    <p className="text-sm font-medium">{t.broadcast.tgNotifSection}</p>
                    <p className="text-xs text-muted-foreground">{t.broadcast.tgNotifSectionDesc}</p>
                  </div>
                  <ChevronRight className={`w-4 h-4 text-muted-foreground transition-transform ${tgNotifOpen ? "rotate-90" : ""}`} />
                </button>

                {/* Expandable panel */}
                <AnimatePresence>
                  {tgNotifOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="overflow-hidden"
                    >
                      <div className="border-t border-border">
                        {!telegramLinked ? (
                          /* Not linked yet */
                          <div className="flex items-start gap-3 p-4">
                            <div className="w-8 h-8 rounded-full bg-yellow-500/10 flex items-center justify-center shrink-0">
                              <Bell className="w-4 h-4 text-yellow-400" />
                            </div>
                            <p className="text-xs text-muted-foreground leading-relaxed pt-1">
                              {t.broadcast.tgNotifNotLinked}
                            </p>
                          </div>
                        ) : (
                          <div className="divide-y divide-border">
                            {/* Payment confirmations */}
                            <div className="flex items-center gap-4 px-4 py-3.5">
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium">{t.broadcast.tgNotifPaymentLabel}</p>
                                <p className="text-xs text-muted-foreground">{t.broadcast.tgNotifPaymentDesc}</p>
                              </div>
                              <Switch checked={notifPayment} onCheckedChange={setNotifPaymentRemote} />
                            </div>
                            {/* Promo messages */}
                            <div className="flex items-center gap-4 px-4 py-3.5">
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium">{t.broadcast.tgNotifPromoLabel}</p>
                                <p className="text-xs text-muted-foreground">{t.broadcast.tgNotifPromoDesc}</p>
                              </div>
                              <Switch checked={telegramOptIn} onCheckedChange={setTelegramOptInRemote} />
                            </div>
                            {/* OTP note */}
                            <div className="px-4 py-3 bg-secondary/20">
                              <p className="text-[11px] text-muted-foreground/70 flex items-start gap-1.5">
                                <ShieldCheck className="w-3 h-3 shrink-0 mt-0.5 text-muted-foreground/50" />
                                {t.broadcast.tgNotifOtpNote}
                              </p>
                            </div>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </CardContent>
            </Card>
          </div>
        )}

        {user && <ReferralCard />}

        <ShareAppCard />

        {user && <SecurityCard />}

        {user && (
          <div className="flex flex-col gap-3">
            <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">
              {t.settings.security}
            </p>
            <Card className="bg-card border-border overflow-hidden">
              <CardContent className="p-0">
                <button
                  onClick={() => setSecurityOpen(!securityOpen)}
                  className="flex items-center gap-4 p-4 w-full hover:bg-secondary/30 transition-colors"
                >
                  <div className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 bg-emerald-400/10">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="text-sm font-medium">{t.settings.security}</p>
                    <p className="text-xs text-muted-foreground">{t.settings.securityDesc}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    {user.email ? (
                      <>
                        <span className="text-xs text-muted-foreground truncate max-w-[120px]">{user.email}</span>
                        {user.emailVerified ? (
                          <span className="flex items-center gap-1 text-xs text-emerald-400 font-medium">
                            <Check className="w-3 h-3" />
                            {t.settings.emailVerified}
                          </span>
                        ) : (
                          <span className="text-xs text-muted-foreground">{t.settings.emailUnverified}</span>
                        )}
                      </>
                    ) : (
                      <span className="text-xs text-muted-foreground">{t.settings.emailNotSet}</span>
                    )}
                    <ChevronRight className={`w-4 h-4 text-muted-foreground transition-transform ${securityOpen ? "rotate-90" : ""}`} />
                  </div>
                </button>

                <AnimatePresence>
                  {securityOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="overflow-hidden"
                    >
                      <div className="px-4 pb-4 pt-1 border-t border-border">
                        {user.email ? (
                          <div className="flex flex-col gap-2">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <Mail className="w-4 h-4 text-muted-foreground" />
                                <span className="text-xs text-muted-foreground font-medium">{t.settings.emailLabel}</span>
                              </div>
                              {user.emailVerified && (
                                <span className="flex items-center gap-1 text-xs text-emerald-400 font-medium">
                                  <Check className="w-3 h-3" />
                                  {t.settings.emailVerified}
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-secondary/40 border border-border">
                              <span className="text-xs text-foreground/80 flex-1 truncate font-mono">{user.email}</span>
                              <button
                                onClick={() => {
                                  setEmailValue(user.email || "");
                                  setEmailChangeOpen(true);
                                  setEmailChangeStep("email");
                                  setEmailChangeOtp("");
                                  setEmailChangeError(null);
                                }}
                                className="text-xs text-primary hover:text-primary/80 font-medium shrink-0"
                              >
                                {t.settings.emailChangeTitle}
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div className="flex flex-col gap-2">
                            <div className="flex items-center gap-2 mb-1">
                              <Mail className="w-4 h-4 text-muted-foreground" />
                              <span className="text-xs text-muted-foreground font-medium">{t.settings.emailLabel}</span>
                            </div>
                            <button
                              onClick={() => {
                                setEmailValue("");
                                setEmailChangeOpen(true);
                                setEmailChangeStep("email");
                                setEmailChangeOtp("");
                                setEmailChangeError(null);
                              }}
                              className="px-4 py-2.5 rounded-lg bg-primary text-white text-xs font-medium transition-colors hover:bg-primary/90"
                            >
                              {t.settings.emailSave}
                            </button>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </CardContent>
            </Card>
          </div>
        )}

        <div className="flex flex-col gap-3">
          <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">{t.settings.account}</p>
          <Card className="bg-card border-border overflow-hidden">
            <CardContent className="p-0 divide-y divide-border">
              {/* Account Info — expandable */}
              <div>
                <button
                  onClick={() => setAccountOpen(!accountOpen)}
                  disabled={!user}
                  className="flex items-center gap-4 p-4 w-full hover:bg-secondary/30 transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
                >
                  <div className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 bg-primary/10">
                    <User className="w-4 h-4 text-primary" />
                  </div>
                  <div className="flex-1 text-left min-w-0">
                    <p className="text-sm font-medium">{t.settings.accountInfo}</p>
                    <p className="text-xs text-muted-foreground truncate">{t.settings.accountInfoDesc}</p>
                  </div>
                  <ChevronRight className={`w-4 h-4 text-muted-foreground transition-transform ${accountOpen ? "rotate-90" : ""}`} />
                </button>

                <AnimatePresence>
                  {accountOpen && user && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="overflow-hidden"
                    >
                      <div className="px-4 pb-4 pt-1 border-t border-border flex flex-col gap-3">
                        {/* Real name — editable once */}
                        <div className="flex items-start gap-3">
                          <IdCard className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-2">
                              <p className="text-[11px] uppercase tracking-wider text-muted-foreground">{t.settings.realName}</p>
                              {!nameAlreadyEdited ? (
                                <button
                                  onClick={() => { setNameValue(user.name); setEditNameOpen(true); }}
                                  className="text-[10px] uppercase tracking-wider text-primary hover:text-primary/80 flex items-center gap-1"
                                >
                                  <Pencil className="w-3 h-3" />
                                  {t.settings.realNameEditOnce}
                                </button>
                              ) : (
                                <span className="text-[10px] uppercase tracking-wider text-emerald-400/70 flex items-center gap-1">
                                  <Check className="w-3 h-3" />
                                  {t.settings.realNameLocked}
                                </span>
                              )}
                            </div>
                            <p className="text-sm font-medium truncate">{user.name}</p>
                            {!nameAlreadyEdited && (
                              <p className="text-[10.5px] text-amber-300/70 mt-1 leading-snug">
                                {t.settings.realNameWarnInline}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Nickname */}
                        <div className="flex items-start gap-3">
                          <Pencil className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="text-[11px] uppercase tracking-wider text-muted-foreground">{t.settings.nickname}</p>
                            <p className="text-sm font-medium truncate">
                              {user.nickname || <span className="text-muted-foreground italic">{t.settings.nicknamePlaceholder}</span>}
                            </p>
                          </div>
                        </div>

                        {/* Phone */}
                        <div className="flex items-start gap-3">
                          <Phone className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="text-[11px] uppercase tracking-wider text-muted-foreground">{t.settings.phone}</p>
                            <p className="text-sm font-mono">{user.phone || "—"}</p>
                          </div>
                        </div>

                        {/* Email */}
                        <div className="flex items-start gap-3">
                          <Mail className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="text-[11px] uppercase tracking-wider text-muted-foreground">{t.settings.emailLine}</p>
                            <p className="text-sm truncate">
                              {user.email
                                ? <span className="text-emerald-400">{user.email}</span>
                                : <span className="text-muted-foreground italic">{t.settings.emailNone}</span>}
                            </p>
                          </div>
                        </div>

                        {/* Join date */}
                        <div className="flex items-start gap-3">
                          <Calendar className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="text-[11px] uppercase tracking-wider text-muted-foreground">{t.settings.joinDate}</p>
                            <p className="text-sm">{formatJoinDate(user.createdAt)}</p>
                          </div>
                        </div>

                        {/* DOB — editable */}
                        <div className="flex items-start gap-3">
                          <Cake className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="text-[11px] uppercase tracking-wider text-muted-foreground mb-1">{t.settings.dob}</p>
                            <div className="flex gap-2">
                              <Input
                                type="date"
                                value={dobValue}
                                max={new Date().toISOString().slice(0, 10)}
                                min="1900-01-01"
                                onChange={(e) => setDobValue(e.target.value)}
                                className="flex-1 h-9 text-sm"
                              />
                              <button
                                onClick={handleSaveDob}
                                disabled={savingDob || (dobValue ?? "") === (user.dob ?? "")}
                                className="px-3 h-9 rounded-lg bg-primary text-white text-xs font-medium disabled:opacity-50 transition-colors hover:bg-primary/90 shrink-0"
                              >
                                {savingDob
                                  ? <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin inline-block" />
                                  : t.settings.dobSave}
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

            </CardContent>
          </Card>
        </div>

        {/* App resources — kept in Settings rather than the Messenger screen */}
        <div className="flex flex-col gap-3">
          <div>
            <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">
              {t.support.resources}
            </p>
            <p className="mt-1 text-xs text-muted-foreground/70">{t.settings.subtitle}</p>
          </div>
          <Card className="bg-card border-border overflow-hidden">
            <CardContent className="p-0 divide-y divide-border">
              {([
                { key: "faq" as const, icon: HelpCircle, label: t.support.faq },
                { key: "guide" as const, icon: FileText, label: t.support.guide },
                { key: "privacy" as const, icon: Shield, label: t.support.privacy },
              ]).map(({ key, icon: Icon, label }) => {
                const isOpen = resourceOpen === key;
                return (
                  <div key={key}>
                    <button
                      type="button"
                      onClick={() => setResourceOpen(isOpen ? null : key)}
                      className="flex w-full items-center gap-4 p-4 text-left transition-colors hover:bg-secondary/30"
                    >
                      <Icon className="h-5 w-5 shrink-0 text-muted-foreground" />
                      <span className="flex-1 text-sm font-medium">{label}</span>
                      <ChevronDown
                        className={`h-4 w-4 text-muted-foreground transition-transform ${isOpen ? "rotate-180" : ""}`}
                      />
                    </button>
                    <AnimatePresence initial={false}>
                      {isOpen && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden"
                        >
                          <div className="bg-secondary/20 px-4 pb-4 pt-1">
                            {renderResourceContent(key)}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </CardContent>
          </Card>
          <div className="rounded-xl border border-primary/20 bg-primary/5 p-4 text-center">
            <p className="text-sm text-muted-foreground">{t.support.version}</p>
            <p className="mt-1 font-bold text-primary">AndersPay+ v{__APP_VERSION__}</p>
          </div>
        </div>

        {user && (
          <>
            <button
              onClick={() => setLogoutConfirmOpen(true)}
              className="flex items-center gap-3 p-4 rounded-xl border border-red-500/20 bg-red-500/5 text-red-400 hover:bg-red-500/10 transition-colors w-full"
            >
              <LogOut className="w-5 h-5" />
              <span className="text-sm font-medium">{t.settings.logout}</span>
            </button>
            <button
              onClick={() => { setDeleteStage("confirm"); setDeleteError(null); }}
              className="flex items-center gap-3 p-4 rounded-xl border border-red-700/40 bg-red-700/10 text-red-300 hover:bg-red-700/20 transition-colors w-full"
            >
              <Trash2 className="w-5 h-5" />
              <div className="flex-1 text-left min-w-0">
                <p className="text-sm font-medium">{t.settings.deleteAccount}</p>
                <p className="text-[11px] text-red-300/70">{t.settings.deleteAccountHint}</p>
              </div>
            </button>
          </>
        )}
      </motion.div>

      {/* Permanent account deletion dialog. Two-stage: confirm → OTP.
          Modal opens at the top of the screen because it contains an
          input (per replit.md user preference — bottom tab bar would
          otherwise cover it). */}
      <AnimatePresence>
        {deleteStage !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[300] bg-black/70 backdrop-blur-sm flex items-start justify-center pt-20 overflow-y-auto p-4"
            onClick={closeDelete}
          >
            <motion.div
              initial={{ y: -20, scale: 0.98 }}
              animate={{ y: 0, scale: 1 }}
              exit={{ y: -20, scale: 0.98 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-card border border-red-500/40 rounded-2xl w-full max-w-sm p-5 flex flex-col gap-4"
            >
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-red-500/15 border border-red-500/40 flex items-center justify-center shrink-0">
                  <AlertTriangle className="w-5 h-5 text-red-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-red-300">
                    {deleteStage === "confirm"
                      ? t.settings.deleteAccountConfirmTitle
                      : t.settings.deleteAccountOtpTitle}
                  </p>
                  <p className="text-[12px] text-muted-foreground mt-1 leading-relaxed">
                    {deleteStage === "confirm"
                      ? t.settings.deleteAccountConfirmDesc
                      : t.settings.deleteAccountOtpDesc.replace(
                          "{phone}",
                          user?.phone ?? "",
                        )}
                  </p>
                </div>
              </div>

              {deleteStage === "otp" && (
                <Input
                  inputMode="numeric"
                  pattern="\d{6}"
                  maxLength={6}
                  placeholder="••••••"
                  value={deleteOtp}
                  onChange={(e) => setDeleteOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
                  className="text-center text-lg tracking-[0.5em] font-mono bg-secondary/40 border-red-500/30"
                />
              )}

              {deleteError && (
                <p className="text-[12px] text-red-400 text-center">{deleteError}</p>
              )}

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={closeDelete}
                  disabled={deleteSubmitting}
                  className="h-10 rounded-lg bg-secondary text-foreground text-sm font-bold hover:bg-secondary/70 disabled:opacity-50"
                >
                  {t.settings.deleteAccountCancel}
                </button>
                {deleteStage === "confirm" ? (
                  <button
                    onClick={startDeleteOtp}
                    disabled={deleteSubmitting}
                    className="h-10 rounded-lg bg-red-500/80 text-white text-sm font-bold hover:bg-red-500 disabled:opacity-50"
                  >
                    {deleteSubmitting ? "…" : t.settings.deleteAccountSureBtn}
                  </button>
                ) : (
                  <button
                    onClick={submitDelete}
                    disabled={deleteSubmitting || deleteOtp.length !== 6}
                    className="h-10 rounded-lg bg-red-600 text-white text-sm font-bold hover:bg-red-500 disabled:opacity-50"
                  >
                    {deleteSubmitting ? "…" : t.settings.deleteAccountFinalBtn}
                  </button>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Real-name edit dialog — one-time edit, top-anchored per replit.md
          (input-bearing modals must clear the bottom tab bar). */}
      <AnimatePresence>
        {editNameOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[300] bg-black/70 backdrop-blur-sm flex items-start justify-center pt-20 overflow-y-auto p-4"
            onClick={() => !savingName && setEditNameOpen(false)}
          >
            <motion.div
              initial={{ y: -20, scale: 0.98 }}
              animate={{ y: 0, scale: 1 }}
              exit={{ y: -20, scale: 0.98 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-card border border-amber-500/40 rounded-2xl w-full max-w-sm p-5 flex flex-col gap-4"
            >
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-amber-500/15 border border-amber-500/40 flex items-center justify-center shrink-0">
                  <AlertTriangle className="w-5 h-5 text-amber-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-amber-300">
                    {t.settings.realNameDialogTitle}
                  </p>
                  <p className="text-[12px] text-muted-foreground mt-1 leading-relaxed">
                    {t.settings.realNameDialogDesc}
                  </p>
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-[11px] uppercase tracking-wider text-muted-foreground">
                  {t.settings.realName}
                </label>
                <Input
                  value={nameValue}
                  onChange={(e) => setNameValue(e.target.value)}
                  placeholder={t.settings.realNamePlaceholder}
                  maxLength={60}
                  className="bg-secondary/40"
                />
                <p className="text-[10.5px] text-amber-300/70 leading-snug mt-1">
                  {t.settings.realNameDialogWarn}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setEditNameOpen(false)}
                  disabled={savingName}
                  className="h-10 rounded-lg bg-secondary text-foreground text-sm font-bold hover:bg-secondary/70 disabled:opacity-50"
                >
                  {t.settings.deleteAccountCancel}
                </button>
                <button
                  onClick={handleSaveName}
                  disabled={savingName || !nameValue.trim() || nameValue.trim() === user?.name}
                  className="h-10 rounded-lg bg-amber-500 text-black text-sm font-bold hover:bg-amber-400 disabled:opacity-50"
                >
                  {savingName ? "…" : t.settings.realNameSaveBtn}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Logout confirmation. Lightweight (no input), but still opens at
          the top so it's never covered by the bottom tab bar. */}
      <AnimatePresence>
        {logoutConfirmOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[300] bg-black/70 backdrop-blur-sm flex items-start justify-center pt-20 overflow-y-auto p-4"
            onClick={() => setLogoutConfirmOpen(false)}
          >
            <motion.div
              initial={{ y: -20, scale: 0.98 }}
              animate={{ y: 0, scale: 1 }}
              exit={{ y: -20, scale: 0.98 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-card border border-red-500/40 rounded-2xl w-full max-w-sm p-5 flex flex-col gap-4"
            >
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-red-500/15 border border-red-500/40 flex items-center justify-center shrink-0">
                  <LogOut className="w-5 h-5 text-red-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-red-300">
                    {t.settings.logoutConfirmTitle}
                  </p>
                  <p className="text-[12px] text-muted-foreground mt-1 leading-relaxed">
                    {t.settings.logoutConfirmDesc}
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setLogoutConfirmOpen(false)}
                  className="h-10 rounded-lg bg-secondary text-foreground text-sm font-bold hover:bg-secondary/70"
                >
                  {t.settings.logoutConfirmCancel}
                </button>
                <button
                  onClick={() => {
                    setLogoutConfirmOpen(false);
                    logout();
                  }}
                  className="h-10 rounded-lg bg-red-500/80 text-white text-sm font-bold hover:bg-red-500"
                >
                  {t.settings.logoutConfirmYes}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <RateManager open={rateOpen} onClose={() => setRateOpen(false)} />

      {/* Email change dialog */}
      <Dialog open={emailChangeOpen} onOpenChange={setEmailChangeOpen}>
        <DialogContent className="flex items-start justify-center pt-20 overflow-y-auto">
          <div className="w-full max-w-md">
            <DialogHeader>
              <DialogTitle>{emailChangeStep === "email" ? t.settings.emailChangeTitle : t.settings.emailChangeOtpTitle}</DialogTitle>
              <DialogDescription>
                {emailChangeStep === "email" ? t.settings.emailChangeDesc : t.settings.emailChangeOtpHint}
              </DialogDescription>
            </DialogHeader>

            <div className="flex flex-col gap-3 mt-4">
              {emailChangeStep === "email" ? (
                <>
                  <Input
                    type="email"
                    inputMode="email"
                    value={emailValue}
                    onChange={(e) => setEmailValue(e.target.value)}
                    placeholder={t.settings.emailPlaceholder}
                    className="h-11"
                    autoFocus
                  />
                  {emailChangeError && (
                    <p className="text-xs text-red-400 bg-red-500/10 py-2 px-3 rounded-lg">{emailChangeError}</p>
                  )}
                  <button
                    onClick={handleEmailChangeSend}
                    disabled={savingEmail || !emailValue.trim()}
                    className="h-10 rounded-lg bg-primary text-white font-bold disabled:opacity-50"
                  >
                    {savingEmail ? t.auth.emailSendingOtp : t.settings.emailChangeSendOtp}
                  </button>
                </>
              ) : (
                <>
                  <div className="flex flex-col gap-2 items-center">
                    <InputOTP
                      maxLength={6}
                      value={emailChangeOtp}
                      onChange={(value) => {
                        setEmailChangeOtp(value);
                        setEmailChangeError(null);
                        if (value.length === 6) {
                          setTimeout(() => {
                            if (value.length === 6) {
                              handleEmailChangeVerify();
                            }
                          }, 100);
                        }
                      }}
                      disabled={savingEmail}
                    >
                      <InputOTPGroup>
                        <InputOTPSlot index={0} />
                        <InputOTPSlot index={1} />
                        <InputOTPSlot index={2} />
                        <InputOTPSlot index={3} />
                        <InputOTPSlot index={4} />
                        <InputOTPSlot index={5} />
                      </InputOTPGroup>
                    </InputOTP>
                  </div>
                  {emailChangeError && (
                    <p className="text-xs text-red-400 bg-red-500/10 py-2 px-3 rounded-lg text-center">{emailChangeError}</p>
                  )}
                  <button
                    onClick={handleEmailChangeVerify}
                    disabled={savingEmail || emailChangeOtp.length !== 6}
                    className="h-10 rounded-lg bg-primary text-white font-bold disabled:opacity-50"
                  >
                    {savingEmail ? t.auth.emailVerifying : t.settings.emailChangeVerify}
                  </button>
                </>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
