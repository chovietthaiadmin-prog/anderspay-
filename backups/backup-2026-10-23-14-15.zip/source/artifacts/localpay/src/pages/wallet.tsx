import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Wallet, ArrowRightLeft, Activity, ArrowDownToLine, TrendingUp } from "lucide-react";
import { BrandSpinner } from "@/components/brand-spinner";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  WorkingHoursStatusPill,
  WorkingHoursWarningBanner,
} from "@/components/working-hours-notice";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/lib/auth";
import { useLang } from "@/lib/use-lang";
import { useToast } from "@/hooks/use-toast";
import InlineAuth from "@/components/inline-auth";
import { useGetExchangeRate, getGetExchangeRateQueryKey } from "@workspace/api-client-react";

const API_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
// Mirrors MIN_USDT_BALANCE on the server (artifacts/api-server/src/lib/fees.ts).
// User must keep at least this much USDT after a convert to cover future gas fees.
const MIN_USDT_RESERVE = 2.5;

interface WalletTx {
  id: string;
  type: "deposit" | "convert_out" | "convert_in" | "topup_fee" | "payment_fee"
    | "payment" | "payment_refund" | "payment_refund_reversal" | "referral_reward";
  amountUsdt: number;
  referralAmountUsdt?: number | null;
  amountThb: number;
  rate: number;
  refOrderId: string | null;
  createdAt: string;
  // Present only on admin (aggregate) responses — identifies the member
  // that owns this transaction so admin can see whose activity it is.
  userUid?: string | null;
  userName?: string | null;
}
interface WalletData {
  usdtBalance: number;
  thbBalance: number;
  transactions: WalletTx[];
}

export default function WalletPage() {
  const [, setLocation] = useLocation();
  const { user, token } = useAuth();
  const { t, lang } = useLang();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [amountStr, setAmountStr] = useState("");

  const { data: rateData } = useGetExchangeRate({
    query: { queryKey: getGetExchangeRateQueryKey(), refetchInterval: 30000 },
  });
  const rate = rateData?.thbPerUsdt ?? 0;

  const walletQuery = useQuery<WalletData>({
    queryKey: ["wallet", user?.id],
    enabled: !!token,
    refetchInterval: 5000,
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/wallet`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("wallet_load_failed");
      return res.json() as Promise<WalletData>;
    },
  });

  const convertMutation = useMutation({
    mutationFn: async (amountUsdt: number) => {
      const res = await fetch(`${API_BASE}/api/wallet/convert`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ amountUsdt }),
      });
      const data = (await res.json().catch(() => ({}))) as { code?: string; amountThb?: number };
      if (!res.ok) throw new Error(data.code ?? "convert_failed");
      return data;
    },
    onSuccess: (data) => {
      const thb = (data.amountThb ?? 0).toLocaleString("th-TH", { maximumFractionDigits: 2 });
      toast({ title: t.wallet.convertSuccess, description: `+${thb} THB` });
      setAmountStr("");
      void queryClient.invalidateQueries({ queryKey: ["wallet"] });
    },
    onError: (err: Error) => {
      const msg = err.message === "AMOUNT_TOO_SMALL"
        ? (lang === "vi" ? "Số tiền đổi phải nhận được ít nhất 0.01 THB" : "Conversion must receive at least 0.01 THB")
        : err.message === "INSUFFICIENT_BALANCE" ? t.wallet.insufficientUsdt : t.wallet.convertError;
      toast({ title: msg, variant: "destructive" });
    },
  });

  const usdtBalance = walletQuery.data?.usdtBalance ?? 0;
  const thbBalance = walletQuery.data?.thbBalance ?? 0;
  const txs = walletQuery.data?.transactions ?? [];

  const amount = parseFloat(amountStr || "0");
  const previewThb = rate > 0 && amount > 0 ? Number((Number(amount.toFixed(6)) * rate).toFixed(2)) : 0;
  const remainingAfter = usdtBalance - amount;
  const wouldBreakReserve = amount > 0 && remainingAfter < MIN_USDT_RESERVE;
  const canConvert =
    !!user && !!token && Number.isFinite(amount) && amount > 0 && previewThb >= 0.01
    && amount <= usdtBalance && !wouldBreakReserve && rate > 0 && !convertMutation.isPending;

  function onConvert() {
    if (!canConvert) return;
    if (wouldBreakReserve) {
      window.alert(t.wallet.gasReserveWarning);
      return;
    }
    convertMutation.mutate(parseFloat(amount.toFixed(6)));
  }

  function onMax() {
    // Cap MAX at (balance - 2.5 USDT gas reserve) so the user can't accidentally
    // try to drain their wallet below the on-chain gas-fee minimum.
    const maxConvertible = Math.max(0, usdtBalance - MIN_USDT_RESERVE);
    if (maxConvertible <= 0) return;
    setAmountStr(maxConvertible.toFixed(6).replace(/0+$/, "").replace(/\.$/, ""));
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col gap-4 pb-28"
    >
      {/* Header */}
      <div className="flex items-center gap-3 pt-6 pb-1">
        <div className="w-10 h-10 rounded-full bg-accent/10 border border-accent/20 flex items-center justify-center shrink-0">
          <Wallet className="w-5 h-5 text-accent" />
        </div>
        <div className="flex-1">
          <h1 className="text-xl font-bold">{t.wallet.title}</h1>
          <p className="text-muted-foreground text-xs">{t.wallet.subtitle}</p>
        </div>
        <div className="flex flex-col items-end gap-1 shrink-0">
          {rateData && (
            <div className="flex items-center gap-1.5 text-xs text-accent font-mono font-bold">
              <Activity className="w-3 h-3 animate-pulse" />
              {rate.toFixed(2)}
            </div>
          )}
          <WorkingHoursStatusPill />
        </div>
      </div>

      {/* Outside-hours notice — non-blocking, shown only when closed */}
      <WorkingHoursWarningBanner />

      {(!user || !token) && <InlineAuth />}

      {/* Balances */}
      <div className="grid grid-cols-2 gap-3">
        <Card className="border-border bg-card overflow-hidden relative">
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-accent to-accent/40" />
          <CardContent className="p-4">
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-medium mb-1">
              {t.wallet.balanceUsdt}
            </p>
            <p className="text-2xl font-bold tabular-nums font-mono text-accent">
              {usdtBalance.toLocaleString("en-US", { maximumFractionDigits: 4 })}
            </p>
            <p className="text-[10px] text-muted-foreground mt-0.5">USDT</p>
          </CardContent>
        </Card>

        <Card className="border-border bg-card overflow-hidden relative">
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-green-500 to-green-400" />
          <CardContent className="p-4">
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-medium mb-1">
              {t.wallet.balanceThb}
            </p>
            <p className="text-2xl font-bold tabular-nums font-mono text-green-400">
              {thbBalance.toLocaleString("th-TH", { maximumFractionDigits: 2 })}
            </p>
            <p className="text-[10px] text-muted-foreground mt-0.5">THB</p>
          </CardContent>
        </Card>
      </div>

      {/* Top up shortcut when no USDT */}
      {user && usdtBalance <= 0 && (
        <button
          onClick={() => setLocation("/topup")}
          className="flex items-center gap-3 p-3 rounded-xl bg-primary/10 border border-primary/20 hover:bg-primary/15 transition"
        >
          <div className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
            <ArrowDownToLine className="w-4 h-4 text-primary" />
          </div>
          <div className="flex-1 text-left">
            <p className="text-xs font-semibold text-primary">{t.wallet.noUsdt}</p>
            <p className="text-[11px] text-muted-foreground mt-0.5">{t.wallet.noUsdtHint}</p>
          </div>
        </button>
      )}

      {/* Convert form */}
      <Card className="border-border bg-card overflow-hidden relative">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary to-accent opacity-60" />
        <CardContent className="p-5 flex flex-col gap-4">
          <div className="flex items-center gap-2">
            <ArrowRightLeft className="w-4 h-4 text-primary" />
            <h2 className="text-sm font-bold">{t.wallet.convertTitle}</h2>
          </div>

          <div>
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium mb-2">
              {t.wallet.convertAmount}
            </p>
            <div className="relative">
              <Input
                type="number"
                inputMode="decimal"
                step="0.000001"
                className="h-14 text-2xl font-bold tabular-nums pl-4 pr-24 bg-input border-border focus-visible:ring-primary rounded-xl"
                placeholder="0"
                value={amountStr}
                onChange={(e) => setAmountStr(e.target.value)}
                disabled={!user || !token || convertMutation.isPending}
              />
              <button
                type="button"
                onClick={onMax}
                disabled={!user || !token || usdtBalance <= 0}
                className="absolute right-3 top-1/2 -translate-y-1/2 px-2 py-1 text-[10px] font-bold text-accent bg-accent/10 rounded-md hover:bg-accent/20 disabled:opacity-40"
              >
                MAX
              </button>
            </div>
            <p className="text-[10px] text-muted-foreground mt-1.5">
              {t.wallet.available}: <span className="text-accent font-mono">{usdtBalance.toLocaleString("en-US", { maximumFractionDigits: 4 })} USDT</span>
            </p>
          </div>

          <div className="bg-secondary/40 rounded-xl px-4 py-3 flex items-center justify-between border border-border/60">
            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{t.wallet.youReceive}</p>
              <p className="text-lg font-bold text-green-400 font-mono tabular-nums">
                {previewThb.toLocaleString("th-TH", { maximumFractionDigits: 2 })} THB
              </p>
            </div>
            <div className="text-right">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{t.wallet.rate}</p>
              <p className="text-xs font-mono text-accent">1 USDT = {rate.toFixed(2)}</p>
            </div>
          </div>

          {amount > 0 && amount > usdtBalance && (
            <p className="text-xs text-red-400 text-center">{t.wallet.insufficientUsdt}</p>
          )}
          {amount > 0 && rate > 0 && previewThb < 0.01 && (
            <p className="text-xs text-red-400 text-center">
              {lang === "vi" ? "Số tiền đổi phải nhận được ít nhất 0.01 THB" : "Conversion must receive at least 0.01 THB"}
            </p>
          )}
          {amount > 0 && amount <= usdtBalance && wouldBreakReserve && (
            <p className="text-xs text-amber-400 text-center leading-snug">
              ⚠ {t.wallet.gasReserveWarning}
            </p>
          )}

          <Button
            onClick={onConvert}
            disabled={!canConvert}
            className="w-full h-14 text-lg font-bold rounded-xl"
          >
            {convertMutation.isPending ? (
              <span className="flex items-center gap-2"><BrandSpinner size={16} /> {t.wallet.converting}</span>
            ) : !user ? (
              lang === "vi" ? "Đăng nhập để chuyển đổi" : "Login to convert"
            ) : (
              t.wallet.convertBtn
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Transactions */}
      <Card className="border-border bg-card">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="w-4 h-4 text-muted-foreground" />
            <h2 className="text-sm font-bold">{t.wallet.txTitle}</h2>
          </div>
          <Separator className="bg-border mb-2" />
          {txs.length === 0 ? (
            <p className="text-xs text-muted-foreground text-center py-6">{t.wallet.txEmpty}</p>
          ) : (
            <div className="flex flex-col">
              {txs.map((tx) => {
                const date = new Date(tx.createdAt).toLocaleString(lang === "vi" ? "vi-VN" : "en-US", {
                  timeZone: "Asia/Bangkok",
                  hour: "2-digit",
                  minute: "2-digit",
                  day: "2-digit",
                  month: "2-digit",
                });
                let label = "";
                let amountText = "";
                let color = "text-muted-foreground";
                if (tx.type === "deposit") {
                  label = t.wallet.txDeposit;
                  amountText = `+${tx.amountUsdt.toFixed(4)} USDT`;
                  color = "text-accent";
                } else if (tx.type === "convert_out") {
                  label = t.wallet.txConvertOut;
                  amountText = `-${tx.amountUsdt.toFixed(4)} USDT`;
                  color = "text-red-400";
                } else if (tx.type === "convert_in") {
                  label = t.wallet.txConvertIn;
                  amountText = `+${tx.amountThb.toLocaleString("th-TH", { maximumFractionDigits: 2 })} THB`;
                  color = "text-green-400";
                } else if (tx.type === "topup_fee") {
                  label = lang === "vi" ? "Phí nạp" : "Top-up fee";
                  amountText = `-${tx.amountUsdt.toFixed(4)} USDT`;
                  color = "text-red-400";
                } else if (tx.type === "payment_fee") {
                  label = lang === "vi" ? "Phí thanh toán" : "Payment fee";
                  amountText = `-${tx.amountUsdt.toFixed(4)} USDT`;
                  color = "text-red-400";
                } else if (tx.type === "payment") {
                  label = lang === "vi" ? "Thanh toán THB" : "THB payment";
                  amountText = `-${tx.amountThb.toFixed(2)} THB`;
                  color = "text-red-400";
                } else if (tx.type === "payment_refund" || tx.type === "payment_refund_reversal") {
                  const reversal = tx.type === "payment_refund_reversal";
                  const sign = reversal ? "-" : "+";
                  label = reversal
                    ? (lang === "vi" ? "Đảo khoản hoàn tiền" : "Refund reversal")
                    : (lang === "vi" ? "Hoàn tiền thanh toán" : "Payment refund");
                  amountText = `${sign}${tx.amountThb.toFixed(2)} THB / ${sign}${tx.amountUsdt.toFixed(6)} USDT`;
                  color = reversal ? "text-red-400" : "text-green-400";
                } else if (tx.type === "referral_reward") {
                  label = lang === "vi" ? "Thưởng giới thiệu" : "Referral reward";
                  amountText = `+${tx.amountUsdt.toFixed(6)} USDT`;
                  color = "text-green-400";
                } else {
                  label = lang === "vi" ? "Giao dịch" : "Transaction";
                  amountText = `${tx.amountThb.toFixed(2)} THB / ${tx.amountUsdt.toFixed(6)} USDT`;
                }
                return (
                  <div key={tx.id} className="flex items-center justify-between py-2.5 border-b border-border/30 last:border-0">
                    <div className="min-w-0 pr-2">
                      <p className="text-xs font-semibold truncate">{label}</p>
                      {tx.userUid && (
                        <p className="text-[10px] text-accent font-mono truncate">
                          UID {tx.userUid}
                          {tx.userName ? <span className="text-muted-foreground"> • {tx.userName}</span> : null}
                        </p>
                      )}
                      <p className="text-[10px] text-muted-foreground">{date}</p>
                      {Number(tx.referralAmountUsdt) > 0 && (
                        <p className="text-[10px] text-muted-foreground">
                          {lang === "vi" ? "Phần thưởng giới thiệu" : "Referral reward portion"}: {Number(tx.referralAmountUsdt).toFixed(6)} USDT
                        </p>
                      )}
                    </div>
                    <p className={`text-xs font-bold tabular-nums font-mono ${color} text-right max-w-[55%]`}>{amountText}</p>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
