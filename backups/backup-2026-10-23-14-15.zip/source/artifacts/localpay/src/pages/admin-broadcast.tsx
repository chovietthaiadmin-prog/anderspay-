import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ArrowLeft,
  Megaphone,
  AlertTriangle,
  Send,
  Users,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Eye,
  ImagePlus,
  X as XIcon,
} from "lucide-react";
import { useLang } from "@/lib/use-lang";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";

const API_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

type Kind = "important" | "promo";
type Audience = "all" | "users";

interface BroadcastHistoryItem {
  id: string;
  sentByName: string;
  kind: Kind;
  audience: Audience;
  body: string;
  imageDataUrl: string | null;
  total: number;
  okCount: number;
  failCount: number;
  createdAt: string;
}

const MAX_IMAGE_BYTES = 3 * 1024 * 1024;

export default function AdminBroadcast() {
  const [, setLocation] = useLocation();
  const { t } = useLang();
  const { user, token } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const b = t.broadcast;

  const [kind, setKind] = useState<Kind>("important");
  const [audience, setAudience] = useState<Audience>("all");
  const [body, setBody] = useState("");
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  function pickImage(file: File | null) {
    if (!file) {
      setImageFile(null);
      setImagePreview(null);
      return;
    }
    if (file.size > MAX_IMAGE_BYTES) {
      toast({ title: b.imageTooBig, variant: "destructive" });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setImagePreview(String(reader.result));
    reader.readAsDataURL(file);
    setImageFile(file);
  }

  function clearImage() {
    setImageFile(null);
    setImagePreview(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  // Hard guard — non-admins cannot view this page.
  if (!user?.isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center pt-20 gap-3 text-center">
        <ShieldCheck className="w-10 h-10 text-muted-foreground/40" />
        <p className="text-sm text-muted-foreground">Admin only</p>
      </div>
    );
  }

  // Live recipient count for the chosen kind+audience combo. Refetches
  // whenever the form changes so the admin sees exactly how many users
  // will be hit before pressing send.
  const recipientsQuery = useQuery<{ count: number }>({
    queryKey: ["admin", "broadcast", "recipients", kind, audience],
    enabled: !!token,
    queryFn: async () => {
      const res = await fetch(
        `${API_BASE}/api/admin/broadcast/recipients?kind=${kind}&audience=${audience}`,
        { headers: { Authorization: `Bearer ${token}` } },
      );
      if (!res.ok) throw new Error("recipients_failed");
      return res.json();
    },
  });

  const historyQuery = useQuery<{ items: BroadcastHistoryItem[] }>({
    queryKey: ["admin", "broadcast", "history"],
    enabled: !!token,
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/admin/broadcast/history`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("history_failed");
      return res.json();
    },
  });

  const recipientCount = recipientsQuery.data?.count ?? 0;
  const bodyTrimmed = body.trim();
  // Telegram caption limit applies when an image is attached.
  const maxBodyLen = imageFile ? 1024 : 4000;
  const tooLong = body.length > maxBodyLen;
  // Need at least body OR image.
  const canSend = (bodyTrimmed.length > 0 || !!imageFile) && !tooLong;

  async function send(target: "self" | Audience) {
    if (!canSend || submitting) return;
    setSubmitting(true);
    try {
      // Send as base64-in-JSON, NOT multipart/form-data: Replit's edge
      // proxy returns 403 Forbidden for any multipart POST before the
      // request reaches our server, so the JSON path is the only shape
      // that works in production. Mirrors the topup bill upload.
      let imageBase64: string | undefined;
      if (imageFile) {
        imageBase64 = await new Promise<string>((resolve, reject) => {
          const r = new FileReader();
          r.onload = () => {
            const result = r.result as string;
            const comma = result.indexOf(",");
            resolve(comma >= 0 ? result.slice(comma + 1) : result);
          };
          r.onerror = () => reject(new Error("read_failed"));
          r.readAsDataURL(imageFile);
        });
      }
      const res = await fetch(`${API_BASE}/api/admin/broadcast`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          kind,
          audience: target,
          body: bodyTrimmed,
          ...(imageBase64
            ? {
                imageBase64,
                imageMime: imageFile?.type || "image/jpeg",
                imageName: imageFile?.name || "broadcast.jpg",
              }
            : {}),
        }),
      });
      const data = (await res.json().catch(() => ({}))) as {
        ok?: boolean;
        queued?: boolean;
        total?: number;
        okCount?: number;
        failCount?: number;
        message?: string;
      };
      if (!res.ok || !data.ok) {
        toast({ title: data.message ?? b.sendFailed, variant: "destructive" });
        return;
      }
      if (target === "self") {
        toast({ title: b.previewSent });
      } else {
        // Backend processes the send loop in the background and
        // updates the audit row when done — show "queued for N
        // recipients" and rely on history polling to show progress.
        toast({
          title: b.sendQueued.replace("{total}", String(data.total ?? 0)),
        });
        setBody("");
        clearImage();
        setConfirmOpen(false);
        // Refresh history a few times so the admin sees ok/fail counts
        // populate as the background loop completes.
        qc.invalidateQueries({ queryKey: ["admin", "broadcast", "history"] });
        qc.invalidateQueries({ queryKey: ["admin", "broadcast", "recipients"] });
        const refresh = () => {
          qc.invalidateQueries({ queryKey: ["admin", "broadcast", "history"] });
        };
        const total = data.total ?? 0;
        // ~50ms/message + DB update; refresh shortly after expected end.
        const eta = Math.min(60_000, total * 60 + 1500);
        setTimeout(refresh, 2_000);
        setTimeout(refresh, eta);
      }
    } catch {
      toast({ title: b.sendFailed, variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col gap-4 pb-28 pt-6"
    >
      <div className="flex items-center gap-3">
        <button
          onClick={() => setLocation("/")}
          className="w-9 h-9 rounded-full bg-secondary/40 hover:bg-secondary flex items-center justify-center"
          aria-label="back"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div className="flex-1 min-w-0">
          <h1 className="text-lg font-bold leading-tight">{b.title}</h1>
          <p className="text-[11px] text-muted-foreground">{b.subtitle}</p>
        </div>
      </div>

      {/* Kind selector — radio cards. "important" bypasses opt-in. */}
      <div className="grid grid-cols-2 gap-2">
        <KindCard
          active={kind === "important"}
          onClick={() => setKind("important")}
          icon={<AlertTriangle className="w-4 h-4" />}
          label={b.kindImportant}
          desc={b.kindImportantDesc}
          tone="red"
        />
        <KindCard
          active={kind === "promo"}
          onClick={() => setKind("promo")}
          icon={<Sparkles className="w-4 h-4" />}
          label={b.kindPromo}
          desc={b.kindPromoDesc}
          tone="gold"
        />
      </div>

      {/* Audience selector. */}
      <Card className="bg-card border-border">
        <CardContent className="p-4 flex flex-col gap-3">
          <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">
            {b.audienceLabel}
          </p>
          <div className="grid grid-cols-2 gap-2">
            <AudienceBtn
              active={audience === "all"}
              onClick={() => setAudience("all")}
              label={b.audienceAll}
            />
            <AudienceBtn
              active={audience === "users"}
              onClick={() => setAudience("users")}
              label={b.audienceUsers}
            />
          </div>
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5" />
              {b.recipientsLabel}
            </span>
            <span className="font-bold text-accent tabular-nums">
              {recipientsQuery.isLoading ? "…" : recipientCount}
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Message body. */}
      <Card className="bg-card border-border">
        <CardContent className="p-4 flex flex-col gap-2">
          <label className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">
            {b.bodyLabel}
          </label>
          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            placeholder={b.bodyPlaceholder}
            rows={8}
            className="w-full resize-y bg-secondary/40 border border-border rounded-lg p-3 text-sm font-mono leading-relaxed focus:outline-none focus:border-accent"
          />
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-muted-foreground">
              {imageFile ? b.bodyHintCaption : b.bodyHint}
            </span>
            <span className={tooLong ? "text-red-400 font-bold" : "text-muted-foreground"}>
              {body.length} / {maxBodyLen}
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Optional image attachment. */}
      <Card className="bg-card border-border">
        <CardContent className="p-4 flex flex-col gap-3">
          <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">
            {b.imageLabel}
          </p>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp,image/gif"
            className="hidden"
            onChange={(e) => pickImage(e.target.files?.[0] ?? null)}
          />
          {imagePreview ? (
            <div className="relative">
              <img
                src={imagePreview}
                alt="preview"
                className="w-full max-h-64 object-contain rounded-lg border border-border bg-secondary/20"
              />
              <button
                type="button"
                onClick={clearImage}
                className="absolute top-2 right-2 w-8 h-8 rounded-full bg-black/70 hover:bg-black text-white flex items-center justify-center"
                aria-label="remove image"
              >
                <XIcon className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center justify-center gap-2 h-20 rounded-lg border-2 border-dashed border-border hover:border-accent/60 hover:bg-accent/5 text-muted-foreground hover:text-accent text-sm font-medium transition-colors"
            >
              <ImagePlus className="w-5 h-5" />
              {b.imageAdd}
            </button>
          )}
          <p className="text-[10px] text-muted-foreground">{b.imageHint}</p>
        </CardContent>
      </Card>

      {/* Action buttons. */}
      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={() => send("self")}
          disabled={!canSend || submitting}
          className="flex items-center justify-center gap-2 h-11 rounded-lg bg-secondary hover:bg-secondary/70 text-foreground text-sm font-bold border border-border disabled:opacity-40"
        >
          <Eye className="w-4 h-4" />
          {b.previewBtn}
        </button>
        <button
          onClick={() => setConfirmOpen(true)}
          disabled={!canSend || submitting || recipientCount === 0}
          className={`flex items-center justify-center gap-2 h-11 rounded-lg text-white text-sm font-bold disabled:opacity-40 ${
            kind === "important"
              ? "bg-red-500 hover:bg-red-600"
              : "bg-accent hover:bg-accent/90 text-accent-foreground"
          }`}
        >
          <Send className="w-4 h-4" />
          {b.sendBtn}
        </button>
      </div>

      {/* History. */}
      <Card className="bg-card border-border">
        <CardContent className="p-4 flex flex-col gap-3">
          <div className="flex items-center gap-2">
            <Megaphone className="w-4 h-4 text-muted-foreground" />
            <h2 className="text-sm font-bold">{b.historyTitle}</h2>
          </div>
          {historyQuery.isLoading ? (
            <p className="text-xs text-muted-foreground">…</p>
          ) : (historyQuery.data?.items ?? []).length === 0 ? (
            <p className="text-xs text-muted-foreground">{b.historyEmpty}</p>
          ) : (
            <div className="flex flex-col gap-2">
              {(historyQuery.data?.items ?? []).map((item) => (
                <HistoryRow key={item.id} item={item} t={b} />
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Confirm send dialog — opens at top to leave room for thumb. */}
      <AnimatePresence>
        {confirmOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[300] bg-black/70 backdrop-blur-sm flex items-start justify-center pt-20 overflow-y-auto p-4"
            onClick={() => !submitting && setConfirmOpen(false)}
          >
            <motion.div
              initial={{ y: -20, scale: 0.98 }}
              animate={{ y: 0, scale: 1 }}
              exit={{ y: -20, scale: 0.98 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-card border border-accent/40 rounded-2xl w-full max-w-sm p-5 flex flex-col gap-4"
            >
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-accent/15 border border-accent/40 flex items-center justify-center shrink-0">
                  <Send className="w-5 h-5 text-accent" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold">{b.confirmTitle}</p>
                  <p className="text-[12px] text-muted-foreground mt-1 leading-relaxed">
                    {b.confirmDesc
                      .replace("{count}", String(recipientCount))
                      .replace(
                        "{kind}",
                        kind === "important" ? b.kindImportant : b.kindPromo,
                      )}
                  </p>
                </div>
              </div>
              <div className="bg-secondary/40 rounded-lg p-3 max-h-60 overflow-y-auto flex flex-col gap-2">
                {imagePreview && (
                  <img
                    src={imagePreview}
                    alt="preview"
                    className="w-full max-h-32 object-contain rounded"
                  />
                )}
                {bodyTrimmed && (
                  <p className="text-xs whitespace-pre-wrap">{bodyTrimmed}</p>
                )}
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setConfirmOpen(false)}
                  disabled={submitting}
                  className="h-10 rounded-lg bg-secondary text-foreground text-sm font-bold disabled:opacity-50"
                >
                  {b.cancel}
                </button>
                <button
                  onClick={() => send(audience)}
                  disabled={submitting}
                  className="h-10 rounded-lg bg-accent text-accent-foreground text-sm font-bold disabled:opacity-50"
                >
                  {submitting ? "…" : b.confirmSend}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function KindCard({
  active,
  onClick,
  icon,
  label,
  desc,
  tone,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
  desc: string;
  tone: "red" | "gold";
}) {
  const ring = tone === "red" ? "border-red-500/60 bg-red-500/10" : "border-accent/60 bg-accent/10";
  const idle = "border-border bg-card";
  const accent = tone === "red" ? "text-red-400" : "text-accent";
  return (
    <button
      type="button"
      onClick={onClick}
      className={`text-left rounded-xl border p-3 transition-colors ${active ? ring : idle}`}
    >
      <div className={`flex items-center gap-2 mb-1 ${active ? accent : "text-muted-foreground"}`}>
        {icon}
        <span className="text-[11px] uppercase tracking-wider font-bold">{label}</span>
      </div>
      <p className="text-[11px] text-muted-foreground leading-snug">{desc}</p>
    </button>
  );
}

function AudienceBtn({
  active,
  onClick,
  label,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`h-9 rounded-lg text-xs font-bold transition-colors ${
        active
          ? "bg-accent text-accent-foreground"
          : "bg-secondary/40 text-muted-foreground hover:bg-secondary/60"
      }`}
    >
      {label}
    </button>
  );
}

function HistoryRow({
  item,
  t,
}: {
  item: BroadcastHistoryItem;
  t: ReturnType<typeof useLang>["t"]["broadcast"];
}) {
  const date = new Date(item.createdAt);
  const ts = date.toLocaleString("vi-VN", { timeZone: "Asia/Bangkok", hour12: false });
  const kindLabel = item.kind === "important" ? t.kindImportant : t.kindPromo;
  const audLabel = item.audience === "users" ? t.audienceUsers : t.audienceAll;
  return (
    <div className="rounded-lg border border-border bg-secondary/20 p-3 flex flex-col gap-1.5">
      <div className="flex items-center justify-between text-[10px] uppercase tracking-wider">
        <span
          className={`font-bold ${item.kind === "important" ? "text-red-400" : "text-accent"}`}
        >
          {kindLabel} • {audLabel}
        </span>
        <span className="text-muted-foreground tabular-nums">{ts}</span>
      </div>
      {item.imageDataUrl && (
        <img
          src={item.imageDataUrl}
          alt="broadcast"
          className="w-full max-h-40 object-contain rounded bg-black/20"
        />
      )}
      {item.body && <p className="text-xs whitespace-pre-wrap line-clamp-3">{item.body}</p>}
      <div className="flex items-center gap-3 text-[11px]">
        <span className="text-muted-foreground">{t.byLabel}: <span className="text-foreground">{item.sentByName}</span></span>
        <span className="flex items-center gap-1 text-emerald-400">
          <CheckCircle2 className="w-3 h-3" />
          {item.okCount}
        </span>
        {item.failCount > 0 && (
          <span className="flex items-center gap-1 text-red-400">
            <XCircle className="w-3 h-3" />
            {item.failCount}
          </span>
        )}
        <span className="text-muted-foreground ml-auto">/ {item.total}</span>
      </div>
    </div>
  );
}
