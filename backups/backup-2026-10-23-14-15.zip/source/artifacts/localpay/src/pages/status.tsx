import { useState } from "react";
import { useRoute, useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { CheckCircle2, Clock, XCircle, ArrowLeft, RefreshCw, AlertTriangle, AlertCircle } from "lucide-react";
import { useGetOrder, getGetOrderQueryKey } from "@workspace/api-client-react";
import { useLang } from "@/lib/use-lang";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";

import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { topupFeeUsdt, payFeeUsdt } from "@/lib/fees";
import {
  WALLET_ADDRESSES,
  NETWORK_INFO,
  LEGACY_BEP20_ADDRESSES,
} from "@/lib/wallet-config";

const REVIEW_COOLDOWN_MS = 30 * 60 * 1000;
const API_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

// Reverse-map a stored deposit address back to its network label
// (TRC-20 / BEP-20 / ERC-20) so the bill shows the chain that matches the
// address the customer actually sent to. Returns null for addresses that
// don't belong to a known deposit network (e.g. THB-payment orders).
function networkLabelForAddress(address: string): string | null {
  for (const net of Object.keys(WALLET_ADDRESSES) as Array<keyof typeof WALLET_ADDRESSES>) {
    if (WALLET_ADDRESSES[net] === address) return NETWORK_INFO[net].label;
  }
  if ((LEGACY_BEP20_ADDRESSES as readonly string[]).includes(address)) {
    return NETWORK_INFO.BEP20.label;
  }
  return null;
}

function formatBillDate(iso: string): string {
  const d = new Date(iso);
  const time = d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false });
  const date = d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  return `${time} ${date}`;
}

function shortId(id: string): string {
  if (!id) return "";
  const clean = id.replace(/-/g, "");
  return `${clean.slice(0, 7)}...${clean.slice(-4)}`;
}

export default function Status() {
  const [, params] = useRoute("/status/:orderId");
  const [, setLocation] = useLocation();
  const { t } = useLang();
  const { token } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [reviewing, setReviewing] = useState(false);
  const orderId = params?.orderId || "";

  async function requestReview() {
    if (!token || !orderId) return;
    setReviewing(true);
    try {
      const res = await fetch(`${API_BASE}/api/orders/${orderId}/request-review`, {
        method: "POST",
        headers: { "Authorization": `Bearer ${token}` },
      });
      if (res.ok) {
        toast({ title: t.status.reviewSent, description: t.status.reviewSentDesc });
        queryClient.invalidateQueries({ queryKey: getGetOrderQueryKey(orderId) });
      } else if (res.status === 429) {
        const data = await res.json().catch(() => ({})) as { retryAfterMs?: number };
        const mins = Math.max(1, Math.ceil((data.retryAfterMs ?? 0) / 60000));
        toast({ title: t.status.reviewCooldown.replace("{minutes}", String(mins)), variant: "destructive" });
      } else {
        toast({ title: t.status.reviewError, variant: "destructive" });
      }
    } catch {
      toast({ title: t.status.reviewError, variant: "destructive" });
    } finally {
      setReviewing(false);
    }
  }

  const { data: order, isLoading } = useGetOrder(orderId, {
    query: {
      enabled: !!orderId,
      queryKey: getGetOrderQueryKey(orderId),
      refetchInterval: (query) => {
        const status = query.state.data?.status;
        return (status === "pending" || status === "paid") ? 3000 : false;
      }
    }
  });

  if (isLoading || !order) {
    return (
      <div className="flex flex-col gap-6 animate-pulse p-4">
        <div className="h-8 w-24 bg-muted rounded" />
        <div className="h-64 w-full bg-card rounded-xl" />
        <div className="h-14 w-full bg-muted rounded-xl" />
      </div>
    );
  }

  const getStatusConfig = (status: string) => {
    switch (status) {
      case "pending":   return { color: "text-yellow-500", bg: "bg-yellow-500/10", icon: Clock,        label: t.status.pending,   animate: "" };
      case "paid":      return { color: "text-blue-500",   bg: "bg-blue-500/10",   icon: RefreshCw,    label: t.status.paid,      animate: "animate-spin" };
      case "completed": return { color: "text-green-500",  bg: "bg-green-500/10",  icon: CheckCircle2, label: t.status.completed, animate: "" };
      case "expired":   return { color: "text-red-500",    bg: "bg-red-500/10",    icon: XCircle,      label: t.status.expired,   animate: "" };
      case "refunded":  return { color: "text-orange-500", bg: "bg-orange-500/10", icon: RefreshCw,    label: t.status.refunded,  animate: "" };
      default:          return { color: "text-gray-500",   bg: "bg-gray-500/10",   icon: Clock,        label: t.status.unknown,   animate: "" };
    }
  };

  // Deposits (USDT top-up) have no THB recipient — bankName is empty.
  // The customer should see USDT-only figures, not the THB equivalent.
  const isDeposit = !order.bankName;

  const baseConfig = getStatusConfig(order.status);
  // For rejected deposits, the user-facing framing is "Bill sai" (wrong
  // bill) with an X icon — not the generic refund/refresh look — so the
  // customer immediately understands their topup bill was rejected.
  const config = (order.status === "refunded" && isDeposit)
    ? { ...baseConfig, icon: XCircle, label: t.status.depositRejectedHeader, animate: "" }
    : baseConfig;
  const StatusIcon = config.icon;
  const grossUsdt = order.amountUsdt;
  const feeUsdt = isDeposit ? topupFeeUsdt(grossUsdt) : 0;
  const netUsdt = Math.max(0, grossUsdt - feeUsdt);

  const isPending = order.status === "pending" || order.status === "paid";
  const now = Date.now();
  const sinceCreated = now - new Date(order.createdAt).getTime();
  const sinceLastReview = order.reviewRequestedAt
    ? now - new Date(order.reviewRequestedAt).getTime()
    : Infinity;
  const showReviewButton =
    isPending &&
    sinceCreated >= REVIEW_COOLDOWN_MS &&
    sinceLastReview >= REVIEW_COOLDOWN_MS;

  // Completed orders render as a clean receipt. Deposits show USDT-only
  // figures (gross / fee / net credited); payments show the THB receipt.
  if (order.status === "completed") {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="flex flex-col gap-6 pb-8 pt-8"
      >
        {/* Success badge + hero amount */}
        <div className="flex flex-col items-center pt-4 gap-3">
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-green-500/10 border border-green-500/30">
            <CheckCircle2 className="w-5 h-5 text-green-400" />
            <span className="text-sm font-bold text-green-400">
              {isDeposit ? t.status.depositSuccess : "Payment successful"}
            </span>
          </div>
          <h1 className="text-5xl font-extrabold tabular-nums tracking-tight text-foreground">
            {isDeposit
              ? <>+{netUsdt.toFixed(2)} <span className="text-3xl text-accent">USDT</span></>
              : <>-{order.amountThb.toLocaleString("en-US", { maximumFractionDigits: 2 })} ฿</>}
          </h1>
        </div>

        {/* Receipt rows */}
        <Card className="border-border bg-card">
          <CardContent className="p-0 divide-y divide-border">
            {isDeposit ? (
              <>
                <Row label={t.status.depositGross} value={`${grossUsdt.toFixed(4)} USDT`} mono />
                <Row label={t.status.depositFee} value={`− ${feeUsdt.toFixed(2)} USDT`} mono />
                <Row label={t.status.depositCredited} value={`${netUsdt.toFixed(2)} USDT`} mono />
                <Row label="Date" value={formatBillDate(order.createdAt)} />
                <Row label="Internal ID" value={shortId(order.id)} mono />
                <Row label="Confirmed at" value={formatBillDate(order.updatedAt)} />
              </>
            ) : (
              <>
                <Row label="Recipient" value={order.accountName} />
                {/* Service fee, expressed in USDT (auto-converted from the THB
                    fee using the order's locked exchange rate). Notification
                    surfaces should always quote the fee in USDT, not THB. */}
                <Row
                  label="Fee"
                  value={`${payFeeUsdt(order.amountThb, order.exchangeRate).toFixed(2)} USDT`}
                  mono
                />
                <Row label="Date" value={formatBillDate(order.createdAt)} />
                <Row label="Internal ID" value={shortId(order.id)} mono />
                <Row label="Account Number" value={order.accountNumber} mono />
                <Row label="Bank" value={order.bankName} />
                <Row label="Confirmed at" value={formatBillDate(order.updatedAt)} />
              </>
            )}
          </CardContent>
        </Card>

        <div className="flex flex-col gap-3">
          <Button
            className="w-full h-14 text-base font-bold"
            onClick={() => setLocation("/")}
          >
            Back to home
          </Button>
          <Button
            variant="outline"
            className="w-full h-14 text-base font-semibold bg-transparent border-border hover:bg-secondary"
            onClick={() => setLocation("/wallet")}
          >
            Open wallet
          </Button>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="flex flex-col gap-6 pb-8 pt-8"
    >
      <div className="flex flex-col items-center justify-center mb-2">
        <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-4 ${config.bg}`}>
          <StatusIcon className={`w-10 h-10 ${config.color} ${config.animate}`} />
        </div>
        <h2 className="text-2xl font-bold">{config.label}</h2>
        <p className="text-muted-foreground font-mono text-sm mt-1">{order.orderId}</p>
      </div>

      {showReviewButton && (
        <Button
          variant="outline"
          disabled={reviewing}
          onClick={() => void requestReview()}
          className="w-full h-12 gap-2 border-yellow-500/40 text-yellow-300 hover:bg-yellow-500/10 hover:text-yellow-200"
        >
          <AlertCircle className="w-4 h-4" />
          {reviewing ? "..." : t.status.requestReview}
        </Button>
      )}

      {order.status === "refunded" && (
        <div className="flex items-start gap-3 p-4 rounded-xl bg-orange-500/10 border border-orange-500/40">
          <AlertTriangle className="w-5 h-5 text-orange-400 shrink-0 mt-0.5" />
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-orange-400 text-sm">
              {isDeposit ? t.status.depositRejectedTitle : t.status.refundedTitle}
            </p>
            <p className="text-xs mt-1.5 leading-snug">
              <span className="font-semibold text-orange-300">{t.status.refundedReasonLabel}: </span>
              <span className="text-orange-100/90">
                {isDeposit ? t.status.depositRejectedReason : t.status.refundedReason}
              </span>
            </p>
            <p className="text-[11px] text-muted-foreground mt-1.5 leading-snug">
              {isDeposit ? t.status.depositRejectedHint : t.status.refundedHint}
            </p>
            {isDeposit && (
              <Button
                size="sm"
                className="mt-3 h-9 text-xs font-bold"
                onClick={() => setLocation("/topup")}
              >
                {t.status.newDeposit}
              </Button>
            )}
          </div>
        </div>
      )}

      <Card className="border-border bg-card">
        <CardContent className="p-0">
          {/* Hero row: deposits show net USDT credited (gross − fee); payments show THB the recipient gets */}
          <div className="p-5 bg-secondary/30 flex justify-between items-center border-b border-border rounded-t-xl">
            <span className="text-sm text-muted-foreground font-medium">{t.status.amountReceived}</span>
            {isDeposit ? (
              <span className="text-2xl font-bold text-accent font-mono tabular-nums">
                {netUsdt.toFixed(2)} <span className="text-base">USDT</span>
              </span>
            ) : (
              <span className="text-2xl font-bold text-green-400 font-mono tabular-nums">
                {order.amountThb.toLocaleString("th-TH", { maximumFractionDigits: 2 })} <span className="text-base">THB</span>
              </span>
            )}
          </div>

          <div className="p-4 space-y-4">
            {isDeposit ? (
              <>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">{t.status.depositGross}</span>
                  <span className="text-sm font-medium tabular-nums font-mono">
                    {order.amountUsdt.toFixed(4)} USDT
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">{t.status.depositFee}</span>
                  <span className="text-sm font-medium tabular-nums font-mono text-amber-300">
                    − {feeUsdt.toFixed(2)} USDT
                  </span>
                </div>
              </>
            ) : (
              <>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">{t.status.exchangeRate}</span>
                  <span className="text-sm font-medium tabular-nums">1 USDT = {order.exchangeRate.toFixed(2)} THB</span>
                </div>

                <div className="flex justify-between items-start">
                  <span className="text-sm text-muted-foreground">{t.status.bankDetails}</span>
                  <span className="text-sm font-medium text-right">
                    {order.bankName}<br />
                    <span className="text-xs text-muted-foreground font-mono">{order.accountNumber}</span><br />
                    <span className="text-xs text-muted-foreground">{order.accountName}</span>
                  </span>
                </div>
              </>
            )}

            <div className="flex justify-between items-center pt-2 border-t border-border/50">
              <span className="text-sm text-muted-foreground">{t.status.wallet}</span>
              <span className="flex items-center gap-2 min-w-0">
                {networkLabelForAddress(order.walletAddress) && (
                  <span className="text-[10px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded bg-secondary text-foreground shrink-0">
                    {networkLabelForAddress(order.walletAddress)}
                  </span>
                )}
                <span className="text-xs font-mono max-w-[150px] truncate text-muted-foreground">{order.walletAddress}</span>
              </span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">{t.status.date}</span>
              <span className="text-sm font-medium">{new Date(order.createdAt).toLocaleString()}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Button
        variant="outline"
        className="w-full h-14 text-lg font-bold gap-2 bg-transparent border-border hover:bg-secondary"
        onClick={() => setLocation("/")}
      >
        <ArrowLeft className="w-5 h-5" />
        {t.status.newPayment}
      </Button>
    </motion.div>
  );
}

function Row({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-4 px-5 py-4">
      <span className="text-sm text-muted-foreground">{label}</span>
      <span className={`text-sm font-medium text-right max-w-[60%] break-words ${mono ? "font-mono" : ""}`}>
        {value}
      </span>
    </div>
  );
}
