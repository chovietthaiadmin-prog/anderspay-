import { useRef, useState } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, Copy, Check, AlertTriangle, Zap, ShieldAlert, Upload, ImageIcon, CheckCircle2 } from "lucide-react";
import { BrandSpinner } from "@/components/brand-spinner";
import { useLang } from "@/lib/use-lang";
import { useAuth } from "@/lib/auth";
import {
  WALLET_ADDRESSES,
  NETWORK_INFO,
  ACTIVE_DEPOSIT_NETWORKS,
  type ActiveDepositNetwork,
} from "@/lib/wallet-config";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  WorkingHoursStatusPill,
  WorkingHoursWarningBanner,
} from "@/components/working-hours-notice";
import { useToast } from "@/hooks/use-toast";
import { isWithinWorkingHours } from "@/lib/working-hours";
import NightDelayWarning from "@/components/night-delay-warning";
import InlineAuth from "@/components/inline-auth";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

export default function Topup() {
  const [, setLocation] = useLocation();
  const { t, lang } = useLang();
  const { user, token } = useAuth();
  const { toast } = useToast();
  const tu = t.topup;

  const [network, setNetwork] = useState<ActiveDepositNetwork>("TRC20");
  const [copied, setCopied] = useState(false);

  // Confirm form state
  const [amountUsdt, setAmountUsdt] = useState("");
  const [billFile, setBillFile] = useState<File | null>(null);
  const [billPreview, setBillPreview] = useState<string | null>(null);
  const [billSizeKb, setBillSizeKb] = useState<number | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  // True while the night-delay warning modal is shown. Set by
  // `handleSubmit` when the user submits between 23:00 and 08:00 ICT;
  // pressing "Continue" calls `handleSubmit(true)` to bypass the gate.
  const [nightWarnOpen, setNightWarnOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const address = WALLET_ADDRESSES[network];
  const info = NETWORK_INFO[network];

  const copyAddress = async () => {
    await navigator.clipboard.writeText(address);
    setCopied(true);
    toast({ title: tu.copied, description: address.slice(0, 16) + "…" });
    setTimeout(() => setCopied(false), 2500);
  };

  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&color=ffffff&bgcolor=1a1a1a&data=${encodeURIComponent(address)}`;

  // Phone screenshots / camera shots are routinely 2–5 MB (HEIC even more),
  // and uploading multipart of that size over a flaky mobile connection
  // is the #1 cause of "Đang gửi..." hanging forever. We resize/compress
  // images client-side to a max edge of 1600px @ 0.82 JPEG quality so the
  // payload is typically <500 KB while still being plenty readable for
  // an admin to verify the bill. PDFs are passed through unchanged.
  const compressImage = (file: File): Promise<File> =>
    new Promise((resolve) => {
      if (!file.type.startsWith("image/")) {
        resolve(file);
        return;
      }
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        const MAX = 1600;
        let { width, height } = img;
        if (width > MAX || height > MAX) {
          const scale = Math.min(MAX / width, MAX / height);
          width = Math.round(width * scale);
          height = Math.round(height * scale);
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          URL.revokeObjectURL(url);
          resolve(file);
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        canvas.toBlob(
          (blob) => {
            URL.revokeObjectURL(url);
            if (!blob) {
              resolve(file);
              return;
            }
            // Only swap if we actually shrunk it.
            if (blob.size >= file.size) {
              resolve(file);
              return;
            }
            const out = new File([blob], file.name.replace(/\.[^.]+$/, "") + ".jpg", {
              type: "image/jpeg",
              lastModified: Date.now(),
            });
            resolve(out);
          },
          "image/jpeg",
          0.82,
        );
      };
      img.onerror = () => {
        URL.revokeObjectURL(url);
        resolve(file);
      };
      img.src = url;
    });

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const compressed = await compressImage(file);
    setBillFile(compressed);
    setBillSizeKb(Math.round(compressed.size / 1024));
    const reader = new FileReader();
    reader.onload = (ev) => setBillPreview(ev.target?.result as string);
    reader.readAsDataURL(compressed);
  };

  const handleSubmit = async (skipNightGate = false) => {
    if (!user || !token) {
      toast({ title: lang === "vi" ? "Cần đăng nhập trước khi nạp USDT" : "Sign in before depositing USDT", variant: "destructive" });
      return;
    }
    const amt = parseFloat(amountUsdt);
    if (!amountUsdt || isNaN(amt) || amt <= 0) {
      toast({ title: tu.errAmount, variant: "destructive" });
      return;
    }
    if (amt < 15) {
      toast({ title: lang === "vi" ? "Tối thiểu 15 USDT" : "Minimum 15 USDT", variant: "destructive" });
      return;
    }
    if (!billFile) {
      toast({ title: tu.errBill, variant: "destructive" });
      return;
    }

    // Outside working hours (08:00–23:00 ICT) → show the night-delay
    // warning modal first. The user confirms with "Continue" which
    // calls handleSubmit(true) to bypass the gate.
    if (!skipNightGate && !isWithinWorkingHours()) {
      setNightWarnOpen(true);
      return;
    }

    setSubmitting(true);
    try {
      // We MUST send the bill as base64-in-JSON, NOT multipart/form-data,
      // because Replit's edge proxy returns 403 Forbidden for any
      // `multipart/form-data` POST before the request ever reaches our
      // Express server. Spent hours debugging "Đang gửi..." hanging — root
      // cause is the platform WAF, not network or our code. Base64 inflates
      // size by ~33% but our compressed JPEG is already <500 KB so total
      // payload stays comfortably under 1 MB.
      const billBase64: string = await new Promise((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => {
          const result = r.result as string;
          // strip the "data:<mime>;base64," prefix — server accepts either
          // form, but raw base64 is smaller and clearer in logs.
          const comma = result.indexOf(",");
          resolve(comma >= 0 ? result.slice(comma + 1) : result);
        };
        r.onerror = () => reject(new Error("read_failed"));
        r.readAsDataURL(billFile);
      });

      // 45s hard timeout so the spinner can never spin forever if the
      // upload stalls on a flaky mobile network or the proxy drops the
      // connection — the user will see a clear error and can retry.
      const ctrl = new AbortController();
      const timeoutId = window.setTimeout(() => ctrl.abort(), 45000);
      let res: Response;
      try {
        res = await fetch(`${BASE}/api/topup`, {
          method: "POST",
          body: JSON.stringify({
            amountUsdt: Number(amountUsdt),
            network,
            billBase64,
            billMime: billFile.type || "image/jpeg",
            billName: billFile.name || "bill.jpg",
          }),
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          signal: ctrl.signal,
        });
      } finally {
        window.clearTimeout(timeoutId);
      }
      const body = (await res.json().catch(() => null)) as
        | { id?: string; message?: string; code?: string }
        | null;
      if (!res.ok) {
        // Surface the server's actual reason (file too large, wrong type,
        // amount too small, etc.) instead of a generic "try again" toast
        // so the user knows what to fix.
        const fallback = lang === "vi" ? "Có lỗi xảy ra, thử lại" : "Something went wrong, try again";
        toast({ title: body?.message || fallback, variant: "destructive" });
        return;
      }
      // Navigate to the status page so the customer can watch the order
      // progress live — and so any admin rejection (status → "refunded")
      // surfaces with the orange banner explaining the wrong-amount issue.
      if (body?.id) {
        setLocation(`/status/${body.id}`);
        return;
      }
      setSuccess(true);
    } catch (err) {
      const aborted = err instanceof DOMException && err.name === "AbortError";
      const title = aborted
        ? (lang === "vi"
            ? "Mạng quá chậm, ảnh chưa gửi xong. Vui lòng thử lại."
            : "Network too slow — upload didn't finish. Please try again.")
        : (lang === "vi"
            ? "Không kết nối được máy chủ. Vui lòng thử lại."
            : "Could not reach the server. Please try again.");
      toast({ title, variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  const resetForm = () => {
    setAmountUsdt("");
    setBillFile(null);
    setBillPreview(null);
    setBillSizeKb(null);
    setSuccess(false);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  if (!user || !token) {
    return <div className="pt-6 pb-28"><InlineAuth /></div>;
  }

  if (user.isAdmin) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col items-center justify-center gap-4 pt-24 pb-28 text-center"
      >
        <div className="w-16 h-16 rounded-full bg-accent/10 border border-accent/20 flex items-center justify-center">
          <ShieldAlert className="w-8 h-8 text-accent" />
        </div>
        <div>
          <p className="font-bold text-base">{lang === "vi" ? "Tính năng không khả dụng" : "Feature unavailable"}</p>
          <p className="text-xs text-muted-foreground mt-1">
            {lang === "vi" ? "Tài khoản admin không thể nạp USDT." : "Admin accounts cannot deposit USDT."}
          </p>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, x: 24 }}
      animate={{ opacity: 1, x: 0 }}
      className="flex flex-col gap-5 pb-10"
    >
      {/* Header */}
      <div className="flex items-center gap-3 pt-6 pb-1">
        <button
          onClick={() => setLocation("/")}
          className="w-9 h-9 rounded-full border border-border flex items-center justify-center hover:bg-secondary/50 transition-colors shrink-0"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div className="flex-1">
          <h1 className="text-xl font-bold">{tu.title}</h1>
          <p className="text-muted-foreground text-xs">{tu.subtitle}</p>
        </div>
        <div className="flex flex-col items-end gap-1 shrink-0">
          <div className="flex items-center gap-1 text-xs text-accent font-bold bg-accent/10 px-2.5 py-1 rounded-full border border-accent/20">
            <Zap className="w-3 h-3" />
            USDT
          </div>
          <WorkingHoursStatusPill />
        </div>
      </div>

      {/* Outside-hours notice — non-blocking, only shown when closed */}
      <WorkingHoursWarningBanner />

      {/* Network selector */}
      <div>
        <p className="text-xs uppercase tracking-widest text-muted-foreground font-medium mb-2">{tu.selectNetwork}</p>
        <div className="grid grid-cols-3 gap-2">
          {ACTIVE_DEPOSIT_NETWORKS.map((net) => {
            const ni = NETWORK_INFO[net];
            const active = network === net;
            return (
              <button
                key={net}
                onClick={() => setNetwork(net)}
                className={`relative flex flex-col items-center gap-1.5 rounded-2xl border p-3 transition-all ${
                  active
                    ? "border-transparent shadow-lg scale-[1.02]"
                    : "border-border bg-card hover:border-border/80"
                }`}
                style={active ? { background: `${ni.color}18`, borderColor: ni.color } : {}}
              >
                {active && (
                  <div
                    className="absolute top-0 left-0 right-0 h-0.5 rounded-t-2xl"
                    style={{ background: ni.color }}
                  />
                )}
                <span
                  className="text-xl font-black tabular-nums leading-none"
                  style={{ color: active ? ni.color : undefined }}
                >
                  {ni.label}
                </span>
                <span className="text-[10px] text-muted-foreground font-medium text-center leading-tight">
                  {ni.chain}
                </span>
                {active && (
                  <span
                    className="text-[9px] font-bold px-1.5 py-0.5 rounded-full"
                    style={{ background: `${ni.color}25`, color: ni.color }}
                  >
                    {ni.token}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* QR + Address */}
      <AnimatePresence mode="wait">
        <motion.div
          key={network}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.15 }}
        >
          <Card className="border-border bg-card overflow-hidden relative">
            <div
              className="absolute top-0 left-0 right-0 h-1"
              style={{ background: NETWORK_INFO[network].color, opacity: 0.8 }}
            />
            <CardContent className="p-5 flex flex-col items-center gap-4">
              <div className="w-[160px] h-[160px] rounded-2xl overflow-hidden border-2 border-border bg-card flex items-center justify-center">
                <img
                  src={qrUrl}
                  alt="QR Code"
                  className="w-full h-full object-cover"
                  onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
                />
              </div>
              <div
                className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold"
                style={{ background: `${NETWORK_INFO[network].color}20`, color: NETWORK_INFO[network].color }}
              >
                <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: NETWORK_INFO[network].color }} />
                {NETWORK_INFO[network].token}
              </div>
              <div className="w-full bg-secondary/60 rounded-xl p-3 border border-border">
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium mb-1.5">{tu.walletAddress}</p>
                <p className="font-mono text-sm break-all leading-relaxed text-foreground/90 select-all">{address}</p>
              </div>
              <Button
                className="w-full h-12 font-bold gap-2"
                onClick={copyAddress}
                style={copied ? { background: "#22c55e" } : {}}
              >
                {copied ? (
                  <><Check className="w-4 h-4" /> {tu.copied}</>
                ) : (
                  <><Copy className="w-4 h-4" /> {tu.copyAddress}</>
                )}
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </AnimatePresence>

      {/* Warning notes */}
      <Card className="border-yellow-500/20 bg-yellow-500/5">
        <CardContent className="p-4 flex flex-col gap-2.5">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-yellow-400 shrink-0" />
            <p className="text-sm font-bold text-yellow-400">{tu.warningTitle}</p>
          </div>
          {tu.warnings.map((w, i) => (
            <div key={i} className="flex items-start gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-yellow-400/60 mt-1.5 shrink-0" />
              <p className="text-xs text-muted-foreground leading-relaxed">{w}</p>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* ── Confirm deposit section ── */}
      <div className="relative flex items-center gap-3">
        <div className="flex-1 h-px bg-border" />
        <span className="text-[11px] uppercase tracking-widest text-muted-foreground font-medium whitespace-nowrap">
          {tu.confirmSection}
        </span>
        <div className="flex-1 h-px bg-border" />
      </div>

      <AnimatePresence mode="wait">
        {success ? (
          <motion.div
            key="success"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
          >
            <Card className="border-green-500/30 bg-green-500/5">
              <CardContent className="p-6 flex flex-col items-center gap-4 text-center">
                <div className="w-16 h-16 rounded-full bg-green-500/10 border border-green-500/30 flex items-center justify-center">
                  <CheckCircle2 className="w-8 h-8 text-green-400" />
                </div>
                <div>
                  <p className="font-bold text-base text-green-400">{tu.successTitle}</p>
                  <p className="text-xs text-muted-foreground mt-1">{tu.successMsg}</p>
                </div>
                <Button variant="outline" className="w-full" onClick={resetForm}>
                  {tu.submitNew}
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        ) : (
          <motion.div
            key="form"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="flex flex-col gap-3"
          >
            <p className="text-xs text-muted-foreground">{tu.confirmHint}</p>

            {/* Service fee notice — applied at credit time */}
            <div className="rounded-2xl border border-primary/30 bg-primary/5 px-3.5 py-3 flex gap-2.5">
              <div className="w-7 h-7 rounded-full bg-primary/15 flex items-center justify-center shrink-0 mt-0.5">
                <Zap className="w-3.5 h-3.5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[12px] font-bold text-primary leading-snug">
                  {tu.svcFeeTitle}
                </p>
                <p className="text-[11px] text-primary/80 leading-snug mt-1">
                  {tu.svcFeeRule}
                </p>
                {amountUsdt && parseFloat(amountUsdt) > 0 && (() => {
                  const gross = parseFloat(amountUsdt);
                  const fee = gross < 100 ? 0.5 : 1;
                  const net = Math.max(0, gross - fee);
                  return (
                    <p className="text-[11px] mt-1.5 font-mono">
                      <span className="text-muted-foreground">{tu.svcFeePreview} </span>
                      <span className="text-green-400 font-bold">{net.toFixed(2)} USDT</span>
                      <span className="text-amber-300/80"> (− {fee.toFixed(2)} USDT)</span>
                    </p>
                  );
                })()}
              </div>
            </div>

            {/* Network fee warning — orders with mismatched USDT amount cannot be credited */}
            <div className="rounded-2xl border border-amber-500/40 bg-amber-500/10 px-3.5 py-3 flex gap-2.5">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div className="flex-1 min-w-0">
                <p className="text-[12px] font-bold text-amber-300 leading-snug">
                  {tu.feeWarningTitle}
                </p>
                <p className="text-[11px] text-amber-100/80 leading-snug mt-1">
                  {tu.feeWarningBody}
                </p>
                <p className="text-[11px] text-amber-200/60 leading-snug mt-1.5 italic">
                  {tu.feeWarningHint}
                </p>
              </div>
            </div>

            {/* USDT amount */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs text-muted-foreground font-medium">{tu.usdtAmountLabel}</label>
              <div className="relative">
                <input
                  type="number"
                  min="15"
                  step="0.000001"
                  inputMode="decimal"
                  value={amountUsdt}
                  onChange={(e) => setAmountUsdt(e.target.value)}
                  placeholder={tu.usdtAmountPlaceholder}
                  className={`w-full h-11 rounded-xl border bg-secondary/50 px-4 pr-16 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-primary/40 transition-all ${
                    amountUsdt && parseFloat(amountUsdt) < 15
                      ? "border-red-500/60 focus:ring-red-500/30"
                      : "border-border focus:border-primary/60"
                  }`}
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-muted-foreground">USDT</span>
              </div>
              {amountUsdt && parseFloat(amountUsdt) < 15 ? (
                <p className="text-xs text-red-400">{lang === "vi" ? "Tối thiểu 15 USDT" : "Minimum 15 USDT"}</p>
              ) : (
                <p className="text-[11px] text-muted-foreground/60">{lang === "vi" ? "Tối thiểu: 15 USDT" : "Minimum: 15 USDT"}</p>
              )}
            </div>

            {/* Bill upload */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs text-muted-foreground font-medium">{tu.uploadBill}</label>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,application/pdf"
                className="hidden"
                onChange={handleFileChange}
              />
              {billPreview ? (
                <div className="relative rounded-2xl overflow-hidden border border-border bg-card">
                  <img src={billPreview} alt="bill" className="w-full max-h-52 object-contain" />
                  {billSizeKb !== null && (
                    <span className="absolute top-2 left-2 text-[10px] bg-black/70 text-white px-2 py-0.5 rounded-full backdrop-blur-sm border border-white/10">
                      {billSizeKb < 1024 ? `${billSizeKb} KB` : `${(billSizeKb / 1024).toFixed(1)} MB`}
                    </span>
                  )}
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute bottom-2 right-2 flex items-center gap-1.5 bg-black/70 text-white text-xs px-3 py-1.5 rounded-full backdrop-blur-sm border border-white/10"
                  >
                    <Upload className="w-3 h-3" />
                    {tu.uploadBillChange}
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex flex-col items-center justify-center gap-2 h-32 rounded-2xl border-2 border-dashed border-border bg-secondary/30 hover:border-primary/40 hover:bg-secondary/50 transition-all"
                >
                  <ImageIcon className="w-8 h-8 text-muted-foreground/50" />
                  <span className="text-xs text-muted-foreground">{tu.uploadBillHint}</span>
                </button>
              )}
            </div>

            {/* Submit */}
            <Button
              className="w-full h-12 font-bold gap-2 mt-1"
              onClick={() => handleSubmit()}
              disabled={submitting}
            >
              {submitting ? (
                <><BrandSpinner size={16} /> {tu.submitting}</>
              ) : (
                tu.submitBtn
              )}
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
      <NightDelayWarning
        open={nightWarnOpen}
        onCancel={() => setNightWarnOpen(false)}
        onContinue={() => {
          setNightWarnOpen(false);
          void handleSubmit(true);
        }}
      />
    </motion.div>
  );
}
