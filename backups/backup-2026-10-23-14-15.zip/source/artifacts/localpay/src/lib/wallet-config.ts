export const WALLET_ADDRESSES = {
  TRC20: "TU8x5xYV5gnHAakuQPh38DqNk4ofPpnGn3",
  BEP20: "0x07c27c73d9b3182ccab7ea06a633e5bea2052c10",
  ERC20: "0x6b7Fc3F701180621b187846A591C1fe157722D6D",
} as const;

export type Network = keyof typeof WALLET_ADDRESSES;
export const ACTIVE_DEPOSIT_NETWORKS = ["TRC20", "BEP20", "ERC20"] as const;
export type ActiveDepositNetwork = (typeof ACTIVE_DEPOSIT_NETWORKS)[number];

export const LEGACY_BEP20_ADDRESSES = [
  "0xcb0dbaf99e3a4243b4473d6b974235bd0d3fca17",
] as const;

export const NETWORK_INFO: Record<Network, { label: string; chain: string; token: string; color: string; minDeposit: number }> = {
  TRC20: {
    label: "TRC-20",
    chain: "Tron (TRX)",
    token: "USDT-TRC20",
    color: "#e84142",
    minDeposit: 20,
  },
  BEP20: {
    label: "BEP-20",
    chain: "BNB Smart Chain",
    token: "USDT-BEP20",
    color: "#F0B90B",
    minDeposit: 20,
  },
  ERC20: {
    label: "ERC-20",
    chain: "Ethereum (ETH)",
    token: "USDT-ERC20",
    color: "#627EEA",
    minDeposit: 20,
  },
};
