import { useEffect, useState } from "react";
import { translations } from "./translations";
import { LangContext } from "./lang-context";
import type { Lang, Translations } from "./translations";

export type { Lang, Translations };
export { LangContext };

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Lang>(() => {
    const saved = localStorage.getItem("ap-lang") as Lang | null;
    return saved === "en" || saved === "vi" || saved === "zh" || saved === "ar" || saved === "ko" || saved === "ru"
      ? saved
      : "vi";
  });

  const setLang = (l: Lang) => {
    setLangState(l);
    localStorage.setItem("ap-lang", l);
  };

  const t = translations[lang] as Translations;

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  }, [lang]);

  return (
    <LangContext.Provider value={{ lang, setLang, t }}>
      {children}
    </LangContext.Provider>
  );
}
