import { startRegistration, startAuthentication } from "@simplewebauthn/browser";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

function authHeaders(token: string): Record<string, string> {
  return {
    "Authorization": `Bearer ${token}`,
    "Content-Type": "application/json",
  };
}

export interface SecurityStatus {
  pinEnabled: boolean;
  passkeys: {
    id: string;
    name: string | null;
    createdAt: string;
    lastUsedAt: string | null;
  }[];
}

export async function fetchSecurityStatus(token: string): Promise<SecurityStatus> {
  const res = await fetch(`${BASE}/api/security/status`, {
    headers: { "Authorization": `Bearer ${token}` },
  });
  if (!res.ok) throw new Error("status_failed");
  return res.json();
}

export async function setPin(token: string, password: string, pin: string): Promise<void> {
  const res = await fetch(`${BASE}/api/security/pin`, {
    method: "POST",
    headers: authHeaders(token),
    body: JSON.stringify({ password, pin }),
  });
  if (!res.ok) {
    const d = (await res.json().catch(() => ({}))) as { error?: string };
    throw new Error(d.error ?? "pin_failed");
  }
}

export async function verifyPin(token: string, pin: string): Promise<void> {
  const res = await fetch(`${BASE}/api/security/pin/verify`, {
    method: "POST",
    headers: authHeaders(token),
    body: JSON.stringify({ pin }),
  });
  if (!res.ok) {
    const d = (await res.json().catch(() => ({}))) as { error?: string };
    throw new Error(d.error ?? "pin_invalid");
  }
}

export async function removePin(token: string, password: string): Promise<void> {
  const res = await fetch(`${BASE}/api/security/pin`, {
    method: "DELETE",
    headers: authHeaders(token),
    body: JSON.stringify({ password }),
  });
  if (!res.ok) {
    const d = (await res.json().catch(() => ({}))) as { error?: string };
    throw new Error(d.error ?? "remove_failed");
  }
}

export async function registerPasskey(token: string, name: string): Promise<void> {
  const optsRes = await fetch(`${BASE}/api/security/passkey/register/options`, {
    method: "POST",
    headers: authHeaders(token),
  });
  if (!optsRes.ok) throw new Error("options_failed");
  const options = await optsRes.json();
  const response = await startRegistration({ optionsJSON: options });
  const verRes = await fetch(`${BASE}/api/security/passkey/register/verify`, {
    method: "POST",
    headers: authHeaders(token),
    body: JSON.stringify({ response, name }),
  });
  if (!verRes.ok) {
    const d = (await verRes.json().catch(() => ({}))) as { error?: string };
    throw new Error(d.error ?? "verify_failed");
  }
}

export async function authenticatePasskey(token: string): Promise<void> {
  const optsRes = await fetch(`${BASE}/api/security/passkey/auth/options`, {
    method: "POST",
    headers: authHeaders(token),
  });
  if (!optsRes.ok) {
    const d = (await optsRes.json().catch(() => ({}))) as { error?: string };
    throw new Error(d.error ?? "options_failed");
  }
  const options = await optsRes.json();
  const response = await startAuthentication({ optionsJSON: options });
  const verRes = await fetch(`${BASE}/api/security/passkey/auth/verify`, {
    method: "POST",
    headers: authHeaders(token),
    body: JSON.stringify({ response }),
  });
  if (!verRes.ok) throw new Error("verify_failed");
}

export async function removePasskey(token: string, id: string): Promise<void> {
  const res = await fetch(`${BASE}/api/security/passkey/${id}`, {
    method: "DELETE",
    headers: { "Authorization": `Bearer ${token}` },
  });
  if (!res.ok) throw new Error("remove_failed");
}

export function isPasskeySupported(): boolean {
  return typeof window !== "undefined"
    && typeof window.PublicKeyCredential !== "undefined";
}

const LOCK_FLAG = "ap-lock-enabled";
const UNLOCK_FLAG = "ap-unlocked";

export function setLockEnabled(enabled: boolean): void {
  if (enabled) localStorage.setItem(LOCK_FLAG, "1");
  else {
    localStorage.removeItem(LOCK_FLAG);
    sessionStorage.removeItem(UNLOCK_FLAG);
  }
}

export function isLockEnabled(): boolean {
  return localStorage.getItem(LOCK_FLAG) === "1";
}

export function markUnlocked(): void {
  sessionStorage.setItem(UNLOCK_FLAG, "1");
}

export function isUnlocked(): boolean {
  return sessionStorage.getItem(UNLOCK_FLAG) === "1";
}

export function clearUnlocked(): void {
  sessionStorage.removeItem(UNLOCK_FLAG);
}
