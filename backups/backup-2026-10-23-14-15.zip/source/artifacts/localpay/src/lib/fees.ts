// Client copy of artifacts/api-server/src/lib/fees.ts — keep in sync.

export const TOPUP_FEE_THRESHOLD_USDT = 100;
export const TOPUP_FEE_SMALL_USDT = 0.5;
export const TOPUP_FEE_LARGE_USDT = 1;

export const ONCHAIN_FEE_RATE = 0.0015; // 0.15%

export const BILL_FEE_TIERS = [
  { upTo: 1000, fee: 15 },
  { upTo: 5000, fee: 20 },
  { upTo: 10000, fee: 25 },
] as const;
export const BILL_FEE_TOP = 30;

export const MIN_USDT_BALANCE = 2.5;
export const MIN_TOPUP_USDT = 15;

export function topupFeeUsdt(amountUsdt: number): number {
  if (amountUsdt <= 0) return 0;
  return amountUsdt < TOPUP_FEE_THRESHOLD_USDT
    ? TOPUP_FEE_SMALL_USDT
    : TOPUP_FEE_LARGE_USDT;
}

export function billFeeThb(amountThb: number): number {
  if (amountThb <= 0) return 0;
  for (const tier of BILL_FEE_TIERS) {
    if (amountThb < tier.upTo) return tier.fee;
  }
  return BILL_FEE_TOP;
}

export function onchainFeeThb(amountThb: number): number {
  if (amountThb <= 0) return 0;
  return Math.round(amountThb * ONCHAIN_FEE_RATE * 100) / 100;
}

export function payFeeBreakdownThb(amountThb: number): {
  billFee: number;
  chainFee: number;
  total: number;
} {
  const billFee = billFeeThb(amountThb);
  const chainFee = onchainFeeThb(amountThb);
  const total = Math.round((billFee + chainFee) * 100) / 100;
  return { billFee, chainFee, total };
}

export function payFeeThb(amountThb: number): number {
  return payFeeBreakdownThb(amountThb).total;
}

export function payFeeUsdt(amountThb: number, rate: number): number {
  if (rate <= 0) return 0;
  return parseFloat((payFeeThb(amountThb) / rate).toFixed(6));
}
