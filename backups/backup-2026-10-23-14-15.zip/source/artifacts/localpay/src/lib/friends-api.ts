const API_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

export interface FriendUser {
  id: string;
  uid: string | null;
  name: string;
  nickname: string | null;
  avatarUrl: string | null;
}

export interface FriendshipRow {
  id: string;
  requesterId: string;
  receiverId: string;
  status: "pending" | "accepted" | "declined";
  createdAt: string;
  updatedAt: string;
}

export interface SearchResult {
  user: FriendUser;
  friendship: { id: string; status: FriendshipRow["status"]; iAmRequester: boolean } | null;
}

export interface FriendEntry {
  friendship: FriendshipRow;
  peer: FriendUser | null;
}

export interface RequestEntry {
  friendship: FriendshipRow;
  requester: FriendUser | null;
}

export interface RecentConversation {
  friendshipId: string;
  peer: FriendUser;
  lastBody: string | null;
  lastImageUrl: string | null;
  lastMediaMimeType: string | null;
  lastAt: string;
}

export interface PeerMessage {
  id: string;
  friendshipId: string;
  senderId: string;
  body: string | null;
  /** Authenticated media proxy URL: /api/friends/{fsId}/media/{itemId} */
  imageUrl: string | null;
  /** MIME type of attached media, e.g. "image/jpeg" or "video/mp4" */
  mediaMimeType: string | null;
  createdAt: string;
}

function authHeaders(token: string) {
  return { Authorization: `Bearer ${token}`, "Content-Type": "application/json" };
}

async function handleResponse<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error((data as { error?: string }).error ?? `HTTP ${res.status}`);
  }
  return res.json() as Promise<T>;
}

/** Search for a user by their AndersPay UID. */
export async function searchByUid(uid: string, token: string): Promise<SearchResult> {
  const res = await fetch(`${API_BASE}/api/friends/search?uid=${encodeURIComponent(uid)}`, {
    headers: authHeaders(token),
  });
  return handleResponse<SearchResult>(res);
}

/** Get the authenticated user's accepted friends list. */
export async function getFriends(token: string): Promise<FriendEntry[]> {
  const res = await fetch(`${API_BASE}/api/friends`, { headers: authHeaders(token) });
  return handleResponse<FriendEntry[]>(res);
}

/** Get the ten most recently active friend conversations. */
export async function getRecentConversations(token: string): Promise<RecentConversation[]> {
  const res = await fetch(`${API_BASE}/api/friends/recent`, { headers: authHeaders(token) });
  const data = await handleResponse<{ conversations: RecentConversation[] }>(res);
  return data.conversations;
}

/** Get incoming pending friend requests. */
export async function getFriendRequests(token: string): Promise<RequestEntry[]> {
  const res = await fetch(`${API_BASE}/api/friends/requests`, { headers: authHeaders(token) });
  return handleResponse<RequestEntry[]>(res);
}

/** Send a friend request to a user by their DB id. */
export async function sendFriendRequest(targetUserId: string, token: string): Promise<{ friendship: FriendshipRow }> {
  const res = await fetch(`${API_BASE}/api/friends/request`, {
    method: "POST",
    headers: authHeaders(token),
    body: JSON.stringify({ targetUserId }),
  });
  return handleResponse<{ friendship: FriendshipRow }>(res);
}

/** Accept a friend request. */
export async function acceptRequest(friendshipId: string, token: string): Promise<{ friendship: FriendshipRow }> {
  const res = await fetch(`${API_BASE}/api/friends/${friendshipId}/accept`, {
    method: "POST",
    headers: authHeaders(token),
  });
  return handleResponse<{ friendship: FriendshipRow }>(res);
}

/** Decline a friend request. */
export async function declineRequest(friendshipId: string, token: string): Promise<{ friendship: FriendshipRow }> {
  const res = await fetch(`${API_BASE}/api/friends/${friendshipId}/decline`, {
    method: "POST",
    headers: authHeaders(token),
  });
  return handleResponse<{ friendship: FriendshipRow }>(res);
}

/** Remove a friend (deletes the friendship and all messages). */
export async function removeFriend(friendshipId: string, token: string): Promise<void> {
  const res = await fetch(`${API_BASE}/api/friends/${friendshipId}`, {
    method: "DELETE",
    headers: authHeaders(token),
  });
  await handleResponse<unknown>(res);
}

/**
 * Ping the server to signal the user is actively viewing this chat.
 * Called every 20 s while the Chat component is mounted.
 * Fire-and-forget — failures are silently swallowed.
 */
export function pingChatPresence(friendshipId: string, token: string): void {
  fetch(`${API_BASE}/api/friends/${friendshipId}/presence`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
  }).catch(() => {});
}

/** Fetch the last-hour messages for a friendship. */
export async function getMessages(
  friendshipId: string,
  token: string
): Promise<{ messages: PeerMessage[]; ttlMs: number }> {
  const res = await fetch(`${API_BASE}/api/friends/${friendshipId}/messages`, {
    headers: authHeaders(token),
  });
  return handleResponse<{ messages: PeerMessage[]; ttlMs: number }>(res);
}

/** Hide selected messages for the current user or remove them from both chats. */
export async function deleteMessages(
  friendshipId: string,
  messageIds: string[],
  mode: "me" | "everyone",
  token: string,
): Promise<{ deletedCount: number; mode: "me" | "everyone" }> {
  const res = await fetch(`${API_BASE}/api/friends/${friendshipId}/messages/delete`, {
    method: "POST",
    headers: authHeaders(token),
    body: JSON.stringify({ messageIds, mode }),
  });
  return handleResponse<{ deletedCount: number; mode: "me" | "everyone" }>(res);
}

/** Send a text message in a friendship chat. */
export async function sendMessage(
  friendshipId: string,
  body: string,
  token: string
): Promise<{ message: PeerMessage }> {
  const res = await fetch(`${API_BASE}/api/friends/${friendshipId}/messages`, {
    method: "POST",
    headers: authHeaders(token),
    body: JSON.stringify({ body }),
  });
  return handleResponse<{ message: PeerMessage }>(res);
}

export interface UploadProgress {
  phase: "reading" | "uploading";
  percent: number;
}

/**
 * Upload a media file (image or video) through the API server.
 * Reads the File as base64, then POSTs to /api/friends/:id/messages.
 * Calls onProgress during the read phase.
 */
export async function sendMediaMessage(
  friendshipId: string,
  file: File,
  token: string,
  caption: string,
  onProgress: (p: UploadProgress) => void
): Promise<{ message: PeerMessage }> {
  // Step 1: Read file as base64 data URL
  onProgress({ phase: "reading", percent: 0 });
  const base64 = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onprogress = (e) => {
      if (e.lengthComputable) {
        onProgress({ phase: "reading", percent: Math.round((e.loaded / e.total) * 50) });
      }
    };
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error("File read failed"));
    reader.readAsDataURL(file);
  });

  // Step 2: POST to API (upload + save message in one call)
  onProgress({ phase: "uploading", percent: 50 });

  const res = await fetch(`${API_BASE}/api/friends/${friendshipId}/messages`, {
    method: "POST",
    headers: authHeaders(token),
    body: JSON.stringify({
      base64,
      mimeType: file.type,
      body: caption || "",
    }),
  });

  onProgress({ phase: "uploading", percent: 100 });
  return handleResponse<{ message: PeerMessage }>(res);
}

/** Resolve the serving URL for a media message (prepends API_BASE for relative URLs). */
export function mediaUrl(imageUrl: string): string {
  if (imageUrl.startsWith("http")) return imageUrl;
  return `${API_BASE}${imageUrl}`;
}

/**
 * Download a chat attachment with the user's auth header and expose it as a
 * browser-local object URL. A plain <img src> cannot send Authorization, so
 * loading the protected media proxy directly in an image/video element would
 * result in a 401 response.
 */
export async function fetchMediaObjectUrl(imageUrl: string, token: string): Promise<string> {
  const res = await fetch(mediaUrl(imageUrl), {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) {
    throw new Error(`Media request failed: HTTP ${res.status}`);
  }
  return URL.createObjectURL(await res.blob());
}
