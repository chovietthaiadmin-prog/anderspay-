import { createContext, useContext, useState, useEffect } from "react";
import { setAuthTokenGetter } from "@workspace/api-client-react";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

export interface AuthUser {
  id: string;
  name: string;
  nameUpdatedAt?: string | null;
  phone?: string;
  email?: string;
  emailVerified?: boolean;
  nickname?: string;
  avatarUrl?: string;
  dob?: string | null;
  uid?: string | null;
  createdAt?: string;
  isAdmin?: boolean;
  usdtBalance?: number;
  thbBalance?: number;
  // Telegram one-click login fields. Present once the user has signed
  // in (or registered) via the Telegram Login Widget. Account is keyed
  // by `telegramId` server-side so a username rename never breaks the
  // link.
  telegramId?: string;
  /** Present for Telegram Login accounts; never rendered as a chat target. */
  telegramChatId?: string;
  telegramUsername?: string;
  telegramFirstName?: string;
  telegramPhotoUrl?: string;
}

// Payload returned by the Telegram Login Widget callback. Forwarded
// verbatim to the server, which validates the HMAC `hash` against the
// bot token.
export interface TelegramLoginPayload {
  id: number;
  first_name?: string;
  last_name?: string;
  username?: string;
  photo_url?: string;
  auth_date: number;
  hash: string;
}

interface AuthContextValue {
  user: AuthUser | null;
  token: string | null;
  loginWithTelegram: (payload: TelegramLoginPayload, referralCode?: string) => Promise<void>;
  emailSendOtp: (email: string) => Promise<{ ok: boolean; exists: boolean; retryAfterSec?: number }>;
  emailVerify: (email: string, otp: string, referralCode?: string) => Promise<void>;
  emailChangeSendOtp: (email: string) => Promise<void>;
  emailChangeVerify: (email: string, otp: string) => Promise<void>;
  updateName: (name: string) => Promise<void>;
  updateNickname: (nickname: string) => Promise<void>;
  updateAvatar: (file: File) => Promise<void>;
  updateEmail: (email: string) => Promise<void>;
  updateDob: (dob: string | null) => Promise<void>;
  setUid: (uid: string) => Promise<void>;
  logout: () => void;
  requestDeleteOtp: () => Promise<void>;
  deleteAccount: (otp: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(() => {
    const saved = localStorage.getItem("ap-user");
    return saved ? JSON.parse(saved) : null;
  });

  const [token, setToken] = useState<string | null>(() => {
    return localStorage.getItem("ap-token");
  });

  useEffect(() => {
    setAuthTokenGetter(() => token);
    return () => setAuthTokenGetter(null);
  }, [token]);

  // Single-device login: if any /api/* call returns 401 while we hold a
  // token, the server has invalidated this session (e.g. user logged in
  // on another device). Drop the local session so the UI bounces to login.
  useEffect(() => {
    if (!token) return;
    const orig = window.fetch.bind(window);
    const wrapped: typeof window.fetch = async (input, init) => {
      const res = await orig(input, init);
      if (res.status === 401) {
        const url =
          typeof input === "string"
            ? input
            : input instanceof URL
              ? input.toString()
              : input.url;
        if (url.includes("/api/") && !url.includes("/api/auth/")) {
          setUser(null);
          setToken(null);
          localStorage.removeItem("ap-user");
          localStorage.removeItem("ap-token");
        }
      }
      return res;
    };
    window.fetch = wrapped;
    return () => {
      window.fetch = orig;
    };
  }, [token]);

  const persist = (u: AuthUser, t: string) => {
    setUser(u);
    setToken(t);
    localStorage.setItem("ap-user", JSON.stringify(u));
    localStorage.setItem("ap-token", t);
  };

  // On app load (and whenever the token changes), re-fetch the user so a
  // freshly computed isAdmin is applied. This is how a newly-promoted
  // admin instantly gains full admin access — and loses the customer-only
  // screens — without having to log out and back in. A 401 here means the
  // session is gone, so we drop it.
  useEffect(() => {
    if (!token) return;
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(`${BASE}/api/auth/me`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (cancelled) return;
        if (res.status === 401) {
          setUser(null);
          setToken(null);
          localStorage.removeItem("ap-user");
          localStorage.removeItem("ap-token");
          return;
        }
        const data = (await res.json().catch(() => ({}))) as { ok?: boolean; user?: AuthUser };
        if (!cancelled && res.ok && data.user) {
          setUser(data.user);
          localStorage.setItem("ap-user", JSON.stringify(data.user));
        }
      } catch {
        // Offline / transient: keep the cached user as-is.
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  const loginWithTelegram = async (payload: TelegramLoginPayload, referralCode?: string) => {
    const res = await fetch(`${BASE}/api/auth/telegram`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...payload, ...(referralCode ? { referralCode } : {}) }),
    });
    const data = (await res.json().catch(() => ({}))) as {
      ok?: boolean; user?: AuthUser; token?: string; error?: string; message?: string;
    };
    if (!res.ok || !data.user || !data.token) {
      const e = new Error(data.message ?? data.error ?? "telegram_auth_failed");
      e.name = data.error ?? "telegram_auth_failed";
      throw e;
    }
    persist(data.user, data.token);
  };

  const updateName = async (name: string) => {
    if (!user || !token) throw new Error("not_logged_in");
    const res = await fetch(`${BASE}/api/profile/name`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
      body: JSON.stringify({ name }),
    });
    const data = await res.json() as { ok?: boolean; name?: string; nameUpdatedAt?: string | null; error?: string; message?: string };
    if (!res.ok) {
      const e = new Error(data.message ?? data.error ?? "name_failed");
      e.name = data.error ?? "name_failed";
      throw e;
    }
    persist({ ...user, name: data.name ?? user.name, nameUpdatedAt: data.nameUpdatedAt ?? null }, token);
  };

  const updateNickname = async (nickname: string) => {
    if (!user || !token) throw new Error("not_logged_in");
    const res = await fetch(`${BASE}/api/profile/nickname`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
      body: JSON.stringify({ nickname }),
    });
    const data = await res.json() as { ok?: boolean; nickname?: string; error?: string };
    if (!res.ok) throw new Error(data.error ?? "update_failed");
    persist({ ...user, nickname: data.nickname }, token);
  };

  const updateEmail = async (email: string) => {
    if (!user || !token) throw new Error("not_logged_in");
    const res = await fetch(`${BASE}/api/profile/email`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
      body: JSON.stringify({ email }),
    });
    const data = await res.json() as { ok?: boolean; email?: string; error?: string };
    if (!res.ok) throw new Error(data.error ?? "update_failed");
    persist({ ...user, email: data.email }, token);
  };

  const updateAvatar = async (file: File) => {
    if (!user || !token) throw new Error("not_logged_in");
    const form = new FormData();
    form.append("avatar", file);
    const res = await fetch(`${BASE}/api/profile/avatar`, {
      method: "POST",
      headers: { "Authorization": `Bearer ${token}` },
      body: form,
    });
    const data = await res.json() as { ok?: boolean; avatarUrl?: string; error?: string };
    if (!res.ok) throw new Error(data.error ?? "upload_failed");
    persist({ ...user, avatarUrl: data.avatarUrl }, token);
  };

  const updateDob = async (dob: string | null) => {
    if (!user || !token) throw new Error("not_logged_in");
    const res = await fetch(`${BASE}/api/profile/dob`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
      body: JSON.stringify({ dob }),
    });
    const data = await res.json() as { ok?: boolean; dob?: string | null; error?: string };
    if (!res.ok) throw new Error(data.error ?? "update_failed");
    persist({ ...user, dob: data.dob ?? null }, token);
  };

  const setUid = async (uid: string) => {
    if (!user || !token) throw new Error("not_logged_in");
    const res = await fetch(`${BASE}/api/profile/uid`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
      body: JSON.stringify({ uid }),
    });
    const data = await res.json() as { ok?: boolean; uid?: string; error?: string };
    if (!res.ok) throw new Error(data.error ?? "uid_failed");
    persist({ ...user, uid: data.uid }, token);
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem("ap-user");
    localStorage.removeItem("ap-token");
  };

  const requestDeleteOtp = async () => {
    if (!token) throw new Error("not_logged_in");
    const res = await fetch(`${BASE}/api/auth/account/delete-otp`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = (await res.json().catch(() => ({}))) as { ok?: boolean; error?: string; message?: string };
    if (!res.ok) {
      const e = new Error(data.message ?? data.error ?? "otp_failed");
      e.name = data.error ?? "otp_failed";
      throw e;
    }
  };

  const deleteAccount = async (otp: string) => {
    if (!token) throw new Error("not_logged_in");
    const res = await fetch(`${BASE}/api/auth/account`, {
      method: "DELETE",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({ otp }),
    });
    const data = (await res.json().catch(() => ({}))) as { ok?: boolean; error?: string; message?: string };
    if (!res.ok) {
      const e = new Error(data.message ?? data.error ?? "delete_failed");
      e.name = data.error ?? "delete_failed";
      throw e;
    }
    logout();
  };

  const emailSendOtp = async (email: string) => {
    const res = await fetch(`${BASE}/api/auth/email/send-otp`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });
    const data = await res.json() as { ok?: boolean; exists?: boolean; retryAfterSec?: number; error?: string; message?: string };
    if (res.status === 429) {
      const e = new Error(data.message ?? "rate_limited");
      e.name = "rate_limited";
      throw e;
    }
    if (!res.ok) throw new Error(data.error ?? "send_otp_failed");
    return { ok: true, exists: data.exists ?? false, retryAfterSec: data.retryAfterSec };
  };

  const emailVerify = async (email: string, otp: string, referralCode?: string) => {
    const res = await fetch(`${BASE}/api/auth/email/verify`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, otp, ...(referralCode ? { referralCode } : {}) }),
    });
    const data = await res.json() as { ok?: boolean; user?: AuthUser; token?: string; error?: string; attemptsLeft?: number; retryAfterSec?: number };
    if (res.status === 423) {
      const e = new Error(data.error ?? "locked");
      e.name = "locked";
      throw e;
    }
    if (!res.ok || !data.user || !data.token) {
      // Carry the server message so the UI can show "expired" vs "wrong code"
      const serverMsg = (data as { message?: string }).message ?? data.error ?? "invalid_otp";
      const e = new Error(serverMsg);
      e.name = data.error ?? "invalid_otp";
      throw e;
    }
    persist(data.user, data.token);
  };

  const emailChangeSendOtp = async (email: string) => {
    if (!token) throw new Error("not_logged_in");
    const res = await fetch(`${BASE}/api/auth/email/change/send-otp`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({ email }),
    });
    const data = await res.json() as { ok?: boolean; error?: string; message?: string; retryAfterSec?: number };
    if (res.status === 429) {
      const e = new Error(data.message ?? "rate_limited");
      e.name = "rate_limited";
      throw e;
    }
    if (!res.ok) throw new Error(data.error ?? "send_otp_failed");
  };

  const emailChangeVerify = async (email: string, otp: string) => {
    if (!user || !token) throw new Error("not_logged_in");
    const res = await fetch(`${BASE}/api/auth/email/change/verify`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({ email, otp }),
    });
    const data = await res.json() as { ok?: boolean; email?: string; emailVerified?: boolean; error?: string; attemptsLeft?: number; retryAfterSec?: number };
    if (res.status === 423) {
      const e = new Error(data.error ?? "locked");
      e.name = "locked";
      throw e;
    }
    if (!res.ok) {
      const e = new Error(data.error ?? "invalid_otp");
      e.name = data.error ?? "invalid_otp";
      throw e;
    }
    persist({ ...user, email: data.email, emailVerified: data.emailVerified }, token);
  };

  return (
    <AuthContext.Provider value={{ user, token, loginWithTelegram, emailSendOtp, emailVerify, emailChangeSendOtp, emailChangeVerify, updateName, updateNickname, updateAvatar, updateEmail, updateDob, setUid, logout, requestDeleteOtp, deleteAccount }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
