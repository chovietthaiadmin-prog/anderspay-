export interface PromPayInfo {
  promptPayId: string;   // raw PromPay ID (phone / national ID)
  displayId: string;     // formatted for display
  amount?: number;       // THB amount if embedded
  merchantName?: string;
  type: "phone" | "national_id" | "unknown";
}

const THAI_QR_AID_PREFIX = "A000000677";
const MERCHANT_ACCOUNT_TAG_START = 26;
const MERCHANT_ACCOUNT_TAG_END = 51;

/** Parse an EMVCo TLV string into a flat map of tag → value */
function parseTlv(data: string): Map<string, string> {
  const map = new Map<string, string>();
  let i = 0;
  while (i < data.length) {
    if (i + 4 > data.length) break;
    const tag = data.slice(i, i + 2);
    const len = parseInt(data.slice(i + 2, i + 4), 10);
    if (isNaN(len)) break;
    const value = data.slice(i + 4, i + 4 + len);
    map.set(tag, value);
    i += 4 + len;
  }
  return map;
}

/**
 * Return the Thai QR account-info block from any EMVCo merchant-account tag.
 *
 * Thai bank apps are allowed to put account data in tags 26–51. In
 * particular, KBank QR codes can include a non-PromptPay account block before
 * the Thai QR block, so looking only at tag 29 or 30 rejects a valid code.
 */
function findThaiQrAccount(root: Map<string, string>): Map<string, string> | null {
  for (let tagNumber = MERCHANT_ACCOUNT_TAG_START; tagNumber <= MERCHANT_ACCOUNT_TAG_END; tagNumber += 1) {
    const tag = tagNumber.toString().padStart(2, "0");
    const value = root.get(tag);
    if (!value) continue;

    const account = parseTlv(value);
    const aid = account.get("00");
    if (aid?.startsWith(THAI_QR_AID_PREFIX)) return account;
  }
  return null;
}

/** Format Thai phone number to readable form */
function formatPhone(raw: string): string {
  // Raw may be: 0066812345678, 66812345678, 0812345678, etc.
  let digits = raw.replace(/\D/g, "");
  if (digits.startsWith("0066")) digits = digits.slice(4);
  if (digits.startsWith("66") && digits.length >= 10) digits = digits.slice(2);
  if (digits.length === 9) digits = "0" + digits;
  // Format: 0XX-XXX-XXXX
  if (digits.length === 10) {
    return `${digits.slice(0, 3)}-${digits.slice(3, 6)}-${digits.slice(6)}`;
  }
  return raw;
}

/** Detect PromPay ID type */
function detectType(id: string): PromPayInfo["type"] {
  const digits = id.replace(/\D/g, "");
  // Thai national ID: exactly 13 digits
  if (/^\d{13}$/.test(digits)) return "national_id";
  // Phone: 9–10 digits after stripping country code
  let phone = digits;
  if (phone.startsWith("0066")) phone = phone.slice(4);
  if (phone.startsWith("66")) phone = phone.slice(2);
  if (/^\d{9,10}$/.test(phone)) return "phone";
  return "unknown";
}

/**
 * Parse a PromPay / Thai QR Payment string (EMVCo format)
 * Returns null if it's not a recognisable PromPay QR.
 *
 * PromPay merchant info is stored in one of EMVCo's merchant-account tags
 * (26–51) and carries a Thai QR AID `A000000677…` in sub-tag 00. Sub-tags
 * carry the actual identifier in one of FOUR slots (per the BOT spec):
 *   01 → Mobile number (e.g. "0066812345678")
 *   02 → National ID / Tax ID (13 digits)
 *   03 → Provider-specific account / reference ID
 *   04 → Bank Account number
 *
 * We accept all Thai QR merchant-account blocks rather than assuming a
 * specific outer tag. This covers PromptPay, Bill Payment and bank-account
 * QR codes emitted by Thai banking apps.
 */
export function parsePromPayQr(raw: string): PromPayInfo | null {
  const root = parseTlv(raw);

  // Must have tag 00 (payload format indicator)
  if (root.get("00") !== "01") return null;

  const sub = findThaiQrAccount(root);
  if (!sub) return null;

  // Pick whichever identifier slot is populated, in priority order.
  let promptPayId: string | undefined;
  let forcedType: PromPayInfo["type"] | undefined;
  if (sub.get("01")) {
    promptPayId = sub.get("01")!;
    // Per the Thai QR specification, sub-tag 01 is always a mobile number.
    // A `0066` country-code prefix makes it 13 digits long, which would
    // otherwise be indistinguishable from a Thai national ID by length alone.
    forcedType = "phone";
  } else if (sub.get("02")) {
    promptPayId = sub.get("02")!;
    forcedType = "national_id";
  } else if (sub.get("03")) {
    // Thai banks can use sub-tag 03 for an account-reference identifier.
    // For example, KBank's official Thai QR Payment account QR uses
    // A000000677010111 + `03 15 004999132637470`. The outer Thai QR AID,
    // rather than the nested field number alone, determines whether this is
    // a supported PromptPay / Thai QR payment. Native wallet QR codes have a
    // different AID and are rejected by findThaiQrAccount().
    promptPayId = sub.get("03")!;
    forcedType = "unknown";
  } else if (sub.get("04")) {
    promptPayId = sub.get("04")!;
    forcedType = "unknown";
  }

  const amount = root.has("54") ? parseFloat(root.get("54")!) : undefined;
  // Merchant name lives in tag 59; some Thai QRs only fill tag 51 ("Bangkok"
  // city) and skip 59 — we tolerate either being absent.
  const merchantName = root.get("59");

  // Some bank-account QR codes only expose an opaque Thai QR merchant block,
  // with no transferable phone / national-ID field. They are still safe to
  // accept: the original QR payload is retained by the order flow and sent to
  // the operator for scan-to-pay. Use the payload as an opaque form value so
  // validation succeeds, but keep the user-facing label short.
  if (!promptPayId) {
    return {
      promptPayId: raw,
      displayId: merchantName?.trim() || "Thai QR Payment",
      amount: amount && !isNaN(amount) ? amount : undefined,
      merchantName: merchantName ?? undefined,
      type: "unknown",
    };
  }

  const type = forcedType ?? detectType(promptPayId);

  let displayId = promptPayId;
  if (type === "phone") displayId = formatPhone(promptPayId);

  return {
    promptPayId,
    displayId,
    amount: amount && !isNaN(amount) ? amount : undefined,
    merchantName: merchantName ?? undefined,
    type,
  };
}
