const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

export interface SupportMessage {
  id: string;
  userId: string;
  fromAdmin: boolean;
  body: string;
  imageUrl?: string | null;
  createdAt: string;
  readByUser: boolean;
  readByAdmin: boolean;
}

export interface SupportThread {
  userId: string;
  name: string | null;
  phone: string | null;
  nickname: string | null;
  avatarUrl: string | null;
  lastBody: string;
  lastAt: string;
  lastFromAdmin: boolean;
  unread: number;
}

function authHeaders(token: string, json = false): Record<string, string> {
  const h: Record<string, string> = { Authorization: `Bearer ${token}` };
  if (json) h["Content-Type"] = "application/json";
  return h;
}

async function jsonOrThrow(res: Response): Promise<unknown> {
  if (!res.ok) throw new Error(`http_${res.status}`);
  return res.json();
}

// Authenticated user
export async function getMyMessages(token: string): Promise<SupportMessage[]> {
  const r = await fetch(`${BASE}/api/support/messages`, { headers: authHeaders(token) });
  const d = (await jsonOrThrow(r)) as { messages: SupportMessage[] };
  return d.messages;
}
export async function sendMyMessage(token: string, body: string): Promise<SupportMessage> {
  const r = await fetch(`${BASE}/api/support/messages`, {
    method: "POST",
    headers: authHeaders(token, true),
    body: JSON.stringify({ body }),
  });
  const d = (await jsonOrThrow(r)) as { message: SupportMessage };
  return d.message;
}
export async function sendMyImage(
  token: string,
  file: File,
  caption = "",
): Promise<SupportMessage> {
  const fd = new FormData();
  fd.append("image", file);
  if (caption) fd.append("body", caption);
  const r = await fetch(`${BASE}/api/support/messages/image`, {
    method: "POST",
    // Don't set Content-Type — browser adds the multipart boundary.
    headers: authHeaders(token, false),
    body: fd,
  });
  const d = (await jsonOrThrow(r)) as { message: SupportMessage };
  return d.message;
}
export async function getMyUnread(token: string): Promise<number> {
  try {
    const r = await fetch(`${BASE}/api/support/unread`, { headers: authHeaders(token) });
    const d = (await jsonOrThrow(r)) as { unread: number };
    return d.unread;
  } catch {
    return 0;
  }
}

// Admin (always requires JWT)
function adminHeaders(token: string, json = false): Record<string, string> {
  const h: Record<string, string> = { Authorization: `Bearer ${token}` };
  if (json) h["Content-Type"] = "application/json";
  return h;
}
export async function getThreads(token: string): Promise<SupportThread[]> {
  const r = await fetch(`${BASE}/api/support/threads`, { headers: adminHeaders(token) });
  const d = (await jsonOrThrow(r)) as { threads: SupportThread[] };
  return d.threads;
}
export async function getThread(token: string, userId: string): Promise<SupportMessage[]> {
  const r = await fetch(`${BASE}/api/support/threads/${encodeURIComponent(userId)}`, { headers: adminHeaders(token) });
  const d = (await jsonOrThrow(r)) as { messages: SupportMessage[] };
  return d.messages;
}
export async function sendThread(token: string, userId: string, body: string): Promise<SupportMessage> {
  const r = await fetch(`${BASE}/api/support/threads/${encodeURIComponent(userId)}`, {
    method: "POST",
    headers: adminHeaders(token, true),
    body: JSON.stringify({ body }),
  });
  const d = (await jsonOrThrow(r)) as { message: SupportMessage };
  return d.message;
}
export async function sendThreadImage(
  token: string,
  userId: string,
  file: File,
  caption = "",
): Promise<SupportMessage> {
  const fd = new FormData();
  fd.append("image", file);
  if (caption) fd.append("body", caption);
  const r = await fetch(`${BASE}/api/support/threads/${encodeURIComponent(userId)}/image`, {
    method: "POST",
    headers: adminHeaders(token, false),
    body: fd,
  });
  const d = (await jsonOrThrow(r)) as { message: SupportMessage };
  return d.message;
}
export async function deleteThread(token: string, userId: string): Promise<number> {
  const r = await fetch(`${BASE}/api/support/threads/${encodeURIComponent(userId)}`, {
    method: "DELETE",
    headers: adminHeaders(token),
  });
  const d = (await jsonOrThrow(r)) as { deleted: number };
  return d.deleted;
}
export async function getAdminUnread(token: string): Promise<number> {
  try {
    const r = await fetch(`${BASE}/api/support/admin/unread-total`, { headers: adminHeaders(token) });
    const d = (await jsonOrThrow(r)) as { unread: number };
    return d.unread;
  } catch {
    return 0;
  }
}

// ── Presence reporting ────────────────────────────────────────────────────

/**
 * Report whether this participant is actively viewing the support chat.
 * Called on mount/unmount, tab visibility change, and heartbeat (every 20 s).
 *
 * @param token        authenticated user's JWT
 * @param conversationOpen  true while the chat modal is open and tab is visible
 * @param activeConversationId  admin only: userId of the thread being viewed
 */
export async function reportPresence(
  token: string,
  conversationOpen: boolean,
  activeConversationId?: string | null,
): Promise<void> {
  try {
    await fetch(`${BASE}/api/support/presence`, {
      method: "POST",
      headers: authHeaders(token, true),
      body: JSON.stringify({
        conversationOpen,
        activeConversationId: activeConversationId ?? null,
      }),
    });
  } catch {
    // ignore — presence is best-effort
  }
}
