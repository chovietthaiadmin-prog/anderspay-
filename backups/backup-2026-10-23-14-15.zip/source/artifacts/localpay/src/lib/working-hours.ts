// Working hours: 08:00 – 23:00 Asia/Ho_Chi_Minh (Vietnam time — the
// operator team is based in Vietnam). Vietnam (ICT, UTC+7) shares
// the same wall-clock offset as Bangkok year-round (no DST in
// either zone), so settlement timing relative to the THB bank day
// is unchanged. Outside this window we still allow order creation
// but warn the user that processing may be slower and may have to
// wait until 08:00 the next morning.
//
// All checks key off Asia/Ho_Chi_Minh using `Intl.DateTimeFormat`
// so the result is identical regardless of the visitor's device
// timezone.
export const WORKING_HOURS_START = 8;
export const WORKING_HOURS_END = 23;
export const WORKING_HOURS_TZ = "Asia/Ho_Chi_Minh";

const HOUR_FORMATTER = new Intl.DateTimeFormat("en-US", {
  hour: "numeric",
  hour12: false,
  timeZone: WORKING_HOURS_TZ,
});

const HOUR_MIN_FORMATTER = new Intl.DateTimeFormat("en-GB", {
  hour: "2-digit",
  minute: "2-digit",
  hour12: false,
  timeZone: WORKING_HOURS_TZ,
});

/** Current hour (0–23) in the working-hours timezone. */
export function currentHour(now: Date = new Date()): number {
  // `Intl` returns "24" at midnight on some engines — normalize.
  const raw = parseInt(HOUR_FORMATTER.format(now), 10);
  return Number.isFinite(raw) ? raw % 24 : new Date().getHours();
}

/** True when the current time is inside [START, END). */
export function isWithinWorkingHours(now: Date = new Date()): boolean {
  const h = currentHour(now);
  return h >= WORKING_HOURS_START && h < WORKING_HOURS_END;
}

/** Pretty "HH:MM" (Bangkok) — used in the status banner subtitle. */
export function formatBangkokTime(now: Date = new Date()): string {
  return HOUR_MIN_FORMATTER.format(now);
}

/** Stable display range, e.g. "08:00 – 23:00". */
export const WORKING_HOURS_RANGE = `${String(WORKING_HOURS_START).padStart(2, "0")}:00 – ${String(WORKING_HOURS_END).padStart(2, "0")}:00`;
