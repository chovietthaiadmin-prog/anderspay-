import { createContext } from "react";
import type { Translations, Lang } from "./translations";

export interface LangContextValue {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: Translations;
}

// Created once at module init — never re-created, so HMR on i18n.tsx
// or translations.ts will never break existing consumers.
export const LangContext = createContext<LangContextValue | null>(null);
