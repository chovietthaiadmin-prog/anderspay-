import { useEffect, useState } from "react";

export type InstallPlatform = "android-chrome" | "ios-safari" | "ios-chrome" | "other" | null;

interface InstallPromptState {
  platform: InstallPlatform;
  canInstall: boolean;
  isInstalled: boolean;
  triggerInstall: () => Promise<void>;
  triggerInstallReady: boolean;
}

// Capture the beforeinstallprompt event as early as possible
let _deferredPrompt: BeforeInstallPromptEvent | null = null;

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

if (typeof window !== "undefined") {
  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    _deferredPrompt = e as BeforeInstallPromptEvent;
  });
}

function detectPlatform(): InstallPlatform {
  const ua = navigator.userAgent;
  const isIos = /iphone|ipad|ipod/i.test(ua);
  const isSafari = /safari/i.test(ua) && !/chrome|crios|fxios/i.test(ua);
  // On iOS, Chrome reports itself as "CriOS" in the UA string.
  const isIosChrome = /crios/i.test(ua);
  const isAndroid = /android/i.test(ua);
  const isChrome = /chrome|crios/i.test(ua) && !/edge|opr\//i.test(ua);

  if (isIos && isSafari) return "ios-safari";
  if (isIos && isIosChrome) return "ios-chrome";
  if (isAndroid && isChrome) return "android-chrome";
  return "other";
}

function isAlreadyInstalled(): boolean {
  // iOS standalone
  if ("standalone" in navigator && (navigator as { standalone?: boolean }).standalone === true) return true;
  // Android / desktop PWA
  if (window.matchMedia("(display-mode: standalone)").matches) return true;
  return false;
}

export function useInstallPrompt(): InstallPromptState {
  const [platform] = useState<InstallPlatform>(detectPlatform);
  const [installed] = useState(isAlreadyInstalled);
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(_deferredPrompt);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      const bip = e as BeforeInstallPromptEvent;
      _deferredPrompt = bip;
      setDeferredPrompt(bip);
    };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const triggerInstall = async () => {
    if (!deferredPrompt) return;
    await deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    _deferredPrompt = null;
    setDeferredPrompt(null);
  };

  // Show the install banner whenever:
  //  - the browser has surfaced a real beforeinstallprompt event
  //    (Chrome/Edge on Android & desktop, Brave, …), OR
  //  - we detect iOS Safari (manual "Add to Home Screen" steps), OR
  //  - we detect any other browser/OS — fall back to a generic
  //    "use your browser menu → Install / Add to Home Screen" hint so
  //    new users always see SOMETHING reminding them to install.
  const canInstall = !installed;

  return {
    platform,
    canInstall,
    isInstalled: installed,
    triggerInstall,
    triggerInstallReady: deferredPrompt !== null,
  };
}
