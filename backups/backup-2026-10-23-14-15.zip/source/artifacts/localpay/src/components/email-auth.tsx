import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { Mail, Send, UserPlus, AlertTriangle } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { useLang } from "@/lib/use-lang";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from "@/components/ui/input-otp";

interface EmailAuthProps {
  onSuccess: () => void;
  onBack: () => void;
}

export default function EmailAuth({ onSuccess, onBack }: EmailAuthProps) {
  const { emailSendOtp, emailVerify } = useAuth();
  const { t } = useLang();
  const at = t.auth;

  const [step, setStep] = useState<"email" | "otp">("email");
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [referralCode, setReferralCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [resendCooldown, setResendCooldown] = useState(0);
  const cooldownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Prefill referral code from localStorage if present
  useEffect(() => {
    const saved = localStorage.getItem("ap-ref-code");
    if (saved) setReferralCode(saved);
  }, []);

  useEffect(() => {
    return () => {
      if (cooldownRef.current) clearInterval(cooldownRef.current);
    };
  }, []);

  const startCooldown = () => {
    setResendCooldown(60);
    cooldownRef.current = setInterval(() => {
      setResendCooldown((s) => {
        if (s <= 1) {
          clearInterval(cooldownRef.current!);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
  };

  const handleSendOtp = async () => {
    const trimmed = email.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) {
      setError(at.emailInvalid);
      return;
    }
    setLoading(true);
    setError("");
    try {
      await emailSendOtp(trimmed);
      setEmail(trimmed);
      setStep("otp");
      startCooldown();
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : "";
      setError(msg || at.registerError);
    } finally {
      setLoading(false);
    }
  };

  // Accept the OTP value directly to avoid stale-closure issues when called
  // from the auto-submit setTimeout (React state may not yet reflect the
  // latest value at the time the timeout callback fires).
  const submitOtp = async (otpValue: string) => {
    if (otpValue.length !== 6) {
      setError(at.emailOtpInvalid);
      return;
    }
    setLoading(true);
    setError("");
    try {
      await emailVerify(email, otpValue, referralCode || undefined);
      onSuccess();
    } catch (e: unknown) {
      const name = e instanceof Error ? e.name : "";
      const msg = e instanceof Error ? e.message : "";
      if (name === "locked" || msg.includes("locked")) {
        setError(at.emailOtpLocked);
      } else if (name === "invalid_referral_code") {
        setError(t.referral.invalidCodeServer);
      } else if (name === "expired_otp" || msg.includes("hết hạn")) {
        setError(at.emailOtpExpired);
      } else {
        setError(at.emailOtpInvalid);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = () => submitOtp(otp);

  const handleResend = async () => {
    if (resendCooldown > 0 || loading) return;
    setLoading(true);
    setError("");
    setOtp("");
    try {
      await emailSendOtp(email);
      startCooldown();
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : "";
      setError(msg || at.registerError);
    } finally {
      setLoading(false);
    }
  };

  if (step === "otp") {
    return (
      <motion.div
        key="email-otp"
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="flex flex-col gap-3"
      >
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
            <Mail className="w-4 h-4 text-primary" />
          </div>
          <div>
            <h2 className="font-bold text-base">{at.emailOtpTitle}</h2>
            <p className="text-xs text-muted-foreground truncate">{email}</p>
          </div>
        </div>

        <p className="text-xs text-muted-foreground">{at.emailOtpHint}</p>

        <div className="flex items-start gap-2 rounded-lg border border-yellow-500/30 bg-yellow-500/10 px-3 py-2">
          <AlertTriangle className="w-3.5 h-3.5 text-yellow-500 shrink-0 mt-0.5" />
          <p className="text-[11px] leading-snug text-yellow-500/90">{at.emailSpamNote}</p>
        </div>

        <div className="flex flex-col gap-2 items-center">
          <InputOTP
            maxLength={6}
            value={otp}
            onChange={(value) => {
              setOtp(value);
              setError("");
              // Auto-submit when 6th digit is entered
              if (value.length === 6) {
                // Use `value` directly (not `otp` state) to avoid the
                // stale-closure issue — state update is async in React.
                setTimeout(() => submitOtp(value), 100);
              }
            }}
            disabled={loading}
          >
            <InputOTPGroup>
              <InputOTPSlot index={0} />
              <InputOTPSlot index={1} />
              <InputOTPSlot index={2} />
              <InputOTPSlot index={3} />
              <InputOTPSlot index={4} />
              <InputOTPSlot index={5} />
            </InputOTPGroup>
          </InputOTP>
        </div>

        {error && (
          <p className="text-xs text-red-400 text-center bg-red-500/10 py-2 px-3 rounded-lg">{error}</p>
        )}

        <Button
          className="w-full h-10 font-bold gap-2 text-sm"
          onClick={handleVerifyOtp}
          disabled={loading || otp.length !== 6}
        >
          <Send className="w-3.5 h-3.5" />
          {loading ? at.emailVerifying : at.otpVerify}
        </Button>

        <div className="flex items-center justify-between text-xs">
          <button
            onClick={() => {
              setStep("email");
              setOtp("");
              setError("");
            }}
            className="text-muted-foreground hover:text-primary transition-colors"
          >
            {at.backToLogin}
          </button>
          <button
            onClick={handleResend}
            disabled={resendCooldown > 0 || loading}
            className="font-medium transition-colors disabled:opacity-40 text-accent hover:text-accent/80"
          >
            {resendCooldown > 0
              ? at.emailResendCountdown.replace("{seconds}", String(resendCooldown))
              : at.emailResend}
          </button>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      key="email-form"
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      className="flex flex-col gap-3"
    >
      <div className="flex items-center gap-2">
        <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <Mail className="w-4 h-4 text-primary" />
        </div>
        <div>
          <h2 className="font-bold text-base">{at.continueWithEmail}</h2>
          <p className="text-xs text-muted-foreground">{at.emailOtpHint}</p>
        </div>
      </div>

      <div className="relative">
        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
        <Input
          type="email"
          inputMode="email"
          placeholder={at.emailPlaceholder}
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="pl-9 bg-input border-border h-11 text-sm"
          onKeyDown={(e) => e.key === "Enter" && handleSendOtp()}
          autoFocus
        />
      </div>

      <div className="flex flex-col gap-1">
        <div className="relative">
          <UserPlus className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            type="text"
            inputMode="numeric"
            placeholder={t.referral.registerPlaceholder}
            value={referralCode}
            onChange={(e) => setReferralCode(e.target.value.replace(/\D/g, "").slice(0, 9))}
            maxLength={9}
            className="pl-9 bg-input border-border h-10 text-sm font-mono tracking-wider"
            onKeyDown={(e) => e.key === "Enter" && handleSendOtp()}
          />
        </div>
        <p className="text-[10px] text-muted-foreground ml-1">{t.referral.registerHint}</p>
      </div>

      {error && (
        <p className="text-xs text-red-400 text-center bg-red-500/10 py-1.5 px-3 rounded-lg">{error}</p>
      )}

      <Button
        className="w-full h-10 font-bold gap-2 text-sm"
        onClick={handleSendOtp}
        disabled={loading}
      >
        <Send className="w-3.5 h-3.5" />
          {loading ? at.emailSendingOtp : at.sendOtpBtn}
      </Button>

      <button
        onClick={onBack}
        className="text-center text-xs text-muted-foreground hover:text-primary transition-colors"
      >
        {at.backToLogin}
      </button>
    </motion.div>
  );
}
