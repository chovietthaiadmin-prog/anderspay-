import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, X, ArrowLeft, MessageCircle, Inbox, Paperclip, Trash2 } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { useLang } from "@/lib/use-lang";
import InlineAuth from "@/components/inline-auth";
import {
  getMyMessages,
  sendMyMessage,
  sendMyImage,
  getThreads,
  getThread,
  sendThread,
  sendThreadImage,
  deleteThread,
  reportPresence,
  type SupportMessage,
  type SupportThread,
} from "@/lib/support-chat";

const MAX_IMAGE_BYTES = 2 * 1024 * 1024;
const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif"];

interface Props {
  open: boolean;
  onClose: () => void;
  /** Admin only: jump straight into this user's thread on open. */
  initialUserId?: string;
  initialUserName?: string;
}

export default function SupportChatModal({ open, onClose, initialUserId, initialUserName }: Props) {
  const { user, token } = useAuth();
  if (!open) return null;
  const isAdmin = !!user?.isAdmin && !!token;
  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[200] bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ y: 40, scale: 0.98 }}
          animate={{ y: 0, scale: 1 }}
          exit={{ y: 40, scale: 0.98 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          onClick={(e) => e.stopPropagation()}
          className="bg-card border border-border rounded-t-2xl sm:rounded-2xl w-full max-w-md h-[85vh] sm:h-[640px] flex flex-col overflow-hidden"
        >
          {isAdmin
            ? <AdminInbox onClose={onClose} initialUserId={initialUserId} initialUserName={initialUserName} />
            : user && token
              ? <UserChat onClose={onClose} token={token} userId={user.id} />
              : <GuestChat onClose={onClose} />}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

function GuestChat({ onClose }: { onClose: () => void }) {
  const { t, lang } = useLang();
  return (
    <>
      <Header title={t.support.messagesAdmin} subtitle={t.support.messagesDesc} onClose={onClose} />
      <div className="flex-1 overflow-y-auto p-4 flex flex-col justify-center gap-3">
        <p className="text-sm text-center text-muted-foreground">
          {lang === "vi"
            ? "Đăng nhập để xem và nhắn tin với bộ phận hỗ trợ."
            : "Sign in to view and message support."}
        </p>
        <InlineAuth />
      </div>
    </>
  );
}

function Header({
  title,
  subtitle,
  onClose,
  onBack,
  onDelete,
  deleteLabel,
}: {
  title: string;
  subtitle?: string;
  onClose: () => void;
  onBack?: () => void;
  onDelete?: () => void;
  deleteLabel?: string;
}) {
  return (
    <div className="flex items-center gap-3 px-4 py-3 border-b border-border shrink-0 bg-secondary/30">
      {onBack && (
        <button onClick={onBack} className="w-8 h-8 rounded-full hover:bg-secondary flex items-center justify-center">
          <ArrowLeft className="w-4 h-4" />
        </button>
      )}
      <div className="flex-1 min-w-0">
        <p className="font-bold text-sm truncate">{title}</p>
        {subtitle && <p className="text-xs text-muted-foreground truncate">{subtitle}</p>}
      </div>
      {onDelete && (
        <button
          onClick={onDelete}
          aria-label={deleteLabel}
          title={deleteLabel}
          className="w-8 h-8 rounded-full hover:bg-red-500/15 text-red-400 flex items-center justify-center"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      )}
      <button onClick={onClose} className="w-8 h-8 rounded-full hover:bg-secondary flex items-center justify-center">
        <X className="w-4 h-4" />
      </button>
    </div>
  );
}

function MessageList({ messages, isAdminView }: { messages: SupportMessage[]; isAdminView: boolean }) {
  const { t } = useLang();
  const ts = t.support;
  const scrollRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages.length]);

  if (messages.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center p-6 text-center text-xs text-muted-foreground">
        {ts.messagesEmpty}
      </div>
    );
  }

  return (
    <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 flex flex-col gap-2">
      {messages.map((m) => {
        // For user view: their own messages = right (primary). admin = left.
        // For admin view: admin's outgoing = right (primary). user incoming = left.
        const isMine = isAdminView ? m.fromAdmin : !m.fromAdmin;
        const hasImage = !!m.imageUrl;
        const hasText = !!m.body;
        return (
          <div key={m.id} className={`flex ${isMine ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[78%] rounded-2xl text-sm whitespace-pre-wrap break-words overflow-hidden ${
                isMine
                  ? "bg-primary text-white rounded-br-sm"
                  : "bg-secondary text-foreground rounded-bl-sm"
              } ${hasImage && !hasText ? "p-1" : "px-3 py-2"}`}
            >
              {hasImage && (
                <a
                  href={m.imageUrl ?? "#"}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block"
                >
                  <img
                    src={m.imageUrl ?? ""}
                    alt=""
                    className={`max-h-64 w-full object-cover rounded-xl ${hasText ? "mb-2" : ""}`}
                    loading="lazy"
                  />
                </a>
              )}
              {hasText && <div>{m.body}</div>}
              <div
                className={`text-[10px] opacity-60 ${
                  isMine ? "text-white" : "text-muted-foreground"
                } ${hasImage && !hasText ? "px-2 pb-1 pt-1" : "mt-1"}`}
              >
                {new Date(m.createdAt).toLocaleString([], { hour: "2-digit", minute: "2-digit", day: "2-digit", month: "2-digit" })}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function Composer({
  onSend,
  onSendImage,
  placeholder,
  disabled,
}: {
  onSend: (text: string) => Promise<void>;
  onSendImage: (file: File, caption: string) => Promise<void>;
  placeholder: string;
  disabled?: boolean;
}) {
  const { t } = useLang();
  const ts = t.support;
  const [val, setVal] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const submit = async () => {
    const trimmed = val.trim();
    if (!trimmed) return;
    setBusy(true);
    setError("");
    try {
      await onSend(trimmed);
      setVal("");
    } finally {
      setBusy(false);
    }
  };

  const handlePick = () => {
    if (busy || disabled) return;
    setError("");
    fileRef.current?.click();
  };

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    // Always reset the input so picking the same file twice still fires.
    e.target.value = "";
    if (!file) return;
    if (!ACCEPTED_IMAGE_TYPES.includes(file.type)) {
      setError(ts.messagesImageInvalid);
      return;
    }
    if (file.size > MAX_IMAGE_BYTES) {
      setError(ts.messagesImageTooLarge);
      return;
    }
    setBusy(true);
    setError("");
    try {
      await onSendImage(file, val.trim());
      setVal("");
    } catch {
      setError(ts.messagesImageFailed);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="border-t border-border shrink-0 bg-card">
      {error && (
        <div className="px-3 pt-2 text-[11px] text-red-400">{error}</div>
      )}
      <div className="p-3 flex gap-2 items-end">
        <input
          ref={fileRef}
          type="file"
          accept={ACCEPTED_IMAGE_TYPES.join(",")}
          className="hidden"
          onChange={handleFile}
        />
        <button
          type="button"
          onClick={handlePick}
          disabled={busy || disabled}
          className="w-10 h-10 rounded-full bg-secondary/60 text-muted-foreground hover:text-foreground hover:bg-secondary flex items-center justify-center disabled:opacity-40 shrink-0"
          aria-label={ts.messagesAttach}
          title={ts.messagesAttach}
        >
          <Paperclip className="w-4 h-4" />
        </button>
        <textarea
          value={val}
          onChange={(e) => setVal(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              void submit();
            }
          }}
          placeholder={placeholder}
          rows={1}
          disabled={disabled || busy}
          className="flex-1 resize-none bg-secondary/50 rounded-xl px-3 py-2 text-sm border border-border focus:outline-none focus:border-primary/50 max-h-32"
        />
        <button
          onClick={submit}
          disabled={!val.trim() || busy || disabled}
          className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center disabled:opacity-40 shrink-0"
          aria-label={ts.messagesSend}
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

function UserChat({ onClose, token, userId }: { onClose: () => void; token: string; userId: string }) {
  const { t } = useLang();
  const ts = t.support;
  const [messages, setMessages] = useState<SupportMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const refresh = async () => {
    try {
      const m = await getMyMessages(token);
      setMessages(m);
      window.dispatchEvent(new Event("support-unread-changed"));
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void refresh();
    const t = setInterval(() => { void refresh(); }, 5000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  // ── Presence reporting ─────────────────────────────────────────────
  // Tell the server we are actively watching this chat so Telegram
  // notifications are suppressed while we're here. Heartbeat every 20 s
  // keeps the 45-second server-side TTL alive.
  useEffect(() => {
    const sendPresence = (open: boolean) => {
      void reportPresence(token, open);
    };
    // Initial report (respect current tab visibility)
    sendPresence(!document.hidden);

    const onVisibility = () => sendPresence(!document.hidden);
    document.addEventListener("visibilitychange", onVisibility);

    const heartbeat = setInterval(() => {
      if (!document.hidden) sendPresence(true);
    }, 20_000);

    return () => {
      clearInterval(heartbeat);
      document.removeEventListener("visibilitychange", onVisibility);
      sendPresence(false); // leaving chat
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  const handleSend = async (text: string) => {
    const optimistic: SupportMessage = {
      id: `tmp-${Date.now()}`,
      userId,
      fromAdmin: false,
      body: text,
      createdAt: new Date().toISOString(),
      readByUser: true,
      readByAdmin: false,
    };
    setMessages((prev) => [...prev, optimistic]);
    try {
      const real = await sendMyMessage(token, text);
      setMessages((prev) => prev.map((m) => (m.id === optimistic.id ? real : m)));
    } catch {
      setMessages((prev) => prev.filter((m) => m.id !== optimistic.id));
    }
  };

  const handleSendImage = async (file: File, caption: string) => {
    const previewUrl = URL.createObjectURL(file);
    const optimistic: SupportMessage = {
      id: `tmp-${Date.now()}`,
      userId,
      fromAdmin: false,
      body: caption,
      imageUrl: previewUrl,
      createdAt: new Date().toISOString(),
      readByUser: true,
      readByAdmin: false,
    };
    setMessages((prev) => [...prev, optimistic]);
    try {
      const real = await sendMyImage(token, file, caption);
      setMessages((prev) => prev.map((m) => (m.id === optimistic.id ? real : m)));
    } catch (err) {
      setMessages((prev) => prev.filter((m) => m.id !== optimistic.id));
      throw err;
    } finally {
      URL.revokeObjectURL(previewUrl);
    }
  };

  return (
    <>
      <Header title={ts.messagesAdmin} subtitle={ts.messagesDesc} onClose={onClose} />
      <div className="px-3 py-1.5 text-center text-[11px] text-muted-foreground bg-secondary/30 border-b border-border shrink-0">
        {ts.messagesRetention}
      </div>
      {loading ? (
        <div className="flex-1 flex items-center justify-center text-xs text-muted-foreground">…</div>
      ) : (
        <MessageList messages={messages} isAdminView={false} />
      )}
      <Composer onSend={handleSend} onSendImage={handleSendImage} placeholder={ts.messagesPlaceholder} />
    </>
  );
}

function AdminInbox({
  onClose,
  initialUserId,
  initialUserName,
}: {
  onClose: () => void;
  initialUserId?: string;
  initialUserName?: string;
}) {
  const { token } = useAuth();
  const { t } = useLang();
  const ts = t.support;
  const [threads, setThreads] = useState<SupportThread[]>([]);
  const [selected, setSelected] = useState<SupportThread | null>(
    initialUserId
      ? {
          userId: initialUserId,
          name: initialUserName ?? null,
          phone: null,
          nickname: null,
          avatarUrl: null,
          lastBody: "",
          lastAt: new Date().toISOString(),
          lastFromAdmin: false,
          unread: 0,
        }
      : null,
  );
  const [messages, setMessages] = useState<SupportMessage[]>([]);
  const [loading, setLoading] = useState(true);

  const refreshThreads = async () => {
    if (!token) return;
    try {
      setThreads(await getThreads(token));
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  const refreshThread = async (uid: string) => {
    if (!token) return;
    try {
      setMessages(await getThread(token, uid));
      window.dispatchEvent(new Event("support-unread-changed"));
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    void refreshThreads();
    const i = setInterval(() => { void refreshThreads(); }, 5000);
    return () => clearInterval(i);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  // ── Presence reporting ─────────────────────────────────────────────
  // Report which thread the admin is viewing so user Telegram notifications
  // are suppressed when the admin is actively watching the conversation.
  // Re-runs when the selected thread changes or on mount/unmount.
  useEffect(() => {
    if (!token) return;
    const sendPresence = () => {
      const watching = !document.hidden && !!selected;
      void reportPresence(
        token,
        watching,
        watching ? selected!.userId : null,
      );
    };
    sendPresence();

    const onVisibility = () => sendPresence();
    document.addEventListener("visibilitychange", onVisibility);

    const heartbeat = setInterval(() => {
      if (!document.hidden && selected) {
        void reportPresence(token, true, selected.userId);
      }
    }, 20_000);

    return () => {
      clearInterval(heartbeat);
      document.removeEventListener("visibilitychange", onVisibility);
      void reportPresence(token, false, null); // leaving
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token, selected?.userId]);

  useEffect(() => {
    if (!selected) return;
    void refreshThread(selected.userId);
    const i = setInterval(() => { void refreshThread(selected.userId); }, 5000);
    return () => clearInterval(i);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected?.userId]);

  const handleSend = async (text: string) => {
    if (!token || !selected) return;
    const optimistic: SupportMessage = {
      id: `tmp-${Date.now()}`,
      userId: selected.userId,
      fromAdmin: true,
      body: text,
      createdAt: new Date().toISOString(),
      readByUser: false,
      readByAdmin: true,
    };
    setMessages((prev) => [...prev, optimistic]);
    try {
      const real = await sendThread(token, selected.userId, text);
      setMessages((prev) => prev.map((m) => (m.id === optimistic.id ? real : m)));
      void refreshThreads();
    } catch {
      setMessages((prev) => prev.filter((m) => m.id !== optimistic.id));
    }
  };

  const handleSendImage = async (file: File, caption: string) => {
    if (!token || !selected) return;
    const previewUrl = URL.createObjectURL(file);
    const optimistic: SupportMessage = {
      id: `tmp-${Date.now()}`,
      userId: selected.userId,
      fromAdmin: true,
      body: caption,
      imageUrl: previewUrl,
      createdAt: new Date().toISOString(),
      readByUser: false,
      readByAdmin: true,
    };
    setMessages((prev) => [...prev, optimistic]);
    try {
      const real = await sendThreadImage(token, selected.userId, file, caption);
      setMessages((prev) => prev.map((m) => (m.id === optimistic.id ? real : m)));
      void refreshThreads();
    } catch (err) {
      setMessages((prev) => prev.filter((m) => m.id !== optimistic.id));
      throw err;
    } finally {
      URL.revokeObjectURL(previewUrl);
    }
  };

  const handleDeleteThread = async () => {
    if (!token || !selected) return;
    const display = selected.nickname || selected.name || selected.phone || selected.userId.slice(0, 8);
    if (!window.confirm(ts.deleteThreadConfirm.replace("{name}", display))) return;
    try {
      await deleteThread(token, selected.userId);
      setSelected(null);
      setMessages([]);
      void refreshThreads();
    } catch {
      window.alert(ts.deleteThreadFailed);
    }
  };

  if (selected) {
    const display = selected.nickname || selected.name || selected.phone || selected.userId.slice(0, 8);
    return (
      <>
        <Header
          title={display}
          subtitle={selected.phone ?? undefined}
          onClose={onClose}
          onBack={() => { setSelected(null); setMessages([]); }}
          onDelete={handleDeleteThread}
          deleteLabel={ts.deleteThreadBtn}
        />
        <MessageList messages={messages} isAdminView={true} />
        <Composer onSend={handleSend} onSendImage={handleSendImage} placeholder={ts.adminReplyPlaceholder} />
      </>
    );
  }

  return (
    <>
      <Header title={ts.adminInbox} onClose={onClose} />
      <div className="flex-1 overflow-y-auto">
        {loading ? (
          <div className="p-6 text-center text-xs text-muted-foreground">…</div>
        ) : threads.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-xs text-muted-foreground gap-3">
            <Inbox className="w-8 h-8 opacity-40" />
            {ts.adminInboxEmpty}
          </div>
        ) : (
          <ul className="divide-y divide-border">
            {threads.map((th) => {
              const display = th.nickname || th.name || th.phone || th.userId.slice(0, 8);
              return (
                <li key={th.userId}>
                  <button
                    onClick={() => setSelected(th)}
                    className="w-full text-left p-3 flex items-start gap-3 hover:bg-secondary/30 transition-colors"
                  >
                    <div className="w-9 h-9 rounded-full bg-primary/15 text-primary font-bold text-sm flex items-center justify-center shrink-0 overflow-hidden">
                      {th.avatarUrl ? (
                        <img src={th.avatarUrl} alt="" className="w-full h-full object-cover" />
                      ) : (
                        display.slice(0, 1).toUpperCase()
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-semibold truncate flex-1">{display}</p>
                        <span className="text-[10px] text-muted-foreground shrink-0">
                          {new Date(th.lastAt).toLocaleString([], { hour: "2-digit", minute: "2-digit", day: "2-digit", month: "2-digit" })}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground truncate">
                        {th.lastFromAdmin ? `${ts.messagesYou}: ` : ""}{th.lastBody}
                      </p>
                    </div>
                    {th.unread > 0 && (
                      <span className="bg-red-500 text-white text-[10px] font-bold rounded-full min-w-[18px] h-[18px] px-1 flex items-center justify-center shrink-0">
                        {th.unread}
                      </span>
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </>
  );
}

// Re-export for any consumer that wants to use the icon
export { MessageCircle as SupportChatIcon };
