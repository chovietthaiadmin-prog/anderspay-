import { useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";
import { useGetRateCandles, getGetRateCandlesQueryKey } from "@workspace/api-client-react";
import { useLang } from "@/lib/use-lang";
import { Activity, ArrowDownRight, ArrowUpRight, BarChart3 } from "lucide-react";

type Candle = {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
};

const UP = "#43d58a";
const DOWN = "#ff5b68";

function RateTooltip({
  active,
  payload,
  label,
  formatTime,
}: {
  active?: boolean;
  payload?: Array<{ payload?: Candle; value?: number }>;
  label?: string;
  formatTime: (value: string) => string;
}) {
  if (!active || !payload?.length || !payload[0]?.payload) return null;
  const candle = payload[0].payload;

  return (
    <div className="min-w-[148px] rounded-xl border border-white/10 bg-[#171615]/95 px-3 py-2.5 shadow-2xl shadow-black/30 backdrop-blur-xl">
      <p className="mb-1.5 text-[10px] font-medium uppercase tracking-[0.12em] text-white/45">
        {label ? formatTime(label) : ""}
      </p>
      <div className="flex items-baseline justify-between gap-4">
        <span className="text-[10px] text-white/50">1 USDT</span>
        <span className="font-mono text-sm font-bold tabular-nums text-white">
          {candle.close.toFixed(4)} ฿
        </span>
      </div>
      <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 border-t border-white/8 pt-2 text-[10px] tabular-nums">
        <span className="text-white/40">Mở {candle.open.toFixed(4)}</span>
        <span className="text-right text-white/60">Đóng {candle.close.toFixed(4)}</span>
        <span className="text-white/40">Cao {candle.high.toFixed(4)}</span>
        <span className="text-right text-white/40">Thấp {candle.low.toFixed(4)}</span>
      </div>
    </div>
  );
}

export default function RateChart() {
  const { t, lang } = useLang();
  const [hours, setHours] = useState(24);

  const { data, isLoading, isFetching } = useGetRateCandles(
    { hours },
    { query: { queryKey: getGetRateCandlesQueryKey({ hours }), refetchInterval: 60_000 } },
  );

  const candles = useMemo<Candle[]>(() => data?.candles ?? [], [data]);

  const chartData = useMemo(
    () =>
      candles.map((c) => ({
        ...c,
        change: c.close - c.open,
      })),
    [candles],
  );

  const { domainMin, domainMax } = useMemo(() => {
    if (candles.length === 0) return { domainMin: 0, domainMax: 1 };
    let lo = Infinity;
    let hi = -Infinity;
    for (const c of candles) {
      lo = Math.min(lo, c.low);
      hi = Math.max(hi, c.high);
    }
    const pad = (hi - lo) * 0.18 || hi * 0.01 || 0.5;
    return { domainMin: lo - pad, domainMax: hi + pad };
  }, [candles]);

  const last = candles[candles.length - 1];
  const first = candles[0];
  const change = last && first ? last.close - first.open : 0;
  const changePct = last && first && first.open ? (change / first.open) * 100 : 0;
  const up = change >= 0;
  const high = candles.length ? Math.max(...candles.map((c) => c.high)) : 0;
  const low = candles.length ? Math.min(...candles.map((c) => c.low)) : 0;

  const fmtTime = (iso: string) => {
    const d = new Date(iso);
    if (hours <= 24) {
      return d.toLocaleTimeString(lang === "vi" ? "vi-VN" : "en-US", {
        hour: "2-digit",
        minute: "2-digit",
        timeZone: "Asia/Bangkok",
        hour12: false,
      });
    }
    return d.toLocaleDateString(lang === "vi" ? "vi-VN" : "en-US", {
      day: "2-digit",
      month: "2-digit",
      timeZone: "Asia/Bangkok",
    });
  };

  return (
    <div className="overflow-hidden rounded-[22px] border border-white/10 bg-[linear-gradient(145deg,rgba(27,25,22,0.98),rgba(17,17,17,0.98))] shadow-[0_18px_50px_rgba(0,0,0,0.18)]">
      <div className="px-4 pb-3 pt-4 sm:px-5">
        <div className="flex items-start justify-between gap-3">
          <div className="flex min-w-0 items-center gap-2.5">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-accent/25 bg-accent/10">
              <BarChart3 className="h-4 w-4 text-accent" strokeWidth={2.2} />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="truncate text-sm font-bold tracking-tight">{t.home.priceChartTitle}</span>
                <span className="hidden items-center gap-1 rounded-full border border-emerald-400/20 bg-emerald-400/10 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-[0.12em] text-emerald-300 sm:flex">
                  <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-300" />
                  Live
                </span>
              </div>
              <div className="mt-1 flex items-center gap-1.5 text-[10px] text-white/40">
                <Activity className={`h-3 w-3 ${isFetching ? "animate-pulse text-accent" : "text-white/35"}`} />
                <span>{t.home.liveRate}</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1 rounded-xl border border-white/8 bg-black/20 p-1">
            {[
              { h: 24, label: t.home.priceChart1d },
              { h: 168, label: t.home.priceChart7d },
            ].map((opt) => (
              <button
                key={opt.h}
                type="button"
                onClick={() => setHours(opt.h)}
                aria-pressed={hours === opt.h}
                className={`rounded-lg px-2.5 py-1.5 text-[10px] font-bold transition-all ${
                  hours === opt.h
                    ? "bg-accent text-accent-foreground shadow-[0_3px_12px_rgba(245,190,42,0.18)]"
                    : "text-white/45 hover:bg-white/8 hover:text-white/80"
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {last && (
          <div className="mt-4 flex items-end justify-between gap-3">
            <div className="flex items-baseline gap-2">
              <span className="font-mono text-[1.85rem] font-black leading-none tracking-[-0.06em] text-white tabular-nums">
                {last.close.toFixed(2)}
              </span>
              <span className="text-xs font-semibold text-white/40">THB</span>
            </div>
            <div
              className={`flex items-center gap-1 rounded-full border px-2.5 py-1 text-[11px] font-bold tabular-nums ${
                up
                  ? "border-emerald-400/20 bg-emerald-400/10 text-emerald-300"
                  : "border-rose-400/20 bg-rose-400/10 text-rose-300"
              }`}
            >
              {up ? <ArrowUpRight className="h-3.5 w-3.5" /> : <ArrowDownRight className="h-3.5 w-3.5" />}
              {up ? "+" : ""}
              {changePct.toFixed(2)}%
            </div>
          </div>
        )}

        {last && (
          <div className="mt-4 grid grid-cols-3 divide-x divide-white/8 rounded-xl border border-white/8 bg-white/[0.025] py-2.5">
            <div className="px-3">
              <p className="text-[9px] uppercase tracking-[0.12em] text-white/35">Open</p>
              <p className="mt-1 font-mono text-[11px] font-semibold tabular-nums text-white/75">{first.open.toFixed(4)}</p>
            </div>
            <div className="px-3">
              <p className="text-[9px] uppercase tracking-[0.12em] text-white/35">High</p>
              <p className="mt-1 font-mono text-[11px] font-semibold tabular-nums text-emerald-300/85">{high.toFixed(4)}</p>
            </div>
            <div className="px-3">
              <p className="text-[9px] uppercase tracking-[0.12em] text-white/35">Low</p>
              <p className="mt-1 font-mono text-[11px] font-semibold tabular-nums text-rose-300/85">{low.toFixed(4)}</p>
            </div>
          </div>
        )}
      </div>

      <div className="h-52 w-full px-1 pb-3 sm:h-56 sm:px-2">
        {isLoading ? (
          <div className="h-full w-full flex items-center justify-center">
            <div className="mx-4 h-40 w-full animate-pulse rounded-2xl bg-white/[0.04]" />
          </div>
        ) : candles.length === 0 ? (
          <div className="flex h-full w-full items-center justify-center text-xs text-white/35">
            —
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={chartData}
              margin={{ top: 8, right: 9, bottom: 0, left: 1 }}
            >
              <defs>
                <linearGradient id="rate-area-fill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={up ? UP : DOWN} stopOpacity={0.28} />
                  <stop offset="72%" stopColor={up ? UP : DOWN} stopOpacity={0.05} />
                  <stop offset="100%" stopColor={up ? UP : DOWN} stopOpacity={0} />
                </linearGradient>
                <filter id="rate-glow" x="-50%" y="-50%" width="200%" height="200%">
                  <feGaussianBlur stdDeviation="3" result="blur" />
                  <feMerge>
                    <feMergeNode in="blur" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
              </defs>
              <CartesianGrid vertical={false} stroke="rgba(255,255,255,0.06)" strokeDasharray="3 6" />
              <XAxis
                dataKey="time"
                tickFormatter={fmtTime}
                tick={{ fontSize: 9, fill: "rgba(255,255,255,0.32)" }}
                axisLine={false}
                tickLine={false}
                minTickGap={32}
                interval="preserveStartEnd"
              />
              <YAxis
                orientation="right"
                domain={[domainMin, domainMax]}
                tick={{ fontSize: 9, fill: "rgba(255,255,255,0.32)" }}
                axisLine={false}
                tickLine={false}
                width={42}
                tickCount={4}
                tickFormatter={(v: number) => v.toFixed(2)}
              />
              <Tooltip
                cursor={{ stroke: "rgba(255,255,255,0.25)", strokeDasharray: "4 4" }}
                content={<RateTooltip formatTime={fmtTime} />}
              />
              <Area
                type="monotone"
                dataKey="close"
                stroke={up ? UP : DOWN}
                strokeWidth={2.25}
                fill="url(#rate-area-fill)"
                isAnimationActive={false}
                activeDot={{
                  r: 4,
                  fill: up ? UP : DOWN,
                  stroke: "#171615",
                  strokeWidth: 2,
                  filter: "url(#rate-glow)",
                }}
                dot={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}
