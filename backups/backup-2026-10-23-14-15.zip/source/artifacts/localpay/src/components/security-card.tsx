import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ShieldCheck, KeyRound, Fingerprint, Trash2, Lock, X } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { useLang } from "@/lib/use-lang";
import {
  fetchSecurityStatus,
  setPin,
  removePin,
  registerPasskey,
  removePasskey,
  isPasskeySupported,
  setLockEnabled,
  isLockEnabled,
  type SecurityStatus,
} from "@/lib/security";

export default function SecurityCard() {
  const { token } = useAuth();
  const { t } = useLang();
  const { toast } = useToast();
  const ts = t.settings;

  const [status, setStatus] = useState<SecurityStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [pinModal, setPinModal] = useState<"set" | "remove" | null>(null);
  const [passkeyModal, setPasskeyModal] = useState(false);
  const [lockOn, setLockOn] = useState(isLockEnabled());

  const refresh = async () => {
    if (!token) return;
    try {
      const s = await fetchSecurityStatus(token);
      setStatus(s);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void refresh(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [token]);

  const hasAnyMethod = !!(status?.pinEnabled || (status && status.passkeys.length > 0));

  // If user removed all methods, also turn off the lock flag.
  useEffect(() => {
    if (status && !hasAnyMethod && lockOn) {
      setLockEnabled(false);
      setLockOn(false);
    }
  }, [status, hasAnyMethod, lockOn]);

  const handleRemovePasskey = async (id: string) => {
    if (!token) return;
    if (!window.confirm(ts.passkeyRemovedToast + "?")) return;
    try {
      await removePasskey(token, id);
      toast({ title: ts.passkeyRemovedToast });
      await refresh();
    } catch {
      toast({ title: "Error", variant: "destructive" });
    }
  };

  return (
    <div className="flex flex-col gap-3">
      <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">
        {ts.appLock}
      </p>

      <Card className="bg-card border-border overflow-hidden">
        <CardContent className="p-0 divide-y divide-border">
          {/* PIN row */}
          <div className="flex items-center gap-4 p-4">
            <div className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 bg-primary/10">
              <KeyRound className="w-4 h-4 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium">{ts.pinTitle}</p>
              <p className="text-xs text-muted-foreground">
                {loading
                  ? "…"
                  : status?.pinEnabled
                    ? ts.pinEnabled
                    : ts.pinDesc}
              </p>
            </div>
            {status?.pinEnabled ? (
              <div className="flex gap-2">
                <button
                  onClick={() => setPinModal("set")}
                  className="text-xs font-medium px-3 py-1.5 rounded-md bg-secondary hover:bg-secondary/70"
                >
                  {ts.pinChange}
                </button>
                <button
                  onClick={() => setPinModal("remove")}
                  className="text-xs font-medium px-2 py-1.5 rounded-md bg-red-500/10 text-red-400 hover:bg-red-500/20"
                  aria-label="remove pin"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => setPinModal("set")}
                className="text-xs font-bold px-3 py-1.5 rounded-md bg-primary text-white hover:bg-primary/90"
              >
                {ts.pinSet}
              </button>
            )}
          </div>

          {/* Passkey row */}
          <div className="flex items-center gap-4 p-4">
            <div className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 bg-emerald-400/10">
              <Fingerprint className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium">{ts.passkeyTitle}</p>
              <p className="text-xs text-muted-foreground">{ts.passkeyDesc}</p>
            </div>
            <button
              disabled={!isPasskeySupported()}
              onClick={() => setPasskeyModal(true)}
              className="text-xs font-bold px-3 py-1.5 rounded-md bg-primary text-white hover:bg-primary/90 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {ts.passkeyAdd}
            </button>
          </div>

          {status && status.passkeys.length > 0 && (
            <div className="px-4 py-3 flex flex-col gap-2 bg-secondary/20">
              {status.passkeys.map((p) => (
                <div key={p.id} className="flex items-center gap-2 text-xs">
                  <Fingerprint className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="flex-1 truncate">{p.name || "Passkey"}</span>
                  <span className="text-[10px] text-muted-foreground">
                    {new Date(p.createdAt).toLocaleDateString()}
                  </span>
                  <button
                    onClick={() => handleRemovePasskey(p.id)}
                    className="w-6 h-6 rounded bg-red-500/10 text-red-400 flex items-center justify-center hover:bg-red-500/20"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* App lock switch */}
          <div className="flex items-center gap-4 p-4">
            <div className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 bg-yellow-400/10">
              <Lock className="w-4 h-4 text-yellow-400" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium">{ts.appLock}</p>
              <p className="text-xs text-muted-foreground">{ts.appLockDesc}</p>
            </div>
            <Switch
              checked={lockOn}
              disabled={!hasAnyMethod}
              onCheckedChange={(v) => {
                setLockEnabled(v);
                setLockOn(v);
              }}
            />
          </div>
        </CardContent>
      </Card>

      <AnimatePresence>
        {pinModal && (
          <PinModal
            mode={pinModal}
            onClose={() => setPinModal(null)}
            onDone={async () => {
              setPinModal(null);
              await refresh();
            }}
          />
        )}
        {passkeyModal && (
          <PasskeyModal
            onClose={() => setPasskeyModal(false)}
            onDone={async () => {
              setPasskeyModal(false);
              await refresh();
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function ModalShell({ children, onClose, title }: { children: React.ReactNode; onClose: () => void; title: string }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[200] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, y: 10 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.95, y: 10 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-card border border-border rounded-2xl w-full max-w-sm p-5 flex flex-col gap-4"
      >
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-base flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-primary" />
            {title}
          </h3>
          <button onClick={onClose} className="w-7 h-7 rounded-md bg-secondary hover:bg-secondary/70 flex items-center justify-center">
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>
        {children}
      </motion.div>
    </motion.div>
  );
}

function PinModal({ mode, onClose, onDone }: { mode: "set" | "remove"; onClose: () => void; onDone: () => Promise<void> }) {
  const { token } = useAuth();
  const { t } = useLang();
  const { toast } = useToast();
  const ts = t.settings;
  const [password, setPassword] = useState("");
  const [pin1, setPin1] = useState("");
  const [pin2, setPin2] = useState("");
  const [busy, setBusy] = useState(false);

  const handle = async () => {
    if (!token) return;
    if (mode === "set") {
      if (!/^\d{6}$/.test(pin1)) {
        toast({ title: ts.pinFormat, variant: "destructive" });
        return;
      }
      if (pin1 !== pin2) {
        toast({ title: ts.pinMismatch, variant: "destructive" });
        return;
      }
    }
    setBusy(true);
    try {
      if (mode === "set") {
        await setPin(token, password, pin1);
        toast({ title: ts.pinSavedToast });
      } else {
        await removePin(token, password);
        toast({ title: ts.pinRemovedToast });
      }
      await onDone();
    } catch (err) {
      const msg = err instanceof Error ? err.message : "";
      toast({
        title: msg === "wrong_password" ? ts.passwordWrong : "Error",
        variant: "destructive",
      });
    } finally {
      setBusy(false);
    }
  };

  return (
    <ModalShell onClose={onClose} title={mode === "set" ? ts.pinSet : ts.pinRemove}>
      <div className="flex flex-col gap-3">
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">{ts.pinPasswordLabel}</label>
          <Input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoFocus
          />
        </div>
        {mode === "set" && (
          <>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">{ts.pinNewLabel}</label>
              <Input
                inputMode="numeric"
                maxLength={6}
                value={pin1}
                onChange={(e) => setPin1(e.target.value.replace(/\D/g, "").slice(0, 6))}
                className="font-mono text-center text-lg tracking-[0.4em]"
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">{ts.pinConfirmLabel}</label>
              <Input
                inputMode="numeric"
                maxLength={6}
                value={pin2}
                onChange={(e) => setPin2(e.target.value.replace(/\D/g, "").slice(0, 6))}
                className="font-mono text-center text-lg tracking-[0.4em]"
              />
            </div>
          </>
        )}
        <div className="flex gap-2 pt-1">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 rounded-lg bg-secondary text-sm font-medium hover:bg-secondary/70"
          >
            {ts.cancel}
          </button>
          <button
            onClick={handle}
            disabled={busy || !password || (mode === "set" && (!pin1 || !pin2))}
            className="flex-1 py-2.5 rounded-lg bg-primary text-white text-sm font-bold disabled:opacity-40"
          >
            {busy ? "…" : ts.save}
          </button>
        </div>
      </div>
    </ModalShell>
  );
}

function PasskeyModal({ onClose, onDone }: { onClose: () => void; onDone: () => Promise<void> }) {
  const { token } = useAuth();
  const { t } = useLang();
  const { toast } = useToast();
  const ts = t.settings;
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);

  const handle = async () => {
    if (!token) return;
    setBusy(true);
    try {
      await registerPasskey(token, name.trim() || (typeof navigator !== "undefined" ? navigator.platform : "Device"));
      toast({ title: ts.passkeyAddedToast });
      await onDone();
    } catch {
      toast({ title: ts.passkeyFailed, variant: "destructive" });
      setBusy(false);
    }
  };

  return (
    <ModalShell onClose={onClose} title={ts.passkeyTitle}>
      <div className="flex flex-col gap-3">
        <p className="text-xs text-muted-foreground">{ts.passkeyDesc}</p>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">{ts.passkeyName}</label>
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="iPhone 15 Pro"
            maxLength={40}
          />
        </div>
        <div className="flex gap-2 pt-1">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 rounded-lg bg-secondary text-sm font-medium hover:bg-secondary/70"
          >
            {ts.cancel}
          </button>
          <button
            onClick={handle}
            disabled={busy}
            className="flex-1 py-2.5 rounded-lg bg-primary text-white text-sm font-bold disabled:opacity-40 flex items-center justify-center gap-2"
          >
            <Fingerprint className="w-4 h-4" />
            {busy ? "…" : ts.passkeyAdd}
          </button>
        </div>
      </div>
    </ModalShell>
  );
}
