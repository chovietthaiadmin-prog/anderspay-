import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, TrendingUp, Save, Calendar, AlertCircle } from "lucide-react";
import { useGetExchangeRate, getGetExchangeRateQueryKey } from "@workspace/api-client-react";
import { useLang } from "@/lib/use-lang";
import { useAuth } from "@/lib/auth";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";

interface RateManagerProps {
  open: boolean;
  onClose: () => void;
}

export default function RateManager({ open, onClose }: RateManagerProps) {
  const { t, lang } = useLang();
  const { token } = useAuth();
  const rt = t.rateManager;
  const queryClient = useQueryClient();

  const { data: currentRate } = useGetExchangeRate({
    query: { queryKey: getGetExchangeRateQueryKey() }
  });

  const [newRate, setNewRate] = useState("");
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  const handleSave = async () => {
    const rate = parseFloat(newRate);
    if (!newRate || isNaN(rate) || rate <= 0 || rate > 1000) {
      setError(rt.invalidRate);
      return;
    }

    setSaving(true);
    setError("");
    setSuccess(false);

    try {
      const base = import.meta.env.BASE_URL.replace(/\/$/, "");
      const res = await fetch(`${base}/api/rates/thb-usdt`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ thbPerUsdt: rate }),
      });

      if (!res.ok) throw new Error("Failed");

      await queryClient.invalidateQueries({ queryKey: getGetExchangeRateQueryKey() });
      setSuccess(true);
      setNewRate("");
      setTimeout(() => setSuccess(false), 3000);
    } catch {
      setError(rt.saveFailed);
    } finally {
      setSaving(false);
    }
  };

  const today = new Date().toLocaleDateString(lang === "vi" ? "vi-VN" : "en-US", {
    weekday: "long", year: "numeric", month: "long", day: "numeric"
  });

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 z-50 backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, y: -40, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -30, scale: 0.97 }}
            transition={{ type: "spring", damping: 24, stiffness: 300 }}
            className="fixed top-0 left-0 right-0 z-50 flex justify-center pt-[env(safe-area-inset-top)]"
          >
            <div className="relative w-full max-w-[480px] bg-card rounded-b-3xl border-b border-border shadow-2xl p-6 pt-14">
              <div className="w-10 h-1 bg-border rounded-full mx-auto mb-6" />

              <button onClick={onClose} className="absolute top-11 right-5 text-muted-foreground hover:text-foreground transition-colors">
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <h2 className="font-bold text-lg">{rt.title}</h2>
                  <p className="text-xs text-muted-foreground">{rt.subtitle}</p>
                </div>
              </div>

              {/* Today's date */}
              <div className="flex items-center gap-2 mb-5 text-xs text-muted-foreground bg-secondary/40 rounded-xl px-3 py-2">
                <Calendar className="w-3.5 h-3.5" />
                <span>{today}</span>
              </div>

              {/* Current rate */}
              <Card className="bg-secondary/30 border-border mb-5">
                <CardContent className="p-4 flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">{rt.currentRate}</span>
                  <div className="text-right">
                    {currentRate ? (
                      <>
                        <span className="text-xl font-bold text-accent font-mono tabular-nums">
                          {currentRate.thbPerUsdt.toFixed(4)}
                        </span>
                        <span className="text-sm text-muted-foreground ml-1">THB/USDT</span>
                      </>
                    ) : (
                      <div className="h-6 w-28 bg-muted animate-pulse rounded" />
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Set new rate */}
              <div className="flex flex-col gap-3">
                <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">{rt.setRate}</p>
                <div className="flex gap-3">
                  <div className="relative flex-1">
                    <Input
                      type="number"
                      step="0.01"
                      min="1"
                      max="1000"
                      placeholder={rt.ratePlaceholder}
                      value={newRate}
                      onChange={(e) => { setNewRate(e.target.value); setError(""); setSuccess(false); }}
                      className="bg-input border-border h-12 text-lg font-bold tabular-nums pr-20 focus-visible:ring-accent"
                      onKeyDown={(e) => e.key === "Enter" && handleSave()}
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground font-medium">
                      THB
                    </span>
                  </div>
                  <Button
                    className="h-12 px-5 gap-2 bg-accent text-accent-foreground hover:bg-accent/90 font-bold shrink-0"
                    onClick={handleSave}
                    disabled={saving || !newRate}
                  >
                    <Save className="w-4 h-4" />
                    {saving ? rt.saving : rt.save}
                  </Button>
                </div>

                <p className="text-xs text-muted-foreground">{rt.hint}</p>

                <AnimatePresence>
                  {error && (
                    <motion.div
                      initial={{ opacity: 0, y: -4 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="flex items-center gap-2 text-sm text-red-400 bg-red-500/10 rounded-lg px-3 py-2"
                    >
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      {error}
                    </motion.div>
                  )}
                  {success && (
                    <motion.div
                      initial={{ opacity: 0, y: -4 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="flex items-center gap-2 text-sm text-green-400 bg-green-500/10 rounded-lg px-3 py-2"
                    >
                      <span>✓</span>
                      {rt.saveSuccess}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
