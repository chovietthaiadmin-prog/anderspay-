import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Home, Clock, CreditCard, MessageCircle, Settings } from "lucide-react";
import { motion } from "framer-motion";
import { useLang } from "@/lib/use-lang";
import { useAuth } from "@/lib/auth";
import { getAdminUnread, getMyUnread } from "@/lib/support-chat";

/** Poll interval for support unread count (ms). */
const SUPPORT_POLL_MS = 10_000;

export default function BottomNav() {
  const [location, setLocation] = useLocation();
  const { t } = useLang();
  const { user, token } = useAuth();

  // Unread support-message count for the current participant. Admins use the
  // aggregate inbox count; regular users use their own admin-reply count.
  const [supportUnread, setSupportUnread] = useState(0);

  useEffect(() => {
    if (!token) {
      setSupportUnread(0);
      return;
    }
    let cancelled = false;
    const fetchUnread = () => {
      const request = user?.isAdmin
        ? getAdminUnread(token)
        : getMyUnread(token);
      request
        .then((n) => { if (!cancelled) setSupportUnread(n); })
        .catch(() => {});
    };
    const handleUnreadChanged = () => fetchUnread();

    fetchUnread();
    const id = setInterval(fetchUnread, SUPPORT_POLL_MS);
    window.addEventListener("support-unread-changed", handleUnreadChanged);
    return () => {
      cancelled = true;
      clearInterval(id);
      window.removeEventListener("support-unread-changed", handleUnreadChanged);
    };
  }, [user?.isAdmin, token]);

  const allNavItems = [
    { path: "/",        label: t.nav.home,    icon: Home },
    { path: "/history", label: t.nav.history, icon: Clock },
    { path: "/pay",     label: t.nav.payment, icon: CreditCard },
    { path: "/support", label: t.nav.support, icon: MessageCircle },
    { path: "/settings",label: t.nav.settings,icon: Settings },
  ];
  const adminNavItems = [
    { path: "/",              label: t.nav.home,    icon: Home },
    { path: "/admin/history", label: t.nav.history, icon: Clock },
    { path: "/support",       label: t.nav.support, icon: MessageCircle },
    { path: "/settings",      label: t.nav.settings,icon: Settings },
  ];
  const navItems = user?.isAdmin ? adminNavItems : allNavItems;

  const isActive = (path: string) => {
    if (path === "/") return location === "/" || location === "";
    return location.startsWith(path);
  };

  const navGridClass = user?.isAdmin ? "grid-cols-4" : "grid-cols-5";

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 flex justify-center">
      <div className="w-full max-w-[480px]">
        <div
          className={`grid ${navGridClass} items-end border-border bg-card px-1 pt-2 shadow-[0_-4px_24px_rgba(0,0,0,0.4)]`}
          style={{ paddingBottom: "calc(0.5rem + env(safe-area-inset-bottom))" }}
        >
          {navItems.map(({ path, label, icon: Icon }) => {
            const active = isActive(path);
            const isCenter = path === "/pay";
            const isSupport = path === "/support";
            const showBadge = isSupport && supportUnread > 0;

            if (isCenter) {
              return (
                <button
                  key={path}
                  data-testid={`nav-${path}`}
                  onClick={() => setLocation(path)}
                  className="flex w-full min-w-0 flex-col items-center justify-center -mt-5 px-1"
                >
                  {/* Pulsing rings */}
                  <div className="relative flex items-center justify-center">
                    <span className="absolute w-14 h-14 rounded-full bg-primary/40"
                      style={{ animation: "pay-ring 1.8s ease-out infinite" }} />
                    <span className="absolute w-14 h-14 rounded-full bg-primary/25"
                      style={{ animation: "pay-ring 1.8s ease-out 0.6s infinite" }} />
                    <motion.div
                      whileTap={{ scale: 0.88 }}
                      animate={{ scale: [1, 1.05, 1] }}
                      transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut" }}
                      className="relative w-14 h-14 rounded-full flex items-center justify-center overflow-hidden shadow-xl"
                      style={{
                        background: "var(--pay-button-background, linear-gradient(135deg, #ff5555 0%, #ff3b3b 50%, #cc1c1c 100%))",
                        boxShadow: "0 0 18px 4px var(--glow-1, rgba(255,59,59,0.45)), 0 4px 12px rgba(0,0,0,0.4)",
                      }}
                    >
                      {/* Shine sweep */}
                      <span className="absolute top-0 bottom-0 w-8 bg-white/20 skew-x-[-20deg] blur-sm pointer-events-none"
                        style={{ animation: "pay-shine 2.6s ease-in-out 1.2s infinite" }} />
                      <Icon
                        className="w-6 h-6 text-white relative z-10"
                        style={{ animation: "pay-float 2.4s ease-in-out infinite" }}
                      />
                    </motion.div>
                  </div>
                   <span className={`mt-1 whitespace-nowrap text-[10px] font-medium ${active ? "text-primary" : "text-muted-foreground"}`}>
                    {label}
                  </span>
                </button>
              );
            }

            return (
              <button
                key={path}
                data-testid={`nav-${path}`}
                onClick={() => setLocation(path)}
                className="relative flex w-full min-w-0 flex-col items-center justify-center gap-1 px-1 py-1"
              >
                {active && (
                  <motion.div
                    layoutId="nav-indicator"
                    className="absolute -top-2 left-1/2 -translate-x-1/2 w-6 h-0.5 bg-primary rounded-full"
                  />
                )}
                <div className="relative">
                  <Icon className={`w-5 h-5 transition-colors ${active ? "text-primary" : "text-muted-foreground"}`} />
                  {showBadge && (
                    <span className="absolute -top-1 -right-1 min-w-[16px] h-4 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center px-[3px] leading-none">
                      {supportUnread > 99 ? "99+" : supportUnread}
                    </span>
                  )}
                </div>
                 <span className={`whitespace-nowrap text-[10px] font-medium transition-colors ${active ? "text-primary" : "text-muted-foreground"}`}>
                  {label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
