import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Share, Plus, Download, MoreHorizontal, MoreVertical, ChevronDown } from "lucide-react";
import { useInstallPrompt } from "@/hooks/use-install-prompt";
import { useLang } from "@/lib/use-lang";

const DISMISSED_KEY = "ap-install-dismissed";
const SHOW_DELAY_MS = 4000;
const FAST_DELAY_MS = 600;

function hasInstallIntent(): boolean {
  if (typeof window === "undefined") return false;
  try {
    const url = new URL(window.location.href);
    return url.searchParams.get("install") === "1";
  } catch {
    return false;
  }
}

export default function InstallBanner() {
  const { platform, canInstall, triggerInstall, triggerInstallReady } = useInstallPrompt();
  const { t } = useLang();
  const [visible, setVisible] = useState(false);
  const [installing, setInstalling] = useState(false);

  useEffect(() => {
    if (!canInstall) return;
    const forced = hasInstallIntent();
    // Honor explicit dismissal, but always re-show when the user
    // arrived via the ?install=1 deep link.
    if (!forced && sessionStorage.getItem(DISMISSED_KEY)) return;
    if (forced) sessionStorage.removeItem(DISMISSED_KEY);

    const timer = setTimeout(
      () => setVisible(true),
      forced ? FAST_DELAY_MS : SHOW_DELAY_MS,
    );
    return () => clearTimeout(timer);
  }, [canInstall]);

  // When arriving via /?install=1 on a browser that supports the native
  // beforeinstallprompt event (Android Chrome, desktop Chrome/Edge, Brave, …),
  // auto-fire the install prompt once it becomes available.
  useEffect(() => {
    if (!canInstall) return;
    // iOS browsers (Safari + Chrome) have no beforeinstallprompt — they
    // require manual "Add to Home Screen" steps, so never auto-fire/hide.
    if (platform === "ios-safari" || platform === "ios-chrome") return;
    if (!triggerInstallReady) return;
    if (!hasInstallIntent()) return;

    let cancelled = false;
    const timer = setTimeout(async () => {
      if (cancelled) return;
      setInstalling(true);
      try {
        await triggerInstall();
      } finally {
        if (!cancelled) {
          setInstalling(false);
          setVisible(false);
        }
      }
    }, FAST_DELAY_MS);

    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [canInstall, platform, triggerInstall, triggerInstallReady]);

  const dismiss = () => {
    setVisible(false);
    sessionStorage.setItem(DISMISSED_KEY, "1");
  };

  const handleInstall = async () => {
    if (platform === "ios-safari" || platform === "ios-chrome") return;
    setInstalling(true);
    await triggerInstall();
    setInstalling(false);
    setVisible(false);
  };

  const install = t.install;

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ y: 120, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 120, opacity: 0 }}
          transition={{ type: "spring", stiffness: 340, damping: 30 }}
          className="fixed bottom-20 left-0 right-0 z-50 flex justify-center px-4 pointer-events-none"
        >
          <div className="w-full max-w-[448px] pointer-events-auto">
            <div
              className="rounded-2xl border border-white/10 shadow-2xl shadow-black/60 overflow-hidden"
              style={{ background: "hsl(var(--card))" }}
            >
              {/* Gold top bar */}
              <div className="h-[3px] w-full" style={{ background: "linear-gradient(90deg, hsl(var(--accent)), hsl(var(--primary)))" }} />

              <div className="p-4 flex gap-3 items-start">
                {/* App icon */}
                <div className="shrink-0 w-12 h-12 rounded-xl overflow-hidden shadow-lg border border-white/10">
                  <img src="/anderspay-logo.png" alt="AndersPay+" className="w-full h-full object-cover" />
                </div>

                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm text-white leading-tight">{install.title}</p>
                  <p className="text-xs text-white/50 mt-0.5 leading-snug">{install.subtitle}</p>

                  {/* Platform-specific instruction */}
                  {platform === "ios-safari" ? (
                    <div className="mt-3 flex flex-col gap-1.5">
                      <Step n={1} icon={<Share className="w-3.5 h-3.5" />} text={install.iosStep1} />
                      <Step n={2} icon={<Plus className="w-3.5 h-3.5" />} text={install.iosStep2} />
                    </div>
                  ) : platform === "ios-chrome" ? (
                    <div className="mt-3 flex flex-col gap-1.5">
                      <Step n={1} icon={<MoreHorizontal className="w-3.5 h-3.5" />} text={install.iosChromeStep1} />
                      <Step n={2} icon={<ChevronDown className="w-3.5 h-3.5" />} text={install.iosChromeStep2} />
                      <Step n={3} icon={<Plus className="w-3.5 h-3.5" />} text={install.iosChromeStep3} />
                    </div>
                  ) : triggerInstallReady ? (
                    <button
                      onClick={handleInstall}
                      disabled={installing}
                      className="mt-3 flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold transition-opacity active:opacity-70 disabled:opacity-50"
                      style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}
                    >
                      <Download className="w-3.5 h-3.5" />
                      {installing ? install.installing : install.installBtn}
                    </button>
                  ) : platform === "android-chrome" ? (
                    // beforeinstallprompt hasn't fired yet (PWA criteria
                    // not met, or user dismissed recently). Show the
                    // exact path Chrome on Android uses: menu → Install.
                    <div className="mt-3 flex flex-col gap-1.5">
                      <Step n={1} icon={<MoreVertical className="w-3.5 h-3.5" />} text={install.androidStep1} />
                      <Step n={2} icon={<Download className="w-3.5 h-3.5" />} text={install.androidStep2} />
                    </div>
                  ) : (
                    <div className="mt-3 flex flex-col gap-1.5">
                      <Step n={1} icon={<MoreHorizontal className="w-3.5 h-3.5" />} text={install.otherStep1} />
                      <Step n={2} icon={<Plus className="w-3.5 h-3.5" />} text={install.otherStep2} />
                    </div>
                  )}
                </div>

                <button
                  onClick={dismiss}
                  className="shrink-0 w-7 h-7 rounded-full flex items-center justify-center text-white/40 hover:text-white/80 hover:bg-white/10 transition-colors -mt-0.5 -mr-0.5"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* iOS arrow pointing to share / menu button */}
              {(platform === "ios-safari" || platform === "ios-chrome") && (
                <div className="pb-3 px-4 flex items-center gap-1.5">
                  <div className="flex-1 h-px bg-white/5" />
                  <p className="text-[10px] text-white/30 text-center">
                    {platform === "ios-safari" ? install.iosTip : install.iosChromeTip}
                  </p>
                  <div className="flex-1 h-px bg-white/5" />
                </div>
              )}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function Step({ n, icon, text }: { n: number; icon: React.ReactNode; text: string }) {
  const color = "hsl(var(--accent))";
  return (
    <div className="flex items-start gap-2">
      <div
        className="w-5 h-5 rounded-full flex items-center justify-center shrink-0 text-[10px] font-bold mt-px"
        style={{ background: `${color}22`, color }}
      >
        {n}
      </div>
      <div className="flex-1 flex items-center gap-1.5">
        <span className="text-[11px] text-white/80 leading-snug">{text}</span>
        <span className="shrink-0" style={{ color }}>{icon}</span>
      </div>
    </div>
  );
}
