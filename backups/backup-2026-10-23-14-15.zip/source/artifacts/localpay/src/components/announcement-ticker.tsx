import { useMemo, useState } from "react";
import { Megaphone, Pencil, Plus, Trash2, GripVertical, ExternalLink } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

import {
  useGetAnnouncements,
  getGetAnnouncementsQueryKey,
  useAdminListAnnouncements,
  getAdminListAnnouncementsQueryKey,
  useCreateAnnouncement,
  useUpdateAnnouncement,
  useDeleteAnnouncement,
  type Announcement,
} from "@workspace/api-client-react";
import { useLang } from "@/lib/use-lang";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";

// Scrolling ad/announcement line shown under the app header. Public users
// see a single marquee line built from all active announcements; tapping a
// segment opens its ad link. Admins get a pencil button that opens a
// management dialog to add / edit / remove / toggle lines.
export default function AnnouncementTicker() {
  const { t } = useLang();
  const { user } = useAuth();
  const isAdmin = !!user?.isAdmin;
  const [manageOpen, setManageOpen] = useState(false);

  const { data } = useGetAnnouncements({
    query: { queryKey: getGetAnnouncementsQueryKey(), refetchInterval: 60_000 },
  });
  const items = useMemo(() => data?.announcements ?? [], [data]);

  if (items.length === 0 && !isAdmin) return null;

  // Duration scales with content length so long text doesn't fly by.
  const totalChars = items.reduce((n, a) => n + a.text.length, 0);
  const duration = Math.max(5, Math.min(35, totalChars * 0.18));

  return (
    <div className="mt-2 mb-1 flex items-center gap-2">
      <div className="flex-1 min-w-0 relative overflow-hidden rounded-lg border border-primary/25 bg-primary/[0.07] h-8">
        {items.length > 0 ? (
          <div className="ticker-track flex items-center h-8 whitespace-nowrap" style={{ animationDuration: `${duration}s` }}>
            {[0, 1].map((copy) => (
              <div key={copy} className="flex items-center shrink-0" aria-hidden={copy === 1}>
                {items.map((a) => (
                  <TickerItem key={`${copy}-${a.id}`} item={a} />
                ))}
              </div>
            ))}
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setManageOpen(true)}
            className="flex items-center gap-2 h-8 px-3 text-[11px] text-muted-foreground w-full"
          >
            <Megaphone className="w-3.5 h-3.5 text-primary shrink-0" />
            {t.ticker.emptyAdminHint}
          </button>
        )}
        {/* Edge fades so text slides in/out smoothly */}
        <div className="pointer-events-none absolute inset-y-0 left-0 w-4 bg-gradient-to-r from-background to-transparent" />
        <div className="pointer-events-none absolute inset-y-0 right-0 w-4 bg-gradient-to-l from-background to-transparent" />
      </div>
      {isAdmin && (
        <button
          type="button"
          onClick={() => setManageOpen(true)}
          className="shrink-0 w-8 h-8 rounded-lg border border-border bg-card flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary/50 transition-colors"
          title={t.ticker.manageTitle}
          aria-label={t.ticker.manageTitle}
        >
          <Pencil className="w-3.5 h-3.5" />
        </button>
      )}
      {isAdmin && manageOpen && <ManageDialog onClose={() => setManageOpen(false)} />}
    </div>
  );
}

function TickerItem({ item }: { item: Announcement }) {
  const content = (
    <>
      <Megaphone className="w-3 h-3 text-primary shrink-0" />
      <span className="text-[12px] font-medium text-foreground/90">{item.text}</span>
      {item.url && <ExternalLink className="w-2.5 h-2.5 text-primary/70 shrink-0" />}
    </>
  );
  const cls = "inline-flex items-center gap-1.5 px-4";
  if (item.url) {
    return (
      <a href={item.url} target="_blank" rel="noopener noreferrer" className={`${cls} hover:underline decoration-primary/60`}>
        {content}
      </a>
    );
  }
  return <span className={cls}>{content}</span>;
}

// ---------------------------------------------------------------------------
// Admin management dialog
// ---------------------------------------------------------------------------

interface DraftState {
  id: string | null; // null = creating new
  text: string;
  url: string;
  active: boolean;
  sortOrder: number;
}

function ManageDialog({ onClose }: { onClose: () => void }) {
  const { t } = useLang();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [draft, setDraft] = useState<DraftState | null>(null);

  const listQuery = useAdminListAnnouncements({
    query: { queryKey: getAdminListAnnouncementsQueryKey() },
  });
  const rows = listQuery.data?.announcements ?? [];

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: getGetAnnouncementsQueryKey() });
    queryClient.invalidateQueries({ queryKey: getAdminListAnnouncementsQueryKey() });
  };

  const onError = () =>
    toast({ title: t.ticker.saveFailed, variant: "destructive" });

  const createMut = useCreateAnnouncement({
    mutation: { onSuccess: () => { invalidate(); setDraft(null); }, onError },
  });
  const updateMut = useUpdateAnnouncement({
    mutation: { onSuccess: () => { invalidate(); setDraft(null); }, onError },
  });
  const deleteMut = useDeleteAnnouncement({
    mutation: { onSuccess: invalidate, onError },
  });

  const saving = createMut.isPending || updateMut.isPending;

  function save() {
    if (!draft || draft.text.trim().length === 0) return;
    const url = draft.url.trim();
    if (url && !/^https?:\/\//i.test(url)) {
      toast({ title: t.ticker.invalidUrl, variant: "destructive" });
      return;
    }
    const body = {
      text: draft.text.trim(),
      url: url || null,
      active: draft.active,
      sortOrder: draft.sortOrder,
    };
    if (draft.id) {
      updateMut.mutate({ announcementId: draft.id, data: body });
    } else {
      createMut.mutate({ data: body });
    }
  }

  return (
    // Input-bearing modal → open at the TOP of the screen (bottom nav
    // covers bottom-anchored dialogs). See replit.md user preferences.
    <div
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-start justify-center pt-20 overflow-y-auto px-4 pb-10"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md bg-card border border-border rounded-2xl p-5 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold text-base flex items-center gap-2">
            <Megaphone className="w-4 h-4 text-primary" />
            {t.ticker.manageTitle}
          </h2>
          <Button
            size="sm"
            className="h-8 gap-1"
            onClick={() => setDraft({ id: null, text: "", url: "", active: true, sortOrder: rows.length })}
          >
            <Plus className="w-3.5 h-3.5" />
            {t.ticker.add}
          </Button>
        </div>

        {draft && (
          <div className="mb-4 p-3 rounded-xl border border-primary/30 bg-primary/5 space-y-3">
            <div>
              <label className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">
                {t.ticker.textLabel}
              </label>
              <Input
                value={draft.text}
                maxLength={300}
                autoFocus
                onChange={(e) => setDraft({ ...draft, text: e.target.value })}
                placeholder={t.ticker.textPlaceholder}
                className="mt-1"
              />
            </div>
            <div>
              <label className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">
                {t.ticker.urlLabel}
              </label>
              <Input
                value={draft.url}
                maxLength={500}
                onChange={(e) => setDraft({ ...draft, url: e.target.value })}
                placeholder="https://..."
                inputMode="url"
                className="mt-1"
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Switch
                  checked={draft.active}
                  onCheckedChange={(v) => setDraft({ ...draft, active: v })}
                />
                <span className="text-xs text-muted-foreground">{t.ticker.activeLabel}</span>
              </div>
              <div className="flex gap-2">
                <Button variant="ghost" size="sm" onClick={() => setDraft(null)} disabled={saving}>
                  {t.ticker.cancel}
                </Button>
                <Button size="sm" onClick={save} disabled={saving || draft.text.trim().length === 0}>
                  {saving ? t.ticker.saving : t.ticker.save}
                </Button>
              </div>
            </div>
          </div>
        )}

        <div className="space-y-2 max-h-[45vh] overflow-y-auto">
          {rows.length === 0 && !draft && (
            <p className="text-xs text-muted-foreground text-center py-6">{t.ticker.emptyList}</p>
          )}
          {rows.map((a) => (
            <div
              key={a.id}
              className={`flex items-center gap-2 p-2.5 rounded-xl border ${a.active ? "border-border bg-secondary/30" : "border-border/50 bg-secondary/10 opacity-60"}`}
            >
              <GripVertical className="w-3.5 h-3.5 text-muted-foreground/50 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium truncate">{a.text}</p>
                {a.url && (
                  <p className="text-[10px] text-primary/80 truncate">{a.url}</p>
                )}
                {!a.active && (
                  <p className="text-[10px] text-muted-foreground">{t.ticker.hidden}</p>
                )}
              </div>
              <button
                type="button"
                className="w-7 h-7 rounded-lg flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors shrink-0"
                onClick={() => setDraft({ id: a.id, text: a.text, url: a.url ?? "", active: a.active, sortOrder: a.sortOrder })}
                aria-label={t.ticker.edit}
              >
                <Pencil className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                className="w-7 h-7 rounded-lg flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors shrink-0"
                onClick={() => {
                  if (window.confirm(t.ticker.deleteConfirm)) {
                    deleteMut.mutate({ announcementId: a.id });
                  }
                }}
                aria-label={t.ticker.delete}
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>

        <Button variant="outline" className="w-full mt-4" onClick={onClose}>
          {t.ticker.close}
        </Button>
      </div>
    </div>
  );
}
