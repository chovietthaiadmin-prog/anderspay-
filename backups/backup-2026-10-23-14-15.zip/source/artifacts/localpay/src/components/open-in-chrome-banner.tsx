import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Chrome, ArrowRight } from "lucide-react";
import { useLang } from "@/lib/use-lang";

const DISMISSED_KEY = "ap-chrome-banner-dismissed";

type InAppKind = "telegram" | "facebook" | "instagram" | "line" | "zalo" | "messenger" | "tiktok" | "other-inapp" | null;

function detectInAppBrowser(): { kind: InAppKind; isIos: boolean; isAndroid: boolean } {
  if (typeof navigator === "undefined") return { kind: null, isIos: false, isAndroid: false };
  const ua = navigator.userAgent || "";
  const isIos = /iphone|ipad|ipod/i.test(ua);
  const isAndroid = /android/i.test(ua);

  let kind: InAppKind = null;
  if (/Telegram/i.test(ua)) kind = "telegram";
  else if (/FBAN|FBAV|FB_IAB/i.test(ua)) kind = "facebook";
  else if (/Instagram/i.test(ua)) kind = "instagram";
  else if (/Line\//i.test(ua)) kind = "line";
  else if (/Zalo/i.test(ua)) kind = "zalo";
  else if (/Messenger/i.test(ua)) kind = "messenger";
  else if (/TikTok|musical_ly|BytedanceWebview/i.test(ua)) kind = "tiktok";
  else if (isAndroid && /; wv\)/i.test(ua)) kind = "other-inapp";

  return { kind, isIos, isAndroid };
}

function isStandalone(): boolean {
  if (typeof window === "undefined") return false;
  if ("standalone" in navigator && (navigator as { standalone?: boolean }).standalone === true) return true;
  if (window.matchMedia("(display-mode: standalone)").matches) return true;
  return false;
}

export default function OpenInChromeBanner() {
  const { t, lang } = useLang();
  const [{ kind, isIos, isAndroid }] = useState(detectInAppBrowser);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (isStandalone()) return;
    if (!kind) return;
    if (sessionStorage.getItem(DISMISSED_KEY)) return;
    setVisible(true);
  }, [kind]);

  const dismiss = () => {
    setVisible(false);
    sessionStorage.setItem(DISMISSED_KEY, "1");
  };

  const openInChrome = () => {
    const fullUrl = window.location.href;
    if (isAndroid) {
      const stripped = fullUrl.replace(/^https?:\/\//, "");
      const intent = `intent://${stripped}#Intent;scheme=https;package=com.android.chrome;end`;
      window.location.href = intent;
      return;
    }
    if (isIos) {
      const chromeUrl = fullUrl.replace(/^https/, "googlechromes").replace(/^http:/, "googlechrome:");
      window.location.href = chromeUrl;
      return;
    }
    window.location.href = fullUrl;
  };

  if (!visible) return null;

  const isVi = lang === "vi";
  const browserName = (() => {
    switch (kind) {
      case "telegram": return "Telegram";
      case "facebook": return "Facebook";
      case "instagram": return "Instagram";
      case "line": return "LINE";
      case "zalo": return "Zalo";
      case "messenger": return "Messenger";
      case "tiktok": return "TikTok";
      default: return isVi ? "trình duyệt trong app" : "in-app browser";
    }
  })();

  const title = isVi
    ? `Bạn đang mở trong ${browserName}`
    : `You are inside ${browserName}`;
  const subtitle = isVi
    ? "Để cài app vào màn hình chính, hãy mở bằng Chrome trước."
    : "To install this app to your home screen, open it in Chrome first.";
  const btn = isVi ? "Mở bằng Chrome" : "Open in Chrome";
  void t;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: -120, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: -120, opacity: 0 }}
        transition={{ type: "spring", stiffness: 320, damping: 28 }}
        className="fixed top-0 left-0 right-0 z-[110] flex justify-center px-3 pt-3 pointer-events-none"
        data-testid="open-chrome-banner"
      >
        <div className="w-full max-w-[448px] pointer-events-auto">
          <div
            className="rounded-2xl shadow-2xl shadow-black/60 overflow-hidden border"
            style={{
              background: "hsl(var(--card))",
              borderColor: "hsl(var(--primary) / 0.3)",
            }}
          >
            <div className="h-[3px] w-full" style={{ background: "linear-gradient(90deg, hsl(var(--primary)), hsl(var(--accent)))" }} />
            <div className="p-3 flex gap-3 items-center">
              <div
                className="shrink-0 w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ background: "hsl(var(--primary) / 0.15)", color: "hsl(var(--primary))" }}
              >
                <Chrome className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-[13px] text-white leading-tight">{title}</p>
                <p className="text-[11px] text-white/60 mt-0.5 leading-snug">{subtitle}</p>
                <button
                  onClick={openInChrome}
                  className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11px] font-bold transition-opacity active:opacity-70"
                  style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}
                  data-testid="btn-open-chrome"
                >
                  {btn}
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
              <button
                onClick={dismiss}
                className="shrink-0 w-7 h-7 rounded-full flex items-center justify-center text-white/40 hover:text-white/80 hover:bg-white/10"
                aria-label="dismiss"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
