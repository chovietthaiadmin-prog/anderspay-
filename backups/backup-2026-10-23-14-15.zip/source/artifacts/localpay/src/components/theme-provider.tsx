import { createContext, useContext, useEffect, useState } from "react";

type Theme = "dark" | "navy";

type ThemeProviderProps = {
  children: React.ReactNode;
  defaultTheme?: Theme;
  storageKey?: string;
};

type ThemeProviderState = {
  theme: Theme;
  setTheme: (theme: Theme) => void;
};

const initialState: ThemeProviderState = {
  theme: "dark",
  setTheme: () => null,
};

const ThemeProviderContext = createContext<ThemeProviderState>(initialState);

export function ThemeProvider({
  children,
  defaultTheme = "dark",
  storageKey = "anderspay-theme",
  ...props
}: ThemeProviderProps) {
  const [theme, setTheme] = useState<Theme>(() => {
    try {
      const stored = localStorage.getItem(storageKey);
      if (stored === "dark" || stored === "navy") return stored;
    } catch {
      // Storage can be unavailable in restrictive browser modes.
    }
    return defaultTheme;
  });

  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove("light", "navy");
    root.classList.add("dark");
    root.dataset.theme = theme;

    if (theme === "navy") {
      root.classList.add("navy");
      document.querySelector('meta[name="theme-color"]')?.setAttribute("content", "#0B1F3A");
    } else {
      document.querySelector('meta[name="theme-color"]')?.setAttribute("content", "#0b0b0b");
    }
  }, [theme]);

  const value = {
    theme,
    setTheme: (theme: Theme) => {
      try {
        localStorage.setItem(storageKey, theme);
      } catch {
        // The active in-memory theme still works when storage is unavailable.
      }
      setTheme(theme);
    },
  };

  return (
    <ThemeProviderContext.Provider {...props} value={value}>
      {children}
    </ThemeProviderContext.Provider>
  );
}

export const useTheme = () => {
  const context = useContext(ThemeProviderContext);
  return context;
};
