import { motion, AnimatePresence } from "framer-motion";
import { AlertTriangle, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/use-lang";

interface NightDelayWarningProps {
  open: boolean;
  onCancel: () => void;
  onContinue: () => void;
}

export default function NightDelayWarning({
  open,
  onCancel,
  onContinue,
}: NightDelayWarningProps) {
  const { t } = useLang();
  const c = t.nightDelay;

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-start justify-center pt-20 px-4 overflow-y-auto"
          onClick={onCancel}
          data-testid="night-delay-warning-backdrop"
        >
          <motion.div
            initial={{ scale: 0.92, y: -16, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.92, y: -16, opacity: 0 }}
            transition={{ type: "spring", stiffness: 320, damping: 26 }}
            className="w-full max-w-sm rounded-2xl bg-background border border-destructive/40 shadow-xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
            data-testid="night-delay-warning"
          >
            <div className="px-6 pt-6 pb-2 flex flex-col items-center text-center">
              <motion.div
                initial={{ scale: 0.6, rotate: -10 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: "spring", stiffness: 400, damping: 18, delay: 0.05 }}
                className="relative mb-4"
              >
                <div className="absolute inset-0 bg-destructive/30 blur-xl rounded-full" />
                <div className="relative w-16 h-16 rounded-full bg-gradient-to-br from-destructive to-destructive/80 flex items-center justify-center shadow-lg">
                  <AlertTriangle className="w-8 h-8 text-white" strokeWidth={2.5} />
                </div>
              </motion.div>
              <h2 className="text-xl font-bold text-white tracking-tight" data-testid="night-delay-title">
                {c.title}
              </h2>
              <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-accent/10 border border-accent/30">
                <Clock className="w-3.5 h-3.5 text-accent" />
                <span className="text-xs font-semibold text-accent">{c.window}</span>
              </div>
            </div>

            <div className="px-6 py-4">
              <p className="text-sm leading-relaxed text-zinc-300 text-center">
                {c.line1}
                <br />
                <span className="text-accent font-medium">{c.line2}</span>
              </p>
            </div>

            <div className="px-6 pb-6 pt-2 flex gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={onCancel}
                className="flex-1 h-11 bg-transparent border-zinc-700 text-zinc-300 hover:bg-zinc-900 hover:text-white"
                data-testid="night-delay-cancel"
              >
                {c.cancel}
              </Button>
              <Button
                type="button"
                onClick={onContinue}
                className="flex-1 h-11 bg-gradient-to-r from-destructive to-destructive/80 hover:from-destructive/90 hover:to-destructive/70 text-white font-semibold shadow-lg shadow-destructive/20"
                data-testid="night-delay-continue"
              >
                {c.continue}
              </Button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
