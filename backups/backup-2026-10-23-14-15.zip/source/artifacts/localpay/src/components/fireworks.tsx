import { useEffect, useRef, useCallback } from "react";

// ─── Colour palette — amber/gold + primary red + white sparkles ───────────────
const COLORS = [
  "#fbbf24", "#f59e0b", "#fcd34d", // amber family
  "#ff3b3b", "#ff6b6b", "#ff5555", // red/primary family
  "#ffffff", "#e5e5e5",             // white sparkles
  "#a78bfa", "#60a5fa",             // accent pops
];

interface Particle {
  x: number; y: number;
  vx: number; vy: number;
  alpha: number; decay: number;
  color: string; size: number;
  gravity: number;
  tail: { x: number; y: number; a: number }[];
}

interface Rocket {
  x: number; y: number;
  vy: number; targetY: number;
  exploded: boolean;
  color: string;
  trail: { x: number; y: number }[];
}

function rand(min: number, max: number) {
  return min + Math.random() * (max - min);
}

function createExplosion(x: number, y: number, color: string, count = 60): Particle[] {
  const particles: Particle[] = [];
  for (let i = 0; i < count; i++) {
    const angle = (Math.PI * 2 * i) / count + rand(-0.3, 0.3);
    const speed = rand(1.5, 6);
    particles.push({
      x, y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed - rand(0, 1),
      alpha: 1,
      decay: rand(0.012, 0.025),
      color: Math.random() < 0.15 ? "#ffffff" : color,
      size: rand(1.5, 3.5),
      gravity: rand(0.05, 0.12),
      tail: [],
    });
  }
  return particles;
}

export default function Fireworks() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number | null>(null);
  const activeRef = useRef(false);

  const launch = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || activeRef.current) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    // Origin: bottom-center, roughly where the pay button lives
    const originX = canvas.width / 2;
    const originY = canvas.height - 80;

    // Create 6 rockets with slight horizontal spread
    const rockets: Rocket[] = Array.from({ length: 6 }, (_, i) => {
      const spreadX = (i - 2.5) * 30 + rand(-15, 15);
      return {
        x: originX + spreadX,
        y: originY,
        vy: rand(-14, -10),
        targetY: rand(canvas.height * 0.12, canvas.height * 0.45),
        exploded: false,
        color: COLORS[Math.floor(Math.random() * COLORS.length)],
        trail: [],
      };
    });

    let particles: Particle[] = [];
    activeRef.current = true;

    const tick = () => {
      ctx.fillStyle = "rgba(0,0,0,0.18)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // ── Rockets ──────────────────────────────────────────────────────────
      for (const r of rockets) {
        if (r.exploded) continue;

        r.trail.push({ x: r.x, y: r.y });
        if (r.trail.length > 8) r.trail.shift();

        // Draw trail
        r.trail.forEach((pt, i) => {
          const a = (i / r.trail.length) * 0.7;
          ctx.beginPath();
          ctx.arc(pt.x, pt.y, 1.5, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(255,220,100,${a})`;
          ctx.fill();
        });

        // Draw rocket head
        ctx.beginPath();
        ctx.arc(r.x, r.y, 2.5, 0, Math.PI * 2);
        ctx.fillStyle = r.color;
        ctx.fill();

        r.y += r.vy;
        r.vy += 0.18; // gravity pulling back

        if (r.y <= r.targetY) {
          r.exploded = true;
          particles.push(...createExplosion(r.x, r.y, r.color, 55));
          // Secondary glitter burst
          particles.push(...createExplosion(r.x, r.y, "#ffffff", 15));
        }
      }

      // ── Particles ─────────────────────────────────────────────────────────
      particles = particles.filter((p) => p.alpha > 0.02);

      for (const p of particles) {
        // Store tail point
        p.tail.push({ x: p.x, y: p.y, a: p.alpha });
        if (p.tail.length > 4) p.tail.shift();

        // Draw tail
        p.tail.forEach((pt, i) => {
          const a = (i / p.tail.length) * pt.a * 0.5;
          ctx.beginPath();
          ctx.arc(pt.x, pt.y, p.size * 0.6, 0, Math.PI * 2);
          ctx.fillStyle = p.color.startsWith("rgba")
            ? p.color
            : hexAlpha(p.color, a);
          ctx.fill();
        });

        // Draw particle
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = hexAlpha(p.color, p.alpha);
        ctx.fill();

        // Shimmer sparkle on bright particles
        if (p.size > 2.5 && p.alpha > 0.6) {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * 0.35, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(255,255,255,${p.alpha * 0.6})`;
          ctx.fill();
        }

        p.x += p.vx;
        p.y += p.vy;
        p.vy += p.gravity;
        p.vx *= 0.97;
        p.alpha -= p.decay;
      }

      // Stop when all done
      const allExploded = rockets.every((r) => r.exploded);
      if (allExploded && particles.length === 0) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        activeRef.current = false;
        return;
      }

      animRef.current = requestAnimationFrame(tick);
    };

    animRef.current = requestAnimationFrame(tick);
  }, []);

  useEffect(() => {
    const onVisible = () => {
      if (!document.hidden) {
        // Small delay so the page finishes compositing before we draw
        setTimeout(launch, 350);
      }
    };

    document.addEventListener("visibilitychange", onVisible);
    return () => {
      document.removeEventListener("visibilitychange", onVisible);
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [launch]);

  return (
    <canvas
      ref={canvasRef}
      className="pointer-events-none fixed inset-0 z-[999]"
      style={{ mixBlendMode: "screen" }}
    />
  );
}

// Hex color → rgba string helper
function hexAlpha(hex: string, alpha: number): string {
  if (hex.startsWith("rgba") || hex.startsWith("rgb")) {
    return hex.replace(/[\d.]+\)$/, `${alpha.toFixed(3)})`);
  }
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r},${g},${b},${alpha.toFixed(3)})`;
}
