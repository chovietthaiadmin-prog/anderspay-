import type { WalletRiskReport } from "@workspace/api-client-react";

type Props = { network: WalletRiskReport["network"]; wallet: WalletRiskReport["wallet"]; address: string; lang: string };

const copy = {
  vi: {
    title: "Thông tin ví trên chuỗi",
    balances: "Số dư hiện tại",
    first: "Mốc thời gian",
    activation: "Kích hoạt tài khoản",
    contract: "Tạo hợp đồng",
    observed: "Hoạt động đầu tiên quan sát được",
    unknown: "Chưa xác định được",
    creationNote: "Ví EVM thông thường không có thời điểm tạo được ghi trên chuỗi. Mốc này chỉ phản ánh hoạt động sớm nhất tìm được.",
    bscNote: "Nguồn BNB hiện không cung cấp toàn bộ lịch sử cũ để xác định lần hoạt động đầu tiên của ví thông thường.",
    latest: "10 giao dịch gần nhất",
    none: "Chưa thấy giao dịch trong dữ liệu trả về.",
    unavailable: "Dữ liệu ví tạm thời không khả dụng. Các cảnh báo rủi ro bên dưới vẫn được kiểm tra riêng.",
    partial: "Một phần dữ liệu không khả dụng hoặc nguồn chỉ cung cấp lịch sử giới hạn.",
    inbound: "Nhận",
    outbound: "Gửi",
    self: "Nội bộ",
    interaction: "Tương tác hợp đồng",
    view: "Xem giao dịch",
    attribution: "Dữ liệu: ",
  },
  en: {
    title: "On-chain wallet information",
    balances: "Current balances",
    first: "Timeline",
    activation: "Account activation",
    contract: "Contract creation",
    observed: "Earliest observed activity",
    unknown: "Not available",
    creationNote: "Ordinary EVM wallets have no on-chain creation timestamp. This is only the earliest activity found.",
    bscNote: "The current BNB source cannot search all older history to find an ordinary wallet's first activity.",
    latest: "10 latest transactions",
    none: "No transactions found in the returned data.",
    unavailable: "Wallet data is temporarily unavailable. Risk warnings below are checked separately.",
    partial: "Some wallet data is unavailable or the source has limited history.",
    inbound: "Received",
    outbound: "Sent",
    self: "Self",
    interaction: "Contract interaction",
    view: "View transaction",
    attribution: "Data: ",
  },
};

function compact(address: string) {
  return address.length > 18 ? `${address.slice(0, 8)}…${address.slice(-6)}` : address;
}

export default function WalletOverviewCard({ network, wallet, address, lang }: Props) {
  const text = lang === "vi" ? copy.vi : copy.en;
  const locale = lang === "vi" ? "vi-VN" : "en-US";
  const time = (date: string) => new Date(date).toLocaleString(locale);
  const explorer = network === "bsc" ? "https://bscscan.com/tx/"
    : network === "tron" ? "https://tronscan.org/#/transaction/" : "https://etherscan.io/tx/";
  const firstLabel = wallet.firstActivityKind === "account_activation" ? text.activation
    : wallet.firstActivityKind === "contract_creation" ? text.contract : text.observed;

  return (
    <section className="rounded-xl border border-border bg-background/40 p-3" aria-label={text.title}>
      <div className="mb-3 flex items-center justify-between gap-2">
        <h3 className="text-xs font-bold">{text.title}</h3>
        <span className="text-[10px] text-muted-foreground">{text.attribution}<a href={wallet.provider === "Etherscan" ? "https://bscscan.com/" : network === "bsc" ? "https://binplorer.com/" : network === "tron" ? "https://tronscan.org/" : "https://routescan.io/"} target="_blank" rel="noopener noreferrer" className="text-accent underline">{wallet.provider}</a></span>
      </div>
      {wallet.status === "unavailable" ? (
        <p className="text-xs text-muted-foreground">{text.unavailable}</p>
      ) : (
        <>
          {wallet.status === "partial" && <p className="mb-3 rounded-lg border border-amber-400/20 bg-amber-400/5 p-2 text-[11px] text-amber-200">{text.partial}</p>}
          <p className="mb-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{text.balances}</p>
          <div className="mb-3 grid grid-cols-2 gap-2">
            <div className="min-w-0 rounded-lg border border-border p-2">
              <p className="text-[10px] text-muted-foreground">{wallet.nativeSymbol}</p>
              <p className="truncate text-sm font-semibold tabular-nums" title={wallet.nativeBalance ?? undefined}>{wallet.nativeBalance ?? "—"}</p>
            </div>
            <div className="min-w-0 rounded-lg border border-border p-2">
              <p className="text-[10px] text-muted-foreground">USDT</p>
              <p className="truncate text-sm font-semibold tabular-nums" title={wallet.usdtBalance ?? undefined}>{wallet.usdtBalance ?? "—"}</p>
            </div>
          </div>
          <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{text.first}</p>
          <p className="mt-1 text-xs"><span className="text-muted-foreground">{firstLabel}: </span>{wallet.firstActivityAt ? time(wallet.firstActivityAt) : text.unknown}</p>
          {network === "bsc" && wallet.firstActivityKind !== "contract_creation" && wallet.provider === "Binplorer" && <p className="mt-1 text-[10px] leading-relaxed text-muted-foreground">{text.bscNote}</p>}
          {network !== "tron" && wallet.firstActivityKind === "earliest_observed" && <p className="mt-1 text-[10px] leading-relaxed text-muted-foreground">{text.creationNote}</p>}
          <h4 className="mt-4 mb-2 text-xs font-bold">{text.latest}</h4>
          {wallet.transactions.length === 0 ? <p className="text-xs text-muted-foreground">{text.none}</p> : (
            <ul className="space-y-2">
              {wallet.transactions.map((tx) => {
                const validHash = /^(0x)?[a-fA-F0-9]{64}$/.test(tx.hash);
                return (
                  <li key={tx.hash} className="rounded-lg border border-border p-2">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold">{tx.direction === "out" ? text.outbound : tx.direction === "self" ? text.self : text.inbound} · {tx.amount === null ? text.interaction : `${tx.amount} ${tx.symbol}`}</span>
                      <time dateTime={tx.timestamp} className="shrink-0 text-[10px] text-muted-foreground">{time(tx.timestamp)}</time>
                    </div>
                    <p className="mt-1 truncate font-mono text-[10px] text-muted-foreground" title={`${tx.from} → ${tx.to}`}>{compact(tx.from || address)} → {compact(tx.to || address)}</p>
                    {validHash && <a href={`${explorer}${tx.hash}`} target="_blank" rel="noopener noreferrer" className="mt-1 inline-block text-[10px] text-accent underline" aria-label={`${text.view}: ${tx.hash}`}>{text.view} ↗</a>}
                  </li>
                );
              })}
            </ul>
          )}
          {wallet.checkedAt && <p className="mt-2 text-[10px] text-muted-foreground">{time(wallet.checkedAt)}</p>}
        </>
      )}
    </section>
  );
}