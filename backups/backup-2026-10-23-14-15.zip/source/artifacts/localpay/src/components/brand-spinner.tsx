import { cn } from "@/lib/utils";

/**
 * AndersPay+ brand loading spinner.
 *
 * Three rotating arcs in the brand colors — black (#0b0b0b), red (#ff3b3b),
 * and gold (#f5c542) — on a white circular plate so all three stripes stay
 * visible on both the dark and light themes. Mirrored in `index.html` as
 * inline CSS for the initial splash.
 */
export function BrandSpinner({
  className,
  size = 32,
}: {
  className?: string;
  size?: number;
}) {
  // The visible plate is `size`; the SVG inside is slightly inset so the
  // arc strokes don't get clipped by the plate's edge.
  const inner = size - 4;
  const stroke = Math.max(2, Math.round(inner / 10));
  const r = (inner - stroke) / 2;
  const c = inner / 2;
  const circumference = 2 * Math.PI * r;
  const arc = circumference * 0.28;
  const gap = circumference - arc;
  const offset = circumference / 3;

  return (
    <span
      role="status"
      aria-label="Loading"
      className={cn(
        "inline-flex items-center justify-center rounded-full bg-white shadow-sm",
        className,
      )}
      style={{ width: size, height: size }}
    >
      <span
        className="inline-block animate-spin"
        style={{ width: inner, height: inner, animationDuration: "0.9s" }}
      >
        <svg width={inner} height={inner} viewBox={`0 0 ${inner} ${inner}`} fill="none">
          <circle
            cx={c}
            cy={c}
            r={r}
            stroke="hsl(var(--foreground))"
            strokeWidth={stroke}
            strokeLinecap="round"
            strokeDasharray={`${arc} ${gap}`}
            strokeDashoffset={0}
          />
          <circle
            cx={c}
            cy={c}
            r={r}
            stroke="hsl(var(--primary))"
            strokeWidth={stroke}
            strokeLinecap="round"
            strokeDasharray={`${arc} ${gap}`}
            strokeDashoffset={-offset}
          />
          <circle
            cx={c}
            cy={c}
            r={r}
            stroke="hsl(var(--accent))"
            strokeWidth={stroke}
            strokeLinecap="round"
            strokeDasharray={`${arc} ${gap}`}
            strokeDashoffset={-2 * offset}
          />
        </svg>
      </span>
    </span>
  );
}
