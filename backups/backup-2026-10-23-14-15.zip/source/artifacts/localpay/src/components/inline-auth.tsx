import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Mail } from "lucide-react";
import { useAuth, type TelegramLoginPayload } from "@/lib/auth";
import { useLang } from "@/lib/use-lang";
import { Card, CardContent } from "@/components/ui/card";
import TelegramLoginButton from "@/components/telegram-login-button";
import EmailAuth from "@/components/email-auth";
import { ToastAction } from "@/components/ui/toast";
import { useToast } from "@/hooks/use-toast";
import { TELEGRAM_BOT_URL } from "@/components/telegram-start-notice";

export default function InlineAuth() {
  const { loginWithTelegram } = useAuth();
  const { t } = useLang();
  const at = t.auth;
  const { toast } = useToast();

  const [authMethod, setAuthMethod] = useState<"chooser" | "telegram" | "email">("chooser");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Remember last auth method
  useEffect(() => {
    const saved = localStorage.getItem("ap-last-auth-method");
    if (saved === "telegram" || saved === "email") {
      setAuthMethod(saved);
    }
  }, []);

  const reset = () => {
    setError(""); setLoading(false);
    setAuthMethod("chooser");
  };

  const handleMethodSelect = (method: "telegram" | "email") => {
    setAuthMethod(method);
    localStorage.setItem("ap-last-auth-method", method);
  };

  const handleTelegramAuth = async (payload: TelegramLoginPayload) => {
    if (loading) return;
    setLoading(true);
    setError("");
    try {
      await loginWithTelegram(payload);
      toast({
        title: at.telegramStartTitle,
        description: at.telegramStartDescription,
        duration: 12000,
        action: (
          <ToastAction altText={at.telegramStartButton} asChild>
            <a href={TELEGRAM_BOT_URL} target="_blank" rel="noreferrer">
              {at.telegramStartButton}
            </a>
          </ToastAction>
        ),
      });
      reset();
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : "";
      setError(msg || at.loginError);
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
      <Card className="border-border bg-card overflow-hidden relative">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary to-accent opacity-70" />
        <CardContent className="p-4 flex flex-col gap-3">

          <AnimatePresence mode="wait">
            {authMethod === "chooser" ? (
              <motion.div
                key="chooser"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex flex-col gap-3"
              >
                <p className="text-sm font-semibold text-center">{at.methodChooser}</p>
                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => handleMethodSelect("telegram")}
                    className="flex items-center gap-3 p-3 rounded-xl bg-accent/10 border border-accent/30 hover:bg-accent/20 transition-colors"
                  >
                    <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center shrink-0">
                      <Send className="w-4 h-4 text-accent" />
                    </div>
                    <div className="flex-1 text-left">
                      <p className="text-xs font-bold">{at.continueWithTelegram}</p>
                      <p className="text-[10px] text-muted-foreground">{at.telegramOtpHint}</p>
                    </div>
                  </button>

                  <button
                    onClick={() => handleMethodSelect("email")}
                    className="flex items-center gap-3 p-3 rounded-xl bg-primary/10 border border-primary/30 hover:bg-primary/20 transition-colors"
                  >
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
                      <Mail className="w-4 h-4 text-primary" />
                    </div>
                    <div className="flex-1 text-left">
                      <p className="text-xs font-bold">{at.continueWithEmail}</p>
                      <p className="text-[10px] text-muted-foreground truncate">{at.emailOtpHint}</p>
                    </div>
                  </button>
                </div>
              </motion.div>
            ) : authMethod === "email" ? (
              <EmailAuth
                onSuccess={reset}
                onBack={() => setAuthMethod("chooser")}
              />
            ) : (
              <motion.div
                key="form"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="flex flex-col gap-3"
              >
                <div className="flex flex-col gap-2.5">
                  {/* Telegram one-click login */}
                  <TelegramLoginButton
                    onAuth={handleTelegramAuth}
                    disabled={loading}
                    label={at.telegramOneClickLogin}
                  />
                  {error && (
                    <p className="text-xs text-red-400 text-center bg-red-500/10 py-1.5 px-3 rounded-lg">{error}</p>
                  )}
                </div>

                <button
                  onClick={() => { setAuthMethod("chooser"); setError(""); }}
                  className="text-center text-xs text-muted-foreground hover:text-primary transition-colors"
                >
                  {at.backToLogin}
                </button>
              </motion.div>
            )}
          </AnimatePresence>

        </CardContent>
      </Card>
    </motion.div>
  );
}
