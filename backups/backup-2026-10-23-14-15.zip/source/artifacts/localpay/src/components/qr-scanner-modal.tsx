import { useEffect, useRef, useState, useCallback } from "react";
import jsQR from "jsqr";
import { motion, AnimatePresence } from "framer-motion";
import { X, QrCode, AlertCircle, Flashlight } from "lucide-react";
import { parsePromPayQr, type PromPayInfo } from "@/lib/parse-promptpay-qr";
import { useLang } from "@/lib/use-lang";

interface QrScannerModalProps {
  open: boolean;
  onClose: () => void;
  onResult: (info: PromPayInfo, rawData: string) => void;
}

export default function QrScannerModal({ open, onClose, onResult }: QrScannerModalProps) {
  const { t } = useLang();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number>(0);
  const [error, setError] = useState<string | null>(null);
  const [scanning, setScanning] = useState(false);
  const [flash, setFlash] = useState(false);
  const [found, setFound] = useState(false);
  const [rejectMsg, setRejectMsg] = useState<string | null>(null);
  const lastRejectRef = useRef<{ data: string; at: number }>({ data: "", at: 0 });

  const stopCamera = useCallback(() => {
    cancelAnimationFrame(rafRef.current);
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  }, []);

  const startCamera = useCallback(async () => {
    setError(null);
    setFound(false);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        setScanning(true);
      }
    } catch (e) {
      setError(t.scan.cameraError);
    }
  }, [t]);

  // Scan loop
  useEffect(() => {
    if (!scanning) return;
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!canvas || !video) return;
    const ctx = canvas.getContext("2d", { willReadFrequently: true })!;

    const tick = () => {
      if (video.readyState === video.HAVE_ENOUGH_DATA) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        // attemptBoth is slower but reads inverted/low-contrast prints that
        // dontInvert misses (very common with phone-photo'd PromPay QRs).
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: "attemptBoth",
        });
        if (code && code.data) {
          // A Thai QR AID is the authoritative signal that this is a supported
          // PromptPay / Thai QR payment. Different banks (KBank, SCB, BBL …)
          // reuse nested field 03 for account references, so we must not
          // reject QR codes by nested field number. Native wallet QR codes
          // do not carry the Thai QR AID and are rejected by the parser.
          const info = parsePromPayQr(code.data);
          if (info) {
            setFound(true);
            stopCamera();
            const rawData = code.data;
            setTimeout(() => {
              onResult(info, rawData);
              onClose();
            }, 600);
            return;
          }
          // Detected a QR but it's not a PromPay code at all. Surface a
          // visible message so the user knows the camera/scanner is fine —
          // it's the QR that's unsupported. Throttle by raw data so the
          // banner doesn't flicker on every frame.
          const now = Date.now();
          if (
            lastRejectRef.current.data !== code.data ||
            now - lastRejectRef.current.at > 2000
          ) {
            lastRejectRef.current = { data: code.data, at: now };
            const msg = t.scan.notPromPay;
            setRejectMsg(msg);
            window.setTimeout(() => {
              setRejectMsg((cur) => (cur === msg ? null : cur));
            }, 2200);
          }
        }
      }
      rafRef.current = requestAnimationFrame(tick);
    };

    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [scanning, stopCamera, onResult, onClose, t]);

  useEffect(() => {
    if (open) {
      startCamera();
    } else {
      setScanning(false);
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [open, startCamera, stopCamera]);

  const toggleFlash = async () => {
    const track = streamRef.current?.getVideoTracks()[0];
    if (!track) return;
    try {
      const current = flash;
      await track.applyConstraints({ advanced: [{ torch: !current } as MediaTrackConstraintSet] });
      setFlash(!current);
    } catch {
      // Flash not supported on this device
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] bg-black flex flex-col"
        >
          {/* Header */}
          <div className="flex items-center justify-between px-5 pt-12 pb-4 bg-gradient-to-b from-black/80 to-transparent absolute top-0 left-0 right-0 z-10">
            <div className="flex-1 min-w-0">
              <h2 className="text-white font-bold text-lg">{t.scan.title}</h2>
              <p className="text-white/60 text-xs">{t.scan.subtitle}</p>
              <div className="inline-flex items-center gap-1.5 mt-2 px-2 py-1 rounded-md bg-primary/20 border border-primary/40">
                <span className="text-sm leading-none">🇹🇭</span>
                <span className="text-[11px] font-bold text-white leading-none">{t.scan.onlyPromPay}</span>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={toggleFlash}
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${flash ? "bg-yellow-400 text-black" : "bg-white/10 text-white"}`}
              >
                <Flashlight className="w-5 h-5" />
              </button>
              <button
                onClick={() => { stopCamera(); onClose(); }}
                className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center"
              >
                <X className="w-5 h-5 text-white" />
              </button>
            </div>
          </div>

          {/* Camera feed */}
          {error ? (
            <div className="flex-1 flex flex-col items-center justify-center gap-4 px-8 text-center">
              <div className="w-16 h-16 rounded-full bg-red-500/20 flex items-center justify-center">
                <AlertCircle className="w-8 h-8 text-red-400" />
              </div>
              <p className="text-white font-semibold">{t.scan.cameraError}</p>
              <p className="text-white/50 text-sm">{t.scan.cameraErrorHint}</p>
              <button
                onClick={startCamera}
                className="mt-2 px-6 py-3 bg-primary text-white rounded-xl font-semibold text-sm"
              >
                {t.scan.retry}
              </button>
            </div>
          ) : (
            <div className="flex-1 relative overflow-hidden">
              <video
                ref={videoRef}
                className="absolute inset-0 w-full h-full object-cover"
                muted
                playsInline
              />
              <canvas ref={canvasRef} className="hidden" />

              {/* Scan frame overlay */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="relative">
                  {/* Dimmed border areas via box shadow */}
                  <div
                    className={`w-64 h-64 relative transition-all duration-300 ${found ? "scale-95 opacity-80" : ""}`}
                    style={{ boxShadow: "0 0 0 9999px rgba(0,0,0,0.55)" }}
                  >
                    {/* Corner markers */}
                    {[
                      "top-0 left-0 border-t-4 border-l-4 rounded-tl-xl",
                      "top-0 right-0 border-t-4 border-r-4 rounded-tr-xl",
                      "bottom-0 left-0 border-b-4 border-l-4 rounded-bl-xl",
                      "bottom-0 right-0 border-b-4 border-r-4 rounded-br-xl",
                    ].map((cls, i) => (
                      <div
                        key={i}
                        className={`absolute w-8 h-8 ${cls} ${found ? "border-green-400" : "border-primary"} transition-colors duration-300`}
                      />
                    ))}

                    {/* Scan line animation */}
                    {!found && (
                      <motion.div
                        className="absolute left-2 right-2 h-0.5 bg-primary/80 rounded-full"
                        animate={{ top: ["8px", "248px", "8px"] }}
                        transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut" }}
                      />
                    )}

                    {/* Success indicator */}
                    {found && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="w-16 h-16 rounded-full bg-green-400 flex items-center justify-center"
                        >
                          <svg className="w-9 h-9 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                          </svg>
                        </motion.div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Transient reject banner — shown when a QR is detected but
                  is not an accepted PromPay code (TrueMoney, e-wallet,
                  random non-PromPay QR, etc.). */}
              <AnimatePresence>
                {rejectMsg && !found && (
                  <motion.div
                    initial={{ opacity: 0, y: -8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -8 }}
                    className="absolute left-1/2 -translate-x-1/2 top-32 z-20 px-3 py-2 rounded-lg bg-red-500/95 text-white text-xs font-semibold shadow-lg flex items-center gap-1.5 max-w-[85%]"
                  >
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span className="leading-tight">{rejectMsg}</span>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Bottom hint */}
              <div className="absolute bottom-0 left-0 right-0 px-6 pb-12 pt-20 bg-gradient-to-t from-black/80 to-transparent text-center">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <QrCode className="w-4 h-4 text-white/60" />
                  <p className="text-white/70 text-sm">{t.scan.hint}</p>
                </div>
                <p className="text-white/40 text-xs">{t.scan.hint2}</p>
                <p className="text-amber-300/80 text-[11px] mt-2 font-medium">⚠️ {t.scan.noTrueMoney}</p>
              </div>
            </div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
