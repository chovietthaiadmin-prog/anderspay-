import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Fingerprint, Lock, LogOut } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/lib/auth";
import { useLang } from "@/lib/use-lang";
import {
  authenticatePasskey,
  fetchSecurityStatus,
  isPasskeySupported,
  markUnlocked,
  setLockEnabled,
  verifyPin,
  type SecurityStatus,
} from "@/lib/security";

interface Props {
  onUnlock: () => void;
}

export default function LockScreen({ onUnlock }: Props) {
  const { token, logout } = useAuth();
  const { t } = useLang();
  const ts = t.settings;
  const [status, setStatus] = useState<SecurityStatus | null>(null);
  const [pin, setPin] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [bioBusy, setBioBusy] = useState(false);

  useEffect(() => {
    if (!token) return;
    let cancelled = false;
    const load = () => {
      fetchSecurityStatus(token)
        .then((s) => {
          if (cancelled) return;
          setStatus(s);
          setError(null);
          // If lock was on but no methods exist (e.g. server-side reset),
          // unlock automatically so the user is not stranded.
          if (!s.pinEnabled && s.passkeys.length === 0) {
            setLockEnabled(false);
            markUnlocked();
            onUnlock();
          }
        })
        .catch(() => {
          if (cancelled) return;
          // Stay locked on error — never fail open. Show retry.
          setError("network");
        });
    };
    load();
    return () => { cancelled = true; };
  }, [token, onUnlock]);

  const tryBio = async () => {
    if (!token) return;
    setBioBusy(true);
    setError(null);
    try {
      await authenticatePasskey(token);
      markUnlocked();
      onUnlock();
    } catch {
      setError(ts.lockBioFailed);
    } finally {
      setBioBusy(false);
    }
  };

  // Auto-prompt biometric if it's the only method available.
  useEffect(() => {
    if (!status) return;
    if (!status.pinEnabled && status.passkeys.length > 0 && isPasskeySupported()) {
      void tryBio();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status]);

  const submitPin = async () => {
    if (!token) return;
    if (!/^\d{6}$/.test(pin)) {
      setError(ts.pinFormat);
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await verifyPin(token, pin);
      markUnlocked();
      onUnlock();
    } catch {
      setError(ts.pinWrong);
      setPin("");
    } finally {
      setBusy(false);
    }
  };

  const handleLogout = () => {
    logout();
    setLockEnabled(false);
    onUnlock();
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 z-[300] bg-background flex flex-col items-center justify-center p-6"
    >
      <div className="flex flex-col items-center gap-6 w-full max-w-xs">
        <div className="w-16 h-16 rounded-2xl bg-primary/15 flex items-center justify-center">
          <Lock className="w-8 h-8 text-primary" />
        </div>
        <div className="text-center">
          <h1 className="text-xl font-bold">{ts.lockHeader}</h1>
        </div>

        {status?.passkeys.length ? (
          <button
            onClick={tryBio}
            disabled={bioBusy || !isPasskeySupported()}
            className="w-full py-3 rounded-xl bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 font-bold flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <Fingerprint className="w-5 h-5" />
            {bioBusy ? "…" : ts.lockUseBio}
          </button>
        ) : null}

        {status?.pinEnabled && (
          <div className="w-full flex flex-col gap-2">
            {status.passkeys.length > 0 && (
              <p className="text-xs text-center text-muted-foreground">{ts.lockOrPin}</p>
            )}
            <Input
              autoFocus={!status.passkeys.length}
              inputMode="numeric"
              maxLength={6}
              value={pin}
              onChange={(e) => { setPin(e.target.value.replace(/\D/g, "").slice(0, 6)); setError(null); }}
              onKeyDown={(e) => { if (e.key === "Enter") void submitPin(); }}
              placeholder="••••••"
              className="text-center font-mono text-2xl tracking-[0.5em] h-14"
            />
            <button
              onClick={submitPin}
              disabled={busy || pin.length !== 6}
              className="py-3 rounded-xl bg-primary text-white font-bold disabled:opacity-40"
            >
              {busy ? "…" : ts.lockHeader}
            </button>
          </div>
        )}

        {error && error !== "network" && <p className="text-sm text-red-400">{error}</p>}
        {!status && error === "network" && (
          <button
            onClick={() => window.location.reload()}
            className="text-sm text-red-400 underline"
          >
            Retry
          </button>
        )}

        <button
          onClick={handleLogout}
          className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1.5 mt-2"
        >
          <LogOut className="w-3.5 h-3.5" />
          {ts.lockLogout}
        </button>
      </div>
    </motion.div>
  );
}
