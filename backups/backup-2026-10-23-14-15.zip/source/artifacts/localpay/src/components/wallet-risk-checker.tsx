import { useRef, useState, type FormEvent } from "react";
import { AlertTriangle, ArrowRight, CheckCircle2, Loader2, SearchCheck, ShieldAlert, ShieldCheck } from "lucide-react";
import { useCheckWalletRisk, type WalletRiskInput, type WalletRiskReport } from "@workspace/api-client-react";
import { useLang } from "@/lib/use-lang";
import { useAuth } from "@/lib/auth";
import { WALLET_ADDRESSES } from "@/lib/wallet-config";
import WalletOverviewCard from "./wallet-overview-card";

const copy = {
  vi: {
    title: "Kiểm tra rủi ro ví",
    subtitle: "Đối chiếu cảnh báo độc lập trước khi chuyển USDT",
    address: "Địa chỉ ví cần kiểm tra",
    placeholder: "Dán địa chỉ ví vào đây",
    submit: "Kiểm tra ví",
    checking: "Đang đối chiếu dữ liệu từ các nguồn...",
    invalid: "Địa chỉ không đúng định dạng của mạng đã chọn.",
    unavailable: "Chưa thể kiểm tra nguồn dữ liệu lúc này. Vui lòng thử lại.",
    limit: "Bạn đã kiểm tra quá nhiều lần. Vui lòng thử lại sau một phút.",
    no_flags: "Chưa phát hiện dấu hiệu cảnh báo",
    caution: "Cần chú ý",
    high: "Rủi ro cao",
    critical: "Rủi ro nghiêm trọng",
    checked: "Đã kiểm tra",
    not_configured: "Chưa cấu hình",
    consistent: "Hai nguồn không bất đồng về việc có cảnh báo. Điều này không đảm bảo ví an toàn.",
    disagreement: "Hai nguồn bất đồng: chỉ một nguồn ghi nhận cảnh báo. Không gộp điểm giữa các nguồn.",
    incomplete: "Chưa thể đối chiếu đầy đủ vì ít nhất một nguồn chưa có kết quả.",
    notConfiguredNote: "Cần cấu hình khóa API Chainabuse để tra cứu nguồn này.",
    sourceUnavailable: "Nguồn này tạm thời chưa phản hồi. Kết quả của nguồn còn lại vẫn được giữ.",
    noReports: "Chưa tìm thấy báo cáo địa chỉ trên Chainabuse.",
    report: "báo cáo",
    reviewed: "Đã được kiểm tra",
    unreviewed: "Chưa được kiểm tra",
    trusted: "Người gửi đã được xác minh",
    communityReport: "Báo cáo cộng đồng",
    sourceDisclaimer: "Mỗi nguồn được hiển thị riêng. Chỉ số GoPlus không phải phần trăm xác suất; số báo cáo Chainabuse không phải điểm rủi ro.",
    safeNote: "Không có cảnh báo không có nghĩa là ví an toàn. Hãy tự xác minh người nhận trước khi chuyển tiền.",
    riskNote: "Nên xác minh lại người nhận và cân nhắc không chuyển tiền tới địa chỉ này.",
    indicator: "Chỉ số GoPlus",
    findings: "Dấu hiệu được phát hiện",
    officialWallet: "Địa chỉ nạp chính thức của AndersPay+. Số dư và lịch sử không hiển thị trong ứng dụng.",
    openExplorer: "Tự tra cứu trên blockchain explorer",
  },
  en: {
    title: "Wallet risk check",
    subtitle: "Compare independent warnings before sending USDT",
    address: "Wallet address to check",
    placeholder: "Paste a wallet address",
    submit: "Check wallet",
    checking: "Checking independent sources...",
    invalid: "This address is not valid for the selected network.",
    unavailable: "Risk data is unavailable. Please try again later.",
    limit: "Too many checks. Please try again in a minute.",
    no_flags: "No warning signals found",
    caution: "Use caution",
    high: "High risk",
    critical: "Critical risk",
    checked: "Checked",
    not_configured: "Not configured",
    consistent: "The sources do not disagree on whether they found a warning. This does not mean the wallet is safe.",
    disagreement: "Sources disagree: only one source found a warning. Their scores are not combined.",
    incomplete: "A full comparison is not available because at least one source could not be checked.",
    notConfiguredNote: "A Chainabuse API key is required to check this source.",
    sourceUnavailable: "This source did not respond. Results from the other source are preserved.",
    noReports: "No address reports were found on Chainabuse.",
    report: "reports",
    reviewed: "Reviewed",
    unreviewed: "Not reviewed",
    trusted: "Verified reporter",
    communityReport: "Community report",
    sourceDisclaimer: "Each source is shown separately. The GoPlus index is not a probability percentage; Chainabuse report counts are not a risk score.",
    safeNote: "No warnings does not mean this wallet is safe. Verify the recipient before sending funds.",
    riskNote: "Verify the recipient again and consider not sending funds to this address.",
    indicator: "GoPlus index",
    findings: "Signals found",
    officialWallet: "Official AndersPay+ deposit address. Balance and transaction history are hidden in the app.",
    openExplorer: "View on blockchain explorer",
  },
};

const signalNames: Record<string, { vi: string; en: string }> = {
  blacklist_doubt: { vi: "Địa chỉ bị nghi ngờ", en: "Suspected address" },
  mixer: { vi: "Liên quan dịch vụ trộn tiền", en: "Mixer activity" },
  fake_kyc: { vi: "KYC đáng ngờ", en: "Suspicious KYC" },
  malicious_mining_activities: { vi: "Hoạt động đào coin độc hại", en: "Malicious mining" },
  darkweb_transactions: { vi: "Giao dịch liên quan dark web", en: "Dark-web transactions" },
  honeypot_related_address: { vi: "Liên quan token bẫy", en: "Honeypot-related address" },
  fake_token: { vi: "Liên quan token giả", en: "Counterfeit token" },
  fake_standard_interface: { vi: "Hợp đồng có giao diện đáng ngờ", en: "Suspicious contract interface" },
  reinit: { vi: "Hợp đồng có thể khởi tạo lại", en: "Reinitializable contract" },
  gas_abuse: { vi: "Lạm dụng phí gas", en: "Gas fee abuse" },
  number_of_malicious_contracts_created: { vi: "Đã tạo hợp đồng độc hại", en: "Created malicious contracts" },
  blackmail_activities: { vi: "Liên quan hành vi tống tiền", en: "Blackmail activity" },
  cybercrime: { vi: "Liên quan tội phạm mạng", en: "Cybercrime activity" },
  financial_crime: { vi: "Liên quan tội phạm tài chính", en: "Financial crime" },
  money_laundering: { vi: "Cảnh báo rửa tiền", en: "Money laundering warning" },
  phishing_activities: { vi: "Liên quan lừa đảo phishing", en: "Phishing activity" },
  stealing_attack: { vi: "Liên quan hành vi đánh cắp", en: "Theft activity" },
  sanctioned: { vi: "Địa chỉ trong danh sách trừng phạt", en: "Sanctioned address" },
};

const networkOptions: { value: WalletRiskInput["network"]; label: string }[] = [
  { value: "bsc", label: "BEP20" },
  { value: "tron", label: "TRC20" },
  { value: "ethereum", label: "ERC20" },
];

function validAddress(network: WalletRiskInput["network"], address: string) {
  return network === "tron"
    ? /^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(address)
    : /^0x[a-fA-F0-9]{40}$/.test(address);
}

export default function WalletRiskChecker() {
  const { lang } = useLang();
  const { user, token } = useAuth();
  const text = lang === "vi" ? copy.vi : copy.en;
  const language = lang === "vi" ? "vi" : "en";
  const [network, setNetwork] = useState<WalletRiskInput["network"]>("bsc");
  const [address, setAddress] = useState("");
  const [validationError, setValidationError] = useState(false);
  const [report, setReport] = useState<WalletRiskReport | null>(null);
  const mutation = useCheckWalletRisk();
  const [requestError, setRequestError] = useState<"limit" | "unavailable" | null>(null);
  const requestVersion = useRef(0);

  function clearResult() {
    requestVersion.current += 1;
    setReport(null);
    setValidationError(false);
    setRequestError(null);
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!user || !token || mutation.isPending) return;
    clearResult();
    const trimmed = address.trim();
    if (!validAddress(network, trimmed)) {
      setValidationError(true);
      return;
    }
    const version = requestVersion.current;
    try {
      const result = await mutation.mutateAsync({ data: { network, address: trimmed } });
      if (version === requestVersion.current) setReport(result);
    } catch (error) {
      if (version === requestVersion.current) {
        setRequestError((error as { status?: number })?.status === 429 ? "limit" : "unavailable");
      }
    }
  }

  const goPlusLevel = report?.goplus.level ?? "no_flags";
  const danger = goPlusLevel === "critical" || goPlusLevel === "high";
  const warning = goPlusLevel === "caution";
  const tone = danger ? "text-red-400 border-red-500/30 bg-red-500/10"
    : warning ? "text-amber-300 border-amber-400/30 bg-amber-400/10"
      : "text-emerald-400 border-emerald-500/25 bg-emerald-500/10";
  const comparisonTone = report?.comparison === "disagreement"
    ? "border-amber-400/30 bg-amber-400/10 text-amber-200"
    : report?.comparison === "incomplete"
      ? "border-border bg-background/50 text-muted-foreground"
      : "border-emerald-500/25 bg-emerald-500/10 text-emerald-200";
  const isOfficialDepositAddress = report?.wallet.status === "hidden";
  const addressExplorer = report?.address === WALLET_ADDRESSES.TRC20
    ? "https://tronscan.org/#/address/"
    : report?.address.toLowerCase() === WALLET_ADDRESSES.BEP20.toLowerCase()
      ? "https://bscscan.com/address/"
      : "https://etherscan.io/address/";

  return (
    <section className="rounded-2xl border border-border bg-card p-4 shadow-sm" aria-labelledby="wallet-risk-title">
      <div className="mb-4 flex items-start gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-accent/30 bg-accent/10">
          <SearchCheck className="h-5 w-5 text-accent" aria-hidden="true" />
        </div>
        <div>
          <h2 id="wallet-risk-title" className="text-sm font-bold">{text.title}</h2>
          <p className="mt-0.5 text-xs text-muted-foreground">{text.subtitle}</p>
        </div>
      </div>
      <form onSubmit={submit} className="space-y-3">
        <fieldset disabled={!user || !token} className="space-y-3">
        <div className="grid grid-cols-3 gap-2" role="group" aria-label="Blockchain network">
          {networkOptions.map((option) => (
            <button
              key={option.value}
              type="button"
              aria-pressed={network === option.value}
              onClick={() => { setNetwork(option.value); clearResult(); }}
              className={`rounded-lg border px-2 py-2 text-xs font-semibold transition-colors ${
                network === option.value
                  ? "border-accent/50 bg-accent/15 text-accent"
                  : "border-border bg-background/50 text-muted-foreground hover:text-foreground"
              }`}
            >
              {option.label}
            </button>
          ))}
        </div>
        <div>
          <label htmlFor="wallet-risk-address" className="mb-1.5 block text-xs font-medium text-muted-foreground">
            {text.address}
          </label>
          <input
            id="wallet-risk-address"
            type="text"
            autoComplete="off"
            autoCapitalize="off"
            spellCheck={false}
            maxLength={90}
            placeholder={text.placeholder}
            value={address}
            onChange={(e) => { setAddress(e.target.value); clearResult(); }}
            aria-invalid={validationError}
            className="w-full rounded-xl border border-border bg-background px-3 py-3 font-mono text-xs text-foreground outline-none placeholder:font-sans placeholder:text-muted-foreground focus:border-accent"
          />
          {validationError && <p role="alert" className="mt-1.5 text-xs text-red-400">{text.invalid}</p>}
        </div>
        <button
          type="submit"
          disabled={!user || !token || mutation.isPending || !address.trim()}
          className="flex w-full items-center justify-center gap-2 rounded-xl bg-accent px-4 py-3 text-sm font-bold text-accent-foreground transition-colors hover:bg-accent/90 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {mutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />}
          {mutation.isPending ? text.checking : text.submit}
          {!mutation.isPending && <ArrowRight className="h-4 w-4" />}
        </button>
        </fieldset>
      </form>
      {(!user || !token) && (
        <p className="mt-3 text-xs text-muted-foreground" data-testid="wallet-risk-login-required">
          {lang === "vi" ? "Đăng nhập để sử dụng chức năng kiểm tra ví." : "Sign in to use the wallet checker."}
        </p>
      )}
      {requestError && (
        <p role="alert" className="mt-3 rounded-lg border border-red-500/20 bg-red-500/10 p-3 text-xs text-red-300">
          {text[requestError]}
        </p>
      )}
      {user && token && report && (
        <div aria-live="polite" className="mt-4 space-y-3 border-t border-border pt-4">
          {isOfficialDepositAddress ? (
            <div className="rounded-lg border border-accent/30 bg-accent/5 p-3 text-xs leading-relaxed text-foreground">
              <p><ShieldCheck className="mr-2 inline h-4 w-4 text-accent" aria-hidden="true" />{text.officialWallet}</p>
              <a href={`${addressExplorer}${report.address}`} target="_blank" rel="noopener noreferrer" className="mt-2 inline-block text-accent underline">
                {text.openExplorer} ↗
              </a>
            </div>
          ) : (
            <WalletOverviewCard network={report.network} wallet={report.wallet} address={report.address} lang={lang} />
          )}
          <p className={`rounded-lg border p-3 text-xs leading-relaxed ${comparisonTone}`}>
            {text[report.comparison]}
          </p>
          <section className="rounded-xl border border-border bg-background/40 p-3" aria-label="GoPlus Security result">
            <div className="mb-2 flex items-center justify-between gap-2">
              <a href="https://docs.gopluslabs.io/reference/malicious-address-api" target="_blank" rel="noopener noreferrer" className="text-xs font-bold text-accent underline">
                GoPlus Security
              </a>
              <span className="rounded-full border border-border px-2 py-0.5 text-[10px] text-muted-foreground">
                {text[report.goplus.status]}
              </span>
            </div>
            {report.goplus.status === "checked" ? (
              <>
                <div className={`flex items-center gap-2 rounded-lg border p-2.5 ${tone}`}>
                  {danger || warning ? <ShieldAlert className="h-4 w-4 shrink-0" /> : <CheckCircle2 className="h-4 w-4 shrink-0" />}
                  <p className="text-xs font-bold">{text[goPlusLevel]}</p>
                  {report.goplus.findings.length > 0 && report.goplus.score !== null && (
                    <span className="ml-auto shrink-0 text-[10px] font-bold">{text.indicator}: {report.goplus.score}/100</span>
                  )}
                </div>
                <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                  {goPlusLevel === "no_flags" ? text.safeNote : text.riskNote}
                </p>
                {report.goplus.findings.length > 0 && (
                  <div className="mt-3">
                    <p className="mb-1.5 text-[11px] font-semibold">{text.findings}</p>
                    <ul className="space-y-1.5">
                      {report.goplus.findings.map((finding) => (
                        <li key={finding.code} className="flex gap-2 text-xs text-muted-foreground">
                          <AlertTriangle className="mt-0.5 h-3 w-3 shrink-0 text-amber-400" />
                          {signalNames[finding.code]?.[language] ?? finding.code}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                <p className="mt-2 text-[10px] text-muted-foreground">
                  {new Date(report.goplus.checkedAt ?? report.checkedAt).toLocaleString(lang === "vi" ? "vi-VN" : "en-US")}
                </p>
              </>
            ) : (
              <p className="text-xs leading-relaxed text-muted-foreground">{text.sourceUnavailable}</p>
            )}
          </section>

          <section className="rounded-xl border border-border bg-background/40 p-3" aria-label="Chainabuse result">
            <div className="mb-2 flex items-center justify-between gap-2">
              <a href="https://docs.chainabuse.com/reference/getting-started" target="_blank" rel="noopener noreferrer" className="text-xs font-bold text-accent underline">
                Chainabuse
              </a>
              <span className="rounded-full border border-border px-2 py-0.5 text-[10px] text-muted-foreground">
                {text[report.chainabuse.status]}
              </span>
            </div>
            {report.chainabuse.status === "checked" ? (
              report.chainabuse.reportCount === null ? (
                <p className="text-xs leading-relaxed text-muted-foreground">{text.sourceUnavailable}</p>
              ) : report.chainabuse.reportCount === 0 ? (
                <p className="text-xs leading-relaxed text-muted-foreground">{text.noReports}</p>
              ) : (
                <>
                  <p className="mb-2 text-xs font-semibold">
                    {report.chainabuse.reportCount} {text.report}
                  </p>
                  <ul className="space-y-2">
                    {report.chainabuse.reports.map((item) => (
                      <li key={item.id} className="rounded-lg border border-border p-2.5">
                        <p className="text-xs font-medium">{item.category.replaceAll("_", " ")}</p>
                        <p className="mt-1 text-[10px] text-muted-foreground">
                          {text.communityReport} · {new Date(item.createdAt).toLocaleDateString(lang === "vi" ? "vi-VN" : "en-US")}
                        </p>
                        <p className="mt-1 text-[10px] text-muted-foreground">
                          {item.checked ? text.reviewed : text.unreviewed}
                          {item.trusted ? ` · ${text.trusted}` : ""}
                        </p>
                      </li>
                    ))}
                  </ul>
                </>
              )
            ) : report.chainabuse.status === "not_configured" ? (
              <p className="text-xs leading-relaxed text-muted-foreground">{text.notConfiguredNote}</p>
            ) : (
              <p className="text-xs leading-relaxed text-muted-foreground">{text.sourceUnavailable}</p>
            )}
            {report.chainabuse.checkedAt && (
              <p className="mt-2 text-[10px] text-muted-foreground">
                {new Date(report.chainabuse.checkedAt).toLocaleString(lang === "vi" ? "vi-VN" : "en-US")}
              </p>
            )}
          </section>
          <p className="text-[10px] leading-relaxed text-muted-foreground">{text.sourceDisclaimer}</p>
        </div>
      )}
    </section>
  );
}