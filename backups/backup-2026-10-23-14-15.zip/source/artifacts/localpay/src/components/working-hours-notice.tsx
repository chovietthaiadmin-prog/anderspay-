import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Clock, AlertTriangle } from "lucide-react";
import { useLang } from "@/lib/use-lang";
import {
  formatBangkokTime,
  isWithinWorkingHours,
  WORKING_HOURS_RANGE,
} from "@/lib/working-hours";

/**
 * Re-evaluates working-hours state once per minute so the banner /
 * pill flip naturally as the clock crosses 08:00 or 23:00 without a
 * page refresh.
 */
function useNowTick(intervalMs = 60_000): Date {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), intervalMs);
    return () => window.clearInterval(id);
  }, [intervalMs]);
  return now;
}

/**
 * Compact status pill. Green when inside business hours, amber when
 * outside. Safe to drop into any header row — fully responsive,
 * dark-mode aware, no layout side effects.
 */
export function WorkingHoursStatusPill({ className = "" }: { className?: string }) {
  const { t } = useLang();
  const now = useNowTick();
  const open = isWithinWorkingHours(now);
  const w = t.workingHours;
  return (
    <div
      className={[
        "inline-flex items-center gap-1.5 px-2 py-1 rounded-full border text-[10px] font-bold uppercase tracking-wider whitespace-nowrap",
        open
          ? "bg-green-500/10 border-green-500/40 text-green-400"
          : "bg-amber-500/10 border-amber-500/40 text-amber-300",
        className,
      ].join(" ")}
      title={`${WORKING_HOURS_RANGE} • ${formatBangkokTime(now)}`}
      role="status"
      aria-live="polite"
    >
      <span
        className={[
          "w-1.5 h-1.5 rounded-full",
          open ? "bg-green-400 animate-pulse" : "bg-amber-400",
        ].join(" ")}
      />
      {open ? w.statusOpen : w.statusClosed}
    </div>
  );
}

/**
 * Non-blocking warning banner that appears above order/payment/convert
 * forms only when the user is OUTSIDE business hours. Modern, soft
 * amber styling — not a destructive alert. Users can still submit; we
 * are only setting expectations about settlement speed.
 */
export function WorkingHoursWarningBanner({ className = "" }: { className?: string }) {
  const { t } = useLang();
  const now = useNowTick();
  if (isWithinWorkingHours(now)) return null;
  const w = t.workingHours;
  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -8 }}
        transition={{ duration: 0.2 }}
        className={[
          "rounded-xl border border-amber-500/40 bg-gradient-to-r from-amber-500/10 to-amber-500/5 px-3.5 py-3 flex items-start gap-2.5",
          className,
        ].join(" ")}
        role="alert"
      >
        <div className="w-8 h-8 rounded-full bg-amber-500/15 border border-amber-500/30 flex items-center justify-center shrink-0">
          <Clock className="w-4 h-4 text-amber-300" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 flex-wrap">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-300 shrink-0" />
            <p className="text-[12px] font-bold text-amber-200">
              {w.bannerTitle}
            </p>
            <span className="text-[10px] font-mono text-amber-300/80">
              {WORKING_HOURS_RANGE}
            </span>
          </div>
          <p className="text-[11px] text-amber-100/80 leading-relaxed mt-0.5">
            {w.bannerDesc}
          </p>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
