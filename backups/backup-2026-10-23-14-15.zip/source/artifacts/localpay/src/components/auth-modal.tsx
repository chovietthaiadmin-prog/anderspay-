import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, User, LogOut, Phone, Send, Copy, Check, AtSign, Mail, Pencil, Camera, Settings } from "lucide-react";
import { useRef } from "react";
import { useLocation } from "wouter";
import { useAuth, type TelegramLoginPayload } from "@/lib/auth";
import { useLang } from "@/lib/use-lang";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import TelegramLoginButton from "@/components/telegram-login-button";
import EmailAuth from "@/components/email-auth";
import TelegramStartNotice from "@/components/telegram-start-notice";

interface AuthModalProps {
  open: boolean;
  onClose: () => void;
}

export default function AuthModal({ open, onClose }: AuthModalProps) {
  const { user, loginWithTelegram, logout, updateNickname, updateAvatar } = useAuth();
  const [, setLocation] = useLocation();
  const { t } = useLang();
  const [authMethod, setAuthMethod] = useState<"chooser" | "telegram" | "email">("chooser");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showTelegramStartNotice, setShowTelegramStartNotice] = useState(false);
  const [copiedField, setCopiedField] = useState<"uid" | "phone" | null>(null);

  // Remember last auth method
  useEffect(() => {
    const saved = localStorage.getItem("ap-last-auth-method");
    if (saved === "telegram" || saved === "email") {
      setAuthMethod(saved);
    }
  }, []);

  const at = t.auth;

  const copyToClipboard = async (text: string, field: "uid" | "phone") => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedField(field);
      setTimeout(() => setCopiedField(null), 1500);
    } catch {
      // Clipboard may be blocked in some browsers — silently ignore.
    }
  };

  const reset = () => {
    setError(""); setLoading(false);
    setShowTelegramStartNotice(false);
    setAuthMethod("chooser");
  };

  const handleClose = () => { reset(); onClose(); };

  const handleMethodSelect = (method: "telegram" | "email") => {
    setAuthMethod(method);
    localStorage.setItem("ap-last-auth-method", method);
  };

  // One-click Telegram Login Widget
  const handleTelegramAuth = async (payload: TelegramLoginPayload) => {
    if (loading) return;
    setLoading(true); setError("");
    try {
      await loginWithTelegram(payload);
      setShowTelegramStartNotice(true);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : "";
      setError(msg || at.loginError);
    } finally {
      setLoading(false);
    }
  };

  // Two-step logout
  const [confirmingLogout, setConfirmingLogout] = useState(false);
  const handleLogout = () => { logout(); handleClose(); setConfirmingLogout(false); };

  // Inline profile editing
  const [editingNickname, setEditingNickname] = useState(false);
  const [nicknameDraft, setNicknameDraft] = useState("");
  const [nicknameLoading, setNicknameLoading] = useState(false);
  const [nicknameError, setNicknameError] = useState("");
  const [avatarUploading, setAvatarUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const startEditNickname = () => {
    setNicknameDraft(user?.nickname?.trim() || "");
    setNicknameError("");
    setEditingNickname(true);
  };
  const saveNickname = async () => {
    const trimmed = nicknameDraft.trim();
    if (!trimmed) { setNicknameError(at.nicknameRequired); return; }
    setNicknameLoading(true);
    try {
      await updateNickname(trimmed);
      setEditingNickname(false);
    } catch {
      setNicknameError(at.saveError);
    } finally {
      setNicknameLoading(false);
    }
  };
  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setAvatarUploading(true);
    try { await updateAvatar(file); } catch { /* silently ignore */ }
    finally { setAvatarUploading(false); if (fileInputRef.current) fileInputRef.current.value = ""; }
  };

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 z-50 backdrop-blur-sm"
            onClick={handleClose}
          />
          <motion.div
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ type: "spring", damping: 26, stiffness: 320 }}
            className="fixed inset-0 z-50 flex justify-center"
          >
            <div
              className="w-full max-w-[480px] bg-background h-full overflow-y-auto p-4 pb-12 flex flex-col"
              style={{ paddingTop: "calc(1rem + env(safe-area-inset-top))" }}
            >

              {/* Top bar */}
              <div className="flex items-center justify-between pt-8">
                {authMethod !== "chooser" && !user ? (
                  <button onClick={() => setAuthMethod("chooser")}
                    className="text-muted-foreground hover:text-foreground transition-colors text-sm font-medium">
                    {at.backToLogin}
                  </button>
                ) : (
                  <div className="w-10 h-1 bg-border rounded-full" />
                )}
                <button onClick={handleClose} className="text-muted-foreground hover:text-foreground transition-colors ml-auto">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 flex flex-col justify-center py-6">
              {user ? (
                /* ── Logged-in view: avatar, nickname, phone, UID ── */
                (() => {
                  const displayName = user.nickname?.trim() || user.name;
                  const avatarSrc = user.avatarUrl
                    ? (user.avatarUrl.startsWith("http") || user.avatarUrl.startsWith("data:")
                        ? user.avatarUrl
                        : `${import.meta.env.BASE_URL.replace(/\/$/, "")}${user.avatarUrl}`)
                    : null;
                  const publicUid = user.uid?.trim() || user.name;
                  return (
                    <div className="flex flex-col gap-5">
                      {showTelegramStartNotice && <TelegramStartNotice />}

                      {/* Avatar + name banner */}
                      <div className="flex flex-col items-center gap-3 pt-2">
                        <div className="relative">
                          <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-primary/40 shadow-lg shadow-primary/20 bg-primary/10 flex items-center justify-center">
                            {avatarUploading ? (
                              <div className="w-full h-full flex items-center justify-center bg-black/50">
                                <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                              </div>
                            ) : avatarSrc ? (
                              <img src={avatarSrc} alt={displayName} className="w-full h-full object-cover" />
                            ) : (
                              <span className="text-3xl font-bold text-primary uppercase">
                                {displayName.charAt(0)}
                              </span>
                            )}
                          </div>
                          <button
                            onClick={() => fileInputRef.current?.click()}
                            disabled={avatarUploading}
                            className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-primary border-2 border-background flex items-center justify-center shadow-md hover:bg-primary/90 transition-colors disabled:opacity-50"
                            title={t.settings.changeAvatar}
                          >
                            <Camera className="w-3.5 h-3.5 text-white" />
                          </button>
                          <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleAvatarChange} />
                        </div>
                        <div className="text-center">
                          <p className="font-bold text-xl leading-tight">{displayName}</p>
                          {user.nickname && user.nickname !== user.name && (
                            <p className="text-xs text-muted-foreground mt-0.5">{user.name}</p>
                          )}
                        </div>
                      </div>

                      {/* Info rows */}
                      <div className="flex flex-col gap-2">
                        {/* Nickname — inline editable */}
                        <div className="flex flex-col gap-1.5 p-3 rounded-xl bg-secondary/40 border border-border">
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-full bg-primary/15 flex items-center justify-center shrink-0">
                              <AtSign className="w-4 h-4 text-primary" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">{at.nicknameLabel}</p>
                              {editingNickname ? (
                                <Input
                                  value={nicknameDraft}
                                  onChange={(e) => setNicknameDraft(e.target.value)}
                                  className="h-7 text-sm px-1 py-0 bg-transparent border-0 border-b border-primary/50 rounded-none focus-visible:ring-0 mt-0.5"
                                  autoFocus
                                  onKeyDown={(e) => { if (e.key === "Enter") saveNickname(); if (e.key === "Escape") setEditingNickname(false); }}
                                />
                              ) : (
                                <p className="text-sm font-semibold truncate">{user.nickname?.trim() || <span className="text-muted-foreground font-normal italic">{at.noNickname}</span>}</p>
                              )}
                              {nicknameError && <p className="text-[10px] text-red-400 mt-0.5">{nicknameError}</p>}
                            </div>
                            {editingNickname ? (
                              <button onClick={saveNickname} disabled={nicknameLoading} className="shrink-0 text-[10px] font-bold text-primary hover:opacity-80 disabled:opacity-50 transition-opacity">
                                {nicknameLoading ? "..." : "✓"}
                              </button>
                            ) : (
                              <button onClick={startEditNickname} className="shrink-0 text-muted-foreground hover:text-primary transition-colors">
                                <Pencil className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>

                        {/* Phone */}
                        {user.phone && !user.phone.startsWith("tg:") && !user.phone.startsWith("em:") && (
                          <div className="flex items-center gap-3 p-3 rounded-xl bg-secondary/40 border border-border">
                            <div className="w-9 h-9 rounded-full bg-accent/15 flex items-center justify-center shrink-0">
                              <Phone className="w-4 h-4 text-accent" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">{at.phoneLabel}</p>
                              <p className="text-sm font-semibold font-mono">{user.phone}</p>
                            </div>
                            <button
                              onClick={() => copyToClipboard(user.phone ?? "", "phone")}
                              className="shrink-0 text-muted-foreground hover:text-primary transition-colors"
                              title={at.copy}
                            >
                              {copiedField === "phone" ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                            </button>
                          </div>
                        )}

                        {/* UID */}
                        <div className="flex items-center gap-3 p-3 rounded-xl bg-secondary/40 border border-border">
                          <div className="w-9 h-9 rounded-full bg-primary/15 flex items-center justify-center shrink-0">
                            <User className="w-4 h-4 text-primary" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">{at.uidLabel}</p>
                            <p className="text-sm font-semibold font-mono">{publicUid}</p>
                          </div>
                          <button
                            onClick={() => copyToClipboard(publicUid, "uid")}
                            className="shrink-0 text-muted-foreground hover:text-primary transition-colors"
                            title={at.copy}
                          >
                            {copiedField === "uid" ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>

                      {/* Settings shortcut */}
                      <button
                        onClick={() => { handleClose(); setLocation("/settings"); }}
                        className="flex items-center gap-2 p-3 rounded-xl border border-border text-sm text-muted-foreground hover:text-foreground hover:border-primary/40 transition-colors"
                      >
                        <Settings className="w-4 h-4" />
                        {at.goToSettings}
                      </button>

                      {/* Logout */}
                      {confirmingLogout ? (
                        <div className="flex flex-col gap-2 p-3 rounded-xl bg-red-500/10 border border-red-500/30">
                          <p className="text-sm font-semibold text-red-400">{at.logoutConfirmTitle}</p>
                          <p className="text-xs text-muted-foreground">{at.logoutConfirmDesc}</p>
                          <div className="flex gap-2 mt-1">
                            <Button size="sm" variant="destructive" className="flex-1 h-8 text-xs" onClick={handleLogout}>
                              {at.logoutConfirmYes}
                            </Button>
                            <Button size="sm" variant="outline" className="flex-1 h-8 text-xs" onClick={() => setConfirmingLogout(false)}>
                              {at.logoutConfirmCancel}
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <button
                          onClick={() => setConfirmingLogout(true)}
                          className="flex items-center justify-center gap-2 w-full py-3 rounded-xl border border-red-500/30 bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors text-sm font-semibold"
                        >
                          <LogOut className="w-4 h-4" />
                          {at.logout}
                        </button>
                      )}
                    </div>
                  );
                })()
              ) : authMethod === "chooser" ? (
                /* ── Auth method chooser ── */
                <div className="flex flex-col gap-4">
                  <div className="text-center">
                    <h2 className="font-bold text-lg">{at.methodChooser}</h2>
                    <p className="text-xs text-muted-foreground mt-1">{t.home.subtitle}</p>
                  </div>

                  <div className="flex flex-col gap-3">
                    <button
                      onClick={() => handleMethodSelect("telegram")}
                      className="flex items-center gap-3 p-4 rounded-xl bg-accent/10 border border-accent/30 hover:bg-accent/20 transition-colors group"
                    >
                      <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center shrink-0">
                        <Send className="w-5 h-5 text-accent" />
                      </div>
                      <div className="flex-1 text-left">
                        <p className="text-sm font-bold">{at.continueWithTelegram}</p>
                        <p className="text-xs text-muted-foreground">{at.telegramOtpHint}</p>
                      </div>
                    </button>

                    <button
                      onClick={() => handleMethodSelect("email")}
                      className="flex items-center gap-3 p-4 rounded-xl bg-primary/10 border border-primary/30 hover:bg-primary/20 transition-colors group"
                    >
                      <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
                        <Mail className="w-5 h-5 text-primary" />
                      </div>
                      <div className="flex-1 text-left">
                        <p className="text-sm font-bold">{at.continueWithEmail}</p>
                        <p className="text-xs text-muted-foreground">{at.emailOtpHint}</p>
                      </div>
                    </button>
                  </div>
                </div>
              ) : authMethod === "email" ? (
                /* ── Email auth flow ── */
                <EmailAuth
                  onSuccess={handleClose}
                  onBack={() => setAuthMethod("chooser")}
                />
              ) : (
                /* ── Direct Telegram Login Widget ── */
                <div className="flex flex-col gap-3">
                  <TelegramLoginButton
                    onAuth={handleTelegramAuth}
                    disabled={loading}
                    label={at.telegramOneClickLogin}
                  />
                  {error && (
                    <p className="text-xs text-red-400 text-center bg-red-500/10 py-2 px-3 rounded-lg">{error}</p>
                  )}
                </div>
              )}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
