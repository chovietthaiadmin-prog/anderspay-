import { useEffect, useState } from "react";
import { Gift, Copy, Share2, Users, Wallet, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/lib/auth";
import { useLang } from "@/lib/use-lang";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

interface ReferralInfo {
  uid?: string | null;
  referralRewardBalance: number;
  totalReferralEarned: number;
  referralCount: number;
  rewardPerReferral: number;
}

export default function ReferralCard() {
  const { token } = useAuth();
  const { t } = useLang();
  const r = t.referral;
  const [info, setInfo] = useState<ReferralInfo | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!token) return;
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(`${BASE}/api/referral/info`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) return;
        const data = (await res.json()) as ReferralInfo;
        if (!cancelled) setInfo(data);
      } catch {
        // best-effort — card will simply not render its stats
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [token]);

  if (!info) return null;
  const code = info.uid ?? null;

  const handleCopy = async () => {
    if (!code) return;
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // clipboard may be unavailable on insecure origins — silently ignore
    }
  };

  const handleShare = async () => {
    if (!code) return;
    const text = r.shareText.replace("{code}", code);
    if (typeof navigator !== "undefined" && "share" in navigator) {
      try {
        await navigator.share({ text });
        return;
      } catch {
        // user cancelled or share unsupported — fall through to copy
      }
    }
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* ignore */
    }
  };

  return (
    <div className="flex flex-col gap-3">
      <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">
        {r.sectionTitle}
      </p>
      <Card className="bg-card border-border overflow-hidden relative">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-accent to-primary opacity-70" />
        <CardContent className="p-4 flex flex-col gap-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
              <Gift className="w-4 h-4 text-accent" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold">{r.cardTitle}</p>
              <p className="text-xs text-muted-foreground">{r.cardDesc}</p>
            </div>
          </div>

          {code ? (
            <div className="flex flex-col gap-1.5">
              <p className="text-[11px] uppercase tracking-wider text-muted-foreground">
                {r.yourCodeLabel}
              </p>
              <div className="flex items-center gap-2 p-3 rounded-lg bg-secondary/40 border border-border">
                <span className="font-mono text-lg font-bold tracking-wider text-primary flex-1 allow-select">
                  {code}
                </span>
                <button
                  onClick={handleCopy}
                  className="h-9 px-3 rounded-md bg-secondary flex items-center gap-1.5 text-xs font-medium hover:bg-secondary/70 transition-colors"
                  aria-label="copy"
                >
                  <Copy className="w-3.5 h-3.5" />
                  {copied ? r.copied : r.copy}
                </button>
                <button
                  onClick={handleShare}
                  className="h-9 px-3 rounded-md bg-primary text-white flex items-center gap-1.5 text-xs font-bold hover:opacity-90 transition-opacity"
                  aria-label="share"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  {r.share}
                </button>
              </div>
            </div>
          ) : (
            <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/30">
              <p className="text-[11px] leading-relaxed text-yellow-200/90">{r.noUidYet}</p>
            </div>
          )}

          <div className="grid grid-cols-3 gap-2">
            <div className="p-2.5 rounded-lg bg-secondary/40 border border-border flex flex-col gap-1">
              <div className="flex items-center gap-1 text-muted-foreground">
                <Wallet className="w-3 h-3" />
                <span className="text-[10px] uppercase tracking-wider">{r.statsRewardBalance}</span>
              </div>
              <p className="text-sm font-bold text-accent">
                {info.referralRewardBalance.toFixed(2)}
                <span className="text-[10px] text-muted-foreground font-normal ml-1">USDT</span>
              </p>
            </div>
            <div className="p-2.5 rounded-lg bg-secondary/40 border border-border flex flex-col gap-1">
              <div className="flex items-center gap-1 text-muted-foreground">
                <TrendingUp className="w-3 h-3" />
                <span className="text-[10px] uppercase tracking-wider">{r.statsTotalEarned}</span>
              </div>
              <p className="text-sm font-bold text-foreground">
                {info.totalReferralEarned.toFixed(2)}
                <span className="text-[10px] text-muted-foreground font-normal ml-1">USDT</span>
              </p>
            </div>
            <div className="p-2.5 rounded-lg bg-secondary/40 border border-border flex flex-col gap-1">
              <div className="flex items-center gap-1 text-muted-foreground">
                <Users className="w-3 h-3" />
                <span className="text-[10px] uppercase tracking-wider">{r.statsCount}</span>
              </div>
              <p className="text-sm font-bold text-foreground">{info.referralCount}</p>
            </div>
          </div>

          <p className="text-[11px] leading-relaxed text-muted-foreground">{r.rewardHint}</p>
        </CardContent>
      </Card>
    </div>
  );
}
