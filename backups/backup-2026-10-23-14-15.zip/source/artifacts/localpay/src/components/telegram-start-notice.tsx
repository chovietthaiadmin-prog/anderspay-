import { ExternalLink, Send } from "lucide-react";
import { useLang } from "@/lib/use-lang";

export const TELEGRAM_BOT_URL = "https://t.me/AndersPayPlus_bot";

export default function TelegramStartNotice() {
  const { t } = useLang();
  const at = t.auth;

  return (
    <div className="flex flex-col gap-3 rounded-2xl border border-accent/40 bg-accent/10 p-4">
      <div className="flex items-start gap-3">
        <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-accent/20">
          <Send className="h-4 w-4 text-accent" />
        </div>
        <div className="min-w-0">
          <p className="text-sm font-bold">{at.telegramStartTitle}</p>
          <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
            {at.telegramStartDescription}
          </p>
        </div>
      </div>
      <a
        href={TELEGRAM_BOT_URL}
        target="_blank"
        rel="noreferrer"
        className="flex items-center justify-center gap-2 rounded-xl bg-accent px-3 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-accent/90"
      >
        {at.telegramStartButton}
        <ExternalLink className="h-3.5 w-3.5" />
      </a>
    </div>
  );
}