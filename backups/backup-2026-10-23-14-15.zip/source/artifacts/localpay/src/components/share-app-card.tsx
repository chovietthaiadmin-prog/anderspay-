import { useMemo, useRef, useState } from "react";
import { QRCodeCanvas } from "qrcode.react";
import { Card, CardContent } from "@/components/ui/card";
import { Copy, Check, Share2, Download, ExternalLink, Smartphone } from "lucide-react";
import { useLang } from "@/lib/use-lang";
import { useToast } from "@/hooks/use-toast";

// Share-app card: surfaces the public URL of this PWA together with a
// scannable QR code so an operator can hand a customer a single tap-or-
// scan target that opens AndersPay+ on their phone.
//
// The URL is derived from the live browser origin + Vite BASE_URL so it
// always matches whichever environment the operator is currently using
// (dev preview, custom domain, or `.replit.app`). No hard-coded host.
export default function ShareAppCard() {
  const { t } = useLang();
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  const qrWrapRef = useRef<HTMLDivElement>(null);
  const s = t.settings;

  const url = useMemo(() => {
    if (typeof window === "undefined") return "";
    const base = import.meta.env.BASE_URL || "/";
    const path = base.endsWith("/") ? base : `${base}/`;
    // Append ?install=1 so the InstallBanner auto-fires the native PWA
    // install prompt on Android Chrome as soon as the customer lands
    // (and shows the iOS "Add to Home Screen" hint with no delay on
    // Safari). See artifacts/localpay/src/components/install-banner.tsx.
    return `${window.location.origin}${path}?install=1`;
  }, []);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
      toast({ title: s.shareLinkCopied });
    } catch {
      toast({ title: s.shareCopyFailed, variant: "destructive" });
    }
  };

  const share = async () => {
    // Native share sheet on mobile lets the operator hand the link off
    // straight to Zalo / Telegram / Messages without leaving the app.
    if (navigator.share) {
      try {
        await navigator.share({ title: "AndersPay+", text: s.shareMessage, url });
      } catch {
        // User dismissed the share sheet — silently ignore.
      }
    } else {
      copy();
    }
  };

  const download = () => {
    // Pull the underlying <canvas> rendered by qrcode.react and turn it
    // into a downloadable PNG so the operator can paste it into chats
    // that don't accept links inline.
    const canvas = qrWrapRef.current?.querySelector("canvas");
    if (!canvas) return;
    const data = canvas.toDataURL("image/png");
    const a = document.createElement("a");
    a.href = data;
    a.download = "anderspay-qr.png";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="flex flex-col gap-3">
      <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">
        {s.shareSection}
      </p>
      <Card className="bg-card border-border overflow-hidden">
        <CardContent className="p-4 flex flex-col gap-4">
          {/* Header */}
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-full bg-primary/15 flex items-center justify-center shrink-0">
              <Smartphone className="w-4 h-4 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold">{s.shareTitle}</p>
              <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                {s.shareDesc}
              </p>
            </div>
          </div>

          {/* QR — wrapped in an <a> so a desktop click still opens the
              app, while a phone scan resolves the same URL. */}
          <div className="flex justify-center">
            <a
              href={url}
              target="_blank"
              rel="noopener noreferrer"
              ref={qrWrapRef as unknown as React.RefObject<HTMLAnchorElement>}
              className="bg-white p-3 rounded-2xl border-2 border-primary/30 hover:border-primary/60 transition-colors active:scale-95"
              title={s.shareQrTitle}
            >
              <QRCodeCanvas
                value={url}
                size={176}
                level="M"
                bgColor="#ffffff"
                fgColor="#0b0b0b"
              />
            </a>
          </div>

          {/* URL row */}
          <div className="flex items-center gap-2 p-2.5 rounded-xl bg-secondary/40 border border-border">
            <ExternalLink className="w-4 h-4 text-muted-foreground shrink-0" />
            <a
              href={url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 min-w-0 text-xs font-mono truncate text-foreground hover:text-primary transition-colors allow-select"
            >
              {url}
            </a>
            <button
              onClick={copy}
              className="w-8 h-8 rounded-md hover:bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors shrink-0"
              title={s.shareCopy}
            >
              {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>

          {/* Actions */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={share}
              className="flex items-center justify-center gap-2 h-10 rounded-lg bg-primary text-white text-sm font-semibold hover:bg-primary/90 transition-colors"
            >
              <Share2 className="w-4 h-4" />
              {s.shareBtn}
            </button>
            <button
              onClick={download}
              className="flex items-center justify-center gap-2 h-10 rounded-lg border border-border bg-secondary/40 text-foreground text-sm font-semibold hover:bg-secondary transition-colors"
            >
              <Download className="w-4 h-4" />
              {s.shareDownload}
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
