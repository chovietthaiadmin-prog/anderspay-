import { motion } from "framer-motion";
import { Globe, ShieldCheck, Zap, Wallet, Users, MessageCircle } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { useLang } from "@/lib/use-lang";

interface AboutDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function AboutDialog({ open, onOpenChange }: AboutDialogProps) {
  const { t } = useLang();
  const a = t.about;

  const features = [
    { icon: Zap, title: a.feat1Title, body: a.feat1Body },
    { icon: Wallet, title: a.feat2Title, body: a.feat2Body },
    { icon: ShieldCheck, title: a.feat3Title, body: a.feat3Body },
    { icon: Globe, title: a.feat4Title, body: a.feat4Body },
  ];

  const audiences = [
    { icon: Users, title: a.audience1Title, body: a.audience1Body },
    { icon: MessageCircle, title: a.audience2Title, body: a.audience2Body },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[440px] p-0 gap-0 bg-card border-border overflow-hidden max-h-[90dvh] overflow-y-auto">
        {/* Hero */}
        <div className="relative bg-gradient-to-br from-primary/15 via-primary/5 to-accent/10 px-6 pt-7 pb-5">
          <div className="absolute inset-0 opacity-[0.04] pointer-events-none" style={{ backgroundImage: "radial-gradient(circle at 20% 20%, white 1px, transparent 1px)", backgroundSize: "16px 16px" }} />
          <div className="relative flex items-center gap-3">
            <motion.img
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 18 }}
              src="/anderspay-logo.png"
              alt="AndersPay+"
              className="w-14 h-14 rounded-full object-cover shadow-lg shadow-primary/30 border border-primary/20"
            />
            <div className="flex-1 min-w-0">
              <DialogHeader className="space-y-0.5 text-left">
                <DialogTitle className="text-2xl font-bold tracking-tight text-primary leading-tight">
                  AndersPay<span className="text-accent">+</span>
                </DialogTitle>
                <DialogDescription className="text-[11px] uppercase tracking-widest text-muted-foreground font-semibold">
                  {a.tagline}
                </DialogDescription>
              </DialogHeader>
            </div>
          </div>

          <p className="relative mt-4 text-sm text-foreground/90 leading-relaxed">
            {a.intro}
          </p>
        </div>

        <Separator className="bg-border" />

        {/* Mission */}
        <div className="px-6 py-5">
          <p className="text-[10px] uppercase tracking-widest text-accent font-bold mb-2">
            {a.missionLabel}
          </p>
          <p className="text-sm text-foreground/85 leading-relaxed">{a.mission}</p>
        </div>

        <Separator className="bg-border" />

        {/* Features */}
        <div className="px-6 py-5">
          <p className="text-[10px] uppercase tracking-widest text-accent font-bold mb-3">
            {a.featuresLabel}
          </p>
          <div className="grid grid-cols-1 gap-2.5">
            {features.map(({ icon: Icon, title, body }, i) => (
              <motion.div
                key={title}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.05 * i }}
                className="flex items-start gap-3 p-3 rounded-xl bg-secondary/40 border border-border/50"
              >
                <div className="w-9 h-9 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
                  <Icon className="w-4 h-4 text-primary" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-bold leading-tight">{title}</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5 leading-snug">{body}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <Separator className="bg-border" />

        {/* Who is it for */}
        <div className="px-6 py-5">
          <p className="text-[10px] uppercase tracking-widest text-accent font-bold mb-3">
            {a.audienceLabel}
          </p>
          <div className="flex flex-col gap-2.5">
            {audiences.map(({ icon: Icon, title, body }) => (
              <div
                key={title}
                className="flex items-start gap-3 p-3 rounded-xl bg-gradient-to-br from-accent/5 to-transparent border border-accent/15"
              >
                <div className="w-9 h-9 rounded-lg bg-accent/10 border border-accent/20 flex items-center justify-center shrink-0">
                  <Icon className="w-4 h-4 text-accent" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-bold leading-tight">{title}</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5 leading-snug">{body}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <Separator className="bg-border" />

        {/* Footer */}
        <div className="px-6 py-4 bg-secondary/30 text-center">
          <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold">
            {a.footer}
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
