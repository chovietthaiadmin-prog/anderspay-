import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Hash, AlertTriangle, ShieldCheck, Loader2 } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { useLang } from "@/lib/use-lang";

// Forced, full-screen UID-creation gate. Renders whenever the
// authenticated user has no valid permanent UID (`^098\d{6}$`).
// There is no close button — the only way out is to successfully
// create a UID. The server enforces the same constraint via 409
// `uid_permanent` and rejects any malformed input, so a tampered
// client cannot bypass this screen.
export default function UidCreateGate() {
  const { user, token, setUid } = useAuth();
  const { t } = useLang();
  const [value, setValue] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!user || !token) return null;
  // Already permanent → nothing to do.
  if (user.uid && /^098\d{6}$/.test(user.uid)) return null;

  const at = t.settings;
  const valid = /^098\d{6}$/.test(value);

  const handleSubmit = async () => {
    if (!valid || submitting) return;
    setSubmitting(true);
    setError(null);
    try {
      await setUid(value);
      // On success the user object updates and this gate unmounts.
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : "";
      setError(
        msg === "uid_taken" ? at.uidTaken
        : msg === "uid_permanent" ? at.uidAlreadySet
        : msg === "invalid_uid" ? at.uidInvalid
        : at.uidError,
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="fixed inset-0 z-[100] bg-background/95 backdrop-blur-md flex items-start justify-center pt-20 overflow-y-auto px-4 pb-8"
        role="dialog"
        aria-modal="true"
      >
        <motion.div
          initial={{ opacity: 0, y: -20, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ type: "spring", damping: 26, stiffness: 320 }}
          className="w-full max-w-[440px] flex flex-col gap-5 rounded-2xl bg-card border border-border p-6 shadow-2xl shadow-primary/10"
        >
          {/* Header */}
          <div className="flex flex-col items-center gap-3 text-center">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/30">
              <Hash className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-foreground">{at.uidCreateTitle}</h2>
              <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                {at.uidCreateSubtitle}
              </p>
            </div>
          </div>

          {/* Permanence warning */}
          <div className="flex items-start gap-2.5 p-3 rounded-xl bg-red-500/10 border border-red-500/40">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <div className="flex-1 text-[12px] leading-relaxed text-red-100/90">
              <p className="font-bold text-red-300">{at.uidPermanentTitle}</p>
              <p className="mt-1">{at.uidPermanentDesc}</p>
            </div>
          </div>

          {/* Input */}
          <div className="flex flex-col gap-2">
            <label className="text-[11px] uppercase tracking-wider text-muted-foreground font-semibold">
              {at.uidLabel}
            </label>
            <div className="relative">
              <Hash className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                inputMode="numeric"
                autoFocus
                placeholder="098xxxxxx"
                value={value}
                onChange={(e) => setValue(e.target.value.replace(/\D/g, "").slice(0, 9))}
                onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
                maxLength={9}
                className="w-full h-12 pl-10 pr-3 rounded-xl bg-input border border-border text-foreground font-mono text-lg tracking-[0.2em] focus:outline-none focus:border-primary"
              />
            </div>
            <p className="text-[11px] text-muted-foreground">
              {at.uidDesc}
            </p>
            {value.length > 0 && !valid && (
              <p className="text-[11px] text-red-400 font-semibold">{at.uidInvalid}</p>
            )}
          </div>

          {error && (
            <div className="text-xs text-red-300 bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2 text-center font-semibold">
              {error}
            </div>
          )}

          <button
            type="button"
            onClick={handleSubmit}
            disabled={!valid || submitting}
            className="w-full h-12 rounded-xl bg-primary hover:bg-primary/90 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold text-sm flex items-center justify-center gap-2 transition-colors shadow-lg shadow-primary/20"
          >
            {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
            {submitting ? at.uidSaving : at.uidCreateBtn}
          </button>

          <p className="text-[10px] text-center text-muted-foreground leading-relaxed">
            {at.uidCreateFooter}
          </p>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
