import { lazy, Suspense, useEffect, useRef, useState } from "react";
import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import { LanguageProvider } from "@/lib/i18n";
import { useLang } from "@/lib/use-lang";
import { AuthProvider, useAuth } from "@/lib/auth";
import LockScreen from "@/components/lock-screen";
import UidCreateGate from "@/components/uid-create-gate";
import { isLockEnabled, isUnlocked } from "@/lib/security";
import NotFound from "@/pages/not-found";
import BottomNav from "@/components/bottom-nav";
import Fireworks from "@/components/fireworks";
import InstallBanner from "@/components/install-banner";
import OpenInChromeBanner from "@/components/open-in-chrome-banner";
import { ArrowDown } from "lucide-react";
import { BrandSpinner } from "@/components/brand-spinner";

// ── Route-level code splitting ─────────────────────────────────────────────
// Each page is a separate JS chunk loaded only when the user navigates to it.
// This cuts the initial bundle from ~4 MB down to only the Home chunk.
const Home         = lazy(() => import("@/pages/home"));
const Topup        = lazy(() => import("@/pages/topup"));
const Pay          = lazy(() => import("@/pages/pay"));
const WalletPage   = lazy(() => import("@/pages/wallet"));
const Status       = lazy(() => import("@/pages/status"));
const History      = lazy(() => import("@/pages/history"));
const Support      = lazy(() => import("@/pages/support"));
const Settings     = lazy(() => import("@/pages/settings"));
const AdminUsers   = lazy(() => import("@/pages/admin-users"));
const AdminHistory = lazy(() => import("@/pages/admin-history"));
const AdminBroadcast = lazy(() => import("@/pages/admin-broadcast"));
const AdminBackup  = lazy(() => import("@/pages/admin-backup"));
const Friends      = lazy(() => import("@/pages/friends"));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // 30 s before re-fetching cached data — reduces repeated API calls
      // while the user navigates between tabs. Critical live data (rates,
      // wallet balance) pass their own staleTime overrides.
      staleTime: 30_000,
      refetchOnWindowFocus: true,
    },
  },
});

const HIDE_NAV_PREFIXES = ["/status/", "/topup"];

// Pages reachable by left/right swipe (in order)
const SWIPE_PAGES = ["/", "/history", "/support", "/settings"];

const PULL_THRESHOLD = 72;
const HARD_THRESHOLD = 160;
const MAX_PULL = 200;

async function hardReload() {
  try {
    if ("serviceWorker" in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.map((r) => r.unregister()));
    }
    if (typeof caches !== "undefined") {
      const keys = await caches.keys();
      await Promise.all(keys.map((k) => caches.delete(k)));
    }
  } catch {
    // ignore
  }
  const url = new URL(window.location.href);
  url.searchParams.set("_r", String(Date.now()));
  window.location.replace(url.toString());
}

function PullToRefresh({ children }: { children: React.ReactNode }) {
  const [pullY, setPullY] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const [hardMode, setHardMode] = useState(false);
  const startY = useRef<number | null>(null);
  const pulling = useRef(false);

  useEffect(() => {
    const getScrollTop = () =>
      document.documentElement.scrollTop || document.body.scrollTop || window.scrollY;

    const onTouchStart = (e: TouchEvent) => {
      if (getScrollTop() === 0) {
        startY.current = e.touches[0].clientY;
        pulling.current = false;
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (startY.current === null) return;
      const dy = e.touches[0].clientY - startY.current;
      if (dy > 4 && getScrollTop() === 0) {
        pulling.current = true;
        const next = Math.min(dy * 0.5, MAX_PULL);
        setPullY(next);
        setHardMode(next >= HARD_THRESHOLD);
      } else if (dy <= 0) {
        startY.current = null;
        setPullY(0);
        setHardMode(false);
      }
    };

    const onTouchEnd = () => {
      if (pulling.current && !refreshing) {
        if (pullY >= HARD_THRESHOLD) {
          setRefreshing(true);
          setTimeout(() => { void hardReload(); }, 350);
        } else if (pullY >= PULL_THRESHOLD) {
          setRefreshing(true);
          setTimeout(() => window.location.reload(), 350);
        } else {
          setPullY(0);
          setHardMode(false);
        }
      } else {
        setPullY(0);
        setHardMode(false);
      }
      startY.current = null;
      pulling.current = false;
    };

    window.addEventListener("touchstart", onTouchStart, { passive: true });
    window.addEventListener("touchmove", onTouchMove, { passive: true });
    window.addEventListener("touchend", onTouchEnd, { passive: true });
    return () => {
      window.removeEventListener("touchstart", onTouchStart);
      window.removeEventListener("touchmove", onTouchMove);
      window.removeEventListener("touchend", onTouchEnd);
    };
  }, [pullY, refreshing]);

  const progress = Math.min(pullY / PULL_THRESHOLD, 1);
  const isTriggered = pullY >= PULL_THRESHOLD || refreshing;
  const indicatorY = pullY - 52;

  return (
    <>
      {/* Pull indicator — slides in from above */}
      <div
        className="fixed top-0 left-0 right-0 z-[100] flex flex-col items-center pointer-events-none"
        style={{
          transform: `translateY(${indicatorY}px)`,
          transition: pullY === 0 && !refreshing ? "transform 0.3s ease" : "none",
          opacity: progress,
        }}
      >
        <div
          className={`w-10 h-10 rounded-full border shadow-lg flex items-center justify-center mt-3 transition-colors ${
            hardMode ? "bg-primary border-primary" : "bg-card border-border"
          }`}
        >
          {isTriggered ? (
            <BrandSpinner size={20} className={hardMode ? "text-primary-foreground" : "text-primary"} />
          ) : (
            <ArrowDown
              className={`w-5 h-5 transition-transform ${hardMode ? "text-primary-foreground" : "text-primary"}`}
              style={{ transform: `rotate(${Math.min(progress, 1) * 180}deg)` }}
            />
          )}
        </div>
        {pullY > PULL_THRESHOLD * 0.6 && (
          <div
            className={`mt-2 px-2 py-0.5 rounded-full text-[10px] font-medium ${
              hardMode ? "bg-primary text-primary-foreground" : "bg-card/80 text-muted-foreground border border-border"
            }`}
          >
            {refreshing
              ? hardMode
                ? "Đang tải lại hoàn toàn…"
                : "Đang làm mới…"
              : hardMode
                ? "Thả để tải lại HOÀN TOÀN"
                : pullY >= PULL_THRESHOLD
                  ? "Thả để làm mới"
                  : "Kéo xuống để làm mới"}
          </div>
        )}
      </div>
      {children}
    </>
  );
}

function SwipeNavigator({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const touchStartX = useRef<number | null>(null);
  const touchStartY = useRef<number | null>(null);

  useEffect(() => {
    const handleTouchStart = (e: TouchEvent) => {
      touchStartX.current = e.touches[0].clientX;
      touchStartY.current = e.touches[0].clientY;
    };

    const handleTouchEnd = (e: TouchEvent) => {
      if (touchStartX.current === null || touchStartY.current === null) return;

      const dx = e.changedTouches[0].clientX - touchStartX.current;
      const dy = e.changedTouches[0].clientY - touchStartY.current;

      // Only handle clearly horizontal swipes (angle < 45°)
      if (Math.abs(dx) < 60 || Math.abs(dy) > Math.abs(dx)) {
        touchStartX.current = null;
        return;
      }

      // Only on swipeable pages
      const currentIdx = SWIPE_PAGES.indexOf(location);
      if (currentIdx === -1) {
        touchStartX.current = null;
        return;
      }

      if (dx < 0) {
        // Swipe left → next page
        const next = SWIPE_PAGES[currentIdx + 1];
        if (next) setLocation(next);
      } else {
        // Swipe right → previous page
        const prev = SWIPE_PAGES[currentIdx - 1];
        if (prev) setLocation(prev);
      }

      touchStartX.current = null;
    };

    window.addEventListener("touchstart", handleTouchStart, { passive: true });
    window.addEventListener("touchend", handleTouchEnd, { passive: true });
    return () => {
      window.removeEventListener("touchstart", handleTouchStart);
      window.removeEventListener("touchend", handleTouchEnd);
    };
  }, [location, setLocation]);

  return <>{children}</>;
}

function LockGate({ children }: { children: React.ReactNode }) {
  const { user, token } = useAuth();
  const [unlocked, setUnlocked] = useState(() => isUnlocked());
  const shouldLock = !!user && !!token && isLockEnabled() && !unlocked;
  if (shouldLock) return <LockScreen onUnlock={() => setUnlocked(true)} />;
  return <>{children}</>;
}

// Note: the previous once-per-session UID nag alert was replaced with
// the always-on `UidCreateGate` modal (see components/uid-create-gate).
// The new flow blocks the UI for any logged-in user whose `uid` does
// not match the permanent `^098\d{6}$` format, because the UID is now
// a one-time, non-revertible commitment.

function AppShell() {
  const [location] = useLocation();
  const hideNav = HIDE_NAV_PREFIXES.some((prefix) => location.startsWith(prefix));

  return (
    <PullToRefresh>
      <SwipeNavigator>
        <div className="min-h-[100dvh] w-full flex justify-center bg-background">
          <div className="w-full max-w-[480px] p-4 flex flex-col relative">
            {/* Suspense boundary: shows a spinner while a lazy page chunk loads */}
            <Suspense fallback={
              <div className="flex items-center justify-center min-h-[60dvh]">
                <BrandSpinner size={32} className="text-primary" />
              </div>
            }>
              <Switch>
                <Route path="/" component={Home} />
                <Route path="/topup" component={Topup} />
                <Route path="/pay" component={Pay} />
                <Route path="/wallet" component={WalletPage} />
                <Route path="/history" component={History} />
                <Route path="/support" component={Support} />
                <Route path="/settings" component={Settings} />
                <Route path="/admin/users" component={AdminUsers} />
                <Route path="/admin/history" component={AdminHistory} />
                <Route path="/admin/broadcast" component={AdminBroadcast} />
                <Route path="/admin/backup" component={AdminBackup} />
                <Route path="/friends" component={Friends} />
                <Route path="/status/:orderId" component={Status} />
                <Route component={NotFound} />
              </Switch>
            </Suspense>
          </div>
          {!hideNav && <BottomNav />}
          <Fireworks />
          <OpenInChromeBanner />
          <InstallBanner />
        </div>
      </SwipeNavigator>
    </PullToRefresh>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="dark" storageKey="anderspay-theme">
        <LanguageProvider>
          <AuthProvider>
            <TooltipProvider>
              <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
                <LockGate>
                  <UidCreateGate />
                  <AppShell />
                </LockGate>
              </WouterRouter>
              <Toaster />
            </TooltipProvider>
          </AuthProvider>
        </LanguageProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
