import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "path";
import { readFileSync } from "fs";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";

// Read the app version from package.json so the UI always shows the
// currently published version. Bump it via `pnpm bump:version` before
// each publish (see scripts/bump-localpay-version.mjs).
const pkgVersion = JSON.parse(
  readFileSync(path.resolve(import.meta.dirname, "package.json"), "utf-8"),
).version as string;

// PORT and BASE_PATH are required for `vite dev`, but not for `vite build`
// (the deployment build step doesn't inject services.env). Default both
// during build so the production build doesn't fail.
const isBuild = process.argv.includes("build");

const rawPort = process.env.PORT ?? (isBuild ? "5173" : undefined);

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const basePath = process.env.BASE_PATH ?? (isBuild ? "/" : undefined);

if (!basePath) {
  throw new Error(
    "BASE_PATH environment variable is required but was not provided.",
  );
}

export default defineConfig({
  base: basePath,
  define: {
    __APP_VERSION__: JSON.stringify(pkgVersion),
  },
  plugins: [
    react(),
    tailwindcss(),
    runtimeErrorOverlay(),
    ...(process.env.NODE_ENV !== "production" &&
    process.env.REPL_ID !== undefined
      ? [
          await import("@replit/vite-plugin-cartographer").then((m) =>
            m.cartographer({
              root: path.resolve(import.meta.dirname, ".."),
            }),
          ),
          await import("@replit/vite-plugin-dev-banner").then((m) =>
            m.devBanner(),
          ),
        ]
      : []),
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "src"),
      "@assets": path.resolve(import.meta.dirname, "..", "..", "attached_assets"),
    },
    dedupe: ["react", "react-dom"],
  },
  root: path.resolve(import.meta.dirname),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true,
    // Split vendor libraries into separate cacheable chunks so the browser
    // re-downloads only what changed between deploys.
    rollupOptions: {
      output: {
        manualChunks(id) {
          // React core — changes rarely, cache indefinitely
          if (id.includes("node_modules/react/") || id.includes("node_modules/react-dom/") || id.includes("node_modules/scheduler/")) {
            return "vendor-react";
          }
          // Animation library — large, rarely updated
          if (id.includes("node_modules/framer-motion/")) {
            return "vendor-framer-motion";
          }
          // Lucide icon set — large, rarely updated
          if (id.includes("node_modules/lucide-react/")) {
            return "vendor-lucide";
          }
          // Radix UI primitives (shadcn components)
          if (id.includes("node_modules/@radix-ui/")) {
            return "vendor-radix";
          }
          // Remaining node_modules
          if (id.includes("node_modules/")) {
            return "vendor";
          }
        },
      },
    },
  },
  server: {
    port,
    strictPort: true,
    host: "0.0.0.0",
    allowedHosts: true,
    fs: {
      strict: true,
    },
  },
  optimizeDeps: {
    include: ["jsqr"],
  },
  preview: {
    port,
    host: "0.0.0.0",
    allowedHosts: true,
  },
});
