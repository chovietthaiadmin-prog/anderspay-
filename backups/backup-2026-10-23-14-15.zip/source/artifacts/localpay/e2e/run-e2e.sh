#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ARTIFACT_DIR="$(dirname "$SCRIPT_DIR")"

# Playwright's bundled Chromium needs libgbm and libxkbcommon.
# Discover them at runtime from the Nix store (no hardcoded hash paths).
GBM_LIB=""
for d in /nix/store/*-mesa*/lib /nix/store/*-libgbm*/lib; do
  if [ -f "$d/libgbm.so.1" ]; then GBM_LIB="$d"; break; fi
done

XKB_LIB=""
for d in /nix/store/*-libxkbcommon-*/lib; do
  if [ -f "$d/libxkbcommon.so.0" ]; then XKB_LIB="$d"; break; fi
done

if [ -z "$GBM_LIB" ] || [ -z "$XKB_LIB" ]; then
  echo "ERROR: required Playwright Chromium libs not found in Nix store" >&2
  echo "  libgbm.so.1       : ${GBM_LIB:-NOT FOUND}" >&2
  echo "  libxkbcommon.so.0 : ${XKB_LIB:-NOT FOUND}" >&2
  exit 1
fi

export LD_LIBRARY_PATH="${GBM_LIB}:${XKB_LIB}${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"

cd "$ARTIFACT_DIR"
exec npx playwright test --config playwright.config.ts "$@"
