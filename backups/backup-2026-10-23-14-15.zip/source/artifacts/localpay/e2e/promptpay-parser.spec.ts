import { expect, test } from "@playwright/test";
import { parsePromPayQr } from "../src/lib/parse-promptpay-qr";

const KBANK_THAI_QR_PAYMENT =
  "00020101021129390016A000000677010111031500499913263747053037645802TH6304632C";

test.describe("Thai QR Payment parser", () => {
  test("accepts KBank PromptPay account QR references in sub-tag 03", () => {
    const parsed = parsePromPayQr(KBANK_THAI_QR_PAYMENT);

    expect(parsed).toMatchObject({
      promptPayId: "004999132637470",
      type: "unknown",
    });
  });

  test("rejects an EMVCo QR without a Thai QR payment AID", () => {
    const nonThaiPaymentQr =
      "00020101021129240016A0000000000000000104TEST53037645802TH6304ABCD";

    expect(parsePromPayQr(nonThaiPaymentQr)).toBeNull();
  });
});