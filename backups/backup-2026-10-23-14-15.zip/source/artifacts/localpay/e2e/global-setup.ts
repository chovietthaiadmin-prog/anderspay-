export default async function globalSetup() {
  // Readiness is handled by playwright.config.ts webServer (both the localpay
  // frontend and the API server). The QR scanner spec seeds a completed order
  // via the real API in its beforeAll hook and cleans up in afterAll — no
  // manual database setup is required.
}
