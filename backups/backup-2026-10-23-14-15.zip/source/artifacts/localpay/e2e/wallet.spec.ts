import { test, expect, request } from "@playwright/test";

/**
 * Wallet API smoke tests (request-fixture only — no browser launched).
 *
 * Verifies the public surface of the new wallet flow:
 *   - POST /api/orders accepts a valid payload (201 Created) — restored as the
 *     primary "Thanh toán" entry from the bottom nav
 *   - GET  /api/wallet requires auth (401 without bearer token)
 *   - POST /api/wallet/convert requires auth (401 without bearer token)
 *   - POST /api/wallet/convert validates input (400 VALIDATION_ERROR for negative amount;
 *     auth check still fires first, so we send a token-shaped header to reach the validator)
 *
 * Authenticated end-to-end behavior (atomic debit/credit, paired ledger
 * inserts, INSUFFICIENT_BALANCE on oversend) is covered separately by the
 * server-side smoke test that runs against a freshly issued JWT.
 */

const BASE = process.env.E2E_BASE_URL ?? "http://localhost:80";
const TEST_SECRET = process.env.TEST_API_SECRET ?? "";

// Sent on every test request so the server knows this is an e2e smoke run
// and skips fire-and-forget side-effects like the admin Telegram notification.
const TEST_HEADERS = TEST_SECRET ? { "x-test-secret": TEST_SECRET } : {};

test.describe("wallet API surface", () => {
  test("POST /api/orders accepts a valid payload (201 Created)", async () => {
    const ctx = await request.newContext({ baseURL: BASE });
    const res = await ctx.post("/api/orders", {
      headers: TEST_HEADERS,
      data: {
        amountUsdt: 1,
        bankName: "PromPay",
        accountNumber: "0812345678",
        accountName: "E2E Smoke",
      },
    });
    expect(res.status()).toBe(201);
    const body = await res.json();
    expect(typeof body.id).toBe("string");
    expect(typeof body.orderId).toBe("string");
    await ctx.dispose();
  });

  test("POST /api/orders rejects invalid payload (400 VALIDATION_ERROR)", async () => {
    const ctx = await request.newContext({ baseURL: BASE });
    const res = await ctx.post("/api/orders", { data: { amountUsdt: "nope" } });
    expect(res.status()).toBe(400);
    const body = await res.json();
    expect(body.code).toBe("VALIDATION_ERROR");
    await ctx.dispose();
  });

  test("GET /api/wallet without auth returns 401", async () => {
    const ctx = await request.newContext({ baseURL: BASE });
    const res = await ctx.get("/api/wallet");
    expect(res.status()).toBe(401);
    const body = await res.json();
    expect(body.code).toBe("UNAUTHORIZED");
    await ctx.dispose();
  });

  test("POST /api/wallet/convert without auth returns 401", async () => {
    const ctx = await request.newContext({ baseURL: BASE });
    const res = await ctx.post("/api/wallet/convert", { data: { amountUsdt: 1 } });
    expect(res.status()).toBe(401);
    const body = await res.json();
    expect(body.code).toBe("UNAUTHORIZED");
    await ctx.dispose();
  });
});
