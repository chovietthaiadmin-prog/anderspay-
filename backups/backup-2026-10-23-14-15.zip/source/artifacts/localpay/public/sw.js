// Minimal AndersPay+ service worker.
//
// Goal: satisfy Chrome / Edge PWA install criteria (a registered service worker
// with a fetch handler) so that the browser fires the `beforeinstallprompt`
// event. We deliberately do NOT cache anything — the app calls a live API and
// stale HTML/JS would cause confusing bugs. Network is always authoritative.

self.addEventListener("install", (event) => {
  event.waitUntil(self.skipWaiting());
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener("fetch", (event) => {
  // Pass through every request untouched. The mere presence of this
  // listener is what unlocks PWA install on Chromium-based browsers.
  event.respondWith(fetch(event.request));
});
