# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.
AndersPay+ — USDT→THB exchange fintech PWA. Dark theme (#0b0b0b, #ff3b3b red, #f5c542 gold). Mobile-first, bilingual EN/VI.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Frontend**: React + Vite, wouter, TanStack Query, framer-motion, shadcn/ui, Tailwind CSS

## Auth

- **Authentication**: Phone number + password (no email). JWT sessions via `Authorization: Bearer <token>`.
- **Registration**: name + phone + password + OTP (sent via Telegram bot).
- **Login**: phone + password.
- **Admin identification**: `ADMIN_PHONES` env var (comma-separated phone numbers with country codes).
- **Admin API access**: Admin-only endpoints (e.g. order confirm) accept either an admin JWT bearer token or an `X-Admin-Secret` header matching the `ADMIN_API_SECRET` env var.
- **OTP delivery**: Telegram bot (@AndersPayPlus_bot). Users link phone via `/otp +phone` command.
- **OTP table**: keyed by `phone` column (not email).
- **Users table**: `email` column is nullable/optional (user can add for security), `phone` is unique and required.
- **AuthUser interface**: `id, name, phone, email?, nickname?, avatarUrl?, isAdmin?`.
- **Optional email**: Users can add a recovery email in Settings → "Xác minh nâng cao" (Advanced Security) section. Not required for registration.
- **`useLang` hook**: import from `@/lib/use-lang`, NEVER from `@/lib/i18n`.

## User preferences

- **Modal/dialog placement**: Any modal that contains an input field (forms, key prompts, confirmations with text input) must open at the **top** of the screen, not bottom. The bottom tab bar covers part of the dialog otherwise. Use `flex items-start justify-center pt-20 overflow-y-auto` on the backdrop, not `items-end` / `items-center`.

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
