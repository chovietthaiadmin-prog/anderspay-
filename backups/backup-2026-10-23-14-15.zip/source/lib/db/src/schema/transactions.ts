import { pgTable, text, numeric, timestamp, pgEnum, index } from "drizzle-orm/pg-core";

export const transactionTypeEnum = pgEnum("transaction_type", [
  "deposit",
  "convert_out",
  "convert_in",
  "topup_fee",
  "payment_fee",
  "referral_reward",
  // Principal THB debit when an authenticated user creates a THB
  // payment order. Recorded alongside `payment_fee` so the user's
  // ledger shows the THB principal and USDT service fee separately.
  "payment",
  // Credit-back of a previously-debited `payment` (and its
  // accompanying `payment_fee`) when admin marks the order as
  // refunded via Telegram. One row per refunded order.
  "payment_refund",
  "payment_refund_reversal",
]);

export const transactionsTable = pgTable(
  "transactions",
  {
    id: text("id").primaryKey(),
    userId: text("user_id").notNull(),
    type: transactionTypeEnum("type").notNull(),
    amountUsdt: numeric("amount_usdt", { precision: 18, scale: 6 }).notNull().default("0"),
    // Portion of amountUsdt taken from / returned to referral rewards.
    // NULL means legacy accounting did not record the source; never guess it.
    referralAmountUsdt: numeric("referral_amount_usdt", { precision: 18, scale: 6 }),
    amountThb: numeric("amount_thb", { precision: 18, scale: 2 }).notNull().default("0"),
    rate: numeric("rate", { precision: 18, scale: 6 }).notNull(),
    refOrderId: text("ref_order_id"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    // Admin feed scans the table newest-first; the user history page
    // filters by user_id then sorts by created_at desc. These two
    // indexes turn both queries into bounded index reads instead of
    // seq scans as the ledger grows.
    index("transactions_created_at_idx").on(t.createdAt.desc()),
    index("transactions_user_created_idx").on(t.userId, t.createdAt.desc()),
  ],
);

export type Transaction = typeof transactionsTable.$inferSelect;
