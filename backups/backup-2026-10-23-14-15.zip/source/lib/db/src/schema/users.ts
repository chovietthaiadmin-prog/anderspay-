import { pgTable, text, boolean, timestamp, numeric, integer, uniqueIndex } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const usersTable = pgTable("users", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  // When the user has used their one-time legal-name edit. Null = still
  // editable. Set to current time on a successful PATCH /api/profile/name.
  nameUpdatedAt: timestamp("name_updated_at", { withTimezone: true }),
  email: text("email").default(""),
  // Email OTP auth: set once the user proves ownership of `email` via a
  // 6-digit emailed code. Only emailVerified accounts are matched during
  // email login (prevents account-confusion via unverified emails).
  emailVerified: boolean("email_verified").notNull().default(false),
  emailVerifiedAt: timestamp("email_verified_at", { withTimezone: true }),
  phone: text("phone").notNull().unique(),
  uid: text("uid").unique(),
  passwordHash: text("password_hash").notNull(),
  pinHash: text("pin_hash"),
  telegramChatId: text("telegram_chat_id"),
  // Telegram one-click login (Telegram Login Widget). Stable numeric
  // user id from Telegram — unique so the same Telegram account can
  // never produce two AndersPay+ users, and so renames of @username
  // never split an account. Username / first name / photo are cached
  // for display; they are refreshed on every successful login.
  telegramId: text("telegram_id").unique(),
  telegramUsername: text("telegram_username"),
  telegramFirstName: text("telegram_first_name"),
  telegramPhotoUrl: text("telegram_photo_url"),
  verified: boolean("verified").notNull().default(false),
  isAdmin: boolean("is_admin").notNull().default(false),
  nickname: text("nickname"),
  avatarUrl: text("avatar_url"),
  dob: text("dob"),
  usdtBalance: numeric("usdt_balance", { precision: 18, scale: 6 }).notNull().default("0"),
  thbBalance: numeric("thb_balance", { precision: 18, scale: 2 }).notNull().default("0"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  lastSeenAt: timestamp("last_seen_at", { withTimezone: true }),
  sessionId: text("session_id"),
  // Whether the user agrees to receive promotional broadcasts via the
  // Telegram bot. Defaults to true (opt-out model). "Important" system
  // broadcasts bypass this flag entirely.
  telegramOptIn: boolean("telegram_opt_in").notNull().default(true),
  // Granular Telegram notification prefs. OTP messages are always sent
  // regardless of these flags. Each defaults true (opt-out model).
  notifPayment: boolean("notif_payment").notNull().default(true),
  // Referral system. The user's own AndersPay UID (the `uid` column above)
  // doubles as the referral code — there is no separate referral_uid. When
  // a new user signs up with another user's UID in `referralCode`, we set
  // `referredBy` here to the referrer's `users.id` (immutable after signup),
  // and credit the referrer with a fixed reward (10 USDT) into
  // `referralRewardBalance`. The reward balance is spent first whenever the
  // user incurs a service fee (see artifacts/api-server/src/routes/orders.ts).
  // `totalReferralEarned` is the lifetime sum credited and never decreases;
  // `referralCount` is the number of users this user has referred.
  referredBy: text("referred_by"),
  referralRewardBalance: numeric("referral_reward_balance", { precision: 18, scale: 6 }).notNull().default("0"),
  totalReferralEarned: numeric("total_referral_earned", { precision: 18, scale: 6 }).notNull().default("0"),
  referralCount: integer("referral_count").notNull().default(0),
}, (t) => [
  // One verified email can only ever belong to one account. Enforced at
  // the DB level so concurrent email-verify / email-change requests
  // cannot race their app-level checks into duplicates.
  uniqueIndex("users_verified_email_unique")
    .on(t.email)
    .where(sql`${t.emailVerified} = true`),
]);

export type User = typeof usersTable.$inferSelect;
