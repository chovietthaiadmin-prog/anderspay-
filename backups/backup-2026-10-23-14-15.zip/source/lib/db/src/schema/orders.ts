import { pgTable, text, numeric, timestamp, pgEnum, index, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const orderStatusEnum = pgEnum("order_status", [
  "pending",
  "paid",
  "completed",
  "expired",
  "refunded",
]);

export const ordersTable = pgTable(
  "orders",
  {
    id: text("id").primaryKey(),
    orderId: text("order_id").notNull().unique(),
    amountThb: numeric("amount_thb", { precision: 18, scale: 2 }).notNull(),
    amountUsdt: numeric("amount_usdt", { precision: 18, scale: 6 }).notNull(),
    exchangeRate: numeric("exchange_rate", { precision: 18, scale: 6 }).notNull(),
    bankName: text("bank_name").notNull(),
    accountNumber: text("account_number").notNull(),
    accountName: text("account_name").notNull(),
    walletAddress: text("wallet_address").notNull(),
    status: orderStatusEnum("status").notNull().default("pending"),
    userId: text("user_id"),
    // Blockchain metadata for USDT top-up orders. These remain nullable until
    // a real chain indexer/admin supplies the value; never synthesize hashes
    // or confirmation counts.
    network: text("network"),
    txHash: text("tx_hash"),
    confirmations: integer("confirmations"),
    confirmedAt: timestamp("confirmed_at", { withTimezone: true }),
    // Source of THB used to fulfill a payment order. Set during the
    // Telegram admin confirmation flow, before the final confirmation.
    bahtSource: text("baht_source"),
    // Display name for the source. For "other", this is the partner name
    // entered by the admin; for fixed sources it is the standard label.
    bahtSourceName: text("baht_source_name"),
    reviewRequestedAt: timestamp("review_requested_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    // Admin transaction feed sorts orders newest-first; per-user
    // history pages filter by user_id then sort by created_at desc.
    index("orders_created_at_idx").on(t.createdAt.desc()),
    index("orders_user_created_idx").on(t.userId, t.createdAt.desc()),
  ],
);

export const insertOrderSchema = createInsertSchema(ordersTable).omit({
  createdAt: true,
  updatedAt: true,
});

export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof ordersTable.$inferSelect;
