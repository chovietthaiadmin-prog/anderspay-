import { pgTable, text, timestamp, pgEnum, uniqueIndex, index } from "drizzle-orm/pg-core";
import { randomUUID } from "crypto";

export const friendshipStatusEnum = pgEnum("friendship_status", [
  "pending",
  "accepted",
  "declined",
]);

export const friendshipsTable = pgTable(
  "friendships",
  {
    id: text("id")
      .primaryKey()
      .$defaultFn(() => randomUUID()),
    // The user who initiated the friend request.
    requesterId: text("requester_id").notNull(),
    // The user who received the request.
    receiverId: text("receiver_id").notNull(),
    status: friendshipStatusEnum("status").notNull().default("pending"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [
    index("friendships_requester_idx").on(t.requesterId),
    index("friendships_receiver_idx").on(t.receiverId),
    // Only one friendship record allowed per ordered pair. The API
    // enforces that the requester's id is always alphabetically ≤
    // the receiver's id before inserting, so the pair is canonical.
    uniqueIndex("friendships_pair_unique").on(t.requesterId, t.receiverId),
  ]
);

export type Friendship = typeof friendshipsTable.$inferSelect;
