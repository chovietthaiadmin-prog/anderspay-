import { pgTable, uuid, numeric, timestamp, index } from "drizzle-orm/pg-core";

// Append-only log of every THB/USDT rate value the admin sets. Used to
// build the hourly candlestick chart on the home screen. The current
// rate still lives in `settings`; this table is purely historical.
export const rateHistoryTable = pgTable(
  "rate_history",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    rate: numeric("rate", { precision: 18, scale: 6 }).notNull(),
    recordedAt: timestamp("recorded_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("rate_history_recorded_at_idx").on(t.recordedAt)],
);

export type RateHistory = typeof rateHistoryTable.$inferSelect;
