import { pgTable, text, integer, timestamp } from "drizzle-orm/pg-core";

// Audit log of admin-initiated mass Telegram broadcasts. One row per
// "send" action — captures who sent, what category (important vs
// promo), how many chats were targeted, and the success/failure
// breakdown so admins can audit reach over time.
export const broadcastsTable = pgTable("broadcasts", {
  id: text("id").primaryKey(),
  sentByUserId: text("sent_by_user_id").notNull(),
  sentByName: text("sent_by_name").notNull(),
  // "important" — bypasses opt-in (security/policy/system updates).
  // "promo"     — only sent to users with telegram_opt_in = true.
  kind: text("kind").notNull(),
  // "all" — every linked user. "users" — non-admin users only.
  // "self" — preview to the sender's own chat (not counted as broadcast).
  audience: text("audience").notNull(),
  body: text("body").notNull(),
  // Optional inline image, stored as a data: URL (base64) so it
  // survives redeploys without external object storage. Capped at
  // ~3 MB by the upload middleware.
  imageDataUrl: text("image_data_url"),
  total: integer("total").notNull().default(0),
  okCount: integer("ok_count").notNull().default(0),
  failCount: integer("fail_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Broadcast = typeof broadcastsTable.$inferSelect;
