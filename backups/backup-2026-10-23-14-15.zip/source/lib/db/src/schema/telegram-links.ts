import { pgTable, text, timestamp } from "drizzle-orm/pg-core";

// Stores Telegram chat IDs linked to phone numbers
// User links by sending /otp <phone> to the bot (e.g. /otp +66812345678)
export const telegramLinksTable = pgTable("telegram_links", {
  chatId: text("chat_id").primaryKey(),
  phone: text("phone").notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type TelegramLink = typeof telegramLinksTable.$inferSelect;
