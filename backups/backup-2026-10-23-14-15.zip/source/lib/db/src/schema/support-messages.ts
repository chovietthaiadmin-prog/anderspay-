import { pgTable, text, boolean, timestamp, index } from "drizzle-orm/pg-core";

export const supportMessagesTable = pgTable(
  "support_messages",
  {
    id: text("id").primaryKey(),
    // The customer/user this thread belongs to. Always the non-admin party,
    // even when the admin is the sender.
    userId: text("user_id").notNull(),
    fromAdmin: boolean("from_admin").notNull().default(false),
    body: text("body").notNull(),
    // Optional inline image, stored as a `data:<mime>;base64,...` URL
    // (same approach as user avatars — survives container restarts on
    // Replit's ephemeral disk and keeps the message self-contained).
    // When set, `body` may be empty and the UI renders the image.
    imageUrl: text("image_url"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    readByUser: boolean("read_by_user").notNull().default(false),
    readByAdmin: boolean("read_by_admin").notNull().default(false),
  },
  (table) => ({
    byUserCreated: index("support_msg_user_created_idx").on(
      table.userId,
      table.createdAt,
    ),
  }),
);

export type SupportMessage = typeof supportMessagesTable.$inferSelect;
