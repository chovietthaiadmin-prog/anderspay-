import { pgTable, text, timestamp, index } from "drizzle-orm/pg-core";
import { randomUUID } from "crypto";

/** How long a peer-to-peer chat message is visible (24 hours). */
export const FRIEND_MSG_TTL_MS = 24 * 60 * 60 * 1000;

/**
 * Ephemeral messages between two friends.
 * The server filters rows older than FRIEND_MSG_TTL_MS on every read
 * and prunes them on every write. No persistent history is kept.
 *
 * Either body or imageUrl (or both) must be non-null for a valid message.
 */
export const friendMessagesTable = pgTable(
  "friend_messages",
  {
    id: text("id")
      .primaryKey()
      .$defaultFn(() => randomUUID()),
    friendshipId: text("friendship_id").notNull(),
    senderId: text("sender_id").notNull(),
    /** Text content — nullable when message is image-only. */
    body: text("body"),
    /** Proxy URL for media attached to the message (served via API → OneDrive). */
    imageUrl: text("image_url"),
    /** MIME type of the attached media, e.g. "image/jpeg" or "video/mp4". */
    mediaMimeType: text("media_mime_type"),
    /** JSON array of user IDs who hid this message for themselves. */
    deletedForUserIds: text("deleted_for_user_ids").notNull().default("[]"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [
    index("friend_messages_friendship_created_idx").on(
      t.friendshipId,
      t.createdAt
    ),
  ]
);

export type FriendMessage = typeof friendMessagesTable.$inferSelect;
