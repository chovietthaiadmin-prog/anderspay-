import { pgTable, text, timestamp } from "drizzle-orm/pg-core";

export const notificationLogsTable = pgTable("notification_logs", {
  id: text("id").primaryKey(),
  // e.g. "admin_new_message" | "admin_spam_warning"
  type: text("type").notNull(),
  // userId or "guest:<uuid>" — nullable for system-level logs
  userId: text("user_id"),
  // Short excerpt of the triggering message (max 500 chars)
  message: text("message").notNull().default(""),
  // "sent" | "failed"
  telegramStatus: text("telegram_status").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type NotificationLog = typeof notificationLogsTable.$inferSelect;
