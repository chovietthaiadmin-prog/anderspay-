import { pgTable, text, integer, timestamp } from "drizzle-orm/pg-core";

export const webauthnCredentialsTable = pgTable("webauthn_credentials", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  credentialId: text("credential_id").notNull().unique(),
  publicKey: text("public_key").notNull(),
  counter: integer("counter").notNull().default(0),
  transports: text("transports"),
  name: text("name"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  lastUsedAt: timestamp("last_used_at", { withTimezone: true }),
});

export type WebauthnCredential = typeof webauthnCredentialsTable.$inferSelect;
