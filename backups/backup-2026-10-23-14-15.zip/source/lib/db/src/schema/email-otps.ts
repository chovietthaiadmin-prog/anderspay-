import { pgTable, text, integer, timestamp } from "drizzle-orm/pg-core";

// Email OTP codes for email-based login/registration and email-change
// verification. Only the SHA-256 hash of the code is stored. Rows are
// kept after use (marked via consumedAt) so per-email rate limits
// (5/hour, 20/day) can be computed from createdAt windows; a periodic
// cleanup can prune rows older than 48h.
export const emailOtpsTable = pgTable("email_otps", {
  id: text("id").primaryKey(),
  email: text("email").notNull(),
  // "auth" — login/registration. "change:<userId>" — email change for that user.
  purpose: text("purpose").notNull().default("auth"),
  otpHash: text("otp_hash").notNull(),
  attempts: integer("attempts").notNull().default(0),
  // Set when 5 wrong attempts hit — verification locked until this time.
  lockedUntil: timestamp("locked_until", { withTimezone: true }),
  consumedAt: timestamp("consumed_at", { withTimezone: true }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type EmailOtp = typeof emailOtpsTable.$inferSelect;
