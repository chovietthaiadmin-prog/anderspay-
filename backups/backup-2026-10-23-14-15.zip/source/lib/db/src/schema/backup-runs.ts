import { pgTable, text, timestamp, bigint, integer, index } from "drizzle-orm/pg-core";

// History of GitHub backup runs. Additive table — no existing schema is
// modified. Persisted in the DB (not on disk) because the production
// filesystem is ephemeral across deploys.
export const backupRunsTable = pgTable(
  "backup_runs",
  {
    id: text("id").primaryKey(),
    // "manual" | "daily" | "weekly"
    trigger: text("trigger").notNull(),
    // "running" | "success" | "failed"
    status: text("status").notNull().default("running"),
    // Zip archive size in bytes (null until archive built).
    sizeBytes: bigint("size_bytes", { mode: "number" }),
    fileCount: integer("file_count"),
    // GitHub commit SHA of the pushed backup (null on failure).
    commitSha: text("commit_sha"),
    branch: text("branch"),
    // Archive filename, e.g. backup-2026-07-07-10-30.zip
    fileName: text("file_name"),
    error: text("error"),
    durationMs: integer("duration_ms"),
    startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
    finishedAt: timestamp("finished_at", { withTimezone: true }),
  },
  (t) => [index("backup_runs_started_at_idx").on(t.startedAt.desc())],
);

export type BackupRun = typeof backupRunsTable.$inferSelect;
