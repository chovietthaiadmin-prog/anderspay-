import { pgTable, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";

// Admin-managed scrolling ad/announcement lines shown as a marquee at
// the top of the app (under the header, above the THB balance card).
// Each row is one line of text; tapping it opens `url` (optional).
export const announcementsTable = pgTable("announcements", {
  id: text("id").primaryKey(),
  text: text("text").notNull(),
  url: text("url"),
  active: boolean("active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Announcement = typeof announcementsTable.$inferSelect;
